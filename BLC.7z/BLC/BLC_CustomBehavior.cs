using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace BLC
{
    #region Enumeration
    public enum Enum_EntityNameFormat
    {
        FML,
        FLM,
        MFL,
        MLF,
        LFM,
        LMF
    }
    #endregion
    public partial class BLC
    {
        #region Members
        #endregion        
        #region Setup
        #region EditSetup
        #region EditSetup
        public void EditSetup(SetupEntry i_SetupEntry)
        {
            #region Declaration And Initialization Section.
            Tools.Tools oTools = new Tools.Tools();
            #endregion
            #region Environment Related Code Handling
            Params_GetEnvCode oParams_GetEnvCode = new Params_GetEnvCode();
            oParams_GetEnvCode.My_Environment = this.Environment;
            oParams_GetEnvCode.My_MethodName = "EditSetup";
            oParams_GetEnvCode.My_Type = typeof(BLC);
            MethodInfo oMethodInfo = EnvCode.GetEnvCode(oParams_GetEnvCode);
            if (oMethodInfo != null)
            {
                oMethodInfo.Invoke(this, new object[] { i_SetupEntry });
                return;
            }
            #endregion
            #region PreEvent_General
            if (OnPreEvent_General != null)
            {
                OnPreEvent_General("EditSetup");
            }
            #endregion
            #region Body Section.
            i_SetupEntry.ENTRY_USER_ID = this.UserID;
            i_SetupEntry.OWNER_ID = this.OwnerID;
            i_SetupEntry.ENTRY_DATE = oTools.GetDateString(DateTime.Today);
            _Tools.InvokeMethod(_AppContext, "UP_EDIT_SETUP", i_SetupEntry);
            #endregion
            #region PostEvent_General
            if (OnPostEvent_General != null)
            {
                OnPostEvent_General("EditSetup");
            }
            #endregion
        }
        #endregion
        #endregion
        #endregion
        #region Ticket
        #region ResolveTicket
        public Dictionary<string, string> ResolveTicket(string i_Input)
        {
            #region Declaration And Initialization Section.
            Dictionary<string, string> oList = new Dictionary<string, string>();
            string str_Ticket_PlainText = string.Empty;
            Crypto.Crypto oCrypto = new Crypto.Crypto();
            string[] oMainTempList = null;
            string[] oSubTempList = null;
            #endregion
            #region PreEvent_General
            if (OnPreEvent_General != null)
            {
                OnPreEvent_General("ResolveTicket");
            }
            #endregion
            #region Body Section.
            if (!string.IsNullOrEmpty(i_Input))
            {
                //str_Ticket_PlainText = oCrypto.Decrypt(i_Input, _KeySet);
                str_Ticket_PlainText = i_Input;

                if (!string.IsNullOrEmpty(str_Ticket_PlainText))
                {
                    oMainTempList = str_Ticket_PlainText.Split(new string[] { "[~!@]" }, StringSplitOptions.RemoveEmptyEntries);

                    var oQuery = from oItem in oMainTempList
                                 select oItem;

                    foreach (var oRow in oQuery)
                    {
                        oSubTempList = oRow.Split(new string[] { ":" }, StringSplitOptions.None);
                        oList.Add(oSubTempList[0], oSubTempList[1]);
                    }
                }
            }
            else
            {
                oList.Add("USER_ID", "1");
                oList.Add("OWNER_ID", "1");
            }
            #endregion
            #region PostEvent_General
            if (OnPostEvent_General != null)
            {
                OnPostEvent_General("ResolveTicket");
            }
            #endregion
            #region Return Section.
            return oList;
            #endregion
        }
        #endregion
        #region IsValidTicket
        public bool IsValidTicket(string i_Input)
        {
            #region Declaration And Initialization Section.
            bool Is_ValidTicket = false;
            long? i_MinutesElapsedSinceMidnight = 0;
            string str_CurrentDate = string.Empty;
            Tools.Tools oTools = new Tools.Tools();
            Dictionary<string, string> oTicketParts = new Dictionary<string, string>();
            #endregion
            #region Environment Related Code Handling
            Params_GetEnvCode oParams_GetEnvCode = new Params_GetEnvCode();
            oParams_GetEnvCode.My_Environment = this.Environment;
            oParams_GetEnvCode.My_MethodName = "IsValidTicket";
            oParams_GetEnvCode.My_Type = typeof(BLC);
            MethodInfo oMethodInfo = EnvCode.GetEnvCode(oParams_GetEnvCode);
            if (oMethodInfo != null)
            {
                return Convert.ToBoolean(oMethodInfo.Invoke(this, new object[] { i_Input }));
                // Intentially Left Empty.
            }
            #endregion
            #region PreEvent_General
            if (OnPreEvent_General != null)
            {
                OnPreEvent_General("IsValidTicket");
            }
            #endregion
            #region Body Section.
            try
            {
                oTicketParts = ResolveTicket(i_Input);
                str_CurrentDate = oTools.GetDateString(DateTime.Today);

                if (oTicketParts["START_DATE"] == str_CurrentDate) // Session Started In Different Day.
                {
                    i_MinutesElapsedSinceMidnight = (long?)(DateTime.Now - DateTime.Today).TotalMinutes;

                    if (i_MinutesElapsedSinceMidnight <= Convert.ToInt32(oTicketParts["START_MINUTE"]) + Convert.ToInt32(oTicketParts["SESSION_PERIOD"]))
                    {
                        Is_ValidTicket = true;
                    }
                }

            }
            catch (Exception ex)
            {
                Is_ValidTicket = false;
            }
            #endregion
            #region PostEvent_General
            if (OnPostEvent_General != null)
            {
                OnPostEvent_General("IsValidTicket");
            }
            #endregion
            #region Return Section.
            return Is_ValidTicket;
            #endregion
        }
        #endregion
        #endregion        

        public User Authenticate(Params_Authenticate i_Params_Authenticate)
        {
            Tools.Tools oTools = new Tools.Tools();
            User oUser = new User();
            User UsertoEdit = new User();
            Crypto.MiniCryptoHelper oCrypto = new Crypto.MiniCryptoHelper();

            List<dynamic> oList = _AppContext.UP_GET_USER_BY_USERNAME(i_Params_Authenticate.USERNAME);
            if ((oList != null) && (oList.Count > 0))
            {
                if (oCrypto.Encrypt(i_Params_Authenticate.PASSWORD) == oList[0].PASSWORD)
                {
                    // check if not already logged in
                    //if (oList[0].IS_LOGGED_IN != true)
                    //{
                    //    UsertoEdit.USER_ID = oList[0].USER_ID;
                    //    UsertoEdit.USERNAME = oList[0].USERNAME;
                    //    UsertoEdit.PASSWORD = oList[0].PASSWORD;
                    //    UsertoEdit.OWNER_ID = oList[0].OWNER_ID;
                    //    UsertoEdit.ENTRY_DATE = oList[0].ENTRY_DATE;
                    //    UsertoEdit.IS_ACTIVE = oList[0].IS_ACTIVE;
                    //    UsertoEdit.USER_TYPE_CODE = oList[0].USER_TYPE_CODE;
                    //    UsertoEdit.IS_LOGGED_IN = true;
                    oUser.USER_ID = oList[0].USER_ID;
                    oUser.OWNER_ID = oList[0].OWNER_ID;
                    oUser.USER_TYPE_CODE = oList[0].USER_TYPE_CODE;

                    var i_MinutesElapsedSinceMidnight = (long?)(DateTime.Now - DateTime.Today).TotalMinutes;
                    string My_Ticket_PlainText = string.Format("USER_ID:{0}[~!@]OWNER_ID:{1}[~!@]START_DATE:{2}[~!@]START_MINUTE:{3}[~!@]" +
                        "SESSION_PERIOD:{4}[~!@]", oUser.USER_ID, oUser.OWNER_ID, oTools.GetDateTimeString(DateTime.Today),
                        i_MinutesElapsedSinceMidnight.ToString(), 60);
                    string str_Enc_Ticket = oCrypto.Encrypt(My_Ticket_PlainText);
                    oUser.My_ticket = System.Net.WebUtility.UrlEncode(str_Enc_Ticket);
                    // oUser.My_ticket = System.Net.WebUtility.UrlEncode(str_Enc_Ticket);
                    // Edit_User(UsertoEdit);

                    // }
                    // if user already logged in throw exception
                    //else
                    //{
                    //    // user already logged in message
                    //    throw new BLCException(GetMessageContent(Enum_BR_Codes.BR_0010));
                    //}
                }
                else
                {
                    throw new BLCException(GetMessageContent(Enum_BR_Codes.BR_9999));
                }
            }
            else
            {
                throw new BLCException(GetMessageContent(Enum_BR_Codes.BR_0002));
            }
        



            return oUser;
        }
        #region De-Authenticate
        public User Deauthenticate(Params_Deauthenticate i_Params_Deauthenticate)
        {
            // Edit User ISLOGGED IN = false;

            Params_Get_User_By_USER_ID params_Get_User_By_USER_ID = new Params_Get_User_By_USER_ID();
            params_Get_User_By_USER_ID.USER_ID = i_Params_Deauthenticate.USER_ID;

            User oUser = Get_User_By_USER_ID(params_Get_User_By_USER_ID);
            oUser.IS_LOGGED_IN = false;
            Edit_User(oUser);
            return oUser;
        }

        #endregion

        #region Sign in Student
        public void Sign_in_Student(Params_Sign_in_Student i_Params_Sign_in_Student)
        {
            Crypto.MiniCryptoHelper oCrypto = new Crypto.MiniCryptoHelper();
            i_Params_Sign_in_Student.Sign_in_User = new User();
            i_Params_Sign_in_Student.Sign_in_Student = new Student();
            //Check if username does not exist before 
            List<dynamic> oList = _AppContext.UP_GET_USER_BY_USERNAME(i_Params_Sign_in_Student.Sign_in_User.USERNAME);
                if (oList.Count == 0)
            {
                //Create User
                User oUser = new User();
                
                oUser.USER_ID = -1;
                oUser.USERNAME = i_Params_Sign_in_Student.Sign_in_User.USERNAME;
                oUser.PASSWORD = oCrypto.Encrypt(i_Params_Sign_in_Student.Sign_in_User.PASSWORD);
                oUser.USER_TYPE_CODE = "003";
                oUser.IS_ACTIVE = true;
                oUser.IS_LOGGED_IN = false;
                oUser.OWNER_ID = this.OwnerID;

                Edit_User(oUser);

                // Create Student
                Params_Get_User_By_USERNAME params_Get_User_By_USERNAME = new Params_Get_User_By_USERNAME();
                params_Get_User_By_USERNAME.USERNAME = oUser.USERNAME;
               List<User> user = Get_User_By_USERNAME(params_Get_User_By_USERNAME);

                Student oStudent = new Student();
                oStudent.STUDENT_ID = -1;
                oStudent.USER_ID = Convert.ToInt32(user[0].USER_ID);
                oStudent.FIRST_NAME = i_Params_Sign_in_Student.Sign_in_Student.FIRST_NAME;
                oStudent.LAST_NAME = i_Params_Sign_in_Student.Sign_in_Student.LAST_NAME;
                oStudent.EMAIL = i_Params_Sign_in_Student.Sign_in_Student.EMAIL;
                oStudent.IS_BLOCKED = true;
                oStudent.PENDING_QUESTIONS = 0;
                oStudent.OWNER_ID = this.OwnerID;
                Edit_Student(oStudent);

                // Notification for BACK-OFFICE
                Notification oNote = new Notification();
                oNote.OWNER_ID = this.OwnerID;
                oNote.NOTIFICATION_ID = -1;
                oNote.USER_ID = 1;
                oNote.DESCRIPTION = String.Format("Student: {0} {1} have just Signed in. Please take necessary actions to unblock", oStudent.FIRST_NAME, oStudent.LAST_NAME);
                Edit_Notification(oNote);

            }
                else
            {
                throw new BLCException(GetMessageContent(Enum_BR_Codes.BR_0011));
            }

        }
        #endregion

        #region Sign in Teacher
        public void Sign_in_Teacher(Params_Sign_in_Teacher i_Params_Sign_in_Teacher)
        {
            Crypto.MiniCryptoHelper oCrypto = new Crypto.MiniCryptoHelper();
            i_Params_Sign_in_Teacher.Sign_in_User = new User();
            i_Params_Sign_in_Teacher.Sign_in_Teacher = new Teacher();
            //Check if username does not exist before 
            List<dynamic> oList = _AppContext.UP_GET_USER_BY_USERNAME(i_Params_Sign_in_Teacher.Sign_in_User.USERNAME);
            if (oList.Count == 0)
            {
                //Create User
                User oUser = new User();
                oUser.USER_ID = -1;
                oUser.USERNAME = i_Params_Sign_in_Teacher.Sign_in_User.USERNAME;
                oUser.PASSWORD = oCrypto.Encrypt(i_Params_Sign_in_Teacher.Sign_in_User.PASSWORD);
                oUser.USER_TYPE_CODE = "002";
                oUser.IS_ACTIVE = true;
                oUser.IS_LOGGED_IN = false;
                oUser.OWNER_ID = this.OwnerID;

                Edit_User(oUser);

                // Create Student
                Params_Get_User_By_USERNAME params_Get_User_By_USERNAME = new Params_Get_User_By_USERNAME();
                params_Get_User_By_USERNAME.USERNAME = oUser.USERNAME;
                List<User> user = Get_User_By_USERNAME(params_Get_User_By_USERNAME);

                Teacher oTeacher = new Teacher();
                oTeacher.TEACHER_ID = -1;
                oTeacher.USER_ID = Convert.ToInt32(user[0].USER_ID);
                oTeacher.FIRST_NAME = i_Params_Sign_in_Teacher.Sign_in_Teacher.FIRST_NAME;
                oTeacher.LAST_NAME = i_Params_Sign_in_Teacher.Sign_in_Teacher.LAST_NAME;
                oTeacher.EMAIL = i_Params_Sign_in_Teacher.Sign_in_Teacher.EMAIL;
                oTeacher.MOBILE = i_Params_Sign_in_Teacher.Sign_in_Teacher.MOBILE;
                oTeacher.SCORE = 0;
                oTeacher.IS_BLOCKED = true;
                oTeacher.OWNER_ID = this.OwnerID;
                Edit_Teacher(oTeacher);

                Params_Get_Teacher_By_USER_ID params_Get_Teacher_By_USER_ID = new Params_Get_Teacher_By_USER_ID();
                params_Get_Teacher_By_USER_ID.USER_ID =Convert.ToInt32(user[0].USER_ID);
                List<Teacher> teacher = Get_Teacher_By_USER_ID(params_Get_Teacher_By_USER_ID);
                 foreach(int Cat in i_Params_Sign_in_Teacher.Categories)
                {
                    Teacher_category tCat = new Teacher_category();
                    tCat.TEACHER_CATEGORY_ID = -1;
                    tCat.TEACHER_ID = teacher[0].TEACHER_ID;
                    tCat.CATEGORY_ID = Cat;
                    tCat.OWNER_ID = this.OwnerID;
                }
                // Notification for BACK-OFFICE
                Notification oNote = new Notification();
                oNote.OWNER_ID = this.OwnerID;
                oNote.NOTIFICATION_ID = -1;
                oNote.USER_ID = 1;
                oNote.DESCRIPTION = String.Format("Teacher: {0} {1} have just Signed in. Please take necessary actions to unblock", oTeacher.FIRST_NAME, oTeacher.LAST_NAME);
                Edit_Notification(oNote);
            }
            else
            {
                throw new BLCException(GetMessageContent(Enum_BR_Codes.BR_0011));
            }

        }
        #endregion

        #region DeactivateQuestion
        public void Deactivate_Question (Params_Deactivate_Question i_Params_Deactivate_Question)
        {
            Tools.Tools oTools = new Tools.Tools();
            //Get date now
            DateTime now = DateTime.Today;
            List<dynamic> oList = _AppContext.UP_GET_QUESTION_NOT_ANSWERED(i_Params_Deactivate_Question.Owner_ID);
            foreach(Question oQ in oList)
            {
                if(oQ.ENTRY_DATE.ToString() == "12")
                {
                    oTools.GetDate(oQ.ENTRY_DATE);
                }
            }


        }
        #endregion

        #region Question Token
        public List<string> Get_Question_Tokens (Question i_Question)
        {
            i_Question.DESCRIPTION = i_Question.DESCRIPTION.Replace(".", " ");
            i_Question.DESCRIPTION = i_Question.DESCRIPTION.Replace("/", " ");
            i_Question.DESCRIPTION = i_Question.DESCRIPTION.Replace("?", " ");
            i_Question.DESCRIPTION = i_Question.DESCRIPTION.Replace("!", " ");
            i_Question.DESCRIPTION = i_Question.DESCRIPTION.Replace(",", " ");
            i_Question.DESCRIPTION = i_Question.DESCRIPTION.Replace(":", " ");
            i_Question.DESCRIPTION = i_Question.DESCRIPTION.Replace(";", " ");
            //i_Question = i_Question.Replace(""", "");
            i_Question.DESCRIPTION = i_Question.DESCRIPTION.Replace("\"", " ");
            i_Question.DESCRIPTION = i_Question.DESCRIPTION.Replace("I", " ");
            i_Question.DESCRIPTION = i_Question.DESCRIPTION.Replace("and", " ");
            i_Question.DESCRIPTION = i_Question.DESCRIPTION.Replace("the", " ");
            i_Question.DESCRIPTION = i_Question.DESCRIPTION.Replace("on", " ");
            i_Question.DESCRIPTION = i_Question.DESCRIPTION.Replace("at", " ");
            i_Question.DESCRIPTION = i_Question.DESCRIPTION.Replace("in", " ");
            i_Question.DESCRIPTION = i_Question.DESCRIPTION.Replace("of", " ");
            i_Question.DESCRIPTION = i_Question.DESCRIPTION.Replace("to", " ");
            List<String> oList_Tokens = i_Question.DESCRIPTION.Split(' ').ToList();
            if (oList_Tokens != null)
            {
                foreach (var o_Row in oList_Tokens)
                {
                    Question_token oQuestion_Token = new Question_token();
                    oQuestion_Token.QUESTION_TOKEN_ID = -1;
                    oQuestion_Token.QUESTION_ID = i_Question.QUESTION_ID;
                    oQuestion_Token.PART = o_Row;
                    Edit_Question_token(oQuestion_Token);
                }
                return oList_Tokens;
            }
            else
            {
                return null;
            }
        }
        #endregion 

        public List<Question> Get_Similar_Question(Params_Get_Similar_Question i_Params_Get_Similar_Question)
        {
            Params_Get_Question_By_OWNER_ID params_Get_Question_By_OWNER_ID = new Params_Get_Question_By_OWNER_ID();
            params_Get_Question_By_OWNER_ID.OWNER_ID = this.OwnerID;
            List<Question> oQList = Get_Question_By_OWNER_ID(params_Get_Question_By_OWNER_ID);
            List<Question> Similar_Question_List = new List<Question>();

            if (oQList != null)
            {
                foreach (Question question in oQList)
                {
                    List<string> Parts_in_DB = Get_Question_Tokens(question);
                    List<string> Parts_Asked = Get_Question_Tokens(i_Params_Get_Similar_Question.Asked_Question);
                    if ((((double)Parts_in_DB.Intersect(Parts_Asked).Count()) / ((double)Parts_Asked.Count())) >= 0.7)
                    {
                        Similar_Question_List.Add(question);

                    }
                }

                return Similar_Question_List;
            }

            else
            {
                return null;
            }



        }


        #region
        public List<Favorite_category> Student_Fav_Category(Params_Student_Fav_Category i_Params_Student_Fav_Category)
        {
            Params_Get_Student_By_USER_ID params_Get_Student_By_USER_ID = new Params_Get_Student_By_USER_ID();
            params_Get_Student_By_USER_ID.USER_ID =  Convert.ToInt32(this.UserID);
            List<Student> oStudentList = Get_Student_By_USER_ID(params_Get_Student_By_USER_ID);
            List<Favorite_category> oFavCatList = new List<Favorite_category>();
            if (oStudentList.Count > 0)
            {
                foreach (Int32 item in i_Params_Student_Fav_Category.CatList)
                {
                    Favorite_category oFavCat = new Favorite_category();
                    oFavCat.FAVORITE_CATEGORY_ID = -1;
                    oFavCat.CATEGORY_ID = item;
                    oFavCat.OWNER_ID = this.OwnerID;
                    oFavCat.STUDENT_ID = oStudentList[0].STUDENT_ID;
                    Edit_Favorite_category(oFavCat);
                    oFavCatList.Add(oFavCat);
                }
                return oFavCatList;
            }
            else
            {
                return null;
            }

          


        }
        #endregion
    }



    #region Params Sign in Student
    public class Params_Sign_in_Student
    {
        public Student Sign_in_Student { get; set; }
        public User Sign_in_User { get; set; }
    }
    #endregion
    #region
    public class Params_Student_Fav_Category
    {
        public List<Int32?> CatList { get; set; }
    }
    #endregion
    #region Params Sign in Teacher
    public class Params_Sign_in_Teacher
    {
        public Teacher Sign_in_Teacher { get; set; }
        public User Sign_in_User { get; set; }

        public List<Int32?> Categories { get; set; }
    }
    #endregion
    #region Params Authenticate
    public class Params_Authenticate
    {
        public string USERNAME { get; set; }
        public string PASSWORD { get; set; }
    }
    #endregion
    #region Params_Deauthenticate

    public class Params_Deauthenticate
    {
        public int USER_ID { get; set; }
    }
    #endregion
    #region Params_Deactivate_Question
    public class Params_Deactivate_Question
    {
        public Int32? Owner_ID { get; set; }
    }
    #endregion
    #region Params_Get_Similar_Question
    public class Params_Get_Similar_Question
    {
        public Question Asked_Question { get; set; }
    }
    #endregion



    public partial class User
    {
        public string My_ticket { get; set; }
    }

    public partial class Notification
    {

        public User My_User { get; set; }
    }

    public partial class Student
    {
        public User My_User { get; set; }
    }

    public partial class Teacher
    {
        public User My_User { get; set; }
    }

    public partial class Question_token
    {
        public Question My_Question { get; set; }
    }

    public partial class Student_report
    {
        public Student My_Reported_by_student { get; set; }
    }

    public partial class Student_report
    {
        public Student My_Reported_student { get; set; }
    }
    #region Business Entities
    #region Setup
    #region SetupEntry
    public class SetupEntry
    {
        #region Properties
        public Int32? OWNER_ID { get; set; }
        public string TBL_NAME { get; set; }
        public string CODE_NAME { get; set; }
        public bool? ISSYSTEM { get; set; }
        public bool? ISDELETEABLE { get; set; }
        public bool? ISUPDATEABLE { get; set; }
        public bool? ISVISIBLE { get; set; }
        public bool? ISDELETED { get; set; }
        public Int32? DISPLAY_ORDER { get; set; }
        public string CODE_VALUE_EN { get; set; }
        public string CODE_VALUE_FR { get; set; }
        public string CODE_VALUE_AR { get; set; }
        public string ENTRY_DATE { get; set; }
        public long? ENTRY_USER_ID { get; set; }
        public string NOTES { get; set; }

        public string INVARIANT_VALUE { get; set; }
        #endregion
    }
    #endregion
    #endregion
    #region Uploaded_file
    public partial class Uploaded_file
    {
        public string My_URL { get; set; }
    }
    #endregion
    #endregion

}







