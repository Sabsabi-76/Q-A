using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;
using System.Configuration;
using DALC;
//using System.Data.Linq;
using System.Text.RegularExpressions;
using System.Transactions;
using System.Reflection;
using System.Diagnostics;
using System.Data.SqlClient;
using System.Threading;







namespace BLC
{
public partial class BLC
{
#region Members
#region Used For Delete Operations
private Answer _Answer;
private Answer_report _Answer_report;
private Appreciate _Appreciate;
private Article _Article;
private Category _Category;
private Evaluation _Evaluation;
private Favorite_category _Favorite_category;
private Favorite_teacher _Favorite_teacher;
private Mark_question _Mark_question;
private Notification _Notification;
private Owner _Owner;
private Question _Question;
private Question_report _Question_report;
private Question_token _Question_token;
private Report_article _Report_article;
private Student _Student;
private Student_report _Student_report;
private Teacher _Teacher;
private Teacher_category _Teacher_category;
private Teacher_favorite _Teacher_favorite;
private Teacher_rank _Teacher_rank;
private Teacher_report _Teacher_report;
private User _User;
#endregion
#region Stop Executing Flags For Edit and Delete Operations
private bool _Stop_Edit_Answer_Execution;
private bool _Stop_Delete_Answer_Execution;
private bool _Stop_Edit_Answer_report_Execution;
private bool _Stop_Delete_Answer_report_Execution;
private bool _Stop_Edit_Appreciate_Execution;
private bool _Stop_Delete_Appreciate_Execution;
private bool _Stop_Edit_Article_Execution;
private bool _Stop_Delete_Article_Execution;
private bool _Stop_Edit_Category_Execution;
private bool _Stop_Delete_Category_Execution;
private bool _Stop_Edit_Evaluation_Execution;
private bool _Stop_Delete_Evaluation_Execution;
private bool _Stop_Edit_Favorite_category_Execution;
private bool _Stop_Delete_Favorite_category_Execution;
private bool _Stop_Edit_Favorite_teacher_Execution;
private bool _Stop_Delete_Favorite_teacher_Execution;
private bool _Stop_Edit_Mark_question_Execution;
private bool _Stop_Delete_Mark_question_Execution;
private bool _Stop_Edit_Notification_Execution;
private bool _Stop_Delete_Notification_Execution;
private bool _Stop_Edit_Owner_Execution;
private bool _Stop_Delete_Owner_Execution;
private bool _Stop_Edit_Question_Execution;
private bool _Stop_Delete_Question_Execution;
private bool _Stop_Edit_Question_report_Execution;
private bool _Stop_Delete_Question_report_Execution;
private bool _Stop_Edit_Question_token_Execution;
private bool _Stop_Delete_Question_token_Execution;
private bool _Stop_Edit_Report_article_Execution;
private bool _Stop_Delete_Report_article_Execution;
private bool _Stop_Edit_Student_Execution;
private bool _Stop_Delete_Student_Execution;
private bool _Stop_Edit_Student_report_Execution;
private bool _Stop_Delete_Student_report_Execution;
private bool _Stop_Edit_Teacher_Execution;
private bool _Stop_Delete_Teacher_Execution;
private bool _Stop_Edit_Teacher_category_Execution;
private bool _Stop_Delete_Teacher_category_Execution;
private bool _Stop_Edit_Teacher_favorite_Execution;
private bool _Stop_Delete_Teacher_favorite_Execution;
private bool _Stop_Edit_Teacher_rank_Execution;
private bool _Stop_Delete_Teacher_rank_Execution;
private bool _Stop_Edit_Teacher_report_Execution;
private bool _Stop_Delete_Teacher_report_Execution;
private bool _Stop_Edit_User_Execution;
private bool _Stop_Delete_User_Execution;
#endregion
#endregion
public Answer Get_Answer_By_ANSWER_ID(Params_Get_Answer_By_ANSWER_ID i_Params_Get_Answer_By_ANSWER_ID)
{
Answer oAnswer = null;
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Answer_By_ANSWER_ID");}
#region Body Section.
DALC.Answer oDBEntry = _AppContext.Get_Answer_By_ANSWER_ID(i_Params_Get_Answer_By_ANSWER_ID.ANSWER_ID);
oAnswer = new Answer();
oTools.CopyPropValues(oDBEntry, oAnswer);
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Answer_By_ANSWER_ID");}
return oAnswer;
}
public Answer_report Get_Answer_report_By_ANSWER_REPORT_ID(Params_Get_Answer_report_By_ANSWER_REPORT_ID i_Params_Get_Answer_report_By_ANSWER_REPORT_ID)
{
Answer_report oAnswer_report = null;
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Answer_report_By_ANSWER_REPORT_ID");}
#region Body Section.
DALC.Answer_report oDBEntry = _AppContext.Get_Answer_report_By_ANSWER_REPORT_ID(i_Params_Get_Answer_report_By_ANSWER_REPORT_ID.ANSWER_REPORT_ID);
oAnswer_report = new Answer_report();
oTools.CopyPropValues(oDBEntry, oAnswer_report);
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Answer_report_By_ANSWER_REPORT_ID");}
return oAnswer_report;
}
public Appreciate Get_Appreciate_By_APPRECIATE_ID(Params_Get_Appreciate_By_APPRECIATE_ID i_Params_Get_Appreciate_By_APPRECIATE_ID)
{
Appreciate oAppreciate = null;
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Appreciate_By_APPRECIATE_ID");}
#region Body Section.
DALC.Appreciate oDBEntry = _AppContext.Get_Appreciate_By_APPRECIATE_ID(i_Params_Get_Appreciate_By_APPRECIATE_ID.APPRECIATE_ID);
oAppreciate = new Appreciate();
oTools.CopyPropValues(oDBEntry, oAppreciate);
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Appreciate_By_APPRECIATE_ID");}
return oAppreciate;
}
public Article Get_Article_By_ARTICLE_ID(Params_Get_Article_By_ARTICLE_ID i_Params_Get_Article_By_ARTICLE_ID)
{
Article oArticle = null;
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Article_By_ARTICLE_ID");}
#region Body Section.
DALC.Article oDBEntry = _AppContext.Get_Article_By_ARTICLE_ID(i_Params_Get_Article_By_ARTICLE_ID.ARTICLE_ID);
oArticle = new Article();
oTools.CopyPropValues(oDBEntry, oArticle);
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Article_By_ARTICLE_ID");}
return oArticle;
}
public Category Get_Category_By_CATEGORY_ID(Params_Get_Category_By_CATEGORY_ID i_Params_Get_Category_By_CATEGORY_ID)
{
Category oCategory = null;
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Category_By_CATEGORY_ID");}
#region Body Section.
DALC.Category oDBEntry = _AppContext.Get_Category_By_CATEGORY_ID(i_Params_Get_Category_By_CATEGORY_ID.CATEGORY_ID);
oCategory = new Category();
oTools.CopyPropValues(oDBEntry, oCategory);
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Category_By_CATEGORY_ID");}
return oCategory;
}
public Evaluation Get_Evaluation_By_EVALUATION_ID(Params_Get_Evaluation_By_EVALUATION_ID i_Params_Get_Evaluation_By_EVALUATION_ID)
{
Evaluation oEvaluation = null;
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Evaluation_By_EVALUATION_ID");}
#region Body Section.
DALC.Evaluation oDBEntry = _AppContext.Get_Evaluation_By_EVALUATION_ID(i_Params_Get_Evaluation_By_EVALUATION_ID.EVALUATION_ID);
oEvaluation = new Evaluation();
oTools.CopyPropValues(oDBEntry, oEvaluation);
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Evaluation_By_EVALUATION_ID");}
return oEvaluation;
}
public Favorite_category Get_Favorite_category_By_FAVORITE_CATEGORY_ID(Params_Get_Favorite_category_By_FAVORITE_CATEGORY_ID i_Params_Get_Favorite_category_By_FAVORITE_CATEGORY_ID)
{
Favorite_category oFavorite_category = null;
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Favorite_category_By_FAVORITE_CATEGORY_ID");}
#region Body Section.
DALC.Favorite_category oDBEntry = _AppContext.Get_Favorite_category_By_FAVORITE_CATEGORY_ID(i_Params_Get_Favorite_category_By_FAVORITE_CATEGORY_ID.FAVORITE_CATEGORY_ID);
oFavorite_category = new Favorite_category();
oTools.CopyPropValues(oDBEntry, oFavorite_category);
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Favorite_category_By_FAVORITE_CATEGORY_ID");}
return oFavorite_category;
}
public Favorite_teacher Get_Favorite_teacher_By_FAVORITE_TEACHER_ID(Params_Get_Favorite_teacher_By_FAVORITE_TEACHER_ID i_Params_Get_Favorite_teacher_By_FAVORITE_TEACHER_ID)
{
Favorite_teacher oFavorite_teacher = null;
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Favorite_teacher_By_FAVORITE_TEACHER_ID");}
#region Body Section.
DALC.Favorite_teacher oDBEntry = _AppContext.Get_Favorite_teacher_By_FAVORITE_TEACHER_ID(i_Params_Get_Favorite_teacher_By_FAVORITE_TEACHER_ID.FAVORITE_TEACHER_ID);
oFavorite_teacher = new Favorite_teacher();
oTools.CopyPropValues(oDBEntry, oFavorite_teacher);
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Favorite_teacher_By_FAVORITE_TEACHER_ID");}
return oFavorite_teacher;
}
public Mark_question Get_Mark_question_By_MARK_QUESTION_ID(Params_Get_Mark_question_By_MARK_QUESTION_ID i_Params_Get_Mark_question_By_MARK_QUESTION_ID)
{
Mark_question oMark_question = null;
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Mark_question_By_MARK_QUESTION_ID");}
#region Body Section.
DALC.Mark_question oDBEntry = _AppContext.Get_Mark_question_By_MARK_QUESTION_ID(i_Params_Get_Mark_question_By_MARK_QUESTION_ID.MARK_QUESTION_ID);
oMark_question = new Mark_question();
oTools.CopyPropValues(oDBEntry, oMark_question);
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Mark_question_By_MARK_QUESTION_ID");}
return oMark_question;
}
public Notification Get_Notification_By_NOTIFICATION_ID(Params_Get_Notification_By_NOTIFICATION_ID i_Params_Get_Notification_By_NOTIFICATION_ID)
{
Notification oNotification = null;
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Notification_By_NOTIFICATION_ID");}
#region Body Section.
DALC.Notification oDBEntry = _AppContext.Get_Notification_By_NOTIFICATION_ID(i_Params_Get_Notification_By_NOTIFICATION_ID.NOTIFICATION_ID);
oNotification = new Notification();
oTools.CopyPropValues(oDBEntry, oNotification);
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Notification_By_NOTIFICATION_ID");}
return oNotification;
}
public Owner Get_Owner_By_OWNER_ID(Params_Get_Owner_By_OWNER_ID i_Params_Get_Owner_By_OWNER_ID)
{
Owner oOwner = null;
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Owner_By_OWNER_ID");}
#region Body Section.
DALC.Owner oDBEntry = _AppContext.Get_Owner_By_OWNER_ID(i_Params_Get_Owner_By_OWNER_ID.OWNER_ID);
oOwner = new Owner();
oTools.CopyPropValues(oDBEntry, oOwner);
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Owner_By_OWNER_ID");}
return oOwner;
}
public Question Get_Question_By_QUESTION_ID(Params_Get_Question_By_QUESTION_ID i_Params_Get_Question_By_QUESTION_ID)
{
Question oQuestion = null;
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Question_By_QUESTION_ID");}
#region Body Section.
DALC.Question oDBEntry = _AppContext.Get_Question_By_QUESTION_ID(i_Params_Get_Question_By_QUESTION_ID.QUESTION_ID);
oQuestion = new Question();
oTools.CopyPropValues(oDBEntry, oQuestion);
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Question_By_QUESTION_ID");}
return oQuestion;
}
public Question_report Get_Question_report_By_QUESTION_REPORT_ID(Params_Get_Question_report_By_QUESTION_REPORT_ID i_Params_Get_Question_report_By_QUESTION_REPORT_ID)
{
Question_report oQuestion_report = null;
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Question_report_By_QUESTION_REPORT_ID");}
#region Body Section.
DALC.Question_report oDBEntry = _AppContext.Get_Question_report_By_QUESTION_REPORT_ID(i_Params_Get_Question_report_By_QUESTION_REPORT_ID.QUESTION_REPORT_ID);
oQuestion_report = new Question_report();
oTools.CopyPropValues(oDBEntry, oQuestion_report);
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Question_report_By_QUESTION_REPORT_ID");}
return oQuestion_report;
}
public Question_token Get_Question_token_By_QUESTION_TOKEN_ID(Params_Get_Question_token_By_QUESTION_TOKEN_ID i_Params_Get_Question_token_By_QUESTION_TOKEN_ID)
{
Question_token oQuestion_token = null;
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Question_token_By_QUESTION_TOKEN_ID");}
#region Body Section.
DALC.Question_token oDBEntry = _AppContext.Get_Question_token_By_QUESTION_TOKEN_ID(i_Params_Get_Question_token_By_QUESTION_TOKEN_ID.QUESTION_TOKEN_ID);
oQuestion_token = new Question_token();
oTools.CopyPropValues(oDBEntry, oQuestion_token);
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Question_token_By_QUESTION_TOKEN_ID");}
return oQuestion_token;
}
public Report_article Get_Report_article_By_REPORT_ARTICLE_ID(Params_Get_Report_article_By_REPORT_ARTICLE_ID i_Params_Get_Report_article_By_REPORT_ARTICLE_ID)
{
Report_article oReport_article = null;
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Report_article_By_REPORT_ARTICLE_ID");}
#region Body Section.
DALC.Report_article oDBEntry = _AppContext.Get_Report_article_By_REPORT_ARTICLE_ID(i_Params_Get_Report_article_By_REPORT_ARTICLE_ID.REPORT_ARTICLE_ID);
oReport_article = new Report_article();
oTools.CopyPropValues(oDBEntry, oReport_article);
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Report_article_By_REPORT_ARTICLE_ID");}
return oReport_article;
}
public Student Get_Student_By_STUDENT_ID(Params_Get_Student_By_STUDENT_ID i_Params_Get_Student_By_STUDENT_ID)
{
Student oStudent = null;
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Student_By_STUDENT_ID");}
#region Body Section.
DALC.Student oDBEntry = _AppContext.Get_Student_By_STUDENT_ID(i_Params_Get_Student_By_STUDENT_ID.STUDENT_ID);
oStudent = new Student();
oTools.CopyPropValues(oDBEntry, oStudent);
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Student_By_STUDENT_ID");}
return oStudent;
}
public Student_report Get_Student_report_By_STUDENT_REPORT_ID(Params_Get_Student_report_By_STUDENT_REPORT_ID i_Params_Get_Student_report_By_STUDENT_REPORT_ID)
{
Student_report oStudent_report = null;
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Student_report_By_STUDENT_REPORT_ID");}
#region Body Section.
DALC.Student_report oDBEntry = _AppContext.Get_Student_report_By_STUDENT_REPORT_ID(i_Params_Get_Student_report_By_STUDENT_REPORT_ID.STUDENT_REPORT_ID);
oStudent_report = new Student_report();
oTools.CopyPropValues(oDBEntry, oStudent_report);
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Student_report_By_STUDENT_REPORT_ID");}
return oStudent_report;
}
public Teacher Get_Teacher_By_TEACHER_ID(Params_Get_Teacher_By_TEACHER_ID i_Params_Get_Teacher_By_TEACHER_ID)
{
Teacher oTeacher = null;
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_By_TEACHER_ID");}
#region Body Section.
DALC.Teacher oDBEntry = _AppContext.Get_Teacher_By_TEACHER_ID(i_Params_Get_Teacher_By_TEACHER_ID.TEACHER_ID);
oTeacher = new Teacher();
oTools.CopyPropValues(oDBEntry, oTeacher);
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_By_TEACHER_ID");}
return oTeacher;
}
public Teacher_category Get_Teacher_category_By_TEACHER_CATEGORY_ID(Params_Get_Teacher_category_By_TEACHER_CATEGORY_ID i_Params_Get_Teacher_category_By_TEACHER_CATEGORY_ID)
{
Teacher_category oTeacher_category = null;
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_category_By_TEACHER_CATEGORY_ID");}
#region Body Section.
DALC.Teacher_category oDBEntry = _AppContext.Get_Teacher_category_By_TEACHER_CATEGORY_ID(i_Params_Get_Teacher_category_By_TEACHER_CATEGORY_ID.TEACHER_CATEGORY_ID);
oTeacher_category = new Teacher_category();
oTools.CopyPropValues(oDBEntry, oTeacher_category);
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_category_By_TEACHER_CATEGORY_ID");}
return oTeacher_category;
}
public Teacher_favorite Get_Teacher_favorite_By_TEACHER_FAVORITE_ID(Params_Get_Teacher_favorite_By_TEACHER_FAVORITE_ID i_Params_Get_Teacher_favorite_By_TEACHER_FAVORITE_ID)
{
Teacher_favorite oTeacher_favorite = null;
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_favorite_By_TEACHER_FAVORITE_ID");}
#region Body Section.
DALC.Teacher_favorite oDBEntry = _AppContext.Get_Teacher_favorite_By_TEACHER_FAVORITE_ID(i_Params_Get_Teacher_favorite_By_TEACHER_FAVORITE_ID.TEACHER_FAVORITE_ID);
oTeacher_favorite = new Teacher_favorite();
oTools.CopyPropValues(oDBEntry, oTeacher_favorite);
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_favorite_By_TEACHER_FAVORITE_ID");}
return oTeacher_favorite;
}
public Teacher_rank Get_Teacher_rank_By_TEACHER_RANK_ID(Params_Get_Teacher_rank_By_TEACHER_RANK_ID i_Params_Get_Teacher_rank_By_TEACHER_RANK_ID)
{
Teacher_rank oTeacher_rank = null;
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_rank_By_TEACHER_RANK_ID");}
#region Body Section.
DALC.Teacher_rank oDBEntry = _AppContext.Get_Teacher_rank_By_TEACHER_RANK_ID(i_Params_Get_Teacher_rank_By_TEACHER_RANK_ID.TEACHER_RANK_ID);
oTeacher_rank = new Teacher_rank();
oTools.CopyPropValues(oDBEntry, oTeacher_rank);
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_rank_By_TEACHER_RANK_ID");}
return oTeacher_rank;
}
public Teacher_report Get_Teacher_report_By_TEACHER_REPORT_ID(Params_Get_Teacher_report_By_TEACHER_REPORT_ID i_Params_Get_Teacher_report_By_TEACHER_REPORT_ID)
{
Teacher_report oTeacher_report = null;
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_report_By_TEACHER_REPORT_ID");}
#region Body Section.
DALC.Teacher_report oDBEntry = _AppContext.Get_Teacher_report_By_TEACHER_REPORT_ID(i_Params_Get_Teacher_report_By_TEACHER_REPORT_ID.TEACHER_REPORT_ID);
oTeacher_report = new Teacher_report();
oTools.CopyPropValues(oDBEntry, oTeacher_report);
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_report_By_TEACHER_REPORT_ID");}
return oTeacher_report;
}
public User Get_User_By_USER_ID(Params_Get_User_By_USER_ID i_Params_Get_User_By_USER_ID)
{
User oUser = null;
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_User_By_USER_ID");}
#region Body Section.
DALC.User oDBEntry = _AppContext.Get_User_By_USER_ID(i_Params_Get_User_By_USER_ID.USER_ID);
oUser = new User();
oTools.CopyPropValues(oDBEntry, oUser);
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_User_By_USER_ID");}
return oUser;
}
public List<Answer> Get_Answer_By_ANSWER_ID_List(Params_Get_Answer_By_ANSWER_ID_List i_Params_Get_Answer_By_ANSWER_ID_List)
{
Answer oAnswer = null;
List<Answer> oList = new List<Answer>();
Params_Get_Answer_By_ANSWER_ID_List_SP oParams_Get_Answer_By_ANSWER_ID_List_SP = new Params_Get_Answer_By_ANSWER_ID_List_SP();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Answer_By_ANSWER_ID_List");}
#region Body Section.
List<DALC.Answer> oList_DBEntries = _AppContext.Get_Answer_By_ANSWER_ID_List(i_Params_Get_Answer_By_ANSWER_ID_List.ANSWER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oAnswer = new Answer();
oTools.CopyPropValues(oDBEntry, oAnswer);
oList.Add(oAnswer);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Answer_By_ANSWER_ID_List");}
return oList;
}
public List<Answer_report> Get_Answer_report_By_ANSWER_REPORT_ID_List(Params_Get_Answer_report_By_ANSWER_REPORT_ID_List i_Params_Get_Answer_report_By_ANSWER_REPORT_ID_List)
{
Answer_report oAnswer_report = null;
List<Answer_report> oList = new List<Answer_report>();
Params_Get_Answer_report_By_ANSWER_REPORT_ID_List_SP oParams_Get_Answer_report_By_ANSWER_REPORT_ID_List_SP = new Params_Get_Answer_report_By_ANSWER_REPORT_ID_List_SP();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Answer_report_By_ANSWER_REPORT_ID_List");}
#region Body Section.
List<DALC.Answer_report> oList_DBEntries = _AppContext.Get_Answer_report_By_ANSWER_REPORT_ID_List(i_Params_Get_Answer_report_By_ANSWER_REPORT_ID_List.ANSWER_REPORT_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oAnswer_report = new Answer_report();
oTools.CopyPropValues(oDBEntry, oAnswer_report);
oList.Add(oAnswer_report);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Answer_report_By_ANSWER_REPORT_ID_List");}
return oList;
}
public List<Appreciate> Get_Appreciate_By_APPRECIATE_ID_List(Params_Get_Appreciate_By_APPRECIATE_ID_List i_Params_Get_Appreciate_By_APPRECIATE_ID_List)
{
Appreciate oAppreciate = null;
List<Appreciate> oList = new List<Appreciate>();
Params_Get_Appreciate_By_APPRECIATE_ID_List_SP oParams_Get_Appreciate_By_APPRECIATE_ID_List_SP = new Params_Get_Appreciate_By_APPRECIATE_ID_List_SP();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Appreciate_By_APPRECIATE_ID_List");}
#region Body Section.
List<DALC.Appreciate> oList_DBEntries = _AppContext.Get_Appreciate_By_APPRECIATE_ID_List(i_Params_Get_Appreciate_By_APPRECIATE_ID_List.APPRECIATE_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oAppreciate = new Appreciate();
oTools.CopyPropValues(oDBEntry, oAppreciate);
oList.Add(oAppreciate);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Appreciate_By_APPRECIATE_ID_List");}
return oList;
}
public List<Article> Get_Article_By_ARTICLE_ID_List(Params_Get_Article_By_ARTICLE_ID_List i_Params_Get_Article_By_ARTICLE_ID_List)
{
Article oArticle = null;
List<Article> oList = new List<Article>();
Params_Get_Article_By_ARTICLE_ID_List_SP oParams_Get_Article_By_ARTICLE_ID_List_SP = new Params_Get_Article_By_ARTICLE_ID_List_SP();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Article_By_ARTICLE_ID_List");}
#region Body Section.
List<DALC.Article> oList_DBEntries = _AppContext.Get_Article_By_ARTICLE_ID_List(i_Params_Get_Article_By_ARTICLE_ID_List.ARTICLE_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oArticle = new Article();
oTools.CopyPropValues(oDBEntry, oArticle);
oList.Add(oArticle);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Article_By_ARTICLE_ID_List");}
return oList;
}
public List<Category> Get_Category_By_CATEGORY_ID_List(Params_Get_Category_By_CATEGORY_ID_List i_Params_Get_Category_By_CATEGORY_ID_List)
{
Category oCategory = null;
List<Category> oList = new List<Category>();
Params_Get_Category_By_CATEGORY_ID_List_SP oParams_Get_Category_By_CATEGORY_ID_List_SP = new Params_Get_Category_By_CATEGORY_ID_List_SP();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Category_By_CATEGORY_ID_List");}
#region Body Section.
List<DALC.Category> oList_DBEntries = _AppContext.Get_Category_By_CATEGORY_ID_List(i_Params_Get_Category_By_CATEGORY_ID_List.CATEGORY_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCategory = new Category();
oTools.CopyPropValues(oDBEntry, oCategory);
oList.Add(oCategory);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Category_By_CATEGORY_ID_List");}
return oList;
}
public List<Evaluation> Get_Evaluation_By_EVALUATION_ID_List(Params_Get_Evaluation_By_EVALUATION_ID_List i_Params_Get_Evaluation_By_EVALUATION_ID_List)
{
Evaluation oEvaluation = null;
List<Evaluation> oList = new List<Evaluation>();
Params_Get_Evaluation_By_EVALUATION_ID_List_SP oParams_Get_Evaluation_By_EVALUATION_ID_List_SP = new Params_Get_Evaluation_By_EVALUATION_ID_List_SP();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Evaluation_By_EVALUATION_ID_List");}
#region Body Section.
List<DALC.Evaluation> oList_DBEntries = _AppContext.Get_Evaluation_By_EVALUATION_ID_List(i_Params_Get_Evaluation_By_EVALUATION_ID_List.EVALUATION_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oEvaluation = new Evaluation();
oTools.CopyPropValues(oDBEntry, oEvaluation);
oList.Add(oEvaluation);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Evaluation_By_EVALUATION_ID_List");}
return oList;
}
public List<Favorite_category> Get_Favorite_category_By_FAVORITE_CATEGORY_ID_List(Params_Get_Favorite_category_By_FAVORITE_CATEGORY_ID_List i_Params_Get_Favorite_category_By_FAVORITE_CATEGORY_ID_List)
{
Favorite_category oFavorite_category = null;
List<Favorite_category> oList = new List<Favorite_category>();
Params_Get_Favorite_category_By_FAVORITE_CATEGORY_ID_List_SP oParams_Get_Favorite_category_By_FAVORITE_CATEGORY_ID_List_SP = new Params_Get_Favorite_category_By_FAVORITE_CATEGORY_ID_List_SP();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Favorite_category_By_FAVORITE_CATEGORY_ID_List");}
#region Body Section.
List<DALC.Favorite_category> oList_DBEntries = _AppContext.Get_Favorite_category_By_FAVORITE_CATEGORY_ID_List(i_Params_Get_Favorite_category_By_FAVORITE_CATEGORY_ID_List.FAVORITE_CATEGORY_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oFavorite_category = new Favorite_category();
oTools.CopyPropValues(oDBEntry, oFavorite_category);
oList.Add(oFavorite_category);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Favorite_category_By_FAVORITE_CATEGORY_ID_List");}
return oList;
}
public List<Favorite_teacher> Get_Favorite_teacher_By_FAVORITE_TEACHER_ID_List(Params_Get_Favorite_teacher_By_FAVORITE_TEACHER_ID_List i_Params_Get_Favorite_teacher_By_FAVORITE_TEACHER_ID_List)
{
Favorite_teacher oFavorite_teacher = null;
List<Favorite_teacher> oList = new List<Favorite_teacher>();
Params_Get_Favorite_teacher_By_FAVORITE_TEACHER_ID_List_SP oParams_Get_Favorite_teacher_By_FAVORITE_TEACHER_ID_List_SP = new Params_Get_Favorite_teacher_By_FAVORITE_TEACHER_ID_List_SP();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Favorite_teacher_By_FAVORITE_TEACHER_ID_List");}
#region Body Section.
List<DALC.Favorite_teacher> oList_DBEntries = _AppContext.Get_Favorite_teacher_By_FAVORITE_TEACHER_ID_List(i_Params_Get_Favorite_teacher_By_FAVORITE_TEACHER_ID_List.FAVORITE_TEACHER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oFavorite_teacher = new Favorite_teacher();
oTools.CopyPropValues(oDBEntry, oFavorite_teacher);
oList.Add(oFavorite_teacher);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Favorite_teacher_By_FAVORITE_TEACHER_ID_List");}
return oList;
}
public List<Mark_question> Get_Mark_question_By_MARK_QUESTION_ID_List(Params_Get_Mark_question_By_MARK_QUESTION_ID_List i_Params_Get_Mark_question_By_MARK_QUESTION_ID_List)
{
Mark_question oMark_question = null;
List<Mark_question> oList = new List<Mark_question>();
Params_Get_Mark_question_By_MARK_QUESTION_ID_List_SP oParams_Get_Mark_question_By_MARK_QUESTION_ID_List_SP = new Params_Get_Mark_question_By_MARK_QUESTION_ID_List_SP();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Mark_question_By_MARK_QUESTION_ID_List");}
#region Body Section.
List<DALC.Mark_question> oList_DBEntries = _AppContext.Get_Mark_question_By_MARK_QUESTION_ID_List(i_Params_Get_Mark_question_By_MARK_QUESTION_ID_List.MARK_QUESTION_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oMark_question = new Mark_question();
oTools.CopyPropValues(oDBEntry, oMark_question);
oList.Add(oMark_question);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Mark_question_By_MARK_QUESTION_ID_List");}
return oList;
}
public List<Notification> Get_Notification_By_NOTIFICATION_ID_List(Params_Get_Notification_By_NOTIFICATION_ID_List i_Params_Get_Notification_By_NOTIFICATION_ID_List)
{
Notification oNotification = null;
List<Notification> oList = new List<Notification>();
Params_Get_Notification_By_NOTIFICATION_ID_List_SP oParams_Get_Notification_By_NOTIFICATION_ID_List_SP = new Params_Get_Notification_By_NOTIFICATION_ID_List_SP();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Notification_By_NOTIFICATION_ID_List");}
#region Body Section.
List<DALC.Notification> oList_DBEntries = _AppContext.Get_Notification_By_NOTIFICATION_ID_List(i_Params_Get_Notification_By_NOTIFICATION_ID_List.NOTIFICATION_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oNotification = new Notification();
oTools.CopyPropValues(oDBEntry, oNotification);
oList.Add(oNotification);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Notification_By_NOTIFICATION_ID_List");}
return oList;
}
public List<Owner> Get_Owner_By_OWNER_ID_List(Params_Get_Owner_By_OWNER_ID_List i_Params_Get_Owner_By_OWNER_ID_List)
{
Owner oOwner = null;
List<Owner> oList = new List<Owner>();
Params_Get_Owner_By_OWNER_ID_List_SP oParams_Get_Owner_By_OWNER_ID_List_SP = new Params_Get_Owner_By_OWNER_ID_List_SP();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Owner_By_OWNER_ID_List");}
#region Body Section.
List<DALC.Owner> oList_DBEntries = _AppContext.Get_Owner_By_OWNER_ID_List(i_Params_Get_Owner_By_OWNER_ID_List.OWNER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oOwner = new Owner();
oTools.CopyPropValues(oDBEntry, oOwner);
oList.Add(oOwner);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Owner_By_OWNER_ID_List");}
return oList;
}
public List<Question> Get_Question_By_QUESTION_ID_List(Params_Get_Question_By_QUESTION_ID_List i_Params_Get_Question_By_QUESTION_ID_List)
{
Question oQuestion = null;
List<Question> oList = new List<Question>();
Params_Get_Question_By_QUESTION_ID_List_SP oParams_Get_Question_By_QUESTION_ID_List_SP = new Params_Get_Question_By_QUESTION_ID_List_SP();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Question_By_QUESTION_ID_List");}
#region Body Section.
List<DALC.Question> oList_DBEntries = _AppContext.Get_Question_By_QUESTION_ID_List(i_Params_Get_Question_By_QUESTION_ID_List.QUESTION_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oQuestion = new Question();
oTools.CopyPropValues(oDBEntry, oQuestion);
oList.Add(oQuestion);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Question_By_QUESTION_ID_List");}
return oList;
}
public List<Question_report> Get_Question_report_By_QUESTION_REPORT_ID_List(Params_Get_Question_report_By_QUESTION_REPORT_ID_List i_Params_Get_Question_report_By_QUESTION_REPORT_ID_List)
{
Question_report oQuestion_report = null;
List<Question_report> oList = new List<Question_report>();
Params_Get_Question_report_By_QUESTION_REPORT_ID_List_SP oParams_Get_Question_report_By_QUESTION_REPORT_ID_List_SP = new Params_Get_Question_report_By_QUESTION_REPORT_ID_List_SP();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Question_report_By_QUESTION_REPORT_ID_List");}
#region Body Section.
List<DALC.Question_report> oList_DBEntries = _AppContext.Get_Question_report_By_QUESTION_REPORT_ID_List(i_Params_Get_Question_report_By_QUESTION_REPORT_ID_List.QUESTION_REPORT_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oQuestion_report = new Question_report();
oTools.CopyPropValues(oDBEntry, oQuestion_report);
oList.Add(oQuestion_report);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Question_report_By_QUESTION_REPORT_ID_List");}
return oList;
}
public List<Question_token> Get_Question_token_By_QUESTION_TOKEN_ID_List(Params_Get_Question_token_By_QUESTION_TOKEN_ID_List i_Params_Get_Question_token_By_QUESTION_TOKEN_ID_List)
{
Question_token oQuestion_token = null;
List<Question_token> oList = new List<Question_token>();
Params_Get_Question_token_By_QUESTION_TOKEN_ID_List_SP oParams_Get_Question_token_By_QUESTION_TOKEN_ID_List_SP = new Params_Get_Question_token_By_QUESTION_TOKEN_ID_List_SP();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Question_token_By_QUESTION_TOKEN_ID_List");}
#region Body Section.
List<DALC.Question_token> oList_DBEntries = _AppContext.Get_Question_token_By_QUESTION_TOKEN_ID_List(i_Params_Get_Question_token_By_QUESTION_TOKEN_ID_List.QUESTION_TOKEN_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oQuestion_token = new Question_token();
oTools.CopyPropValues(oDBEntry, oQuestion_token);
oList.Add(oQuestion_token);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Question_token_By_QUESTION_TOKEN_ID_List");}
return oList;
}
public List<Report_article> Get_Report_article_By_REPORT_ARTICLE_ID_List(Params_Get_Report_article_By_REPORT_ARTICLE_ID_List i_Params_Get_Report_article_By_REPORT_ARTICLE_ID_List)
{
Report_article oReport_article = null;
List<Report_article> oList = new List<Report_article>();
Params_Get_Report_article_By_REPORT_ARTICLE_ID_List_SP oParams_Get_Report_article_By_REPORT_ARTICLE_ID_List_SP = new Params_Get_Report_article_By_REPORT_ARTICLE_ID_List_SP();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Report_article_By_REPORT_ARTICLE_ID_List");}
#region Body Section.
List<DALC.Report_article> oList_DBEntries = _AppContext.Get_Report_article_By_REPORT_ARTICLE_ID_List(i_Params_Get_Report_article_By_REPORT_ARTICLE_ID_List.REPORT_ARTICLE_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oReport_article = new Report_article();
oTools.CopyPropValues(oDBEntry, oReport_article);
oList.Add(oReport_article);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Report_article_By_REPORT_ARTICLE_ID_List");}
return oList;
}
public List<Student> Get_Student_By_STUDENT_ID_List(Params_Get_Student_By_STUDENT_ID_List i_Params_Get_Student_By_STUDENT_ID_List)
{
Student oStudent = null;
List<Student> oList = new List<Student>();
Params_Get_Student_By_STUDENT_ID_List_SP oParams_Get_Student_By_STUDENT_ID_List_SP = new Params_Get_Student_By_STUDENT_ID_List_SP();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Student_By_STUDENT_ID_List");}
#region Body Section.
List<DALC.Student> oList_DBEntries = _AppContext.Get_Student_By_STUDENT_ID_List(i_Params_Get_Student_By_STUDENT_ID_List.STUDENT_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oStudent = new Student();
oTools.CopyPropValues(oDBEntry, oStudent);
oList.Add(oStudent);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Student_By_STUDENT_ID_List");}
return oList;
}
public List<Student_report> Get_Student_report_By_STUDENT_REPORT_ID_List(Params_Get_Student_report_By_STUDENT_REPORT_ID_List i_Params_Get_Student_report_By_STUDENT_REPORT_ID_List)
{
Student_report oStudent_report = null;
List<Student_report> oList = new List<Student_report>();
Params_Get_Student_report_By_STUDENT_REPORT_ID_List_SP oParams_Get_Student_report_By_STUDENT_REPORT_ID_List_SP = new Params_Get_Student_report_By_STUDENT_REPORT_ID_List_SP();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Student_report_By_STUDENT_REPORT_ID_List");}
#region Body Section.
List<DALC.Student_report> oList_DBEntries = _AppContext.Get_Student_report_By_STUDENT_REPORT_ID_List(i_Params_Get_Student_report_By_STUDENT_REPORT_ID_List.STUDENT_REPORT_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oStudent_report = new Student_report();
oTools.CopyPropValues(oDBEntry, oStudent_report);
oList.Add(oStudent_report);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Student_report_By_STUDENT_REPORT_ID_List");}
return oList;
}
public List<Teacher> Get_Teacher_By_TEACHER_ID_List(Params_Get_Teacher_By_TEACHER_ID_List i_Params_Get_Teacher_By_TEACHER_ID_List)
{
Teacher oTeacher = null;
List<Teacher> oList = new List<Teacher>();
Params_Get_Teacher_By_TEACHER_ID_List_SP oParams_Get_Teacher_By_TEACHER_ID_List_SP = new Params_Get_Teacher_By_TEACHER_ID_List_SP();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_By_TEACHER_ID_List");}
#region Body Section.
List<DALC.Teacher> oList_DBEntries = _AppContext.Get_Teacher_By_TEACHER_ID_List(i_Params_Get_Teacher_By_TEACHER_ID_List.TEACHER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher = new Teacher();
oTools.CopyPropValues(oDBEntry, oTeacher);
oList.Add(oTeacher);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_By_TEACHER_ID_List");}
return oList;
}
public List<Teacher_category> Get_Teacher_category_By_TEACHER_CATEGORY_ID_List(Params_Get_Teacher_category_By_TEACHER_CATEGORY_ID_List i_Params_Get_Teacher_category_By_TEACHER_CATEGORY_ID_List)
{
Teacher_category oTeacher_category = null;
List<Teacher_category> oList = new List<Teacher_category>();
Params_Get_Teacher_category_By_TEACHER_CATEGORY_ID_List_SP oParams_Get_Teacher_category_By_TEACHER_CATEGORY_ID_List_SP = new Params_Get_Teacher_category_By_TEACHER_CATEGORY_ID_List_SP();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_category_By_TEACHER_CATEGORY_ID_List");}
#region Body Section.
List<DALC.Teacher_category> oList_DBEntries = _AppContext.Get_Teacher_category_By_TEACHER_CATEGORY_ID_List(i_Params_Get_Teacher_category_By_TEACHER_CATEGORY_ID_List.TEACHER_CATEGORY_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_category = new Teacher_category();
oTools.CopyPropValues(oDBEntry, oTeacher_category);
oList.Add(oTeacher_category);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_category_By_TEACHER_CATEGORY_ID_List");}
return oList;
}
public List<Teacher_favorite> Get_Teacher_favorite_By_TEACHER_FAVORITE_ID_List(Params_Get_Teacher_favorite_By_TEACHER_FAVORITE_ID_List i_Params_Get_Teacher_favorite_By_TEACHER_FAVORITE_ID_List)
{
Teacher_favorite oTeacher_favorite = null;
List<Teacher_favorite> oList = new List<Teacher_favorite>();
Params_Get_Teacher_favorite_By_TEACHER_FAVORITE_ID_List_SP oParams_Get_Teacher_favorite_By_TEACHER_FAVORITE_ID_List_SP = new Params_Get_Teacher_favorite_By_TEACHER_FAVORITE_ID_List_SP();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_favorite_By_TEACHER_FAVORITE_ID_List");}
#region Body Section.
List<DALC.Teacher_favorite> oList_DBEntries = _AppContext.Get_Teacher_favorite_By_TEACHER_FAVORITE_ID_List(i_Params_Get_Teacher_favorite_By_TEACHER_FAVORITE_ID_List.TEACHER_FAVORITE_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_favorite = new Teacher_favorite();
oTools.CopyPropValues(oDBEntry, oTeacher_favorite);
oList.Add(oTeacher_favorite);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_favorite_By_TEACHER_FAVORITE_ID_List");}
return oList;
}
public List<Teacher_rank> Get_Teacher_rank_By_TEACHER_RANK_ID_List(Params_Get_Teacher_rank_By_TEACHER_RANK_ID_List i_Params_Get_Teacher_rank_By_TEACHER_RANK_ID_List)
{
Teacher_rank oTeacher_rank = null;
List<Teacher_rank> oList = new List<Teacher_rank>();
Params_Get_Teacher_rank_By_TEACHER_RANK_ID_List_SP oParams_Get_Teacher_rank_By_TEACHER_RANK_ID_List_SP = new Params_Get_Teacher_rank_By_TEACHER_RANK_ID_List_SP();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_rank_By_TEACHER_RANK_ID_List");}
#region Body Section.
List<DALC.Teacher_rank> oList_DBEntries = _AppContext.Get_Teacher_rank_By_TEACHER_RANK_ID_List(i_Params_Get_Teacher_rank_By_TEACHER_RANK_ID_List.TEACHER_RANK_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_rank = new Teacher_rank();
oTools.CopyPropValues(oDBEntry, oTeacher_rank);
oList.Add(oTeacher_rank);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_rank_By_TEACHER_RANK_ID_List");}
return oList;
}
public List<Teacher_report> Get_Teacher_report_By_TEACHER_REPORT_ID_List(Params_Get_Teacher_report_By_TEACHER_REPORT_ID_List i_Params_Get_Teacher_report_By_TEACHER_REPORT_ID_List)
{
Teacher_report oTeacher_report = null;
List<Teacher_report> oList = new List<Teacher_report>();
Params_Get_Teacher_report_By_TEACHER_REPORT_ID_List_SP oParams_Get_Teacher_report_By_TEACHER_REPORT_ID_List_SP = new Params_Get_Teacher_report_By_TEACHER_REPORT_ID_List_SP();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_report_By_TEACHER_REPORT_ID_List");}
#region Body Section.
List<DALC.Teacher_report> oList_DBEntries = _AppContext.Get_Teacher_report_By_TEACHER_REPORT_ID_List(i_Params_Get_Teacher_report_By_TEACHER_REPORT_ID_List.TEACHER_REPORT_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_report = new Teacher_report();
oTools.CopyPropValues(oDBEntry, oTeacher_report);
oList.Add(oTeacher_report);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_report_By_TEACHER_REPORT_ID_List");}
return oList;
}
public List<User> Get_User_By_USER_ID_List(Params_Get_User_By_USER_ID_List i_Params_Get_User_By_USER_ID_List)
{
User oUser = null;
List<User> oList = new List<User>();
Params_Get_User_By_USER_ID_List_SP oParams_Get_User_By_USER_ID_List_SP = new Params_Get_User_By_USER_ID_List_SP();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_User_By_USER_ID_List");}
#region Body Section.
List<DALC.User> oList_DBEntries = _AppContext.Get_User_By_USER_ID_List(i_Params_Get_User_By_USER_ID_List.USER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oUser = new User();
oTools.CopyPropValues(oDBEntry, oUser);
oList.Add(oUser);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_User_By_USER_ID_List");}
return oList;
}
public List<Answer> Get_Answer_By_OWNER_ID(Params_Get_Answer_By_OWNER_ID i_Params_Get_Answer_By_OWNER_ID)
{
List<Answer> oList = new List<Answer>();
Tools.Tools oTools = new Tools.Tools();
Answer oAnswer = new Answer();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Answer_By_OWNER_ID");}
#region Body Section.
List<DALC.Answer> oList_DBEntries = _AppContext.Get_Answer_By_OWNER_ID(i_Params_Get_Answer_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oAnswer = new Answer();
oTools.CopyPropValues(oDBEntry, oAnswer);
oList.Add(oAnswer);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Answer_By_OWNER_ID");}
return oList;
}
public List<Answer> Get_Answer_By_QUESTION_ID(Params_Get_Answer_By_QUESTION_ID i_Params_Get_Answer_By_QUESTION_ID)
{
List<Answer> oList = new List<Answer>();
Tools.Tools oTools = new Tools.Tools();
Answer oAnswer = new Answer();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Answer_By_QUESTION_ID");}
#region Body Section.
List<DALC.Answer> oList_DBEntries = _AppContext.Get_Answer_By_QUESTION_ID(i_Params_Get_Answer_By_QUESTION_ID.QUESTION_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oAnswer = new Answer();
oTools.CopyPropValues(oDBEntry, oAnswer);
oList.Add(oAnswer);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Answer_By_QUESTION_ID");}
return oList;
}
public List<Answer> Get_Answer_By_TEACHER_ID(Params_Get_Answer_By_TEACHER_ID i_Params_Get_Answer_By_TEACHER_ID)
{
List<Answer> oList = new List<Answer>();
Tools.Tools oTools = new Tools.Tools();
Answer oAnswer = new Answer();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Answer_By_TEACHER_ID");}
#region Body Section.
List<DALC.Answer> oList_DBEntries = _AppContext.Get_Answer_By_TEACHER_ID(i_Params_Get_Answer_By_TEACHER_ID.TEACHER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oAnswer = new Answer();
oTools.CopyPropValues(oDBEntry, oAnswer);
oList.Add(oAnswer);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Answer_By_TEACHER_ID");}
return oList;
}
public List<Answer_report> Get_Answer_report_By_OWNER_ID(Params_Get_Answer_report_By_OWNER_ID i_Params_Get_Answer_report_By_OWNER_ID)
{
List<Answer_report> oList = new List<Answer_report>();
Tools.Tools oTools = new Tools.Tools();
Answer_report oAnswer_report = new Answer_report();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Answer_report_By_OWNER_ID");}
#region Body Section.
List<DALC.Answer_report> oList_DBEntries = _AppContext.Get_Answer_report_By_OWNER_ID(i_Params_Get_Answer_report_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oAnswer_report = new Answer_report();
oTools.CopyPropValues(oDBEntry, oAnswer_report);
oList.Add(oAnswer_report);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Answer_report_By_OWNER_ID");}
return oList;
}
public List<Answer_report> Get_Answer_report_By_TEACHER_ID(Params_Get_Answer_report_By_TEACHER_ID i_Params_Get_Answer_report_By_TEACHER_ID)
{
List<Answer_report> oList = new List<Answer_report>();
Tools.Tools oTools = new Tools.Tools();
Answer_report oAnswer_report = new Answer_report();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Answer_report_By_TEACHER_ID");}
#region Body Section.
List<DALC.Answer_report> oList_DBEntries = _AppContext.Get_Answer_report_By_TEACHER_ID(i_Params_Get_Answer_report_By_TEACHER_ID.TEACHER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oAnswer_report = new Answer_report();
oTools.CopyPropValues(oDBEntry, oAnswer_report);
oList.Add(oAnswer_report);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Answer_report_By_TEACHER_ID");}
return oList;
}
public List<Answer_report> Get_Answer_report_By_STUDENT_ID(Params_Get_Answer_report_By_STUDENT_ID i_Params_Get_Answer_report_By_STUDENT_ID)
{
List<Answer_report> oList = new List<Answer_report>();
Tools.Tools oTools = new Tools.Tools();
Answer_report oAnswer_report = new Answer_report();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Answer_report_By_STUDENT_ID");}
#region Body Section.
List<DALC.Answer_report> oList_DBEntries = _AppContext.Get_Answer_report_By_STUDENT_ID(i_Params_Get_Answer_report_By_STUDENT_ID.STUDENT_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oAnswer_report = new Answer_report();
oTools.CopyPropValues(oDBEntry, oAnswer_report);
oList.Add(oAnswer_report);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Answer_report_By_STUDENT_ID");}
return oList;
}
public List<Answer_report> Get_Answer_report_By_ANSWER_ID(Params_Get_Answer_report_By_ANSWER_ID i_Params_Get_Answer_report_By_ANSWER_ID)
{
List<Answer_report> oList = new List<Answer_report>();
Tools.Tools oTools = new Tools.Tools();
Answer_report oAnswer_report = new Answer_report();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Answer_report_By_ANSWER_ID");}
#region Body Section.
List<DALC.Answer_report> oList_DBEntries = _AppContext.Get_Answer_report_By_ANSWER_ID(i_Params_Get_Answer_report_By_ANSWER_ID.ANSWER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oAnswer_report = new Answer_report();
oTools.CopyPropValues(oDBEntry, oAnswer_report);
oList.Add(oAnswer_report);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Answer_report_By_ANSWER_ID");}
return oList;
}
public List<Appreciate> Get_Appreciate_By_OWNER_ID(Params_Get_Appreciate_By_OWNER_ID i_Params_Get_Appreciate_By_OWNER_ID)
{
List<Appreciate> oList = new List<Appreciate>();
Tools.Tools oTools = new Tools.Tools();
Appreciate oAppreciate = new Appreciate();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Appreciate_By_OWNER_ID");}
#region Body Section.
List<DALC.Appreciate> oList_DBEntries = _AppContext.Get_Appreciate_By_OWNER_ID(i_Params_Get_Appreciate_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oAppreciate = new Appreciate();
oTools.CopyPropValues(oDBEntry, oAppreciate);
oList.Add(oAppreciate);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Appreciate_By_OWNER_ID");}
return oList;
}
public List<Appreciate> Get_Appreciate_By_ARTICLE_ID(Params_Get_Appreciate_By_ARTICLE_ID i_Params_Get_Appreciate_By_ARTICLE_ID)
{
List<Appreciate> oList = new List<Appreciate>();
Tools.Tools oTools = new Tools.Tools();
Appreciate oAppreciate = new Appreciate();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Appreciate_By_ARTICLE_ID");}
#region Body Section.
List<DALC.Appreciate> oList_DBEntries = _AppContext.Get_Appreciate_By_ARTICLE_ID(i_Params_Get_Appreciate_By_ARTICLE_ID.ARTICLE_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oAppreciate = new Appreciate();
oTools.CopyPropValues(oDBEntry, oAppreciate);
oList.Add(oAppreciate);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Appreciate_By_ARTICLE_ID");}
return oList;
}
public List<Appreciate> Get_Appreciate_By_STUDENT_ID(Params_Get_Appreciate_By_STUDENT_ID i_Params_Get_Appreciate_By_STUDENT_ID)
{
List<Appreciate> oList = new List<Appreciate>();
Tools.Tools oTools = new Tools.Tools();
Appreciate oAppreciate = new Appreciate();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Appreciate_By_STUDENT_ID");}
#region Body Section.
List<DALC.Appreciate> oList_DBEntries = _AppContext.Get_Appreciate_By_STUDENT_ID(i_Params_Get_Appreciate_By_STUDENT_ID.STUDENT_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oAppreciate = new Appreciate();
oTools.CopyPropValues(oDBEntry, oAppreciate);
oList.Add(oAppreciate);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Appreciate_By_STUDENT_ID");}
return oList;
}
public List<Article> Get_Article_By_OWNER_ID(Params_Get_Article_By_OWNER_ID i_Params_Get_Article_By_OWNER_ID)
{
List<Article> oList = new List<Article>();
Tools.Tools oTools = new Tools.Tools();
Article oArticle = new Article();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Article_By_OWNER_ID");}
#region Body Section.
List<DALC.Article> oList_DBEntries = _AppContext.Get_Article_By_OWNER_ID(i_Params_Get_Article_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oArticle = new Article();
oTools.CopyPropValues(oDBEntry, oArticle);
oList.Add(oArticle);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Article_By_OWNER_ID");}
return oList;
}
public List<Article> Get_Article_By_TEACHER_ID(Params_Get_Article_By_TEACHER_ID i_Params_Get_Article_By_TEACHER_ID)
{
List<Article> oList = new List<Article>();
Tools.Tools oTools = new Tools.Tools();
Article oArticle = new Article();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Article_By_TEACHER_ID");}
#region Body Section.
List<DALC.Article> oList_DBEntries = _AppContext.Get_Article_By_TEACHER_ID(i_Params_Get_Article_By_TEACHER_ID.TEACHER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oArticle = new Article();
oTools.CopyPropValues(oDBEntry, oArticle);
oList.Add(oArticle);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Article_By_TEACHER_ID");}
return oList;
}
public List<Article> Get_Article_By_CATEGORY_ID(Params_Get_Article_By_CATEGORY_ID i_Params_Get_Article_By_CATEGORY_ID)
{
List<Article> oList = new List<Article>();
Tools.Tools oTools = new Tools.Tools();
Article oArticle = new Article();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Article_By_CATEGORY_ID");}
#region Body Section.
List<DALC.Article> oList_DBEntries = _AppContext.Get_Article_By_CATEGORY_ID(i_Params_Get_Article_By_CATEGORY_ID.CATEGORY_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oArticle = new Article();
oTools.CopyPropValues(oDBEntry, oArticle);
oList.Add(oArticle);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Article_By_CATEGORY_ID");}
return oList;
}
public List<Category> Get_Category_By_OWNER_ID(Params_Get_Category_By_OWNER_ID i_Params_Get_Category_By_OWNER_ID)
{
List<Category> oList = new List<Category>();
Tools.Tools oTools = new Tools.Tools();
Category oCategory = new Category();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Category_By_OWNER_ID");}
#region Body Section.
List<DALC.Category> oList_DBEntries = _AppContext.Get_Category_By_OWNER_ID(i_Params_Get_Category_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCategory = new Category();
oTools.CopyPropValues(oDBEntry, oCategory);
oList.Add(oCategory);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Category_By_OWNER_ID");}
return oList;
}
public List<Evaluation> Get_Evaluation_By_OWNER_ID(Params_Get_Evaluation_By_OWNER_ID i_Params_Get_Evaluation_By_OWNER_ID)
{
List<Evaluation> oList = new List<Evaluation>();
Tools.Tools oTools = new Tools.Tools();
Evaluation oEvaluation = new Evaluation();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Evaluation_By_OWNER_ID");}
#region Body Section.
List<DALC.Evaluation> oList_DBEntries = _AppContext.Get_Evaluation_By_OWNER_ID(i_Params_Get_Evaluation_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oEvaluation = new Evaluation();
oTools.CopyPropValues(oDBEntry, oEvaluation);
oList.Add(oEvaluation);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Evaluation_By_OWNER_ID");}
return oList;
}
public List<Evaluation> Get_Evaluation_By_STUDENT_ID(Params_Get_Evaluation_By_STUDENT_ID i_Params_Get_Evaluation_By_STUDENT_ID)
{
List<Evaluation> oList = new List<Evaluation>();
Tools.Tools oTools = new Tools.Tools();
Evaluation oEvaluation = new Evaluation();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Evaluation_By_STUDENT_ID");}
#region Body Section.
List<DALC.Evaluation> oList_DBEntries = _AppContext.Get_Evaluation_By_STUDENT_ID(i_Params_Get_Evaluation_By_STUDENT_ID.STUDENT_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oEvaluation = new Evaluation();
oTools.CopyPropValues(oDBEntry, oEvaluation);
oList.Add(oEvaluation);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Evaluation_By_STUDENT_ID");}
return oList;
}
public List<Evaluation> Get_Evaluation_By_ANSWER_ID(Params_Get_Evaluation_By_ANSWER_ID i_Params_Get_Evaluation_By_ANSWER_ID)
{
List<Evaluation> oList = new List<Evaluation>();
Tools.Tools oTools = new Tools.Tools();
Evaluation oEvaluation = new Evaluation();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Evaluation_By_ANSWER_ID");}
#region Body Section.
List<DALC.Evaluation> oList_DBEntries = _AppContext.Get_Evaluation_By_ANSWER_ID(i_Params_Get_Evaluation_By_ANSWER_ID.ANSWER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oEvaluation = new Evaluation();
oTools.CopyPropValues(oDBEntry, oEvaluation);
oList.Add(oEvaluation);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Evaluation_By_ANSWER_ID");}
return oList;
}
public List<Favorite_category> Get_Favorite_category_By_STUDENT_ID(Params_Get_Favorite_category_By_STUDENT_ID i_Params_Get_Favorite_category_By_STUDENT_ID)
{
List<Favorite_category> oList = new List<Favorite_category>();
Tools.Tools oTools = new Tools.Tools();
Favorite_category oFavorite_category = new Favorite_category();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Favorite_category_By_STUDENT_ID");}
#region Body Section.
List<DALC.Favorite_category> oList_DBEntries = _AppContext.Get_Favorite_category_By_STUDENT_ID(i_Params_Get_Favorite_category_By_STUDENT_ID.STUDENT_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oFavorite_category = new Favorite_category();
oTools.CopyPropValues(oDBEntry, oFavorite_category);
oList.Add(oFavorite_category);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Favorite_category_By_STUDENT_ID");}
return oList;
}
public List<Favorite_category> Get_Favorite_category_By_CATEGORY_ID(Params_Get_Favorite_category_By_CATEGORY_ID i_Params_Get_Favorite_category_By_CATEGORY_ID)
{
List<Favorite_category> oList = new List<Favorite_category>();
Tools.Tools oTools = new Tools.Tools();
Favorite_category oFavorite_category = new Favorite_category();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Favorite_category_By_CATEGORY_ID");}
#region Body Section.
List<DALC.Favorite_category> oList_DBEntries = _AppContext.Get_Favorite_category_By_CATEGORY_ID(i_Params_Get_Favorite_category_By_CATEGORY_ID.CATEGORY_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oFavorite_category = new Favorite_category();
oTools.CopyPropValues(oDBEntry, oFavorite_category);
oList.Add(oFavorite_category);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Favorite_category_By_CATEGORY_ID");}
return oList;
}
public List<Favorite_category> Get_Favorite_category_By_OWNER_ID(Params_Get_Favorite_category_By_OWNER_ID i_Params_Get_Favorite_category_By_OWNER_ID)
{
List<Favorite_category> oList = new List<Favorite_category>();
Tools.Tools oTools = new Tools.Tools();
Favorite_category oFavorite_category = new Favorite_category();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Favorite_category_By_OWNER_ID");}
#region Body Section.
List<DALC.Favorite_category> oList_DBEntries = _AppContext.Get_Favorite_category_By_OWNER_ID(i_Params_Get_Favorite_category_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oFavorite_category = new Favorite_category();
oTools.CopyPropValues(oDBEntry, oFavorite_category);
oList.Add(oFavorite_category);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Favorite_category_By_OWNER_ID");}
return oList;
}
public List<Favorite_teacher> Get_Favorite_teacher_By_TEACHER_ID(Params_Get_Favorite_teacher_By_TEACHER_ID i_Params_Get_Favorite_teacher_By_TEACHER_ID)
{
List<Favorite_teacher> oList = new List<Favorite_teacher>();
Tools.Tools oTools = new Tools.Tools();
Favorite_teacher oFavorite_teacher = new Favorite_teacher();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Favorite_teacher_By_TEACHER_ID");}
#region Body Section.
List<DALC.Favorite_teacher> oList_DBEntries = _AppContext.Get_Favorite_teacher_By_TEACHER_ID(i_Params_Get_Favorite_teacher_By_TEACHER_ID.TEACHER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oFavorite_teacher = new Favorite_teacher();
oTools.CopyPropValues(oDBEntry, oFavorite_teacher);
oList.Add(oFavorite_teacher);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Favorite_teacher_By_TEACHER_ID");}
return oList;
}
public List<Favorite_teacher> Get_Favorite_teacher_By_STUDENT_ID(Params_Get_Favorite_teacher_By_STUDENT_ID i_Params_Get_Favorite_teacher_By_STUDENT_ID)
{
List<Favorite_teacher> oList = new List<Favorite_teacher>();
Tools.Tools oTools = new Tools.Tools();
Favorite_teacher oFavorite_teacher = new Favorite_teacher();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Favorite_teacher_By_STUDENT_ID");}
#region Body Section.
List<DALC.Favorite_teacher> oList_DBEntries = _AppContext.Get_Favorite_teacher_By_STUDENT_ID(i_Params_Get_Favorite_teacher_By_STUDENT_ID.STUDENT_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oFavorite_teacher = new Favorite_teacher();
oTools.CopyPropValues(oDBEntry, oFavorite_teacher);
oList.Add(oFavorite_teacher);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Favorite_teacher_By_STUDENT_ID");}
return oList;
}
public List<Favorite_teacher> Get_Favorite_teacher_By_OWNER_ID(Params_Get_Favorite_teacher_By_OWNER_ID i_Params_Get_Favorite_teacher_By_OWNER_ID)
{
List<Favorite_teacher> oList = new List<Favorite_teacher>();
Tools.Tools oTools = new Tools.Tools();
Favorite_teacher oFavorite_teacher = new Favorite_teacher();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Favorite_teacher_By_OWNER_ID");}
#region Body Section.
List<DALC.Favorite_teacher> oList_DBEntries = _AppContext.Get_Favorite_teacher_By_OWNER_ID(i_Params_Get_Favorite_teacher_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oFavorite_teacher = new Favorite_teacher();
oTools.CopyPropValues(oDBEntry, oFavorite_teacher);
oList.Add(oFavorite_teacher);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Favorite_teacher_By_OWNER_ID");}
return oList;
}
public List<Mark_question> Get_Mark_question_By_OWNER_ID(Params_Get_Mark_question_By_OWNER_ID i_Params_Get_Mark_question_By_OWNER_ID)
{
List<Mark_question> oList = new List<Mark_question>();
Tools.Tools oTools = new Tools.Tools();
Mark_question oMark_question = new Mark_question();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Mark_question_By_OWNER_ID");}
#region Body Section.
List<DALC.Mark_question> oList_DBEntries = _AppContext.Get_Mark_question_By_OWNER_ID(i_Params_Get_Mark_question_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oMark_question = new Mark_question();
oTools.CopyPropValues(oDBEntry, oMark_question);
oList.Add(oMark_question);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Mark_question_By_OWNER_ID");}
return oList;
}
public List<Mark_question> Get_Mark_question_By_QUESTION_ID(Params_Get_Mark_question_By_QUESTION_ID i_Params_Get_Mark_question_By_QUESTION_ID)
{
List<Mark_question> oList = new List<Mark_question>();
Tools.Tools oTools = new Tools.Tools();
Mark_question oMark_question = new Mark_question();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Mark_question_By_QUESTION_ID");}
#region Body Section.
List<DALC.Mark_question> oList_DBEntries = _AppContext.Get_Mark_question_By_QUESTION_ID(i_Params_Get_Mark_question_By_QUESTION_ID.QUESTION_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oMark_question = new Mark_question();
oTools.CopyPropValues(oDBEntry, oMark_question);
oList.Add(oMark_question);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Mark_question_By_QUESTION_ID");}
return oList;
}
public List<Mark_question> Get_Mark_question_By_STUDENT_ID(Params_Get_Mark_question_By_STUDENT_ID i_Params_Get_Mark_question_By_STUDENT_ID)
{
List<Mark_question> oList = new List<Mark_question>();
Tools.Tools oTools = new Tools.Tools();
Mark_question oMark_question = new Mark_question();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Mark_question_By_STUDENT_ID");}
#region Body Section.
List<DALC.Mark_question> oList_DBEntries = _AppContext.Get_Mark_question_By_STUDENT_ID(i_Params_Get_Mark_question_By_STUDENT_ID.STUDENT_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oMark_question = new Mark_question();
oTools.CopyPropValues(oDBEntry, oMark_question);
oList.Add(oMark_question);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Mark_question_By_STUDENT_ID");}
return oList;
}
public List<Notification> Get_Notification_By_OWNER_ID(Params_Get_Notification_By_OWNER_ID i_Params_Get_Notification_By_OWNER_ID)
{
List<Notification> oList = new List<Notification>();
Tools.Tools oTools = new Tools.Tools();
Notification oNotification = new Notification();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Notification_By_OWNER_ID");}
#region Body Section.
List<DALC.Notification> oList_DBEntries = _AppContext.Get_Notification_By_OWNER_ID(i_Params_Get_Notification_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oNotification = new Notification();
oTools.CopyPropValues(oDBEntry, oNotification);
oList.Add(oNotification);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Notification_By_OWNER_ID");}
return oList;
}
public List<Notification> Get_Notification_By_USER_ID(Params_Get_Notification_By_USER_ID i_Params_Get_Notification_By_USER_ID)
{
List<Notification> oList = new List<Notification>();
Tools.Tools oTools = new Tools.Tools();
Notification oNotification = new Notification();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Notification_By_USER_ID");}
#region Body Section.
List<DALC.Notification> oList_DBEntries = _AppContext.Get_Notification_By_USER_ID(i_Params_Get_Notification_By_USER_ID.USER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oNotification = new Notification();
oTools.CopyPropValues(oDBEntry, oNotification);
oList.Add(oNotification);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Notification_By_USER_ID");}
return oList;
}
public List<Notification> Get_Notification_By_QUESTION_ID(Params_Get_Notification_By_QUESTION_ID i_Params_Get_Notification_By_QUESTION_ID)
{
List<Notification> oList = new List<Notification>();
Tools.Tools oTools = new Tools.Tools();
Notification oNotification = new Notification();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Notification_By_QUESTION_ID");}
#region Body Section.
List<DALC.Notification> oList_DBEntries = _AppContext.Get_Notification_By_QUESTION_ID(i_Params_Get_Notification_By_QUESTION_ID.QUESTION_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oNotification = new Notification();
oTools.CopyPropValues(oDBEntry, oNotification);
oList.Add(oNotification);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Notification_By_QUESTION_ID");}
return oList;
}
public List<Notification> Get_Notification_By_ANSWER_ID(Params_Get_Notification_By_ANSWER_ID i_Params_Get_Notification_By_ANSWER_ID)
{
List<Notification> oList = new List<Notification>();
Tools.Tools oTools = new Tools.Tools();
Notification oNotification = new Notification();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Notification_By_ANSWER_ID");}
#region Body Section.
List<DALC.Notification> oList_DBEntries = _AppContext.Get_Notification_By_ANSWER_ID(i_Params_Get_Notification_By_ANSWER_ID.ANSWER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oNotification = new Notification();
oTools.CopyPropValues(oDBEntry, oNotification);
oList.Add(oNotification);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Notification_By_ANSWER_ID");}
return oList;
}
public List<Question> Get_Question_By_OWNER_ID(Params_Get_Question_By_OWNER_ID i_Params_Get_Question_By_OWNER_ID)
{
List<Question> oList = new List<Question>();
Tools.Tools oTools = new Tools.Tools();
Question oQuestion = new Question();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Question_By_OWNER_ID");}
#region Body Section.
List<DALC.Question> oList_DBEntries = _AppContext.Get_Question_By_OWNER_ID(i_Params_Get_Question_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oQuestion = new Question();
oTools.CopyPropValues(oDBEntry, oQuestion);
oList.Add(oQuestion);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Question_By_OWNER_ID");}
return oList;
}
public List<Question> Get_Question_By_STUDENT_ID(Params_Get_Question_By_STUDENT_ID i_Params_Get_Question_By_STUDENT_ID)
{
List<Question> oList = new List<Question>();
Tools.Tools oTools = new Tools.Tools();
Question oQuestion = new Question();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Question_By_STUDENT_ID");}
#region Body Section.
List<DALC.Question> oList_DBEntries = _AppContext.Get_Question_By_STUDENT_ID(i_Params_Get_Question_By_STUDENT_ID.STUDENT_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oQuestion = new Question();
oTools.CopyPropValues(oDBEntry, oQuestion);
oList.Add(oQuestion);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Question_By_STUDENT_ID");}
return oList;
}
public List<Question> Get_Question_By_CATEGORY_ID(Params_Get_Question_By_CATEGORY_ID i_Params_Get_Question_By_CATEGORY_ID)
{
List<Question> oList = new List<Question>();
Tools.Tools oTools = new Tools.Tools();
Question oQuestion = new Question();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Question_By_CATEGORY_ID");}
#region Body Section.
List<DALC.Question> oList_DBEntries = _AppContext.Get_Question_By_CATEGORY_ID(i_Params_Get_Question_By_CATEGORY_ID.CATEGORY_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oQuestion = new Question();
oTools.CopyPropValues(oDBEntry, oQuestion);
oList.Add(oQuestion);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Question_By_CATEGORY_ID");}
return oList;
}
public List<Question> Get_Question_By_TEACHER_ID(Params_Get_Question_By_TEACHER_ID i_Params_Get_Question_By_TEACHER_ID)
{
List<Question> oList = new List<Question>();
Tools.Tools oTools = new Tools.Tools();
Question oQuestion = new Question();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Question_By_TEACHER_ID");}
#region Body Section.
List<DALC.Question> oList_DBEntries = _AppContext.Get_Question_By_TEACHER_ID(i_Params_Get_Question_By_TEACHER_ID.TEACHER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oQuestion = new Question();
oTools.CopyPropValues(oDBEntry, oQuestion);
oList.Add(oQuestion);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Question_By_TEACHER_ID");}
return oList;
}
public List<Question_report> Get_Question_report_By_OWNER_ID(Params_Get_Question_report_By_OWNER_ID i_Params_Get_Question_report_By_OWNER_ID)
{
List<Question_report> oList = new List<Question_report>();
Tools.Tools oTools = new Tools.Tools();
Question_report oQuestion_report = new Question_report();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Question_report_By_OWNER_ID");}
#region Body Section.
List<DALC.Question_report> oList_DBEntries = _AppContext.Get_Question_report_By_OWNER_ID(i_Params_Get_Question_report_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oQuestion_report = new Question_report();
oTools.CopyPropValues(oDBEntry, oQuestion_report);
oList.Add(oQuestion_report);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Question_report_By_OWNER_ID");}
return oList;
}
public List<Question_report> Get_Question_report_By_STUDENT_ID(Params_Get_Question_report_By_STUDENT_ID i_Params_Get_Question_report_By_STUDENT_ID)
{
List<Question_report> oList = new List<Question_report>();
Tools.Tools oTools = new Tools.Tools();
Question_report oQuestion_report = new Question_report();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Question_report_By_STUDENT_ID");}
#region Body Section.
List<DALC.Question_report> oList_DBEntries = _AppContext.Get_Question_report_By_STUDENT_ID(i_Params_Get_Question_report_By_STUDENT_ID.STUDENT_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oQuestion_report = new Question_report();
oTools.CopyPropValues(oDBEntry, oQuestion_report);
oList.Add(oQuestion_report);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Question_report_By_STUDENT_ID");}
return oList;
}
public List<Question_report> Get_Question_report_By_TEACHER_ID(Params_Get_Question_report_By_TEACHER_ID i_Params_Get_Question_report_By_TEACHER_ID)
{
List<Question_report> oList = new List<Question_report>();
Tools.Tools oTools = new Tools.Tools();
Question_report oQuestion_report = new Question_report();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Question_report_By_TEACHER_ID");}
#region Body Section.
List<DALC.Question_report> oList_DBEntries = _AppContext.Get_Question_report_By_TEACHER_ID(i_Params_Get_Question_report_By_TEACHER_ID.TEACHER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oQuestion_report = new Question_report();
oTools.CopyPropValues(oDBEntry, oQuestion_report);
oList.Add(oQuestion_report);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Question_report_By_TEACHER_ID");}
return oList;
}
public List<Question_report> Get_Question_report_By_QUESTION_ID(Params_Get_Question_report_By_QUESTION_ID i_Params_Get_Question_report_By_QUESTION_ID)
{
List<Question_report> oList = new List<Question_report>();
Tools.Tools oTools = new Tools.Tools();
Question_report oQuestion_report = new Question_report();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Question_report_By_QUESTION_ID");}
#region Body Section.
List<DALC.Question_report> oList_DBEntries = _AppContext.Get_Question_report_By_QUESTION_ID(i_Params_Get_Question_report_By_QUESTION_ID.QUESTION_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oQuestion_report = new Question_report();
oTools.CopyPropValues(oDBEntry, oQuestion_report);
oList.Add(oQuestion_report);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Question_report_By_QUESTION_ID");}
return oList;
}
public List<Question_token> Get_Question_token_By_PART(Params_Get_Question_token_By_PART i_Params_Get_Question_token_By_PART)
{
List<Question_token> oList = new List<Question_token>();
Tools.Tools oTools = new Tools.Tools();
Question_token oQuestion_token = new Question_token();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Question_token_By_PART");}
#region Body Section.
List<DALC.Question_token> oList_DBEntries = _AppContext.Get_Question_token_By_PART(i_Params_Get_Question_token_By_PART.PART);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oQuestion_token = new Question_token();
oTools.CopyPropValues(oDBEntry, oQuestion_token);
oList.Add(oQuestion_token);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Question_token_By_PART");}
return oList;
}
public List<Question_token> Get_Question_token_By_OWNER_ID(Params_Get_Question_token_By_OWNER_ID i_Params_Get_Question_token_By_OWNER_ID)
{
List<Question_token> oList = new List<Question_token>();
Tools.Tools oTools = new Tools.Tools();
Question_token oQuestion_token = new Question_token();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Question_token_By_OWNER_ID");}
#region Body Section.
List<DALC.Question_token> oList_DBEntries = _AppContext.Get_Question_token_By_OWNER_ID(i_Params_Get_Question_token_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oQuestion_token = new Question_token();
oTools.CopyPropValues(oDBEntry, oQuestion_token);
oList.Add(oQuestion_token);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Question_token_By_OWNER_ID");}
return oList;
}
public List<Question_token> Get_Question_token_By_QUESTION_ID(Params_Get_Question_token_By_QUESTION_ID i_Params_Get_Question_token_By_QUESTION_ID)
{
List<Question_token> oList = new List<Question_token>();
Tools.Tools oTools = new Tools.Tools();
Question_token oQuestion_token = new Question_token();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Question_token_By_QUESTION_ID");}
#region Body Section.
List<DALC.Question_token> oList_DBEntries = _AppContext.Get_Question_token_By_QUESTION_ID(i_Params_Get_Question_token_By_QUESTION_ID.QUESTION_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oQuestion_token = new Question_token();
oTools.CopyPropValues(oDBEntry, oQuestion_token);
oList.Add(oQuestion_token);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Question_token_By_QUESTION_ID");}
return oList;
}
public List<Report_article> Get_Report_article_By_OWNER_ID(Params_Get_Report_article_By_OWNER_ID i_Params_Get_Report_article_By_OWNER_ID)
{
List<Report_article> oList = new List<Report_article>();
Tools.Tools oTools = new Tools.Tools();
Report_article oReport_article = new Report_article();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Report_article_By_OWNER_ID");}
#region Body Section.
List<DALC.Report_article> oList_DBEntries = _AppContext.Get_Report_article_By_OWNER_ID(i_Params_Get_Report_article_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oReport_article = new Report_article();
oTools.CopyPropValues(oDBEntry, oReport_article);
oList.Add(oReport_article);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Report_article_By_OWNER_ID");}
return oList;
}
public List<Report_article> Get_Report_article_By_ARTICLE_ID(Params_Get_Report_article_By_ARTICLE_ID i_Params_Get_Report_article_By_ARTICLE_ID)
{
List<Report_article> oList = new List<Report_article>();
Tools.Tools oTools = new Tools.Tools();
Report_article oReport_article = new Report_article();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Report_article_By_ARTICLE_ID");}
#region Body Section.
List<DALC.Report_article> oList_DBEntries = _AppContext.Get_Report_article_By_ARTICLE_ID(i_Params_Get_Report_article_By_ARTICLE_ID.ARTICLE_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oReport_article = new Report_article();
oTools.CopyPropValues(oDBEntry, oReport_article);
oList.Add(oReport_article);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Report_article_By_ARTICLE_ID");}
return oList;
}
public List<Report_article> Get_Report_article_By_STUDENT_ID(Params_Get_Report_article_By_STUDENT_ID i_Params_Get_Report_article_By_STUDENT_ID)
{
List<Report_article> oList = new List<Report_article>();
Tools.Tools oTools = new Tools.Tools();
Report_article oReport_article = new Report_article();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Report_article_By_STUDENT_ID");}
#region Body Section.
List<DALC.Report_article> oList_DBEntries = _AppContext.Get_Report_article_By_STUDENT_ID(i_Params_Get_Report_article_By_STUDENT_ID.STUDENT_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oReport_article = new Report_article();
oTools.CopyPropValues(oDBEntry, oReport_article);
oList.Add(oReport_article);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Report_article_By_STUDENT_ID");}
return oList;
}
public List<Student> Get_Student_By_OWNER_ID(Params_Get_Student_By_OWNER_ID i_Params_Get_Student_By_OWNER_ID)
{
List<Student> oList = new List<Student>();
Tools.Tools oTools = new Tools.Tools();
Student oStudent = new Student();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Student_By_OWNER_ID");}
#region Body Section.
List<DALC.Student> oList_DBEntries = _AppContext.Get_Student_By_OWNER_ID(i_Params_Get_Student_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oStudent = new Student();
oTools.CopyPropValues(oDBEntry, oStudent);
oList.Add(oStudent);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Student_By_OWNER_ID");}
return oList;
}
public List<Student> Get_Student_By_USER_ID(Params_Get_Student_By_USER_ID i_Params_Get_Student_By_USER_ID)
{
List<Student> oList = new List<Student>();
Tools.Tools oTools = new Tools.Tools();
Student oStudent = new Student();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Student_By_USER_ID");}
#region Body Section.
List<DALC.Student> oList_DBEntries = _AppContext.Get_Student_By_USER_ID(i_Params_Get_Student_By_USER_ID.USER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oStudent = new Student();
oTools.CopyPropValues(oDBEntry, oStudent);
oList.Add(oStudent);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Student_By_USER_ID");}
return oList;
}
public List<Student_report> Get_Student_report_By_OWNER_ID(Params_Get_Student_report_By_OWNER_ID i_Params_Get_Student_report_By_OWNER_ID)
{
List<Student_report> oList = new List<Student_report>();
Tools.Tools oTools = new Tools.Tools();
Student_report oStudent_report = new Student_report();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Student_report_By_OWNER_ID");}
#region Body Section.
List<DALC.Student_report> oList_DBEntries = _AppContext.Get_Student_report_By_OWNER_ID(i_Params_Get_Student_report_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oStudent_report = new Student_report();
oTools.CopyPropValues(oDBEntry, oStudent_report);
oList.Add(oStudent_report);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Student_report_By_OWNER_ID");}
return oList;
}
public List<Student_report> Get_Student_report_By_REPORTED_BY_STUDENT_ID(Params_Get_Student_report_By_REPORTED_BY_STUDENT_ID i_Params_Get_Student_report_By_REPORTED_BY_STUDENT_ID)
{
List<Student_report> oList = new List<Student_report>();
Tools.Tools oTools = new Tools.Tools();
Student_report oStudent_report = new Student_report();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Student_report_By_REPORTED_BY_STUDENT_ID");}
#region Body Section.
List<DALC.Student_report> oList_DBEntries = _AppContext.Get_Student_report_By_REPORTED_BY_STUDENT_ID(i_Params_Get_Student_report_By_REPORTED_BY_STUDENT_ID.REPORTED_BY_STUDENT_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oStudent_report = new Student_report();
oTools.CopyPropValues(oDBEntry, oStudent_report);
oList.Add(oStudent_report);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Student_report_By_REPORTED_BY_STUDENT_ID");}
return oList;
}
public List<Student_report> Get_Student_report_By_REPORTED_STUDENT_ID(Params_Get_Student_report_By_REPORTED_STUDENT_ID i_Params_Get_Student_report_By_REPORTED_STUDENT_ID)
{
List<Student_report> oList = new List<Student_report>();
Tools.Tools oTools = new Tools.Tools();
Student_report oStudent_report = new Student_report();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Student_report_By_REPORTED_STUDENT_ID");}
#region Body Section.
List<DALC.Student_report> oList_DBEntries = _AppContext.Get_Student_report_By_REPORTED_STUDENT_ID(i_Params_Get_Student_report_By_REPORTED_STUDENT_ID.REPORTED_STUDENT_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oStudent_report = new Student_report();
oTools.CopyPropValues(oDBEntry, oStudent_report);
oList.Add(oStudent_report);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Student_report_By_REPORTED_STUDENT_ID");}
return oList;
}
public List<Teacher> Get_Teacher_By_OWNER_ID(Params_Get_Teacher_By_OWNER_ID i_Params_Get_Teacher_By_OWNER_ID)
{
List<Teacher> oList = new List<Teacher>();
Tools.Tools oTools = new Tools.Tools();
Teacher oTeacher = new Teacher();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_By_OWNER_ID");}
#region Body Section.
List<DALC.Teacher> oList_DBEntries = _AppContext.Get_Teacher_By_OWNER_ID(i_Params_Get_Teacher_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher = new Teacher();
oTools.CopyPropValues(oDBEntry, oTeacher);
oList.Add(oTeacher);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_By_OWNER_ID");}
return oList;
}
public List<Teacher> Get_Teacher_By_USER_ID(Params_Get_Teacher_By_USER_ID i_Params_Get_Teacher_By_USER_ID)
{
List<Teacher> oList = new List<Teacher>();
Tools.Tools oTools = new Tools.Tools();
Teacher oTeacher = new Teacher();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_By_USER_ID");}
#region Body Section.
List<DALC.Teacher> oList_DBEntries = _AppContext.Get_Teacher_By_USER_ID(i_Params_Get_Teacher_By_USER_ID.USER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher = new Teacher();
oTools.CopyPropValues(oDBEntry, oTeacher);
oList.Add(oTeacher);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_By_USER_ID");}
return oList;
}
public List<Teacher_category> Get_Teacher_category_By_OWNER_ID(Params_Get_Teacher_category_By_OWNER_ID i_Params_Get_Teacher_category_By_OWNER_ID)
{
List<Teacher_category> oList = new List<Teacher_category>();
Tools.Tools oTools = new Tools.Tools();
Teacher_category oTeacher_category = new Teacher_category();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_category_By_OWNER_ID");}
#region Body Section.
List<DALC.Teacher_category> oList_DBEntries = _AppContext.Get_Teacher_category_By_OWNER_ID(i_Params_Get_Teacher_category_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_category = new Teacher_category();
oTools.CopyPropValues(oDBEntry, oTeacher_category);
oList.Add(oTeacher_category);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_category_By_OWNER_ID");}
return oList;
}
public List<Teacher_category> Get_Teacher_category_By_TEACHER_ID(Params_Get_Teacher_category_By_TEACHER_ID i_Params_Get_Teacher_category_By_TEACHER_ID)
{
List<Teacher_category> oList = new List<Teacher_category>();
Tools.Tools oTools = new Tools.Tools();
Teacher_category oTeacher_category = new Teacher_category();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_category_By_TEACHER_ID");}
#region Body Section.
List<DALC.Teacher_category> oList_DBEntries = _AppContext.Get_Teacher_category_By_TEACHER_ID(i_Params_Get_Teacher_category_By_TEACHER_ID.TEACHER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_category = new Teacher_category();
oTools.CopyPropValues(oDBEntry, oTeacher_category);
oList.Add(oTeacher_category);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_category_By_TEACHER_ID");}
return oList;
}
public List<Teacher_category> Get_Teacher_category_By_CATEGORY_ID(Params_Get_Teacher_category_By_CATEGORY_ID i_Params_Get_Teacher_category_By_CATEGORY_ID)
{
List<Teacher_category> oList = new List<Teacher_category>();
Tools.Tools oTools = new Tools.Tools();
Teacher_category oTeacher_category = new Teacher_category();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_category_By_CATEGORY_ID");}
#region Body Section.
List<DALC.Teacher_category> oList_DBEntries = _AppContext.Get_Teacher_category_By_CATEGORY_ID(i_Params_Get_Teacher_category_By_CATEGORY_ID.CATEGORY_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_category = new Teacher_category();
oTools.CopyPropValues(oDBEntry, oTeacher_category);
oList.Add(oTeacher_category);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_category_By_CATEGORY_ID");}
return oList;
}
public List<Teacher_favorite> Get_Teacher_favorite_By_OWNER_ID(Params_Get_Teacher_favorite_By_OWNER_ID i_Params_Get_Teacher_favorite_By_OWNER_ID)
{
List<Teacher_favorite> oList = new List<Teacher_favorite>();
Tools.Tools oTools = new Tools.Tools();
Teacher_favorite oTeacher_favorite = new Teacher_favorite();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_favorite_By_OWNER_ID");}
#region Body Section.
List<DALC.Teacher_favorite> oList_DBEntries = _AppContext.Get_Teacher_favorite_By_OWNER_ID(i_Params_Get_Teacher_favorite_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_favorite = new Teacher_favorite();
oTools.CopyPropValues(oDBEntry, oTeacher_favorite);
oList.Add(oTeacher_favorite);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_favorite_By_OWNER_ID");}
return oList;
}
public List<Teacher_favorite> Get_Teacher_favorite_By_TEACHER_ID(Params_Get_Teacher_favorite_By_TEACHER_ID i_Params_Get_Teacher_favorite_By_TEACHER_ID)
{
List<Teacher_favorite> oList = new List<Teacher_favorite>();
Tools.Tools oTools = new Tools.Tools();
Teacher_favorite oTeacher_favorite = new Teacher_favorite();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_favorite_By_TEACHER_ID");}
#region Body Section.
List<DALC.Teacher_favorite> oList_DBEntries = _AppContext.Get_Teacher_favorite_By_TEACHER_ID(i_Params_Get_Teacher_favorite_By_TEACHER_ID.TEACHER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_favorite = new Teacher_favorite();
oTools.CopyPropValues(oDBEntry, oTeacher_favorite);
oList.Add(oTeacher_favorite);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_favorite_By_TEACHER_ID");}
return oList;
}
public List<Teacher_favorite> Get_Teacher_favorite_By_STUDENT_ID(Params_Get_Teacher_favorite_By_STUDENT_ID i_Params_Get_Teacher_favorite_By_STUDENT_ID)
{
List<Teacher_favorite> oList = new List<Teacher_favorite>();
Tools.Tools oTools = new Tools.Tools();
Teacher_favorite oTeacher_favorite = new Teacher_favorite();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_favorite_By_STUDENT_ID");}
#region Body Section.
List<DALC.Teacher_favorite> oList_DBEntries = _AppContext.Get_Teacher_favorite_By_STUDENT_ID(i_Params_Get_Teacher_favorite_By_STUDENT_ID.STUDENT_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_favorite = new Teacher_favorite();
oTools.CopyPropValues(oDBEntry, oTeacher_favorite);
oList.Add(oTeacher_favorite);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_favorite_By_STUDENT_ID");}
return oList;
}
public List<Teacher_rank> Get_Teacher_rank_By_TEACHER_ID(Params_Get_Teacher_rank_By_TEACHER_ID i_Params_Get_Teacher_rank_By_TEACHER_ID)
{
List<Teacher_rank> oList = new List<Teacher_rank>();
Tools.Tools oTools = new Tools.Tools();
Teacher_rank oTeacher_rank = new Teacher_rank();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_rank_By_TEACHER_ID");}
#region Body Section.
List<DALC.Teacher_rank> oList_DBEntries = _AppContext.Get_Teacher_rank_By_TEACHER_ID(i_Params_Get_Teacher_rank_By_TEACHER_ID.TEACHER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_rank = new Teacher_rank();
oTools.CopyPropValues(oDBEntry, oTeacher_rank);
oList.Add(oTeacher_rank);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_rank_By_TEACHER_ID");}
return oList;
}
public List<Teacher_rank> Get_Teacher_rank_By_OWNER_ID(Params_Get_Teacher_rank_By_OWNER_ID i_Params_Get_Teacher_rank_By_OWNER_ID)
{
List<Teacher_rank> oList = new List<Teacher_rank>();
Tools.Tools oTools = new Tools.Tools();
Teacher_rank oTeacher_rank = new Teacher_rank();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_rank_By_OWNER_ID");}
#region Body Section.
List<DALC.Teacher_rank> oList_DBEntries = _AppContext.Get_Teacher_rank_By_OWNER_ID(i_Params_Get_Teacher_rank_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_rank = new Teacher_rank();
oTools.CopyPropValues(oDBEntry, oTeacher_rank);
oList.Add(oTeacher_rank);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_rank_By_OWNER_ID");}
return oList;
}
public List<Teacher_report> Get_Teacher_report_By_OWNER_ID(Params_Get_Teacher_report_By_OWNER_ID i_Params_Get_Teacher_report_By_OWNER_ID)
{
List<Teacher_report> oList = new List<Teacher_report>();
Tools.Tools oTools = new Tools.Tools();
Teacher_report oTeacher_report = new Teacher_report();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_report_By_OWNER_ID");}
#region Body Section.
List<DALC.Teacher_report> oList_DBEntries = _AppContext.Get_Teacher_report_By_OWNER_ID(i_Params_Get_Teacher_report_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_report = new Teacher_report();
oTools.CopyPropValues(oDBEntry, oTeacher_report);
oList.Add(oTeacher_report);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_report_By_OWNER_ID");}
return oList;
}
public List<Teacher_report> Get_Teacher_report_By_TEACHER_ID(Params_Get_Teacher_report_By_TEACHER_ID i_Params_Get_Teacher_report_By_TEACHER_ID)
{
List<Teacher_report> oList = new List<Teacher_report>();
Tools.Tools oTools = new Tools.Tools();
Teacher_report oTeacher_report = new Teacher_report();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_report_By_TEACHER_ID");}
#region Body Section.
List<DALC.Teacher_report> oList_DBEntries = _AppContext.Get_Teacher_report_By_TEACHER_ID(i_Params_Get_Teacher_report_By_TEACHER_ID.TEACHER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_report = new Teacher_report();
oTools.CopyPropValues(oDBEntry, oTeacher_report);
oList.Add(oTeacher_report);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_report_By_TEACHER_ID");}
return oList;
}
public List<Teacher_report> Get_Teacher_report_By_STUDENT_ID(Params_Get_Teacher_report_By_STUDENT_ID i_Params_Get_Teacher_report_By_STUDENT_ID)
{
List<Teacher_report> oList = new List<Teacher_report>();
Tools.Tools oTools = new Tools.Tools();
Teacher_report oTeacher_report = new Teacher_report();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_report_By_STUDENT_ID");}
#region Body Section.
List<DALC.Teacher_report> oList_DBEntries = _AppContext.Get_Teacher_report_By_STUDENT_ID(i_Params_Get_Teacher_report_By_STUDENT_ID.STUDENT_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_report = new Teacher_report();
oTools.CopyPropValues(oDBEntry, oTeacher_report);
oList.Add(oTeacher_report);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_report_By_STUDENT_ID");}
return oList;
}
public List<User> Get_User_By_OWNER_ID(Params_Get_User_By_OWNER_ID i_Params_Get_User_By_OWNER_ID)
{
List<User> oList = new List<User>();
Tools.Tools oTools = new Tools.Tools();
User oUser = new User();
if (OnPreEvent_General != null){OnPreEvent_General("Get_User_By_OWNER_ID");}
#region Body Section.
List<DALC.User> oList_DBEntries = _AppContext.Get_User_By_OWNER_ID(i_Params_Get_User_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oUser = new User();
oTools.CopyPropValues(oDBEntry, oUser);
oList.Add(oUser);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_User_By_OWNER_ID");}
return oList;
}
public List<User> Get_User_By_USERNAME(Params_Get_User_By_USERNAME i_Params_Get_User_By_USERNAME)
{
List<User> oList = new List<User>();
Tools.Tools oTools = new Tools.Tools();
User oUser = new User();
if (OnPreEvent_General != null){OnPreEvent_General("Get_User_By_USERNAME");}
#region Body Section.
List<DALC.User> oList_DBEntries = _AppContext.Get_User_By_USERNAME(i_Params_Get_User_By_USERNAME.USERNAME);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oUser = new User();
oTools.CopyPropValues(oDBEntry, oUser);
oList.Add(oUser);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_User_By_USERNAME");}
return oList;
}
public List<Answer> Get_Answer_By_QUESTION_ID_List(Params_Get_Answer_By_QUESTION_ID_List i_Params_Get_Answer_By_QUESTION_ID_List)
{
List<Answer> oList = new List<Answer>();
Tools.Tools oTools = new Tools.Tools();
Answer oAnswer = new Answer();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Answer_By_QUESTION_ID_List");}
#region Body Section.
List<DALC.Answer> oList_DBEntries = _AppContext.Get_Answer_By_QUESTION_ID_List(i_Params_Get_Answer_By_QUESTION_ID_List.QUESTION_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oAnswer = new Answer();
oTools.CopyPropValues(oDBEntry, oAnswer);
oList.Add(oAnswer);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Answer_By_QUESTION_ID_List");}
return oList;
}
public List<Answer> Get_Answer_By_TEACHER_ID_List(Params_Get_Answer_By_TEACHER_ID_List i_Params_Get_Answer_By_TEACHER_ID_List)
{
List<Answer> oList = new List<Answer>();
Tools.Tools oTools = new Tools.Tools();
Answer oAnswer = new Answer();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Answer_By_TEACHER_ID_List");}
#region Body Section.
List<DALC.Answer> oList_DBEntries = _AppContext.Get_Answer_By_TEACHER_ID_List(i_Params_Get_Answer_By_TEACHER_ID_List.TEACHER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oAnswer = new Answer();
oTools.CopyPropValues(oDBEntry, oAnswer);
oList.Add(oAnswer);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Answer_By_TEACHER_ID_List");}
return oList;
}
public List<Answer_report> Get_Answer_report_By_TEACHER_ID_List(Params_Get_Answer_report_By_TEACHER_ID_List i_Params_Get_Answer_report_By_TEACHER_ID_List)
{
List<Answer_report> oList = new List<Answer_report>();
Tools.Tools oTools = new Tools.Tools();
Answer_report oAnswer_report = new Answer_report();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Answer_report_By_TEACHER_ID_List");}
#region Body Section.
List<DALC.Answer_report> oList_DBEntries = _AppContext.Get_Answer_report_By_TEACHER_ID_List(i_Params_Get_Answer_report_By_TEACHER_ID_List.TEACHER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oAnswer_report = new Answer_report();
oTools.CopyPropValues(oDBEntry, oAnswer_report);
oList.Add(oAnswer_report);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Answer_report_By_TEACHER_ID_List");}
return oList;
}
public List<Answer_report> Get_Answer_report_By_STUDENT_ID_List(Params_Get_Answer_report_By_STUDENT_ID_List i_Params_Get_Answer_report_By_STUDENT_ID_List)
{
List<Answer_report> oList = new List<Answer_report>();
Tools.Tools oTools = new Tools.Tools();
Answer_report oAnswer_report = new Answer_report();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Answer_report_By_STUDENT_ID_List");}
#region Body Section.
List<DALC.Answer_report> oList_DBEntries = _AppContext.Get_Answer_report_By_STUDENT_ID_List(i_Params_Get_Answer_report_By_STUDENT_ID_List.STUDENT_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oAnswer_report = new Answer_report();
oTools.CopyPropValues(oDBEntry, oAnswer_report);
oList.Add(oAnswer_report);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Answer_report_By_STUDENT_ID_List");}
return oList;
}
public List<Answer_report> Get_Answer_report_By_ANSWER_ID_List(Params_Get_Answer_report_By_ANSWER_ID_List i_Params_Get_Answer_report_By_ANSWER_ID_List)
{
List<Answer_report> oList = new List<Answer_report>();
Tools.Tools oTools = new Tools.Tools();
Answer_report oAnswer_report = new Answer_report();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Answer_report_By_ANSWER_ID_List");}
#region Body Section.
List<DALC.Answer_report> oList_DBEntries = _AppContext.Get_Answer_report_By_ANSWER_ID_List(i_Params_Get_Answer_report_By_ANSWER_ID_List.ANSWER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oAnswer_report = new Answer_report();
oTools.CopyPropValues(oDBEntry, oAnswer_report);
oList.Add(oAnswer_report);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Answer_report_By_ANSWER_ID_List");}
return oList;
}
public List<Appreciate> Get_Appreciate_By_ARTICLE_ID_List(Params_Get_Appreciate_By_ARTICLE_ID_List i_Params_Get_Appreciate_By_ARTICLE_ID_List)
{
List<Appreciate> oList = new List<Appreciate>();
Tools.Tools oTools = new Tools.Tools();
Appreciate oAppreciate = new Appreciate();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Appreciate_By_ARTICLE_ID_List");}
#region Body Section.
List<DALC.Appreciate> oList_DBEntries = _AppContext.Get_Appreciate_By_ARTICLE_ID_List(i_Params_Get_Appreciate_By_ARTICLE_ID_List.ARTICLE_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oAppreciate = new Appreciate();
oTools.CopyPropValues(oDBEntry, oAppreciate);
oList.Add(oAppreciate);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Appreciate_By_ARTICLE_ID_List");}
return oList;
}
public List<Appreciate> Get_Appreciate_By_STUDENT_ID_List(Params_Get_Appreciate_By_STUDENT_ID_List i_Params_Get_Appreciate_By_STUDENT_ID_List)
{
List<Appreciate> oList = new List<Appreciate>();
Tools.Tools oTools = new Tools.Tools();
Appreciate oAppreciate = new Appreciate();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Appreciate_By_STUDENT_ID_List");}
#region Body Section.
List<DALC.Appreciate> oList_DBEntries = _AppContext.Get_Appreciate_By_STUDENT_ID_List(i_Params_Get_Appreciate_By_STUDENT_ID_List.STUDENT_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oAppreciate = new Appreciate();
oTools.CopyPropValues(oDBEntry, oAppreciate);
oList.Add(oAppreciate);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Appreciate_By_STUDENT_ID_List");}
return oList;
}
public List<Article> Get_Article_By_TEACHER_ID_List(Params_Get_Article_By_TEACHER_ID_List i_Params_Get_Article_By_TEACHER_ID_List)
{
List<Article> oList = new List<Article>();
Tools.Tools oTools = new Tools.Tools();
Article oArticle = new Article();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Article_By_TEACHER_ID_List");}
#region Body Section.
List<DALC.Article> oList_DBEntries = _AppContext.Get_Article_By_TEACHER_ID_List(i_Params_Get_Article_By_TEACHER_ID_List.TEACHER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oArticle = new Article();
oTools.CopyPropValues(oDBEntry, oArticle);
oList.Add(oArticle);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Article_By_TEACHER_ID_List");}
return oList;
}
public List<Article> Get_Article_By_CATEGORY_ID_List(Params_Get_Article_By_CATEGORY_ID_List i_Params_Get_Article_By_CATEGORY_ID_List)
{
List<Article> oList = new List<Article>();
Tools.Tools oTools = new Tools.Tools();
Article oArticle = new Article();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Article_By_CATEGORY_ID_List");}
#region Body Section.
List<DALC.Article> oList_DBEntries = _AppContext.Get_Article_By_CATEGORY_ID_List(i_Params_Get_Article_By_CATEGORY_ID_List.CATEGORY_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oArticle = new Article();
oTools.CopyPropValues(oDBEntry, oArticle);
oList.Add(oArticle);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Article_By_CATEGORY_ID_List");}
return oList;
}
public List<Evaluation> Get_Evaluation_By_STUDENT_ID_List(Params_Get_Evaluation_By_STUDENT_ID_List i_Params_Get_Evaluation_By_STUDENT_ID_List)
{
List<Evaluation> oList = new List<Evaluation>();
Tools.Tools oTools = new Tools.Tools();
Evaluation oEvaluation = new Evaluation();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Evaluation_By_STUDENT_ID_List");}
#region Body Section.
List<DALC.Evaluation> oList_DBEntries = _AppContext.Get_Evaluation_By_STUDENT_ID_List(i_Params_Get_Evaluation_By_STUDENT_ID_List.STUDENT_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oEvaluation = new Evaluation();
oTools.CopyPropValues(oDBEntry, oEvaluation);
oList.Add(oEvaluation);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Evaluation_By_STUDENT_ID_List");}
return oList;
}
public List<Evaluation> Get_Evaluation_By_ANSWER_ID_List(Params_Get_Evaluation_By_ANSWER_ID_List i_Params_Get_Evaluation_By_ANSWER_ID_List)
{
List<Evaluation> oList = new List<Evaluation>();
Tools.Tools oTools = new Tools.Tools();
Evaluation oEvaluation = new Evaluation();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Evaluation_By_ANSWER_ID_List");}
#region Body Section.
List<DALC.Evaluation> oList_DBEntries = _AppContext.Get_Evaluation_By_ANSWER_ID_List(i_Params_Get_Evaluation_By_ANSWER_ID_List.ANSWER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oEvaluation = new Evaluation();
oTools.CopyPropValues(oDBEntry, oEvaluation);
oList.Add(oEvaluation);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Evaluation_By_ANSWER_ID_List");}
return oList;
}
public List<Favorite_category> Get_Favorite_category_By_STUDENT_ID_List(Params_Get_Favorite_category_By_STUDENT_ID_List i_Params_Get_Favorite_category_By_STUDENT_ID_List)
{
List<Favorite_category> oList = new List<Favorite_category>();
Tools.Tools oTools = new Tools.Tools();
Favorite_category oFavorite_category = new Favorite_category();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Favorite_category_By_STUDENT_ID_List");}
#region Body Section.
List<DALC.Favorite_category> oList_DBEntries = _AppContext.Get_Favorite_category_By_STUDENT_ID_List(i_Params_Get_Favorite_category_By_STUDENT_ID_List.STUDENT_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oFavorite_category = new Favorite_category();
oTools.CopyPropValues(oDBEntry, oFavorite_category);
oList.Add(oFavorite_category);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Favorite_category_By_STUDENT_ID_List");}
return oList;
}
public List<Favorite_category> Get_Favorite_category_By_CATEGORY_ID_List(Params_Get_Favorite_category_By_CATEGORY_ID_List i_Params_Get_Favorite_category_By_CATEGORY_ID_List)
{
List<Favorite_category> oList = new List<Favorite_category>();
Tools.Tools oTools = new Tools.Tools();
Favorite_category oFavorite_category = new Favorite_category();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Favorite_category_By_CATEGORY_ID_List");}
#region Body Section.
List<DALC.Favorite_category> oList_DBEntries = _AppContext.Get_Favorite_category_By_CATEGORY_ID_List(i_Params_Get_Favorite_category_By_CATEGORY_ID_List.CATEGORY_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oFavorite_category = new Favorite_category();
oTools.CopyPropValues(oDBEntry, oFavorite_category);
oList.Add(oFavorite_category);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Favorite_category_By_CATEGORY_ID_List");}
return oList;
}
public List<Favorite_teacher> Get_Favorite_teacher_By_TEACHER_ID_List(Params_Get_Favorite_teacher_By_TEACHER_ID_List i_Params_Get_Favorite_teacher_By_TEACHER_ID_List)
{
List<Favorite_teacher> oList = new List<Favorite_teacher>();
Tools.Tools oTools = new Tools.Tools();
Favorite_teacher oFavorite_teacher = new Favorite_teacher();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Favorite_teacher_By_TEACHER_ID_List");}
#region Body Section.
List<DALC.Favorite_teacher> oList_DBEntries = _AppContext.Get_Favorite_teacher_By_TEACHER_ID_List(i_Params_Get_Favorite_teacher_By_TEACHER_ID_List.TEACHER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oFavorite_teacher = new Favorite_teacher();
oTools.CopyPropValues(oDBEntry, oFavorite_teacher);
oList.Add(oFavorite_teacher);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Favorite_teacher_By_TEACHER_ID_List");}
return oList;
}
public List<Favorite_teacher> Get_Favorite_teacher_By_STUDENT_ID_List(Params_Get_Favorite_teacher_By_STUDENT_ID_List i_Params_Get_Favorite_teacher_By_STUDENT_ID_List)
{
List<Favorite_teacher> oList = new List<Favorite_teacher>();
Tools.Tools oTools = new Tools.Tools();
Favorite_teacher oFavorite_teacher = new Favorite_teacher();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Favorite_teacher_By_STUDENT_ID_List");}
#region Body Section.
List<DALC.Favorite_teacher> oList_DBEntries = _AppContext.Get_Favorite_teacher_By_STUDENT_ID_List(i_Params_Get_Favorite_teacher_By_STUDENT_ID_List.STUDENT_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oFavorite_teacher = new Favorite_teacher();
oTools.CopyPropValues(oDBEntry, oFavorite_teacher);
oList.Add(oFavorite_teacher);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Favorite_teacher_By_STUDENT_ID_List");}
return oList;
}
public List<Mark_question> Get_Mark_question_By_QUESTION_ID_List(Params_Get_Mark_question_By_QUESTION_ID_List i_Params_Get_Mark_question_By_QUESTION_ID_List)
{
List<Mark_question> oList = new List<Mark_question>();
Tools.Tools oTools = new Tools.Tools();
Mark_question oMark_question = new Mark_question();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Mark_question_By_QUESTION_ID_List");}
#region Body Section.
List<DALC.Mark_question> oList_DBEntries = _AppContext.Get_Mark_question_By_QUESTION_ID_List(i_Params_Get_Mark_question_By_QUESTION_ID_List.QUESTION_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oMark_question = new Mark_question();
oTools.CopyPropValues(oDBEntry, oMark_question);
oList.Add(oMark_question);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Mark_question_By_QUESTION_ID_List");}
return oList;
}
public List<Mark_question> Get_Mark_question_By_STUDENT_ID_List(Params_Get_Mark_question_By_STUDENT_ID_List i_Params_Get_Mark_question_By_STUDENT_ID_List)
{
List<Mark_question> oList = new List<Mark_question>();
Tools.Tools oTools = new Tools.Tools();
Mark_question oMark_question = new Mark_question();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Mark_question_By_STUDENT_ID_List");}
#region Body Section.
List<DALC.Mark_question> oList_DBEntries = _AppContext.Get_Mark_question_By_STUDENT_ID_List(i_Params_Get_Mark_question_By_STUDENT_ID_List.STUDENT_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oMark_question = new Mark_question();
oTools.CopyPropValues(oDBEntry, oMark_question);
oList.Add(oMark_question);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Mark_question_By_STUDENT_ID_List");}
return oList;
}
public List<Notification> Get_Notification_By_USER_ID_List(Params_Get_Notification_By_USER_ID_List i_Params_Get_Notification_By_USER_ID_List)
{
List<Notification> oList = new List<Notification>();
Tools.Tools oTools = new Tools.Tools();
Notification oNotification = new Notification();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Notification_By_USER_ID_List");}
#region Body Section.
List<DALC.Notification> oList_DBEntries = _AppContext.Get_Notification_By_USER_ID_List(i_Params_Get_Notification_By_USER_ID_List.USER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oNotification = new Notification();
oTools.CopyPropValues(oDBEntry, oNotification);
oList.Add(oNotification);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Notification_By_USER_ID_List");}
return oList;
}
public List<Notification> Get_Notification_By_QUESTION_ID_List(Params_Get_Notification_By_QUESTION_ID_List i_Params_Get_Notification_By_QUESTION_ID_List)
{
List<Notification> oList = new List<Notification>();
Tools.Tools oTools = new Tools.Tools();
Notification oNotification = new Notification();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Notification_By_QUESTION_ID_List");}
#region Body Section.
List<DALC.Notification> oList_DBEntries = _AppContext.Get_Notification_By_QUESTION_ID_List(i_Params_Get_Notification_By_QUESTION_ID_List.QUESTION_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oNotification = new Notification();
oTools.CopyPropValues(oDBEntry, oNotification);
oList.Add(oNotification);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Notification_By_QUESTION_ID_List");}
return oList;
}
public List<Notification> Get_Notification_By_ANSWER_ID_List(Params_Get_Notification_By_ANSWER_ID_List i_Params_Get_Notification_By_ANSWER_ID_List)
{
List<Notification> oList = new List<Notification>();
Tools.Tools oTools = new Tools.Tools();
Notification oNotification = new Notification();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Notification_By_ANSWER_ID_List");}
#region Body Section.
List<DALC.Notification> oList_DBEntries = _AppContext.Get_Notification_By_ANSWER_ID_List(i_Params_Get_Notification_By_ANSWER_ID_List.ANSWER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oNotification = new Notification();
oTools.CopyPropValues(oDBEntry, oNotification);
oList.Add(oNotification);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Notification_By_ANSWER_ID_List");}
return oList;
}
public List<Question> Get_Question_By_STUDENT_ID_List(Params_Get_Question_By_STUDENT_ID_List i_Params_Get_Question_By_STUDENT_ID_List)
{
List<Question> oList = new List<Question>();
Tools.Tools oTools = new Tools.Tools();
Question oQuestion = new Question();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Question_By_STUDENT_ID_List");}
#region Body Section.
List<DALC.Question> oList_DBEntries = _AppContext.Get_Question_By_STUDENT_ID_List(i_Params_Get_Question_By_STUDENT_ID_List.STUDENT_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oQuestion = new Question();
oTools.CopyPropValues(oDBEntry, oQuestion);
oList.Add(oQuestion);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Question_By_STUDENT_ID_List");}
return oList;
}
public List<Question> Get_Question_By_CATEGORY_ID_List(Params_Get_Question_By_CATEGORY_ID_List i_Params_Get_Question_By_CATEGORY_ID_List)
{
List<Question> oList = new List<Question>();
Tools.Tools oTools = new Tools.Tools();
Question oQuestion = new Question();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Question_By_CATEGORY_ID_List");}
#region Body Section.
List<DALC.Question> oList_DBEntries = _AppContext.Get_Question_By_CATEGORY_ID_List(i_Params_Get_Question_By_CATEGORY_ID_List.CATEGORY_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oQuestion = new Question();
oTools.CopyPropValues(oDBEntry, oQuestion);
oList.Add(oQuestion);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Question_By_CATEGORY_ID_List");}
return oList;
}
public List<Question> Get_Question_By_TEACHER_ID_List(Params_Get_Question_By_TEACHER_ID_List i_Params_Get_Question_By_TEACHER_ID_List)
{
List<Question> oList = new List<Question>();
Tools.Tools oTools = new Tools.Tools();
Question oQuestion = new Question();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Question_By_TEACHER_ID_List");}
#region Body Section.
List<DALC.Question> oList_DBEntries = _AppContext.Get_Question_By_TEACHER_ID_List(i_Params_Get_Question_By_TEACHER_ID_List.TEACHER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oQuestion = new Question();
oTools.CopyPropValues(oDBEntry, oQuestion);
oList.Add(oQuestion);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Question_By_TEACHER_ID_List");}
return oList;
}
public List<Question_report> Get_Question_report_By_STUDENT_ID_List(Params_Get_Question_report_By_STUDENT_ID_List i_Params_Get_Question_report_By_STUDENT_ID_List)
{
List<Question_report> oList = new List<Question_report>();
Tools.Tools oTools = new Tools.Tools();
Question_report oQuestion_report = new Question_report();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Question_report_By_STUDENT_ID_List");}
#region Body Section.
List<DALC.Question_report> oList_DBEntries = _AppContext.Get_Question_report_By_STUDENT_ID_List(i_Params_Get_Question_report_By_STUDENT_ID_List.STUDENT_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oQuestion_report = new Question_report();
oTools.CopyPropValues(oDBEntry, oQuestion_report);
oList.Add(oQuestion_report);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Question_report_By_STUDENT_ID_List");}
return oList;
}
public List<Question_report> Get_Question_report_By_TEACHER_ID_List(Params_Get_Question_report_By_TEACHER_ID_List i_Params_Get_Question_report_By_TEACHER_ID_List)
{
List<Question_report> oList = new List<Question_report>();
Tools.Tools oTools = new Tools.Tools();
Question_report oQuestion_report = new Question_report();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Question_report_By_TEACHER_ID_List");}
#region Body Section.
List<DALC.Question_report> oList_DBEntries = _AppContext.Get_Question_report_By_TEACHER_ID_List(i_Params_Get_Question_report_By_TEACHER_ID_List.TEACHER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oQuestion_report = new Question_report();
oTools.CopyPropValues(oDBEntry, oQuestion_report);
oList.Add(oQuestion_report);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Question_report_By_TEACHER_ID_List");}
return oList;
}
public List<Question_report> Get_Question_report_By_QUESTION_ID_List(Params_Get_Question_report_By_QUESTION_ID_List i_Params_Get_Question_report_By_QUESTION_ID_List)
{
List<Question_report> oList = new List<Question_report>();
Tools.Tools oTools = new Tools.Tools();
Question_report oQuestion_report = new Question_report();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Question_report_By_QUESTION_ID_List");}
#region Body Section.
List<DALC.Question_report> oList_DBEntries = _AppContext.Get_Question_report_By_QUESTION_ID_List(i_Params_Get_Question_report_By_QUESTION_ID_List.QUESTION_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oQuestion_report = new Question_report();
oTools.CopyPropValues(oDBEntry, oQuestion_report);
oList.Add(oQuestion_report);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Question_report_By_QUESTION_ID_List");}
return oList;
}
public List<Question_token> Get_Question_token_By_QUESTION_ID_List(Params_Get_Question_token_By_QUESTION_ID_List i_Params_Get_Question_token_By_QUESTION_ID_List)
{
List<Question_token> oList = new List<Question_token>();
Tools.Tools oTools = new Tools.Tools();
Question_token oQuestion_token = new Question_token();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Question_token_By_QUESTION_ID_List");}
#region Body Section.
List<DALC.Question_token> oList_DBEntries = _AppContext.Get_Question_token_By_QUESTION_ID_List(i_Params_Get_Question_token_By_QUESTION_ID_List.QUESTION_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oQuestion_token = new Question_token();
oTools.CopyPropValues(oDBEntry, oQuestion_token);
oList.Add(oQuestion_token);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Question_token_By_QUESTION_ID_List");}
return oList;
}
public List<Report_article> Get_Report_article_By_ARTICLE_ID_List(Params_Get_Report_article_By_ARTICLE_ID_List i_Params_Get_Report_article_By_ARTICLE_ID_List)
{
List<Report_article> oList = new List<Report_article>();
Tools.Tools oTools = new Tools.Tools();
Report_article oReport_article = new Report_article();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Report_article_By_ARTICLE_ID_List");}
#region Body Section.
List<DALC.Report_article> oList_DBEntries = _AppContext.Get_Report_article_By_ARTICLE_ID_List(i_Params_Get_Report_article_By_ARTICLE_ID_List.ARTICLE_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oReport_article = new Report_article();
oTools.CopyPropValues(oDBEntry, oReport_article);
oList.Add(oReport_article);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Report_article_By_ARTICLE_ID_List");}
return oList;
}
public List<Report_article> Get_Report_article_By_STUDENT_ID_List(Params_Get_Report_article_By_STUDENT_ID_List i_Params_Get_Report_article_By_STUDENT_ID_List)
{
List<Report_article> oList = new List<Report_article>();
Tools.Tools oTools = new Tools.Tools();
Report_article oReport_article = new Report_article();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Report_article_By_STUDENT_ID_List");}
#region Body Section.
List<DALC.Report_article> oList_DBEntries = _AppContext.Get_Report_article_By_STUDENT_ID_List(i_Params_Get_Report_article_By_STUDENT_ID_List.STUDENT_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oReport_article = new Report_article();
oTools.CopyPropValues(oDBEntry, oReport_article);
oList.Add(oReport_article);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Report_article_By_STUDENT_ID_List");}
return oList;
}
public List<Student> Get_Student_By_USER_ID_List(Params_Get_Student_By_USER_ID_List i_Params_Get_Student_By_USER_ID_List)
{
List<Student> oList = new List<Student>();
Tools.Tools oTools = new Tools.Tools();
Student oStudent = new Student();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Student_By_USER_ID_List");}
#region Body Section.
List<DALC.Student> oList_DBEntries = _AppContext.Get_Student_By_USER_ID_List(i_Params_Get_Student_By_USER_ID_List.USER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oStudent = new Student();
oTools.CopyPropValues(oDBEntry, oStudent);
oList.Add(oStudent);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Student_By_USER_ID_List");}
return oList;
}
public List<Student_report> Get_Student_report_By_REPORTED_BY_STUDENT_ID_List(Params_Get_Student_report_By_REPORTED_BY_STUDENT_ID_List i_Params_Get_Student_report_By_REPORTED_BY_STUDENT_ID_List)
{
List<Student_report> oList = new List<Student_report>();
Tools.Tools oTools = new Tools.Tools();
Student_report oStudent_report = new Student_report();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Student_report_By_REPORTED_BY_STUDENT_ID_List");}
#region Body Section.
List<DALC.Student_report> oList_DBEntries = _AppContext.Get_Student_report_By_REPORTED_BY_STUDENT_ID_List(i_Params_Get_Student_report_By_REPORTED_BY_STUDENT_ID_List.REPORTED_BY_STUDENT_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oStudent_report = new Student_report();
oTools.CopyPropValues(oDBEntry, oStudent_report);
oList.Add(oStudent_report);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Student_report_By_REPORTED_BY_STUDENT_ID_List");}
return oList;
}
public List<Student_report> Get_Student_report_By_REPORTED_STUDENT_ID_List(Params_Get_Student_report_By_REPORTED_STUDENT_ID_List i_Params_Get_Student_report_By_REPORTED_STUDENT_ID_List)
{
List<Student_report> oList = new List<Student_report>();
Tools.Tools oTools = new Tools.Tools();
Student_report oStudent_report = new Student_report();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Student_report_By_REPORTED_STUDENT_ID_List");}
#region Body Section.
List<DALC.Student_report> oList_DBEntries = _AppContext.Get_Student_report_By_REPORTED_STUDENT_ID_List(i_Params_Get_Student_report_By_REPORTED_STUDENT_ID_List.REPORTED_STUDENT_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oStudent_report = new Student_report();
oTools.CopyPropValues(oDBEntry, oStudent_report);
oList.Add(oStudent_report);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Student_report_By_REPORTED_STUDENT_ID_List");}
return oList;
}
public List<Teacher> Get_Teacher_By_USER_ID_List(Params_Get_Teacher_By_USER_ID_List i_Params_Get_Teacher_By_USER_ID_List)
{
List<Teacher> oList = new List<Teacher>();
Tools.Tools oTools = new Tools.Tools();
Teacher oTeacher = new Teacher();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_By_USER_ID_List");}
#region Body Section.
List<DALC.Teacher> oList_DBEntries = _AppContext.Get_Teacher_By_USER_ID_List(i_Params_Get_Teacher_By_USER_ID_List.USER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher = new Teacher();
oTools.CopyPropValues(oDBEntry, oTeacher);
oList.Add(oTeacher);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_By_USER_ID_List");}
return oList;
}
public List<Teacher_category> Get_Teacher_category_By_TEACHER_ID_List(Params_Get_Teacher_category_By_TEACHER_ID_List i_Params_Get_Teacher_category_By_TEACHER_ID_List)
{
List<Teacher_category> oList = new List<Teacher_category>();
Tools.Tools oTools = new Tools.Tools();
Teacher_category oTeacher_category = new Teacher_category();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_category_By_TEACHER_ID_List");}
#region Body Section.
List<DALC.Teacher_category> oList_DBEntries = _AppContext.Get_Teacher_category_By_TEACHER_ID_List(i_Params_Get_Teacher_category_By_TEACHER_ID_List.TEACHER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_category = new Teacher_category();
oTools.CopyPropValues(oDBEntry, oTeacher_category);
oList.Add(oTeacher_category);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_category_By_TEACHER_ID_List");}
return oList;
}
public List<Teacher_category> Get_Teacher_category_By_CATEGORY_ID_List(Params_Get_Teacher_category_By_CATEGORY_ID_List i_Params_Get_Teacher_category_By_CATEGORY_ID_List)
{
List<Teacher_category> oList = new List<Teacher_category>();
Tools.Tools oTools = new Tools.Tools();
Teacher_category oTeacher_category = new Teacher_category();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_category_By_CATEGORY_ID_List");}
#region Body Section.
List<DALC.Teacher_category> oList_DBEntries = _AppContext.Get_Teacher_category_By_CATEGORY_ID_List(i_Params_Get_Teacher_category_By_CATEGORY_ID_List.CATEGORY_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_category = new Teacher_category();
oTools.CopyPropValues(oDBEntry, oTeacher_category);
oList.Add(oTeacher_category);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_category_By_CATEGORY_ID_List");}
return oList;
}
public List<Teacher_favorite> Get_Teacher_favorite_By_TEACHER_ID_List(Params_Get_Teacher_favorite_By_TEACHER_ID_List i_Params_Get_Teacher_favorite_By_TEACHER_ID_List)
{
List<Teacher_favorite> oList = new List<Teacher_favorite>();
Tools.Tools oTools = new Tools.Tools();
Teacher_favorite oTeacher_favorite = new Teacher_favorite();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_favorite_By_TEACHER_ID_List");}
#region Body Section.
List<DALC.Teacher_favorite> oList_DBEntries = _AppContext.Get_Teacher_favorite_By_TEACHER_ID_List(i_Params_Get_Teacher_favorite_By_TEACHER_ID_List.TEACHER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_favorite = new Teacher_favorite();
oTools.CopyPropValues(oDBEntry, oTeacher_favorite);
oList.Add(oTeacher_favorite);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_favorite_By_TEACHER_ID_List");}
return oList;
}
public List<Teacher_favorite> Get_Teacher_favorite_By_STUDENT_ID_List(Params_Get_Teacher_favorite_By_STUDENT_ID_List i_Params_Get_Teacher_favorite_By_STUDENT_ID_List)
{
List<Teacher_favorite> oList = new List<Teacher_favorite>();
Tools.Tools oTools = new Tools.Tools();
Teacher_favorite oTeacher_favorite = new Teacher_favorite();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_favorite_By_STUDENT_ID_List");}
#region Body Section.
List<DALC.Teacher_favorite> oList_DBEntries = _AppContext.Get_Teacher_favorite_By_STUDENT_ID_List(i_Params_Get_Teacher_favorite_By_STUDENT_ID_List.STUDENT_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_favorite = new Teacher_favorite();
oTools.CopyPropValues(oDBEntry, oTeacher_favorite);
oList.Add(oTeacher_favorite);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_favorite_By_STUDENT_ID_List");}
return oList;
}
public List<Teacher_rank> Get_Teacher_rank_By_TEACHER_ID_List(Params_Get_Teacher_rank_By_TEACHER_ID_List i_Params_Get_Teacher_rank_By_TEACHER_ID_List)
{
List<Teacher_rank> oList = new List<Teacher_rank>();
Tools.Tools oTools = new Tools.Tools();
Teacher_rank oTeacher_rank = new Teacher_rank();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_rank_By_TEACHER_ID_List");}
#region Body Section.
List<DALC.Teacher_rank> oList_DBEntries = _AppContext.Get_Teacher_rank_By_TEACHER_ID_List(i_Params_Get_Teacher_rank_By_TEACHER_ID_List.TEACHER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_rank = new Teacher_rank();
oTools.CopyPropValues(oDBEntry, oTeacher_rank);
oList.Add(oTeacher_rank);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_rank_By_TEACHER_ID_List");}
return oList;
}
public List<Teacher_report> Get_Teacher_report_By_TEACHER_ID_List(Params_Get_Teacher_report_By_TEACHER_ID_List i_Params_Get_Teacher_report_By_TEACHER_ID_List)
{
List<Teacher_report> oList = new List<Teacher_report>();
Tools.Tools oTools = new Tools.Tools();
Teacher_report oTeacher_report = new Teacher_report();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_report_By_TEACHER_ID_List");}
#region Body Section.
List<DALC.Teacher_report> oList_DBEntries = _AppContext.Get_Teacher_report_By_TEACHER_ID_List(i_Params_Get_Teacher_report_By_TEACHER_ID_List.TEACHER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_report = new Teacher_report();
oTools.CopyPropValues(oDBEntry, oTeacher_report);
oList.Add(oTeacher_report);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_report_By_TEACHER_ID_List");}
return oList;
}
public List<Teacher_report> Get_Teacher_report_By_STUDENT_ID_List(Params_Get_Teacher_report_By_STUDENT_ID_List i_Params_Get_Teacher_report_By_STUDENT_ID_List)
{
List<Teacher_report> oList = new List<Teacher_report>();
Tools.Tools oTools = new Tools.Tools();
Teacher_report oTeacher_report = new Teacher_report();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_report_By_STUDENT_ID_List");}
#region Body Section.
List<DALC.Teacher_report> oList_DBEntries = _AppContext.Get_Teacher_report_By_STUDENT_ID_List(i_Params_Get_Teacher_report_By_STUDENT_ID_List.STUDENT_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_report = new Teacher_report();
oTools.CopyPropValues(oDBEntry, oTeacher_report);
oList.Add(oTeacher_report);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_report_By_STUDENT_ID_List");}
return oList;
}
public List<Answer> Get_Answer_By_Criteria(Params_Get_Answer_By_Criteria i_Params_Get_Answer_By_Criteria)
{
List<Answer> oList = new List<Answer>();
Tools.Tools oTools = new Tools.Tools();
Answer oAnswer = new Answer();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Answer_By_Criteria");}
#region Body Section.
if ((i_Params_Get_Answer_By_Criteria.OWNER_ID == null) || (i_Params_Get_Answer_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Answer_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Answer_By_Criteria.START_ROW == null) { i_Params_Get_Answer_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Answer_By_Criteria.END_ROW == null) || (i_Params_Get_Answer_By_Criteria.END_ROW == 0)) { i_Params_Get_Answer_By_Criteria.END_ROW = 1000000; }
List<DALC.Answer> oList_DBEntries = _AppContext.Get_Answer_By_Criteria(i_Params_Get_Answer_By_Criteria.DESCRIPTION,i_Params_Get_Answer_By_Criteria.OWNER_ID,i_Params_Get_Answer_By_Criteria.START_ROW,i_Params_Get_Answer_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oAnswer = new Answer();
oTools.CopyPropValues(oDBEntry, oAnswer);
oList.Add(oAnswer);
}
}
i_Params_Get_Answer_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Answer_By_Criteria");}
return oList;
}
public List<Answer> Get_Answer_By_Where(Params_Get_Answer_By_Where i_Params_Get_Answer_By_Where)
{
List<Answer> oList = new List<Answer>();
Tools.Tools oTools = new Tools.Tools();
Answer oAnswer = new Answer();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Answer_By_Where");}
#region Body Section.
if ((i_Params_Get_Answer_By_Where.OWNER_ID == null) || (i_Params_Get_Answer_By_Where.OWNER_ID == 0)) { i_Params_Get_Answer_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Answer_By_Where.START_ROW == null) { i_Params_Get_Answer_By_Where.START_ROW = 0; }
if ((i_Params_Get_Answer_By_Where.END_ROW == null) || (i_Params_Get_Answer_By_Where.END_ROW == 0)) { i_Params_Get_Answer_By_Where.END_ROW = 1000000; }
List<DALC.Answer> oList_DBEntries = _AppContext.Get_Answer_By_Where(i_Params_Get_Answer_By_Where.DESCRIPTION,i_Params_Get_Answer_By_Where.OWNER_ID,i_Params_Get_Answer_By_Where.START_ROW,i_Params_Get_Answer_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oAnswer = new Answer();
oTools.CopyPropValues(oDBEntry, oAnswer);
oList.Add(oAnswer);
}
}
i_Params_Get_Answer_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Answer_By_Where");}
return oList;
}
public List<Answer_report> Get_Answer_report_By_Criteria(Params_Get_Answer_report_By_Criteria i_Params_Get_Answer_report_By_Criteria)
{
List<Answer_report> oList = new List<Answer_report>();
Tools.Tools oTools = new Tools.Tools();
Answer_report oAnswer_report = new Answer_report();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Answer_report_By_Criteria");}
#region Body Section.
if ((i_Params_Get_Answer_report_By_Criteria.OWNER_ID == null) || (i_Params_Get_Answer_report_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Answer_report_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Answer_report_By_Criteria.START_ROW == null) { i_Params_Get_Answer_report_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Answer_report_By_Criteria.END_ROW == null) || (i_Params_Get_Answer_report_By_Criteria.END_ROW == 0)) { i_Params_Get_Answer_report_By_Criteria.END_ROW = 1000000; }
List<DALC.Answer_report> oList_DBEntries = _AppContext.Get_Answer_report_By_Criteria(i_Params_Get_Answer_report_By_Criteria.DESCRIPTION,i_Params_Get_Answer_report_By_Criteria.OWNER_ID,i_Params_Get_Answer_report_By_Criteria.START_ROW,i_Params_Get_Answer_report_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oAnswer_report = new Answer_report();
oTools.CopyPropValues(oDBEntry, oAnswer_report);
oList.Add(oAnswer_report);
}
}
i_Params_Get_Answer_report_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Answer_report_By_Criteria");}
return oList;
}
public List<Answer_report> Get_Answer_report_By_Where(Params_Get_Answer_report_By_Where i_Params_Get_Answer_report_By_Where)
{
List<Answer_report> oList = new List<Answer_report>();
Tools.Tools oTools = new Tools.Tools();
Answer_report oAnswer_report = new Answer_report();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Answer_report_By_Where");}
#region Body Section.
if ((i_Params_Get_Answer_report_By_Where.OWNER_ID == null) || (i_Params_Get_Answer_report_By_Where.OWNER_ID == 0)) { i_Params_Get_Answer_report_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Answer_report_By_Where.START_ROW == null) { i_Params_Get_Answer_report_By_Where.START_ROW = 0; }
if ((i_Params_Get_Answer_report_By_Where.END_ROW == null) || (i_Params_Get_Answer_report_By_Where.END_ROW == 0)) { i_Params_Get_Answer_report_By_Where.END_ROW = 1000000; }
List<DALC.Answer_report> oList_DBEntries = _AppContext.Get_Answer_report_By_Where(i_Params_Get_Answer_report_By_Where.DESCRIPTION,i_Params_Get_Answer_report_By_Where.OWNER_ID,i_Params_Get_Answer_report_By_Where.START_ROW,i_Params_Get_Answer_report_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oAnswer_report = new Answer_report();
oTools.CopyPropValues(oDBEntry, oAnswer_report);
oList.Add(oAnswer_report);
}
}
i_Params_Get_Answer_report_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Answer_report_By_Where");}
return oList;
}
public List<Article> Get_Article_By_Criteria(Params_Get_Article_By_Criteria i_Params_Get_Article_By_Criteria)
{
List<Article> oList = new List<Article>();
Tools.Tools oTools = new Tools.Tools();
Article oArticle = new Article();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Article_By_Criteria");}
#region Body Section.
if ((i_Params_Get_Article_By_Criteria.OWNER_ID == null) || (i_Params_Get_Article_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Article_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Article_By_Criteria.START_ROW == null) { i_Params_Get_Article_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Article_By_Criteria.END_ROW == null) || (i_Params_Get_Article_By_Criteria.END_ROW == 0)) { i_Params_Get_Article_By_Criteria.END_ROW = 1000000; }
List<DALC.Article> oList_DBEntries = _AppContext.Get_Article_By_Criteria(i_Params_Get_Article_By_Criteria.TITLE,i_Params_Get_Article_By_Criteria.DESCRIPTION,i_Params_Get_Article_By_Criteria.OWNER_ID,i_Params_Get_Article_By_Criteria.START_ROW,i_Params_Get_Article_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oArticle = new Article();
oTools.CopyPropValues(oDBEntry, oArticle);
oList.Add(oArticle);
}
}
i_Params_Get_Article_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Article_By_Criteria");}
return oList;
}
public List<Article> Get_Article_By_Where(Params_Get_Article_By_Where i_Params_Get_Article_By_Where)
{
List<Article> oList = new List<Article>();
Tools.Tools oTools = new Tools.Tools();
Article oArticle = new Article();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Article_By_Where");}
#region Body Section.
if ((i_Params_Get_Article_By_Where.OWNER_ID == null) || (i_Params_Get_Article_By_Where.OWNER_ID == 0)) { i_Params_Get_Article_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Article_By_Where.START_ROW == null) { i_Params_Get_Article_By_Where.START_ROW = 0; }
if ((i_Params_Get_Article_By_Where.END_ROW == null) || (i_Params_Get_Article_By_Where.END_ROW == 0)) { i_Params_Get_Article_By_Where.END_ROW = 1000000; }
List<DALC.Article> oList_DBEntries = _AppContext.Get_Article_By_Where(i_Params_Get_Article_By_Where.TITLE,i_Params_Get_Article_By_Where.DESCRIPTION,i_Params_Get_Article_By_Where.OWNER_ID,i_Params_Get_Article_By_Where.START_ROW,i_Params_Get_Article_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oArticle = new Article();
oTools.CopyPropValues(oDBEntry, oArticle);
oList.Add(oArticle);
}
}
i_Params_Get_Article_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Article_By_Where");}
return oList;
}
public List<Category> Get_Category_By_Criteria(Params_Get_Category_By_Criteria i_Params_Get_Category_By_Criteria)
{
List<Category> oList = new List<Category>();
Tools.Tools oTools = new Tools.Tools();
Category oCategory = new Category();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Category_By_Criteria");}
#region Body Section.
if ((i_Params_Get_Category_By_Criteria.OWNER_ID == null) || (i_Params_Get_Category_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Category_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Category_By_Criteria.START_ROW == null) { i_Params_Get_Category_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Category_By_Criteria.END_ROW == null) || (i_Params_Get_Category_By_Criteria.END_ROW == 0)) { i_Params_Get_Category_By_Criteria.END_ROW = 1000000; }
List<DALC.Category> oList_DBEntries = _AppContext.Get_Category_By_Criteria(i_Params_Get_Category_By_Criteria.NAME,i_Params_Get_Category_By_Criteria.DECRIPTION,i_Params_Get_Category_By_Criteria.OWNER_ID,i_Params_Get_Category_By_Criteria.START_ROW,i_Params_Get_Category_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCategory = new Category();
oTools.CopyPropValues(oDBEntry, oCategory);
oList.Add(oCategory);
}
}
i_Params_Get_Category_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Category_By_Criteria");}
return oList;
}
public List<Category> Get_Category_By_Where(Params_Get_Category_By_Where i_Params_Get_Category_By_Where)
{
List<Category> oList = new List<Category>();
Tools.Tools oTools = new Tools.Tools();
Category oCategory = new Category();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Category_By_Where");}
#region Body Section.
if ((i_Params_Get_Category_By_Where.OWNER_ID == null) || (i_Params_Get_Category_By_Where.OWNER_ID == 0)) { i_Params_Get_Category_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Category_By_Where.START_ROW == null) { i_Params_Get_Category_By_Where.START_ROW = 0; }
if ((i_Params_Get_Category_By_Where.END_ROW == null) || (i_Params_Get_Category_By_Where.END_ROW == 0)) { i_Params_Get_Category_By_Where.END_ROW = 1000000; }
List<DALC.Category> oList_DBEntries = _AppContext.Get_Category_By_Where(i_Params_Get_Category_By_Where.NAME,i_Params_Get_Category_By_Where.DECRIPTION,i_Params_Get_Category_By_Where.OWNER_ID,i_Params_Get_Category_By_Where.START_ROW,i_Params_Get_Category_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCategory = new Category();
oTools.CopyPropValues(oDBEntry, oCategory);
oList.Add(oCategory);
}
}
i_Params_Get_Category_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Category_By_Where");}
return oList;
}
public List<Evaluation> Get_Evaluation_By_Criteria(Params_Get_Evaluation_By_Criteria i_Params_Get_Evaluation_By_Criteria)
{
List<Evaluation> oList = new List<Evaluation>();
Tools.Tools oTools = new Tools.Tools();
Evaluation oEvaluation = new Evaluation();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Evaluation_By_Criteria");}
#region Body Section.
if ((i_Params_Get_Evaluation_By_Criteria.OWNER_ID == null) || (i_Params_Get_Evaluation_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Evaluation_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Evaluation_By_Criteria.START_ROW == null) { i_Params_Get_Evaluation_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Evaluation_By_Criteria.END_ROW == null) || (i_Params_Get_Evaluation_By_Criteria.END_ROW == 0)) { i_Params_Get_Evaluation_By_Criteria.END_ROW = 1000000; }
List<DALC.Evaluation> oList_DBEntries = _AppContext.Get_Evaluation_By_Criteria(i_Params_Get_Evaluation_By_Criteria.DESCRIPTION,i_Params_Get_Evaluation_By_Criteria.OWNER_ID,i_Params_Get_Evaluation_By_Criteria.START_ROW,i_Params_Get_Evaluation_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oEvaluation = new Evaluation();
oTools.CopyPropValues(oDBEntry, oEvaluation);
oList.Add(oEvaluation);
}
}
i_Params_Get_Evaluation_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Evaluation_By_Criteria");}
return oList;
}
public List<Evaluation> Get_Evaluation_By_Where(Params_Get_Evaluation_By_Where i_Params_Get_Evaluation_By_Where)
{
List<Evaluation> oList = new List<Evaluation>();
Tools.Tools oTools = new Tools.Tools();
Evaluation oEvaluation = new Evaluation();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Evaluation_By_Where");}
#region Body Section.
if ((i_Params_Get_Evaluation_By_Where.OWNER_ID == null) || (i_Params_Get_Evaluation_By_Where.OWNER_ID == 0)) { i_Params_Get_Evaluation_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Evaluation_By_Where.START_ROW == null) { i_Params_Get_Evaluation_By_Where.START_ROW = 0; }
if ((i_Params_Get_Evaluation_By_Where.END_ROW == null) || (i_Params_Get_Evaluation_By_Where.END_ROW == 0)) { i_Params_Get_Evaluation_By_Where.END_ROW = 1000000; }
List<DALC.Evaluation> oList_DBEntries = _AppContext.Get_Evaluation_By_Where(i_Params_Get_Evaluation_By_Where.DESCRIPTION,i_Params_Get_Evaluation_By_Where.OWNER_ID,i_Params_Get_Evaluation_By_Where.START_ROW,i_Params_Get_Evaluation_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oEvaluation = new Evaluation();
oTools.CopyPropValues(oDBEntry, oEvaluation);
oList.Add(oEvaluation);
}
}
i_Params_Get_Evaluation_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Evaluation_By_Where");}
return oList;
}
public List<Favorite_category> Get_Favorite_category_By_Criteria(Params_Get_Favorite_category_By_Criteria i_Params_Get_Favorite_category_By_Criteria)
{
List<Favorite_category> oList = new List<Favorite_category>();
Tools.Tools oTools = new Tools.Tools();
Favorite_category oFavorite_category = new Favorite_category();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Favorite_category_By_Criteria");}
#region Body Section.
if ((i_Params_Get_Favorite_category_By_Criteria.OWNER_ID == null) || (i_Params_Get_Favorite_category_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Favorite_category_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Favorite_category_By_Criteria.START_ROW == null) { i_Params_Get_Favorite_category_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Favorite_category_By_Criteria.END_ROW == null) || (i_Params_Get_Favorite_category_By_Criteria.END_ROW == 0)) { i_Params_Get_Favorite_category_By_Criteria.END_ROW = 1000000; }
List<DALC.Favorite_category> oList_DBEntries = _AppContext.Get_Favorite_category_By_Criteria(i_Params_Get_Favorite_category_By_Criteria.DESCRIPTION,i_Params_Get_Favorite_category_By_Criteria.OWNER_ID,i_Params_Get_Favorite_category_By_Criteria.START_ROW,i_Params_Get_Favorite_category_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oFavorite_category = new Favorite_category();
oTools.CopyPropValues(oDBEntry, oFavorite_category);
oList.Add(oFavorite_category);
}
}
i_Params_Get_Favorite_category_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Favorite_category_By_Criteria");}
return oList;
}
public List<Favorite_category> Get_Favorite_category_By_Where(Params_Get_Favorite_category_By_Where i_Params_Get_Favorite_category_By_Where)
{
List<Favorite_category> oList = new List<Favorite_category>();
Tools.Tools oTools = new Tools.Tools();
Favorite_category oFavorite_category = new Favorite_category();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Favorite_category_By_Where");}
#region Body Section.
if ((i_Params_Get_Favorite_category_By_Where.OWNER_ID == null) || (i_Params_Get_Favorite_category_By_Where.OWNER_ID == 0)) { i_Params_Get_Favorite_category_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Favorite_category_By_Where.START_ROW == null) { i_Params_Get_Favorite_category_By_Where.START_ROW = 0; }
if ((i_Params_Get_Favorite_category_By_Where.END_ROW == null) || (i_Params_Get_Favorite_category_By_Where.END_ROW == 0)) { i_Params_Get_Favorite_category_By_Where.END_ROW = 1000000; }
List<DALC.Favorite_category> oList_DBEntries = _AppContext.Get_Favorite_category_By_Where(i_Params_Get_Favorite_category_By_Where.DESCRIPTION,i_Params_Get_Favorite_category_By_Where.OWNER_ID,i_Params_Get_Favorite_category_By_Where.START_ROW,i_Params_Get_Favorite_category_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oFavorite_category = new Favorite_category();
oTools.CopyPropValues(oDBEntry, oFavorite_category);
oList.Add(oFavorite_category);
}
}
i_Params_Get_Favorite_category_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Favorite_category_By_Where");}
return oList;
}
public List<Favorite_teacher> Get_Favorite_teacher_By_Criteria(Params_Get_Favorite_teacher_By_Criteria i_Params_Get_Favorite_teacher_By_Criteria)
{
List<Favorite_teacher> oList = new List<Favorite_teacher>();
Tools.Tools oTools = new Tools.Tools();
Favorite_teacher oFavorite_teacher = new Favorite_teacher();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Favorite_teacher_By_Criteria");}
#region Body Section.
if ((i_Params_Get_Favorite_teacher_By_Criteria.OWNER_ID == null) || (i_Params_Get_Favorite_teacher_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Favorite_teacher_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Favorite_teacher_By_Criteria.START_ROW == null) { i_Params_Get_Favorite_teacher_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Favorite_teacher_By_Criteria.END_ROW == null) || (i_Params_Get_Favorite_teacher_By_Criteria.END_ROW == 0)) { i_Params_Get_Favorite_teacher_By_Criteria.END_ROW = 1000000; }
List<DALC.Favorite_teacher> oList_DBEntries = _AppContext.Get_Favorite_teacher_By_Criteria(i_Params_Get_Favorite_teacher_By_Criteria.DESCRIPTION,i_Params_Get_Favorite_teacher_By_Criteria.OWNER_ID,i_Params_Get_Favorite_teacher_By_Criteria.START_ROW,i_Params_Get_Favorite_teacher_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oFavorite_teacher = new Favorite_teacher();
oTools.CopyPropValues(oDBEntry, oFavorite_teacher);
oList.Add(oFavorite_teacher);
}
}
i_Params_Get_Favorite_teacher_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Favorite_teacher_By_Criteria");}
return oList;
}
public List<Favorite_teacher> Get_Favorite_teacher_By_Where(Params_Get_Favorite_teacher_By_Where i_Params_Get_Favorite_teacher_By_Where)
{
List<Favorite_teacher> oList = new List<Favorite_teacher>();
Tools.Tools oTools = new Tools.Tools();
Favorite_teacher oFavorite_teacher = new Favorite_teacher();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Favorite_teacher_By_Where");}
#region Body Section.
if ((i_Params_Get_Favorite_teacher_By_Where.OWNER_ID == null) || (i_Params_Get_Favorite_teacher_By_Where.OWNER_ID == 0)) { i_Params_Get_Favorite_teacher_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Favorite_teacher_By_Where.START_ROW == null) { i_Params_Get_Favorite_teacher_By_Where.START_ROW = 0; }
if ((i_Params_Get_Favorite_teacher_By_Where.END_ROW == null) || (i_Params_Get_Favorite_teacher_By_Where.END_ROW == 0)) { i_Params_Get_Favorite_teacher_By_Where.END_ROW = 1000000; }
List<DALC.Favorite_teacher> oList_DBEntries = _AppContext.Get_Favorite_teacher_By_Where(i_Params_Get_Favorite_teacher_By_Where.DESCRIPTION,i_Params_Get_Favorite_teacher_By_Where.OWNER_ID,i_Params_Get_Favorite_teacher_By_Where.START_ROW,i_Params_Get_Favorite_teacher_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oFavorite_teacher = new Favorite_teacher();
oTools.CopyPropValues(oDBEntry, oFavorite_teacher);
oList.Add(oFavorite_teacher);
}
}
i_Params_Get_Favorite_teacher_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Favorite_teacher_By_Where");}
return oList;
}
public List<Mark_question> Get_Mark_question_By_Criteria(Params_Get_Mark_question_By_Criteria i_Params_Get_Mark_question_By_Criteria)
{
List<Mark_question> oList = new List<Mark_question>();
Tools.Tools oTools = new Tools.Tools();
Mark_question oMark_question = new Mark_question();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Mark_question_By_Criteria");}
#region Body Section.
if ((i_Params_Get_Mark_question_By_Criteria.OWNER_ID == null) || (i_Params_Get_Mark_question_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Mark_question_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Mark_question_By_Criteria.START_ROW == null) { i_Params_Get_Mark_question_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Mark_question_By_Criteria.END_ROW == null) || (i_Params_Get_Mark_question_By_Criteria.END_ROW == 0)) { i_Params_Get_Mark_question_By_Criteria.END_ROW = 1000000; }
List<DALC.Mark_question> oList_DBEntries = _AppContext.Get_Mark_question_By_Criteria(i_Params_Get_Mark_question_By_Criteria.DESCRIPTION,i_Params_Get_Mark_question_By_Criteria.OWNER_ID,i_Params_Get_Mark_question_By_Criteria.START_ROW,i_Params_Get_Mark_question_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oMark_question = new Mark_question();
oTools.CopyPropValues(oDBEntry, oMark_question);
oList.Add(oMark_question);
}
}
i_Params_Get_Mark_question_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Mark_question_By_Criteria");}
return oList;
}
public List<Mark_question> Get_Mark_question_By_Where(Params_Get_Mark_question_By_Where i_Params_Get_Mark_question_By_Where)
{
List<Mark_question> oList = new List<Mark_question>();
Tools.Tools oTools = new Tools.Tools();
Mark_question oMark_question = new Mark_question();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Mark_question_By_Where");}
#region Body Section.
if ((i_Params_Get_Mark_question_By_Where.OWNER_ID == null) || (i_Params_Get_Mark_question_By_Where.OWNER_ID == 0)) { i_Params_Get_Mark_question_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Mark_question_By_Where.START_ROW == null) { i_Params_Get_Mark_question_By_Where.START_ROW = 0; }
if ((i_Params_Get_Mark_question_By_Where.END_ROW == null) || (i_Params_Get_Mark_question_By_Where.END_ROW == 0)) { i_Params_Get_Mark_question_By_Where.END_ROW = 1000000; }
List<DALC.Mark_question> oList_DBEntries = _AppContext.Get_Mark_question_By_Where(i_Params_Get_Mark_question_By_Where.DESCRIPTION,i_Params_Get_Mark_question_By_Where.OWNER_ID,i_Params_Get_Mark_question_By_Where.START_ROW,i_Params_Get_Mark_question_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oMark_question = new Mark_question();
oTools.CopyPropValues(oDBEntry, oMark_question);
oList.Add(oMark_question);
}
}
i_Params_Get_Mark_question_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Mark_question_By_Where");}
return oList;
}
public List<Notification> Get_Notification_By_Criteria(Params_Get_Notification_By_Criteria i_Params_Get_Notification_By_Criteria)
{
List<Notification> oList = new List<Notification>();
Tools.Tools oTools = new Tools.Tools();
Notification oNotification = new Notification();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Notification_By_Criteria");}
#region Body Section.
if ((i_Params_Get_Notification_By_Criteria.OWNER_ID == null) || (i_Params_Get_Notification_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Notification_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Notification_By_Criteria.START_ROW == null) { i_Params_Get_Notification_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Notification_By_Criteria.END_ROW == null) || (i_Params_Get_Notification_By_Criteria.END_ROW == 0)) { i_Params_Get_Notification_By_Criteria.END_ROW = 1000000; }
List<DALC.Notification> oList_DBEntries = _AppContext.Get_Notification_By_Criteria(i_Params_Get_Notification_By_Criteria.DESCRIPTION,i_Params_Get_Notification_By_Criteria.OWNER_ID,i_Params_Get_Notification_By_Criteria.START_ROW,i_Params_Get_Notification_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oNotification = new Notification();
oTools.CopyPropValues(oDBEntry, oNotification);
oList.Add(oNotification);
}
}
i_Params_Get_Notification_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Notification_By_Criteria");}
return oList;
}
public List<Notification> Get_Notification_By_Where(Params_Get_Notification_By_Where i_Params_Get_Notification_By_Where)
{
List<Notification> oList = new List<Notification>();
Tools.Tools oTools = new Tools.Tools();
Notification oNotification = new Notification();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Notification_By_Where");}
#region Body Section.
if ((i_Params_Get_Notification_By_Where.OWNER_ID == null) || (i_Params_Get_Notification_By_Where.OWNER_ID == 0)) { i_Params_Get_Notification_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Notification_By_Where.START_ROW == null) { i_Params_Get_Notification_By_Where.START_ROW = 0; }
if ((i_Params_Get_Notification_By_Where.END_ROW == null) || (i_Params_Get_Notification_By_Where.END_ROW == 0)) { i_Params_Get_Notification_By_Where.END_ROW = 1000000; }
List<DALC.Notification> oList_DBEntries = _AppContext.Get_Notification_By_Where(i_Params_Get_Notification_By_Where.DESCRIPTION,i_Params_Get_Notification_By_Where.OWNER_ID,i_Params_Get_Notification_By_Where.START_ROW,i_Params_Get_Notification_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oNotification = new Notification();
oTools.CopyPropValues(oDBEntry, oNotification);
oList.Add(oNotification);
}
}
i_Params_Get_Notification_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Notification_By_Where");}
return oList;
}
public List<Owner> Get_Owner_By_Criteria(Params_Get_Owner_By_Criteria i_Params_Get_Owner_By_Criteria)
{
List<Owner> oList = new List<Owner>();
Tools.Tools oTools = new Tools.Tools();
Owner oOwner = new Owner();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Owner_By_Criteria");}
#region Body Section.
if ((i_Params_Get_Owner_By_Criteria.OWNER_ID == null) || (i_Params_Get_Owner_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Owner_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Owner_By_Criteria.START_ROW == null) { i_Params_Get_Owner_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Owner_By_Criteria.END_ROW == null) || (i_Params_Get_Owner_By_Criteria.END_ROW == 0)) { i_Params_Get_Owner_By_Criteria.END_ROW = 1000000; }
List<DALC.Owner> oList_DBEntries = _AppContext.Get_Owner_By_Criteria(i_Params_Get_Owner_By_Criteria.CODE,i_Params_Get_Owner_By_Criteria.DESCRIPTION,i_Params_Get_Owner_By_Criteria.OWNER_ID,i_Params_Get_Owner_By_Criteria.START_ROW,i_Params_Get_Owner_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oOwner = new Owner();
oTools.CopyPropValues(oDBEntry, oOwner);
oList.Add(oOwner);
}
}
i_Params_Get_Owner_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Owner_By_Criteria");}
return oList;
}
public List<Owner> Get_Owner_By_Where(Params_Get_Owner_By_Where i_Params_Get_Owner_By_Where)
{
List<Owner> oList = new List<Owner>();
Tools.Tools oTools = new Tools.Tools();
Owner oOwner = new Owner();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Owner_By_Where");}
#region Body Section.
if ((i_Params_Get_Owner_By_Where.OWNER_ID == null) || (i_Params_Get_Owner_By_Where.OWNER_ID == 0)) { i_Params_Get_Owner_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Owner_By_Where.START_ROW == null) { i_Params_Get_Owner_By_Where.START_ROW = 0; }
if ((i_Params_Get_Owner_By_Where.END_ROW == null) || (i_Params_Get_Owner_By_Where.END_ROW == 0)) { i_Params_Get_Owner_By_Where.END_ROW = 1000000; }
List<DALC.Owner> oList_DBEntries = _AppContext.Get_Owner_By_Where(i_Params_Get_Owner_By_Where.CODE,i_Params_Get_Owner_By_Where.DESCRIPTION,i_Params_Get_Owner_By_Where.OWNER_ID,i_Params_Get_Owner_By_Where.START_ROW,i_Params_Get_Owner_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oOwner = new Owner();
oTools.CopyPropValues(oDBEntry, oOwner);
oList.Add(oOwner);
}
}
i_Params_Get_Owner_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Owner_By_Where");}
return oList;
}
public List<Owner> Get_Owner_By_Criteria_V2(Params_Get_Owner_By_Criteria_V2 i_Params_Get_Owner_By_Criteria_V2)
{
List<Owner> oList = new List<Owner>();
Tools.Tools oTools = new Tools.Tools();
Owner oOwner = new Owner();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Owner_By_Criteria_V2");}
#region Body Section.
if ((i_Params_Get_Owner_By_Criteria_V2.OWNER_ID == null) || (i_Params_Get_Owner_By_Criteria_V2.OWNER_ID == 0)) { i_Params_Get_Owner_By_Criteria_V2.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Owner_By_Criteria_V2.START_ROW == null) { i_Params_Get_Owner_By_Criteria_V2.START_ROW = 0; }
if ((i_Params_Get_Owner_By_Criteria_V2.END_ROW == null) || (i_Params_Get_Owner_By_Criteria_V2.END_ROW == 0)) { i_Params_Get_Owner_By_Criteria_V2.END_ROW = 1000000; }
List<DALC.Owner> oList_DBEntries = _AppContext.Get_Owner_By_Criteria_V2(i_Params_Get_Owner_By_Criteria_V2.CODE,i_Params_Get_Owner_By_Criteria_V2.MAINTENANCE_DUE_DATE,i_Params_Get_Owner_By_Criteria_V2.DESCRIPTION,i_Params_Get_Owner_By_Criteria_V2.OWNER_ID,i_Params_Get_Owner_By_Criteria_V2.START_ROW,i_Params_Get_Owner_By_Criteria_V2.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oOwner = new Owner();
oTools.CopyPropValues(oDBEntry, oOwner);
oList.Add(oOwner);
}
}
i_Params_Get_Owner_By_Criteria_V2.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Owner_By_Criteria_V2");}
return oList;
}
public List<Owner> Get_Owner_By_Where_V2(Params_Get_Owner_By_Where_V2 i_Params_Get_Owner_By_Where_V2)
{
List<Owner> oList = new List<Owner>();
Tools.Tools oTools = new Tools.Tools();
Owner oOwner = new Owner();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Owner_By_Where_V2");}
#region Body Section.
if ((i_Params_Get_Owner_By_Where_V2.OWNER_ID == null) || (i_Params_Get_Owner_By_Where_V2.OWNER_ID == 0)) { i_Params_Get_Owner_By_Where_V2.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Owner_By_Where_V2.START_ROW == null) { i_Params_Get_Owner_By_Where_V2.START_ROW = 0; }
if ((i_Params_Get_Owner_By_Where_V2.END_ROW == null) || (i_Params_Get_Owner_By_Where_V2.END_ROW == 0)) { i_Params_Get_Owner_By_Where_V2.END_ROW = 1000000; }
List<DALC.Owner> oList_DBEntries = _AppContext.Get_Owner_By_Where_V2(i_Params_Get_Owner_By_Where_V2.CODE,i_Params_Get_Owner_By_Where_V2.MAINTENANCE_DUE_DATE,i_Params_Get_Owner_By_Where_V2.DESCRIPTION,i_Params_Get_Owner_By_Where_V2.OWNER_ID,i_Params_Get_Owner_By_Where_V2.START_ROW,i_Params_Get_Owner_By_Where_V2.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oOwner = new Owner();
oTools.CopyPropValues(oDBEntry, oOwner);
oList.Add(oOwner);
}
}
i_Params_Get_Owner_By_Where_V2.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Owner_By_Where_V2");}
return oList;
}
public List<Question> Get_Question_By_Criteria(Params_Get_Question_By_Criteria i_Params_Get_Question_By_Criteria)
{
List<Question> oList = new List<Question>();
Tools.Tools oTools = new Tools.Tools();
Question oQuestion = new Question();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Question_By_Criteria");}
#region Body Section.
if ((i_Params_Get_Question_By_Criteria.OWNER_ID == null) || (i_Params_Get_Question_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Question_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Question_By_Criteria.START_ROW == null) { i_Params_Get_Question_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Question_By_Criteria.END_ROW == null) || (i_Params_Get_Question_By_Criteria.END_ROW == 0)) { i_Params_Get_Question_By_Criteria.END_ROW = 1000000; }
List<DALC.Question> oList_DBEntries = _AppContext.Get_Question_By_Criteria(i_Params_Get_Question_By_Criteria.DESCRIPTION,i_Params_Get_Question_By_Criteria.OWNER_ID,i_Params_Get_Question_By_Criteria.START_ROW,i_Params_Get_Question_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oQuestion = new Question();
oTools.CopyPropValues(oDBEntry, oQuestion);
oList.Add(oQuestion);
}
}
i_Params_Get_Question_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Question_By_Criteria");}
return oList;
}
public List<Question> Get_Question_By_Where(Params_Get_Question_By_Where i_Params_Get_Question_By_Where)
{
List<Question> oList = new List<Question>();
Tools.Tools oTools = new Tools.Tools();
Question oQuestion = new Question();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Question_By_Where");}
#region Body Section.
if ((i_Params_Get_Question_By_Where.OWNER_ID == null) || (i_Params_Get_Question_By_Where.OWNER_ID == 0)) { i_Params_Get_Question_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Question_By_Where.START_ROW == null) { i_Params_Get_Question_By_Where.START_ROW = 0; }
if ((i_Params_Get_Question_By_Where.END_ROW == null) || (i_Params_Get_Question_By_Where.END_ROW == 0)) { i_Params_Get_Question_By_Where.END_ROW = 1000000; }
List<DALC.Question> oList_DBEntries = _AppContext.Get_Question_By_Where(i_Params_Get_Question_By_Where.DESCRIPTION,i_Params_Get_Question_By_Where.OWNER_ID,i_Params_Get_Question_By_Where.START_ROW,i_Params_Get_Question_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oQuestion = new Question();
oTools.CopyPropValues(oDBEntry, oQuestion);
oList.Add(oQuestion);
}
}
i_Params_Get_Question_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Question_By_Where");}
return oList;
}
public List<Question_report> Get_Question_report_By_Criteria(Params_Get_Question_report_By_Criteria i_Params_Get_Question_report_By_Criteria)
{
List<Question_report> oList = new List<Question_report>();
Tools.Tools oTools = new Tools.Tools();
Question_report oQuestion_report = new Question_report();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Question_report_By_Criteria");}
#region Body Section.
if ((i_Params_Get_Question_report_By_Criteria.OWNER_ID == null) || (i_Params_Get_Question_report_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Question_report_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Question_report_By_Criteria.START_ROW == null) { i_Params_Get_Question_report_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Question_report_By_Criteria.END_ROW == null) || (i_Params_Get_Question_report_By_Criteria.END_ROW == 0)) { i_Params_Get_Question_report_By_Criteria.END_ROW = 1000000; }
List<DALC.Question_report> oList_DBEntries = _AppContext.Get_Question_report_By_Criteria(i_Params_Get_Question_report_By_Criteria.DESCRIPTION,i_Params_Get_Question_report_By_Criteria.OWNER_ID,i_Params_Get_Question_report_By_Criteria.START_ROW,i_Params_Get_Question_report_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oQuestion_report = new Question_report();
oTools.CopyPropValues(oDBEntry, oQuestion_report);
oList.Add(oQuestion_report);
}
}
i_Params_Get_Question_report_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Question_report_By_Criteria");}
return oList;
}
public List<Question_report> Get_Question_report_By_Where(Params_Get_Question_report_By_Where i_Params_Get_Question_report_By_Where)
{
List<Question_report> oList = new List<Question_report>();
Tools.Tools oTools = new Tools.Tools();
Question_report oQuestion_report = new Question_report();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Question_report_By_Where");}
#region Body Section.
if ((i_Params_Get_Question_report_By_Where.OWNER_ID == null) || (i_Params_Get_Question_report_By_Where.OWNER_ID == 0)) { i_Params_Get_Question_report_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Question_report_By_Where.START_ROW == null) { i_Params_Get_Question_report_By_Where.START_ROW = 0; }
if ((i_Params_Get_Question_report_By_Where.END_ROW == null) || (i_Params_Get_Question_report_By_Where.END_ROW == 0)) { i_Params_Get_Question_report_By_Where.END_ROW = 1000000; }
List<DALC.Question_report> oList_DBEntries = _AppContext.Get_Question_report_By_Where(i_Params_Get_Question_report_By_Where.DESCRIPTION,i_Params_Get_Question_report_By_Where.OWNER_ID,i_Params_Get_Question_report_By_Where.START_ROW,i_Params_Get_Question_report_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oQuestion_report = new Question_report();
oTools.CopyPropValues(oDBEntry, oQuestion_report);
oList.Add(oQuestion_report);
}
}
i_Params_Get_Question_report_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Question_report_By_Where");}
return oList;
}
public List<Question_token> Get_Question_token_By_Criteria(Params_Get_Question_token_By_Criteria i_Params_Get_Question_token_By_Criteria)
{
List<Question_token> oList = new List<Question_token>();
Tools.Tools oTools = new Tools.Tools();
Question_token oQuestion_token = new Question_token();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Question_token_By_Criteria");}
#region Body Section.
if ((i_Params_Get_Question_token_By_Criteria.OWNER_ID == null) || (i_Params_Get_Question_token_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Question_token_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Question_token_By_Criteria.START_ROW == null) { i_Params_Get_Question_token_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Question_token_By_Criteria.END_ROW == null) || (i_Params_Get_Question_token_By_Criteria.END_ROW == 0)) { i_Params_Get_Question_token_By_Criteria.END_ROW = 1000000; }
List<DALC.Question_token> oList_DBEntries = _AppContext.Get_Question_token_By_Criteria(i_Params_Get_Question_token_By_Criteria.PART,i_Params_Get_Question_token_By_Criteria.OWNER_ID,i_Params_Get_Question_token_By_Criteria.START_ROW,i_Params_Get_Question_token_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oQuestion_token = new Question_token();
oTools.CopyPropValues(oDBEntry, oQuestion_token);
oList.Add(oQuestion_token);
}
}
i_Params_Get_Question_token_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Question_token_By_Criteria");}
return oList;
}
public List<Question_token> Get_Question_token_By_Where(Params_Get_Question_token_By_Where i_Params_Get_Question_token_By_Where)
{
List<Question_token> oList = new List<Question_token>();
Tools.Tools oTools = new Tools.Tools();
Question_token oQuestion_token = new Question_token();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Question_token_By_Where");}
#region Body Section.
if ((i_Params_Get_Question_token_By_Where.OWNER_ID == null) || (i_Params_Get_Question_token_By_Where.OWNER_ID == 0)) { i_Params_Get_Question_token_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Question_token_By_Where.START_ROW == null) { i_Params_Get_Question_token_By_Where.START_ROW = 0; }
if ((i_Params_Get_Question_token_By_Where.END_ROW == null) || (i_Params_Get_Question_token_By_Where.END_ROW == 0)) { i_Params_Get_Question_token_By_Where.END_ROW = 1000000; }
List<DALC.Question_token> oList_DBEntries = _AppContext.Get_Question_token_By_Where(i_Params_Get_Question_token_By_Where.PART,i_Params_Get_Question_token_By_Where.OWNER_ID,i_Params_Get_Question_token_By_Where.START_ROW,i_Params_Get_Question_token_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oQuestion_token = new Question_token();
oTools.CopyPropValues(oDBEntry, oQuestion_token);
oList.Add(oQuestion_token);
}
}
i_Params_Get_Question_token_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Question_token_By_Where");}
return oList;
}
public List<Report_article> Get_Report_article_By_Criteria(Params_Get_Report_article_By_Criteria i_Params_Get_Report_article_By_Criteria)
{
List<Report_article> oList = new List<Report_article>();
Tools.Tools oTools = new Tools.Tools();
Report_article oReport_article = new Report_article();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Report_article_By_Criteria");}
#region Body Section.
if ((i_Params_Get_Report_article_By_Criteria.OWNER_ID == null) || (i_Params_Get_Report_article_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Report_article_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Report_article_By_Criteria.START_ROW == null) { i_Params_Get_Report_article_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Report_article_By_Criteria.END_ROW == null) || (i_Params_Get_Report_article_By_Criteria.END_ROW == 0)) { i_Params_Get_Report_article_By_Criteria.END_ROW = 1000000; }
List<DALC.Report_article> oList_DBEntries = _AppContext.Get_Report_article_By_Criteria(i_Params_Get_Report_article_By_Criteria.DESCRIPTION,i_Params_Get_Report_article_By_Criteria.OWNER_ID,i_Params_Get_Report_article_By_Criteria.START_ROW,i_Params_Get_Report_article_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oReport_article = new Report_article();
oTools.CopyPropValues(oDBEntry, oReport_article);
oList.Add(oReport_article);
}
}
i_Params_Get_Report_article_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Report_article_By_Criteria");}
return oList;
}
public List<Report_article> Get_Report_article_By_Where(Params_Get_Report_article_By_Where i_Params_Get_Report_article_By_Where)
{
List<Report_article> oList = new List<Report_article>();
Tools.Tools oTools = new Tools.Tools();
Report_article oReport_article = new Report_article();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Report_article_By_Where");}
#region Body Section.
if ((i_Params_Get_Report_article_By_Where.OWNER_ID == null) || (i_Params_Get_Report_article_By_Where.OWNER_ID == 0)) { i_Params_Get_Report_article_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Report_article_By_Where.START_ROW == null) { i_Params_Get_Report_article_By_Where.START_ROW = 0; }
if ((i_Params_Get_Report_article_By_Where.END_ROW == null) || (i_Params_Get_Report_article_By_Where.END_ROW == 0)) { i_Params_Get_Report_article_By_Where.END_ROW = 1000000; }
List<DALC.Report_article> oList_DBEntries = _AppContext.Get_Report_article_By_Where(i_Params_Get_Report_article_By_Where.DESCRIPTION,i_Params_Get_Report_article_By_Where.OWNER_ID,i_Params_Get_Report_article_By_Where.START_ROW,i_Params_Get_Report_article_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oReport_article = new Report_article();
oTools.CopyPropValues(oDBEntry, oReport_article);
oList.Add(oReport_article);
}
}
i_Params_Get_Report_article_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Report_article_By_Where");}
return oList;
}
public List<Student> Get_Student_By_Criteria(Params_Get_Student_By_Criteria i_Params_Get_Student_By_Criteria)
{
List<Student> oList = new List<Student>();
Tools.Tools oTools = new Tools.Tools();
Student oStudent = new Student();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Student_By_Criteria");}
#region Body Section.
if ((i_Params_Get_Student_By_Criteria.OWNER_ID == null) || (i_Params_Get_Student_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Student_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Student_By_Criteria.START_ROW == null) { i_Params_Get_Student_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Student_By_Criteria.END_ROW == null) || (i_Params_Get_Student_By_Criteria.END_ROW == 0)) { i_Params_Get_Student_By_Criteria.END_ROW = 1000000; }
List<DALC.Student> oList_DBEntries = _AppContext.Get_Student_By_Criteria(i_Params_Get_Student_By_Criteria.FIRST_NAME,i_Params_Get_Student_By_Criteria.LAST_NAME,i_Params_Get_Student_By_Criteria.EMAIL,i_Params_Get_Student_By_Criteria.OWNER_ID,i_Params_Get_Student_By_Criteria.START_ROW,i_Params_Get_Student_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oStudent = new Student();
oTools.CopyPropValues(oDBEntry, oStudent);
oList.Add(oStudent);
}
}
i_Params_Get_Student_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Student_By_Criteria");}
return oList;
}
public List<Student> Get_Student_By_Where(Params_Get_Student_By_Where i_Params_Get_Student_By_Where)
{
List<Student> oList = new List<Student>();
Tools.Tools oTools = new Tools.Tools();
Student oStudent = new Student();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Student_By_Where");}
#region Body Section.
if ((i_Params_Get_Student_By_Where.OWNER_ID == null) || (i_Params_Get_Student_By_Where.OWNER_ID == 0)) { i_Params_Get_Student_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Student_By_Where.START_ROW == null) { i_Params_Get_Student_By_Where.START_ROW = 0; }
if ((i_Params_Get_Student_By_Where.END_ROW == null) || (i_Params_Get_Student_By_Where.END_ROW == 0)) { i_Params_Get_Student_By_Where.END_ROW = 1000000; }
List<DALC.Student> oList_DBEntries = _AppContext.Get_Student_By_Where(i_Params_Get_Student_By_Where.FIRST_NAME,i_Params_Get_Student_By_Where.LAST_NAME,i_Params_Get_Student_By_Where.EMAIL,i_Params_Get_Student_By_Where.OWNER_ID,i_Params_Get_Student_By_Where.START_ROW,i_Params_Get_Student_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oStudent = new Student();
oTools.CopyPropValues(oDBEntry, oStudent);
oList.Add(oStudent);
}
}
i_Params_Get_Student_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Student_By_Where");}
return oList;
}
public List<Student_report> Get_Student_report_By_Criteria(Params_Get_Student_report_By_Criteria i_Params_Get_Student_report_By_Criteria)
{
List<Student_report> oList = new List<Student_report>();
Tools.Tools oTools = new Tools.Tools();
Student_report oStudent_report = new Student_report();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Student_report_By_Criteria");}
#region Body Section.
if ((i_Params_Get_Student_report_By_Criteria.OWNER_ID == null) || (i_Params_Get_Student_report_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Student_report_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Student_report_By_Criteria.START_ROW == null) { i_Params_Get_Student_report_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Student_report_By_Criteria.END_ROW == null) || (i_Params_Get_Student_report_By_Criteria.END_ROW == 0)) { i_Params_Get_Student_report_By_Criteria.END_ROW = 1000000; }
List<DALC.Student_report> oList_DBEntries = _AppContext.Get_Student_report_By_Criteria(i_Params_Get_Student_report_By_Criteria.DESCRIPTION,i_Params_Get_Student_report_By_Criteria.OWNER_ID,i_Params_Get_Student_report_By_Criteria.START_ROW,i_Params_Get_Student_report_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oStudent_report = new Student_report();
oTools.CopyPropValues(oDBEntry, oStudent_report);
oList.Add(oStudent_report);
}
}
i_Params_Get_Student_report_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Student_report_By_Criteria");}
return oList;
}
public List<Student_report> Get_Student_report_By_Where(Params_Get_Student_report_By_Where i_Params_Get_Student_report_By_Where)
{
List<Student_report> oList = new List<Student_report>();
Tools.Tools oTools = new Tools.Tools();
Student_report oStudent_report = new Student_report();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Student_report_By_Where");}
#region Body Section.
if ((i_Params_Get_Student_report_By_Where.OWNER_ID == null) || (i_Params_Get_Student_report_By_Where.OWNER_ID == 0)) { i_Params_Get_Student_report_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Student_report_By_Where.START_ROW == null) { i_Params_Get_Student_report_By_Where.START_ROW = 0; }
if ((i_Params_Get_Student_report_By_Where.END_ROW == null) || (i_Params_Get_Student_report_By_Where.END_ROW == 0)) { i_Params_Get_Student_report_By_Where.END_ROW = 1000000; }
List<DALC.Student_report> oList_DBEntries = _AppContext.Get_Student_report_By_Where(i_Params_Get_Student_report_By_Where.DESCRIPTION,i_Params_Get_Student_report_By_Where.OWNER_ID,i_Params_Get_Student_report_By_Where.START_ROW,i_Params_Get_Student_report_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oStudent_report = new Student_report();
oTools.CopyPropValues(oDBEntry, oStudent_report);
oList.Add(oStudent_report);
}
}
i_Params_Get_Student_report_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Student_report_By_Where");}
return oList;
}
public List<Teacher> Get_Teacher_By_Criteria(Params_Get_Teacher_By_Criteria i_Params_Get_Teacher_By_Criteria)
{
List<Teacher> oList = new List<Teacher>();
Tools.Tools oTools = new Tools.Tools();
Teacher oTeacher = new Teacher();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_By_Criteria");}
#region Body Section.
if ((i_Params_Get_Teacher_By_Criteria.OWNER_ID == null) || (i_Params_Get_Teacher_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Teacher_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Teacher_By_Criteria.START_ROW == null) { i_Params_Get_Teacher_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Teacher_By_Criteria.END_ROW == null) || (i_Params_Get_Teacher_By_Criteria.END_ROW == 0)) { i_Params_Get_Teacher_By_Criteria.END_ROW = 1000000; }
List<DALC.Teacher> oList_DBEntries = _AppContext.Get_Teacher_By_Criteria(i_Params_Get_Teacher_By_Criteria.FIRST_NAME,i_Params_Get_Teacher_By_Criteria.LAST_NAME,i_Params_Get_Teacher_By_Criteria.DESCRIPTION,i_Params_Get_Teacher_By_Criteria.EMAIL,i_Params_Get_Teacher_By_Criteria.MOBILE,i_Params_Get_Teacher_By_Criteria.OWNER_ID,i_Params_Get_Teacher_By_Criteria.START_ROW,i_Params_Get_Teacher_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher = new Teacher();
oTools.CopyPropValues(oDBEntry, oTeacher);
oList.Add(oTeacher);
}
}
i_Params_Get_Teacher_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_By_Criteria");}
return oList;
}
public List<Teacher> Get_Teacher_By_Where(Params_Get_Teacher_By_Where i_Params_Get_Teacher_By_Where)
{
List<Teacher> oList = new List<Teacher>();
Tools.Tools oTools = new Tools.Tools();
Teacher oTeacher = new Teacher();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_By_Where");}
#region Body Section.
if ((i_Params_Get_Teacher_By_Where.OWNER_ID == null) || (i_Params_Get_Teacher_By_Where.OWNER_ID == 0)) { i_Params_Get_Teacher_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Teacher_By_Where.START_ROW == null) { i_Params_Get_Teacher_By_Where.START_ROW = 0; }
if ((i_Params_Get_Teacher_By_Where.END_ROW == null) || (i_Params_Get_Teacher_By_Where.END_ROW == 0)) { i_Params_Get_Teacher_By_Where.END_ROW = 1000000; }
List<DALC.Teacher> oList_DBEntries = _AppContext.Get_Teacher_By_Where(i_Params_Get_Teacher_By_Where.FIRST_NAME,i_Params_Get_Teacher_By_Where.LAST_NAME,i_Params_Get_Teacher_By_Where.DESCRIPTION,i_Params_Get_Teacher_By_Where.EMAIL,i_Params_Get_Teacher_By_Where.MOBILE,i_Params_Get_Teacher_By_Where.OWNER_ID,i_Params_Get_Teacher_By_Where.START_ROW,i_Params_Get_Teacher_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher = new Teacher();
oTools.CopyPropValues(oDBEntry, oTeacher);
oList.Add(oTeacher);
}
}
i_Params_Get_Teacher_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_By_Where");}
return oList;
}
public List<Teacher_category> Get_Teacher_category_By_Criteria(Params_Get_Teacher_category_By_Criteria i_Params_Get_Teacher_category_By_Criteria)
{
List<Teacher_category> oList = new List<Teacher_category>();
Tools.Tools oTools = new Tools.Tools();
Teacher_category oTeacher_category = new Teacher_category();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_category_By_Criteria");}
#region Body Section.
if ((i_Params_Get_Teacher_category_By_Criteria.OWNER_ID == null) || (i_Params_Get_Teacher_category_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Teacher_category_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Teacher_category_By_Criteria.START_ROW == null) { i_Params_Get_Teacher_category_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Teacher_category_By_Criteria.END_ROW == null) || (i_Params_Get_Teacher_category_By_Criteria.END_ROW == 0)) { i_Params_Get_Teacher_category_By_Criteria.END_ROW = 1000000; }
List<DALC.Teacher_category> oList_DBEntries = _AppContext.Get_Teacher_category_By_Criteria(i_Params_Get_Teacher_category_By_Criteria.DESCRIPTION,i_Params_Get_Teacher_category_By_Criteria.OWNER_ID,i_Params_Get_Teacher_category_By_Criteria.START_ROW,i_Params_Get_Teacher_category_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_category = new Teacher_category();
oTools.CopyPropValues(oDBEntry, oTeacher_category);
oList.Add(oTeacher_category);
}
}
i_Params_Get_Teacher_category_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_category_By_Criteria");}
return oList;
}
public List<Teacher_category> Get_Teacher_category_By_Where(Params_Get_Teacher_category_By_Where i_Params_Get_Teacher_category_By_Where)
{
List<Teacher_category> oList = new List<Teacher_category>();
Tools.Tools oTools = new Tools.Tools();
Teacher_category oTeacher_category = new Teacher_category();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_category_By_Where");}
#region Body Section.
if ((i_Params_Get_Teacher_category_By_Where.OWNER_ID == null) || (i_Params_Get_Teacher_category_By_Where.OWNER_ID == 0)) { i_Params_Get_Teacher_category_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Teacher_category_By_Where.START_ROW == null) { i_Params_Get_Teacher_category_By_Where.START_ROW = 0; }
if ((i_Params_Get_Teacher_category_By_Where.END_ROW == null) || (i_Params_Get_Teacher_category_By_Where.END_ROW == 0)) { i_Params_Get_Teacher_category_By_Where.END_ROW = 1000000; }
List<DALC.Teacher_category> oList_DBEntries = _AppContext.Get_Teacher_category_By_Where(i_Params_Get_Teacher_category_By_Where.DESCRIPTION,i_Params_Get_Teacher_category_By_Where.OWNER_ID,i_Params_Get_Teacher_category_By_Where.START_ROW,i_Params_Get_Teacher_category_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_category = new Teacher_category();
oTools.CopyPropValues(oDBEntry, oTeacher_category);
oList.Add(oTeacher_category);
}
}
i_Params_Get_Teacher_category_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_category_By_Where");}
return oList;
}
public List<Teacher_favorite> Get_Teacher_favorite_By_Criteria(Params_Get_Teacher_favorite_By_Criteria i_Params_Get_Teacher_favorite_By_Criteria)
{
List<Teacher_favorite> oList = new List<Teacher_favorite>();
Tools.Tools oTools = new Tools.Tools();
Teacher_favorite oTeacher_favorite = new Teacher_favorite();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_favorite_By_Criteria");}
#region Body Section.
if ((i_Params_Get_Teacher_favorite_By_Criteria.OWNER_ID == null) || (i_Params_Get_Teacher_favorite_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Teacher_favorite_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Teacher_favorite_By_Criteria.START_ROW == null) { i_Params_Get_Teacher_favorite_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Teacher_favorite_By_Criteria.END_ROW == null) || (i_Params_Get_Teacher_favorite_By_Criteria.END_ROW == 0)) { i_Params_Get_Teacher_favorite_By_Criteria.END_ROW = 1000000; }
List<DALC.Teacher_favorite> oList_DBEntries = _AppContext.Get_Teacher_favorite_By_Criteria(i_Params_Get_Teacher_favorite_By_Criteria.DESCRIPTION,i_Params_Get_Teacher_favorite_By_Criteria.OWNER_ID,i_Params_Get_Teacher_favorite_By_Criteria.START_ROW,i_Params_Get_Teacher_favorite_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_favorite = new Teacher_favorite();
oTools.CopyPropValues(oDBEntry, oTeacher_favorite);
oList.Add(oTeacher_favorite);
}
}
i_Params_Get_Teacher_favorite_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_favorite_By_Criteria");}
return oList;
}
public List<Teacher_favorite> Get_Teacher_favorite_By_Where(Params_Get_Teacher_favorite_By_Where i_Params_Get_Teacher_favorite_By_Where)
{
List<Teacher_favorite> oList = new List<Teacher_favorite>();
Tools.Tools oTools = new Tools.Tools();
Teacher_favorite oTeacher_favorite = new Teacher_favorite();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_favorite_By_Where");}
#region Body Section.
if ((i_Params_Get_Teacher_favorite_By_Where.OWNER_ID == null) || (i_Params_Get_Teacher_favorite_By_Where.OWNER_ID == 0)) { i_Params_Get_Teacher_favorite_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Teacher_favorite_By_Where.START_ROW == null) { i_Params_Get_Teacher_favorite_By_Where.START_ROW = 0; }
if ((i_Params_Get_Teacher_favorite_By_Where.END_ROW == null) || (i_Params_Get_Teacher_favorite_By_Where.END_ROW == 0)) { i_Params_Get_Teacher_favorite_By_Where.END_ROW = 1000000; }
List<DALC.Teacher_favorite> oList_DBEntries = _AppContext.Get_Teacher_favorite_By_Where(i_Params_Get_Teacher_favorite_By_Where.DESCRIPTION,i_Params_Get_Teacher_favorite_By_Where.OWNER_ID,i_Params_Get_Teacher_favorite_By_Where.START_ROW,i_Params_Get_Teacher_favorite_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_favorite = new Teacher_favorite();
oTools.CopyPropValues(oDBEntry, oTeacher_favorite);
oList.Add(oTeacher_favorite);
}
}
i_Params_Get_Teacher_favorite_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_favorite_By_Where");}
return oList;
}
public List<Teacher_rank> Get_Teacher_rank_By_Criteria(Params_Get_Teacher_rank_By_Criteria i_Params_Get_Teacher_rank_By_Criteria)
{
List<Teacher_rank> oList = new List<Teacher_rank>();
Tools.Tools oTools = new Tools.Tools();
Teacher_rank oTeacher_rank = new Teacher_rank();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_rank_By_Criteria");}
#region Body Section.
if ((i_Params_Get_Teacher_rank_By_Criteria.OWNER_ID == null) || (i_Params_Get_Teacher_rank_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Teacher_rank_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Teacher_rank_By_Criteria.START_ROW == null) { i_Params_Get_Teacher_rank_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Teacher_rank_By_Criteria.END_ROW == null) || (i_Params_Get_Teacher_rank_By_Criteria.END_ROW == 0)) { i_Params_Get_Teacher_rank_By_Criteria.END_ROW = 1000000; }
List<DALC.Teacher_rank> oList_DBEntries = _AppContext.Get_Teacher_rank_By_Criteria(i_Params_Get_Teacher_rank_By_Criteria.DESCRIPTION,i_Params_Get_Teacher_rank_By_Criteria.OWNER_ID,i_Params_Get_Teacher_rank_By_Criteria.START_ROW,i_Params_Get_Teacher_rank_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_rank = new Teacher_rank();
oTools.CopyPropValues(oDBEntry, oTeacher_rank);
oList.Add(oTeacher_rank);
}
}
i_Params_Get_Teacher_rank_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_rank_By_Criteria");}
return oList;
}
public List<Teacher_rank> Get_Teacher_rank_By_Where(Params_Get_Teacher_rank_By_Where i_Params_Get_Teacher_rank_By_Where)
{
List<Teacher_rank> oList = new List<Teacher_rank>();
Tools.Tools oTools = new Tools.Tools();
Teacher_rank oTeacher_rank = new Teacher_rank();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_rank_By_Where");}
#region Body Section.
if ((i_Params_Get_Teacher_rank_By_Where.OWNER_ID == null) || (i_Params_Get_Teacher_rank_By_Where.OWNER_ID == 0)) { i_Params_Get_Teacher_rank_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Teacher_rank_By_Where.START_ROW == null) { i_Params_Get_Teacher_rank_By_Where.START_ROW = 0; }
if ((i_Params_Get_Teacher_rank_By_Where.END_ROW == null) || (i_Params_Get_Teacher_rank_By_Where.END_ROW == 0)) { i_Params_Get_Teacher_rank_By_Where.END_ROW = 1000000; }
List<DALC.Teacher_rank> oList_DBEntries = _AppContext.Get_Teacher_rank_By_Where(i_Params_Get_Teacher_rank_By_Where.DESCRIPTION,i_Params_Get_Teacher_rank_By_Where.OWNER_ID,i_Params_Get_Teacher_rank_By_Where.START_ROW,i_Params_Get_Teacher_rank_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_rank = new Teacher_rank();
oTools.CopyPropValues(oDBEntry, oTeacher_rank);
oList.Add(oTeacher_rank);
}
}
i_Params_Get_Teacher_rank_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_rank_By_Where");}
return oList;
}
public List<Teacher_report> Get_Teacher_report_By_Criteria(Params_Get_Teacher_report_By_Criteria i_Params_Get_Teacher_report_By_Criteria)
{
List<Teacher_report> oList = new List<Teacher_report>();
Tools.Tools oTools = new Tools.Tools();
Teacher_report oTeacher_report = new Teacher_report();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_report_By_Criteria");}
#region Body Section.
if ((i_Params_Get_Teacher_report_By_Criteria.OWNER_ID == null) || (i_Params_Get_Teacher_report_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Teacher_report_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Teacher_report_By_Criteria.START_ROW == null) { i_Params_Get_Teacher_report_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Teacher_report_By_Criteria.END_ROW == null) || (i_Params_Get_Teacher_report_By_Criteria.END_ROW == 0)) { i_Params_Get_Teacher_report_By_Criteria.END_ROW = 1000000; }
List<DALC.Teacher_report> oList_DBEntries = _AppContext.Get_Teacher_report_By_Criteria(i_Params_Get_Teacher_report_By_Criteria.DESCRIPTION,i_Params_Get_Teacher_report_By_Criteria.OWNER_ID,i_Params_Get_Teacher_report_By_Criteria.START_ROW,i_Params_Get_Teacher_report_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_report = new Teacher_report();
oTools.CopyPropValues(oDBEntry, oTeacher_report);
oList.Add(oTeacher_report);
}
}
i_Params_Get_Teacher_report_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_report_By_Criteria");}
return oList;
}
public List<Teacher_report> Get_Teacher_report_By_Where(Params_Get_Teacher_report_By_Where i_Params_Get_Teacher_report_By_Where)
{
List<Teacher_report> oList = new List<Teacher_report>();
Tools.Tools oTools = new Tools.Tools();
Teacher_report oTeacher_report = new Teacher_report();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_report_By_Where");}
#region Body Section.
if ((i_Params_Get_Teacher_report_By_Where.OWNER_ID == null) || (i_Params_Get_Teacher_report_By_Where.OWNER_ID == 0)) { i_Params_Get_Teacher_report_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Teacher_report_By_Where.START_ROW == null) { i_Params_Get_Teacher_report_By_Where.START_ROW = 0; }
if ((i_Params_Get_Teacher_report_By_Where.END_ROW == null) || (i_Params_Get_Teacher_report_By_Where.END_ROW == 0)) { i_Params_Get_Teacher_report_By_Where.END_ROW = 1000000; }
List<DALC.Teacher_report> oList_DBEntries = _AppContext.Get_Teacher_report_By_Where(i_Params_Get_Teacher_report_By_Where.DESCRIPTION,i_Params_Get_Teacher_report_By_Where.OWNER_ID,i_Params_Get_Teacher_report_By_Where.START_ROW,i_Params_Get_Teacher_report_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_report = new Teacher_report();
oTools.CopyPropValues(oDBEntry, oTeacher_report);
oList.Add(oTeacher_report);
}
}
i_Params_Get_Teacher_report_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_report_By_Where");}
return oList;
}
public List<User> Get_User_By_Criteria(Params_Get_User_By_Criteria i_Params_Get_User_By_Criteria)
{
List<User> oList = new List<User>();
Tools.Tools oTools = new Tools.Tools();
User oUser = new User();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_User_By_Criteria");}
#region Body Section.
if ((i_Params_Get_User_By_Criteria.OWNER_ID == null) || (i_Params_Get_User_By_Criteria.OWNER_ID == 0)) { i_Params_Get_User_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_User_By_Criteria.START_ROW == null) { i_Params_Get_User_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_User_By_Criteria.END_ROW == null) || (i_Params_Get_User_By_Criteria.END_ROW == 0)) { i_Params_Get_User_By_Criteria.END_ROW = 1000000; }
List<DALC.User> oList_DBEntries = _AppContext.Get_User_By_Criteria(i_Params_Get_User_By_Criteria.USERNAME,i_Params_Get_User_By_Criteria.PASSWORD,i_Params_Get_User_By_Criteria.USER_TYPE_CODE,i_Params_Get_User_By_Criteria.OWNER_ID,i_Params_Get_User_By_Criteria.START_ROW,i_Params_Get_User_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oUser = new User();
oTools.CopyPropValues(oDBEntry, oUser);
oList.Add(oUser);
}
}
i_Params_Get_User_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_User_By_Criteria");}
return oList;
}
public List<User> Get_User_By_Where(Params_Get_User_By_Where i_Params_Get_User_By_Where)
{
List<User> oList = new List<User>();
Tools.Tools oTools = new Tools.Tools();
User oUser = new User();
long? tmp_TOTAL_COUNT = 0;
if (OnPreEvent_General != null){OnPreEvent_General("Get_User_By_Where");}
#region Body Section.
if ((i_Params_Get_User_By_Where.OWNER_ID == null) || (i_Params_Get_User_By_Where.OWNER_ID == 0)) { i_Params_Get_User_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_User_By_Where.START_ROW == null) { i_Params_Get_User_By_Where.START_ROW = 0; }
if ((i_Params_Get_User_By_Where.END_ROW == null) || (i_Params_Get_User_By_Where.END_ROW == 0)) { i_Params_Get_User_By_Where.END_ROW = 1000000; }
List<DALC.User> oList_DBEntries = _AppContext.Get_User_By_Where(i_Params_Get_User_By_Where.USERNAME,i_Params_Get_User_By_Where.PASSWORD,i_Params_Get_User_By_Where.USER_TYPE_CODE,i_Params_Get_User_By_Where.OWNER_ID,i_Params_Get_User_By_Where.START_ROW,i_Params_Get_User_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oUser = new User();
oTools.CopyPropValues(oDBEntry, oUser);
oList.Add(oUser);
}
}
i_Params_Get_User_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_User_By_Where");}
return oList;
}
public List<Answer> Get_Answer_By_Criteria_InList(Params_Get_Answer_By_Criteria_InList i_Params_Get_Answer_By_Criteria_InList)
{
List<Answer> oList = new List<Answer>();
Tools.Tools oTools = new Tools.Tools();
Answer oAnswer = new Answer();
long? tmp_TOTAL_COUNT = 0;
Params_Get_Answer_By_Criteria_InList_SP oParams_Get_Answer_By_Criteria_InList_SP = new Params_Get_Answer_By_Criteria_InList_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Answer_By_Criteria_InList");}
#region Body Section.
if ((i_Params_Get_Answer_By_Criteria_InList.OWNER_ID == null) || (i_Params_Get_Answer_By_Criteria_InList.OWNER_ID == 0)) { i_Params_Get_Answer_By_Criteria_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Answer_By_Criteria_InList.START_ROW == null) { i_Params_Get_Answer_By_Criteria_InList.START_ROW = 0; }
if ((i_Params_Get_Answer_By_Criteria_InList.END_ROW == null) || (i_Params_Get_Answer_By_Criteria_InList.END_ROW == 0)) { i_Params_Get_Answer_By_Criteria_InList.END_ROW = 1000000; }
oParams_Get_Answer_By_Criteria_InList_SP.OWNER_ID = i_Params_Get_Answer_By_Criteria_InList.OWNER_ID;
oParams_Get_Answer_By_Criteria_InList_SP.DESCRIPTION = i_Params_Get_Answer_By_Criteria_InList.DESCRIPTION;
if ( i_Params_Get_Answer_By_Criteria_InList.QUESTION_ID_LIST == null)
{
i_Params_Get_Answer_By_Criteria_InList.QUESTION_ID_LIST = new List<Int32?>();
}
oParams_Get_Answer_By_Criteria_InList_SP.QUESTION_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Answer_By_Criteria_InList.QUESTION_ID_LIST);
if ( i_Params_Get_Answer_By_Criteria_InList.TEACHER_ID_LIST == null)
{
i_Params_Get_Answer_By_Criteria_InList.TEACHER_ID_LIST = new List<Int32?>();
}
oParams_Get_Answer_By_Criteria_InList_SP.TEACHER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Answer_By_Criteria_InList.TEACHER_ID_LIST);
oParams_Get_Answer_By_Criteria_InList_SP.START_ROW = i_Params_Get_Answer_By_Criteria_InList.START_ROW;
oParams_Get_Answer_By_Criteria_InList_SP.END_ROW = i_Params_Get_Answer_By_Criteria_InList.END_ROW;
oParams_Get_Answer_By_Criteria_InList_SP.TOTAL_COUNT = i_Params_Get_Answer_By_Criteria_InList.TOTAL_COUNT;
List<DALC.Answer> oList_DBEntries = _AppContext.Get_Answer_By_Criteria_InList(i_Params_Get_Answer_By_Criteria_InList.DESCRIPTION,i_Params_Get_Answer_By_Criteria_InList.QUESTION_ID_LIST,i_Params_Get_Answer_By_Criteria_InList.TEACHER_ID_LIST,i_Params_Get_Answer_By_Criteria_InList.OWNER_ID,i_Params_Get_Answer_By_Criteria_InList.START_ROW,i_Params_Get_Answer_By_Criteria_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oAnswer = new Answer();
oTools.CopyPropValues(oDBEntry, oAnswer);
oList.Add(oAnswer);
}
}
i_Params_Get_Answer_By_Criteria_InList.TOTAL_COUNT = oParams_Get_Answer_By_Criteria_InList_SP.TOTAL_COUNT;
i_Params_Get_Answer_By_Criteria_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Answer_By_Criteria_InList");}
return oList;
}
public List<Answer> Get_Answer_By_Where_InList(Params_Get_Answer_By_Where_InList i_Params_Get_Answer_By_Where_InList)
{
List<Answer> oList = new List<Answer>();
Tools.Tools oTools = new Tools.Tools();
Answer oAnswer = new Answer();
long? tmp_TOTAL_COUNT = 0;
Params_Get_Answer_By_Where_InList_SP oParams_Get_Answer_By_Where_InList_SP = new Params_Get_Answer_By_Where_InList_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Answer_By_Where_InList");}
#region Body Section.
if ((i_Params_Get_Answer_By_Where_InList.OWNER_ID == null) || (i_Params_Get_Answer_By_Where_InList.OWNER_ID == 0)) { i_Params_Get_Answer_By_Where_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Answer_By_Where_InList.START_ROW == null) { i_Params_Get_Answer_By_Where_InList.START_ROW = 0; }
if ((i_Params_Get_Answer_By_Where_InList.END_ROW == null) || (i_Params_Get_Answer_By_Where_InList.END_ROW == 0)) { i_Params_Get_Answer_By_Where_InList.END_ROW = 1000000; }
oParams_Get_Answer_By_Where_InList_SP.OWNER_ID = i_Params_Get_Answer_By_Where_InList.OWNER_ID;
oParams_Get_Answer_By_Where_InList_SP.DESCRIPTION = i_Params_Get_Answer_By_Where_InList.DESCRIPTION;
if ( i_Params_Get_Answer_By_Where_InList.QUESTION_ID_LIST == null)
{
i_Params_Get_Answer_By_Where_InList.QUESTION_ID_LIST = new List<Int32?>();
}
oParams_Get_Answer_By_Where_InList_SP.QUESTION_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Answer_By_Where_InList.QUESTION_ID_LIST);
if ( i_Params_Get_Answer_By_Where_InList.TEACHER_ID_LIST == null)
{
i_Params_Get_Answer_By_Where_InList.TEACHER_ID_LIST = new List<Int32?>();
}
oParams_Get_Answer_By_Where_InList_SP.TEACHER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Answer_By_Where_InList.TEACHER_ID_LIST);
oParams_Get_Answer_By_Where_InList_SP.START_ROW = i_Params_Get_Answer_By_Where_InList.START_ROW;
oParams_Get_Answer_By_Where_InList_SP.END_ROW = i_Params_Get_Answer_By_Where_InList.END_ROW;
oParams_Get_Answer_By_Where_InList_SP.TOTAL_COUNT = i_Params_Get_Answer_By_Where_InList.TOTAL_COUNT;
List<DALC.Answer> oList_DBEntries = _AppContext.Get_Answer_By_Where_InList(i_Params_Get_Answer_By_Where_InList.DESCRIPTION,i_Params_Get_Answer_By_Where_InList.QUESTION_ID_LIST,i_Params_Get_Answer_By_Where_InList.TEACHER_ID_LIST,i_Params_Get_Answer_By_Where_InList.OWNER_ID,i_Params_Get_Answer_By_Where_InList.START_ROW,i_Params_Get_Answer_By_Where_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oAnswer = new Answer();
oTools.CopyPropValues(oDBEntry, oAnswer);
oList.Add(oAnswer);
}
}
i_Params_Get_Answer_By_Where_InList.TOTAL_COUNT = oParams_Get_Answer_By_Where_InList_SP.TOTAL_COUNT;
i_Params_Get_Answer_By_Where_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Answer_By_Where_InList");}
return oList;
}
public List<Answer_report> Get_Answer_report_By_Criteria_InList(Params_Get_Answer_report_By_Criteria_InList i_Params_Get_Answer_report_By_Criteria_InList)
{
List<Answer_report> oList = new List<Answer_report>();
Tools.Tools oTools = new Tools.Tools();
Answer_report oAnswer_report = new Answer_report();
long? tmp_TOTAL_COUNT = 0;
Params_Get_Answer_report_By_Criteria_InList_SP oParams_Get_Answer_report_By_Criteria_InList_SP = new Params_Get_Answer_report_By_Criteria_InList_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Answer_report_By_Criteria_InList");}
#region Body Section.
if ((i_Params_Get_Answer_report_By_Criteria_InList.OWNER_ID == null) || (i_Params_Get_Answer_report_By_Criteria_InList.OWNER_ID == 0)) { i_Params_Get_Answer_report_By_Criteria_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Answer_report_By_Criteria_InList.START_ROW == null) { i_Params_Get_Answer_report_By_Criteria_InList.START_ROW = 0; }
if ((i_Params_Get_Answer_report_By_Criteria_InList.END_ROW == null) || (i_Params_Get_Answer_report_By_Criteria_InList.END_ROW == 0)) { i_Params_Get_Answer_report_By_Criteria_InList.END_ROW = 1000000; }
oParams_Get_Answer_report_By_Criteria_InList_SP.OWNER_ID = i_Params_Get_Answer_report_By_Criteria_InList.OWNER_ID;
oParams_Get_Answer_report_By_Criteria_InList_SP.DESCRIPTION = i_Params_Get_Answer_report_By_Criteria_InList.DESCRIPTION;
if ( i_Params_Get_Answer_report_By_Criteria_InList.TEACHER_ID_LIST == null)
{
i_Params_Get_Answer_report_By_Criteria_InList.TEACHER_ID_LIST = new List<Int32?>();
}
oParams_Get_Answer_report_By_Criteria_InList_SP.TEACHER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Answer_report_By_Criteria_InList.TEACHER_ID_LIST);
if ( i_Params_Get_Answer_report_By_Criteria_InList.STUDENT_ID_LIST == null)
{
i_Params_Get_Answer_report_By_Criteria_InList.STUDENT_ID_LIST = new List<Int32?>();
}
oParams_Get_Answer_report_By_Criteria_InList_SP.STUDENT_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Answer_report_By_Criteria_InList.STUDENT_ID_LIST);
if ( i_Params_Get_Answer_report_By_Criteria_InList.ANSWER_ID_LIST == null)
{
i_Params_Get_Answer_report_By_Criteria_InList.ANSWER_ID_LIST = new List<Int32?>();
}
oParams_Get_Answer_report_By_Criteria_InList_SP.ANSWER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Answer_report_By_Criteria_InList.ANSWER_ID_LIST);
oParams_Get_Answer_report_By_Criteria_InList_SP.START_ROW = i_Params_Get_Answer_report_By_Criteria_InList.START_ROW;
oParams_Get_Answer_report_By_Criteria_InList_SP.END_ROW = i_Params_Get_Answer_report_By_Criteria_InList.END_ROW;
oParams_Get_Answer_report_By_Criteria_InList_SP.TOTAL_COUNT = i_Params_Get_Answer_report_By_Criteria_InList.TOTAL_COUNT;
List<DALC.Answer_report> oList_DBEntries = _AppContext.Get_Answer_report_By_Criteria_InList(i_Params_Get_Answer_report_By_Criteria_InList.DESCRIPTION,i_Params_Get_Answer_report_By_Criteria_InList.TEACHER_ID_LIST,i_Params_Get_Answer_report_By_Criteria_InList.STUDENT_ID_LIST,i_Params_Get_Answer_report_By_Criteria_InList.ANSWER_ID_LIST,i_Params_Get_Answer_report_By_Criteria_InList.OWNER_ID,i_Params_Get_Answer_report_By_Criteria_InList.START_ROW,i_Params_Get_Answer_report_By_Criteria_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oAnswer_report = new Answer_report();
oTools.CopyPropValues(oDBEntry, oAnswer_report);
oList.Add(oAnswer_report);
}
}
i_Params_Get_Answer_report_By_Criteria_InList.TOTAL_COUNT = oParams_Get_Answer_report_By_Criteria_InList_SP.TOTAL_COUNT;
i_Params_Get_Answer_report_By_Criteria_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Answer_report_By_Criteria_InList");}
return oList;
}
public List<Answer_report> Get_Answer_report_By_Where_InList(Params_Get_Answer_report_By_Where_InList i_Params_Get_Answer_report_By_Where_InList)
{
List<Answer_report> oList = new List<Answer_report>();
Tools.Tools oTools = new Tools.Tools();
Answer_report oAnswer_report = new Answer_report();
long? tmp_TOTAL_COUNT = 0;
Params_Get_Answer_report_By_Where_InList_SP oParams_Get_Answer_report_By_Where_InList_SP = new Params_Get_Answer_report_By_Where_InList_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Answer_report_By_Where_InList");}
#region Body Section.
if ((i_Params_Get_Answer_report_By_Where_InList.OWNER_ID == null) || (i_Params_Get_Answer_report_By_Where_InList.OWNER_ID == 0)) { i_Params_Get_Answer_report_By_Where_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Answer_report_By_Where_InList.START_ROW == null) { i_Params_Get_Answer_report_By_Where_InList.START_ROW = 0; }
if ((i_Params_Get_Answer_report_By_Where_InList.END_ROW == null) || (i_Params_Get_Answer_report_By_Where_InList.END_ROW == 0)) { i_Params_Get_Answer_report_By_Where_InList.END_ROW = 1000000; }
oParams_Get_Answer_report_By_Where_InList_SP.OWNER_ID = i_Params_Get_Answer_report_By_Where_InList.OWNER_ID;
oParams_Get_Answer_report_By_Where_InList_SP.DESCRIPTION = i_Params_Get_Answer_report_By_Where_InList.DESCRIPTION;
if ( i_Params_Get_Answer_report_By_Where_InList.TEACHER_ID_LIST == null)
{
i_Params_Get_Answer_report_By_Where_InList.TEACHER_ID_LIST = new List<Int32?>();
}
oParams_Get_Answer_report_By_Where_InList_SP.TEACHER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Answer_report_By_Where_InList.TEACHER_ID_LIST);
if ( i_Params_Get_Answer_report_By_Where_InList.STUDENT_ID_LIST == null)
{
i_Params_Get_Answer_report_By_Where_InList.STUDENT_ID_LIST = new List<Int32?>();
}
oParams_Get_Answer_report_By_Where_InList_SP.STUDENT_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Answer_report_By_Where_InList.STUDENT_ID_LIST);
if ( i_Params_Get_Answer_report_By_Where_InList.ANSWER_ID_LIST == null)
{
i_Params_Get_Answer_report_By_Where_InList.ANSWER_ID_LIST = new List<Int32?>();
}
oParams_Get_Answer_report_By_Where_InList_SP.ANSWER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Answer_report_By_Where_InList.ANSWER_ID_LIST);
oParams_Get_Answer_report_By_Where_InList_SP.START_ROW = i_Params_Get_Answer_report_By_Where_InList.START_ROW;
oParams_Get_Answer_report_By_Where_InList_SP.END_ROW = i_Params_Get_Answer_report_By_Where_InList.END_ROW;
oParams_Get_Answer_report_By_Where_InList_SP.TOTAL_COUNT = i_Params_Get_Answer_report_By_Where_InList.TOTAL_COUNT;
List<DALC.Answer_report> oList_DBEntries = _AppContext.Get_Answer_report_By_Where_InList(i_Params_Get_Answer_report_By_Where_InList.DESCRIPTION,i_Params_Get_Answer_report_By_Where_InList.TEACHER_ID_LIST,i_Params_Get_Answer_report_By_Where_InList.STUDENT_ID_LIST,i_Params_Get_Answer_report_By_Where_InList.ANSWER_ID_LIST,i_Params_Get_Answer_report_By_Where_InList.OWNER_ID,i_Params_Get_Answer_report_By_Where_InList.START_ROW,i_Params_Get_Answer_report_By_Where_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oAnswer_report = new Answer_report();
oTools.CopyPropValues(oDBEntry, oAnswer_report);
oList.Add(oAnswer_report);
}
}
i_Params_Get_Answer_report_By_Where_InList.TOTAL_COUNT = oParams_Get_Answer_report_By_Where_InList_SP.TOTAL_COUNT;
i_Params_Get_Answer_report_By_Where_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Answer_report_By_Where_InList");}
return oList;
}
public List<Article> Get_Article_By_Criteria_InList(Params_Get_Article_By_Criteria_InList i_Params_Get_Article_By_Criteria_InList)
{
List<Article> oList = new List<Article>();
Tools.Tools oTools = new Tools.Tools();
Article oArticle = new Article();
long? tmp_TOTAL_COUNT = 0;
Params_Get_Article_By_Criteria_InList_SP oParams_Get_Article_By_Criteria_InList_SP = new Params_Get_Article_By_Criteria_InList_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Article_By_Criteria_InList");}
#region Body Section.
if ((i_Params_Get_Article_By_Criteria_InList.OWNER_ID == null) || (i_Params_Get_Article_By_Criteria_InList.OWNER_ID == 0)) { i_Params_Get_Article_By_Criteria_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Article_By_Criteria_InList.START_ROW == null) { i_Params_Get_Article_By_Criteria_InList.START_ROW = 0; }
if ((i_Params_Get_Article_By_Criteria_InList.END_ROW == null) || (i_Params_Get_Article_By_Criteria_InList.END_ROW == 0)) { i_Params_Get_Article_By_Criteria_InList.END_ROW = 1000000; }
oParams_Get_Article_By_Criteria_InList_SP.OWNER_ID = i_Params_Get_Article_By_Criteria_InList.OWNER_ID;
oParams_Get_Article_By_Criteria_InList_SP.TITLE = i_Params_Get_Article_By_Criteria_InList.TITLE;
oParams_Get_Article_By_Criteria_InList_SP.DESCRIPTION = i_Params_Get_Article_By_Criteria_InList.DESCRIPTION;
if ( i_Params_Get_Article_By_Criteria_InList.TEACHER_ID_LIST == null)
{
i_Params_Get_Article_By_Criteria_InList.TEACHER_ID_LIST = new List<Int32?>();
}
oParams_Get_Article_By_Criteria_InList_SP.TEACHER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Article_By_Criteria_InList.TEACHER_ID_LIST);
if ( i_Params_Get_Article_By_Criteria_InList.CATEGORY_ID_LIST == null)
{
i_Params_Get_Article_By_Criteria_InList.CATEGORY_ID_LIST = new List<Int32?>();
}
oParams_Get_Article_By_Criteria_InList_SP.CATEGORY_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Article_By_Criteria_InList.CATEGORY_ID_LIST);
oParams_Get_Article_By_Criteria_InList_SP.START_ROW = i_Params_Get_Article_By_Criteria_InList.START_ROW;
oParams_Get_Article_By_Criteria_InList_SP.END_ROW = i_Params_Get_Article_By_Criteria_InList.END_ROW;
oParams_Get_Article_By_Criteria_InList_SP.TOTAL_COUNT = i_Params_Get_Article_By_Criteria_InList.TOTAL_COUNT;
List<DALC.Article> oList_DBEntries = _AppContext.Get_Article_By_Criteria_InList(i_Params_Get_Article_By_Criteria_InList.TITLE,i_Params_Get_Article_By_Criteria_InList.DESCRIPTION,i_Params_Get_Article_By_Criteria_InList.TEACHER_ID_LIST,i_Params_Get_Article_By_Criteria_InList.CATEGORY_ID_LIST,i_Params_Get_Article_By_Criteria_InList.OWNER_ID,i_Params_Get_Article_By_Criteria_InList.START_ROW,i_Params_Get_Article_By_Criteria_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oArticle = new Article();
oTools.CopyPropValues(oDBEntry, oArticle);
oList.Add(oArticle);
}
}
i_Params_Get_Article_By_Criteria_InList.TOTAL_COUNT = oParams_Get_Article_By_Criteria_InList_SP.TOTAL_COUNT;
i_Params_Get_Article_By_Criteria_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Article_By_Criteria_InList");}
return oList;
}
public List<Article> Get_Article_By_Where_InList(Params_Get_Article_By_Where_InList i_Params_Get_Article_By_Where_InList)
{
List<Article> oList = new List<Article>();
Tools.Tools oTools = new Tools.Tools();
Article oArticle = new Article();
long? tmp_TOTAL_COUNT = 0;
Params_Get_Article_By_Where_InList_SP oParams_Get_Article_By_Where_InList_SP = new Params_Get_Article_By_Where_InList_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Article_By_Where_InList");}
#region Body Section.
if ((i_Params_Get_Article_By_Where_InList.OWNER_ID == null) || (i_Params_Get_Article_By_Where_InList.OWNER_ID == 0)) { i_Params_Get_Article_By_Where_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Article_By_Where_InList.START_ROW == null) { i_Params_Get_Article_By_Where_InList.START_ROW = 0; }
if ((i_Params_Get_Article_By_Where_InList.END_ROW == null) || (i_Params_Get_Article_By_Where_InList.END_ROW == 0)) { i_Params_Get_Article_By_Where_InList.END_ROW = 1000000; }
oParams_Get_Article_By_Where_InList_SP.OWNER_ID = i_Params_Get_Article_By_Where_InList.OWNER_ID;
oParams_Get_Article_By_Where_InList_SP.TITLE = i_Params_Get_Article_By_Where_InList.TITLE;
oParams_Get_Article_By_Where_InList_SP.DESCRIPTION = i_Params_Get_Article_By_Where_InList.DESCRIPTION;
if ( i_Params_Get_Article_By_Where_InList.TEACHER_ID_LIST == null)
{
i_Params_Get_Article_By_Where_InList.TEACHER_ID_LIST = new List<Int32?>();
}
oParams_Get_Article_By_Where_InList_SP.TEACHER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Article_By_Where_InList.TEACHER_ID_LIST);
if ( i_Params_Get_Article_By_Where_InList.CATEGORY_ID_LIST == null)
{
i_Params_Get_Article_By_Where_InList.CATEGORY_ID_LIST = new List<Int32?>();
}
oParams_Get_Article_By_Where_InList_SP.CATEGORY_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Article_By_Where_InList.CATEGORY_ID_LIST);
oParams_Get_Article_By_Where_InList_SP.START_ROW = i_Params_Get_Article_By_Where_InList.START_ROW;
oParams_Get_Article_By_Where_InList_SP.END_ROW = i_Params_Get_Article_By_Where_InList.END_ROW;
oParams_Get_Article_By_Where_InList_SP.TOTAL_COUNT = i_Params_Get_Article_By_Where_InList.TOTAL_COUNT;
List<DALC.Article> oList_DBEntries = _AppContext.Get_Article_By_Where_InList(i_Params_Get_Article_By_Where_InList.TITLE,i_Params_Get_Article_By_Where_InList.DESCRIPTION,i_Params_Get_Article_By_Where_InList.TEACHER_ID_LIST,i_Params_Get_Article_By_Where_InList.CATEGORY_ID_LIST,i_Params_Get_Article_By_Where_InList.OWNER_ID,i_Params_Get_Article_By_Where_InList.START_ROW,i_Params_Get_Article_By_Where_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oArticle = new Article();
oTools.CopyPropValues(oDBEntry, oArticle);
oList.Add(oArticle);
}
}
i_Params_Get_Article_By_Where_InList.TOTAL_COUNT = oParams_Get_Article_By_Where_InList_SP.TOTAL_COUNT;
i_Params_Get_Article_By_Where_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Article_By_Where_InList");}
return oList;
}
public List<Evaluation> Get_Evaluation_By_Criteria_InList(Params_Get_Evaluation_By_Criteria_InList i_Params_Get_Evaluation_By_Criteria_InList)
{
List<Evaluation> oList = new List<Evaluation>();
Tools.Tools oTools = new Tools.Tools();
Evaluation oEvaluation = new Evaluation();
long? tmp_TOTAL_COUNT = 0;
Params_Get_Evaluation_By_Criteria_InList_SP oParams_Get_Evaluation_By_Criteria_InList_SP = new Params_Get_Evaluation_By_Criteria_InList_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Evaluation_By_Criteria_InList");}
#region Body Section.
if ((i_Params_Get_Evaluation_By_Criteria_InList.OWNER_ID == null) || (i_Params_Get_Evaluation_By_Criteria_InList.OWNER_ID == 0)) { i_Params_Get_Evaluation_By_Criteria_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Evaluation_By_Criteria_InList.START_ROW == null) { i_Params_Get_Evaluation_By_Criteria_InList.START_ROW = 0; }
if ((i_Params_Get_Evaluation_By_Criteria_InList.END_ROW == null) || (i_Params_Get_Evaluation_By_Criteria_InList.END_ROW == 0)) { i_Params_Get_Evaluation_By_Criteria_InList.END_ROW = 1000000; }
oParams_Get_Evaluation_By_Criteria_InList_SP.OWNER_ID = i_Params_Get_Evaluation_By_Criteria_InList.OWNER_ID;
oParams_Get_Evaluation_By_Criteria_InList_SP.DESCRIPTION = i_Params_Get_Evaluation_By_Criteria_InList.DESCRIPTION;
if ( i_Params_Get_Evaluation_By_Criteria_InList.STUDENT_ID_LIST == null)
{
i_Params_Get_Evaluation_By_Criteria_InList.STUDENT_ID_LIST = new List<Int32?>();
}
oParams_Get_Evaluation_By_Criteria_InList_SP.STUDENT_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Evaluation_By_Criteria_InList.STUDENT_ID_LIST);
if ( i_Params_Get_Evaluation_By_Criteria_InList.ANSWER_ID_LIST == null)
{
i_Params_Get_Evaluation_By_Criteria_InList.ANSWER_ID_LIST = new List<Int32?>();
}
oParams_Get_Evaluation_By_Criteria_InList_SP.ANSWER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Evaluation_By_Criteria_InList.ANSWER_ID_LIST);
oParams_Get_Evaluation_By_Criteria_InList_SP.START_ROW = i_Params_Get_Evaluation_By_Criteria_InList.START_ROW;
oParams_Get_Evaluation_By_Criteria_InList_SP.END_ROW = i_Params_Get_Evaluation_By_Criteria_InList.END_ROW;
oParams_Get_Evaluation_By_Criteria_InList_SP.TOTAL_COUNT = i_Params_Get_Evaluation_By_Criteria_InList.TOTAL_COUNT;
List<DALC.Evaluation> oList_DBEntries = _AppContext.Get_Evaluation_By_Criteria_InList(i_Params_Get_Evaluation_By_Criteria_InList.DESCRIPTION,i_Params_Get_Evaluation_By_Criteria_InList.STUDENT_ID_LIST,i_Params_Get_Evaluation_By_Criteria_InList.ANSWER_ID_LIST,i_Params_Get_Evaluation_By_Criteria_InList.OWNER_ID,i_Params_Get_Evaluation_By_Criteria_InList.START_ROW,i_Params_Get_Evaluation_By_Criteria_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oEvaluation = new Evaluation();
oTools.CopyPropValues(oDBEntry, oEvaluation);
oList.Add(oEvaluation);
}
}
i_Params_Get_Evaluation_By_Criteria_InList.TOTAL_COUNT = oParams_Get_Evaluation_By_Criteria_InList_SP.TOTAL_COUNT;
i_Params_Get_Evaluation_By_Criteria_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Evaluation_By_Criteria_InList");}
return oList;
}
public List<Evaluation> Get_Evaluation_By_Where_InList(Params_Get_Evaluation_By_Where_InList i_Params_Get_Evaluation_By_Where_InList)
{
List<Evaluation> oList = new List<Evaluation>();
Tools.Tools oTools = new Tools.Tools();
Evaluation oEvaluation = new Evaluation();
long? tmp_TOTAL_COUNT = 0;
Params_Get_Evaluation_By_Where_InList_SP oParams_Get_Evaluation_By_Where_InList_SP = new Params_Get_Evaluation_By_Where_InList_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Evaluation_By_Where_InList");}
#region Body Section.
if ((i_Params_Get_Evaluation_By_Where_InList.OWNER_ID == null) || (i_Params_Get_Evaluation_By_Where_InList.OWNER_ID == 0)) { i_Params_Get_Evaluation_By_Where_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Evaluation_By_Where_InList.START_ROW == null) { i_Params_Get_Evaluation_By_Where_InList.START_ROW = 0; }
if ((i_Params_Get_Evaluation_By_Where_InList.END_ROW == null) || (i_Params_Get_Evaluation_By_Where_InList.END_ROW == 0)) { i_Params_Get_Evaluation_By_Where_InList.END_ROW = 1000000; }
oParams_Get_Evaluation_By_Where_InList_SP.OWNER_ID = i_Params_Get_Evaluation_By_Where_InList.OWNER_ID;
oParams_Get_Evaluation_By_Where_InList_SP.DESCRIPTION = i_Params_Get_Evaluation_By_Where_InList.DESCRIPTION;
if ( i_Params_Get_Evaluation_By_Where_InList.STUDENT_ID_LIST == null)
{
i_Params_Get_Evaluation_By_Where_InList.STUDENT_ID_LIST = new List<Int32?>();
}
oParams_Get_Evaluation_By_Where_InList_SP.STUDENT_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Evaluation_By_Where_InList.STUDENT_ID_LIST);
if ( i_Params_Get_Evaluation_By_Where_InList.ANSWER_ID_LIST == null)
{
i_Params_Get_Evaluation_By_Where_InList.ANSWER_ID_LIST = new List<Int32?>();
}
oParams_Get_Evaluation_By_Where_InList_SP.ANSWER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Evaluation_By_Where_InList.ANSWER_ID_LIST);
oParams_Get_Evaluation_By_Where_InList_SP.START_ROW = i_Params_Get_Evaluation_By_Where_InList.START_ROW;
oParams_Get_Evaluation_By_Where_InList_SP.END_ROW = i_Params_Get_Evaluation_By_Where_InList.END_ROW;
oParams_Get_Evaluation_By_Where_InList_SP.TOTAL_COUNT = i_Params_Get_Evaluation_By_Where_InList.TOTAL_COUNT;
List<DALC.Evaluation> oList_DBEntries = _AppContext.Get_Evaluation_By_Where_InList(i_Params_Get_Evaluation_By_Where_InList.DESCRIPTION,i_Params_Get_Evaluation_By_Where_InList.STUDENT_ID_LIST,i_Params_Get_Evaluation_By_Where_InList.ANSWER_ID_LIST,i_Params_Get_Evaluation_By_Where_InList.OWNER_ID,i_Params_Get_Evaluation_By_Where_InList.START_ROW,i_Params_Get_Evaluation_By_Where_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oEvaluation = new Evaluation();
oTools.CopyPropValues(oDBEntry, oEvaluation);
oList.Add(oEvaluation);
}
}
i_Params_Get_Evaluation_By_Where_InList.TOTAL_COUNT = oParams_Get_Evaluation_By_Where_InList_SP.TOTAL_COUNT;
i_Params_Get_Evaluation_By_Where_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Evaluation_By_Where_InList");}
return oList;
}
public List<Favorite_category> Get_Favorite_category_By_Criteria_InList(Params_Get_Favorite_category_By_Criteria_InList i_Params_Get_Favorite_category_By_Criteria_InList)
{
List<Favorite_category> oList = new List<Favorite_category>();
Tools.Tools oTools = new Tools.Tools();
Favorite_category oFavorite_category = new Favorite_category();
long? tmp_TOTAL_COUNT = 0;
Params_Get_Favorite_category_By_Criteria_InList_SP oParams_Get_Favorite_category_By_Criteria_InList_SP = new Params_Get_Favorite_category_By_Criteria_InList_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Favorite_category_By_Criteria_InList");}
#region Body Section.
if ((i_Params_Get_Favorite_category_By_Criteria_InList.OWNER_ID == null) || (i_Params_Get_Favorite_category_By_Criteria_InList.OWNER_ID == 0)) { i_Params_Get_Favorite_category_By_Criteria_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Favorite_category_By_Criteria_InList.START_ROW == null) { i_Params_Get_Favorite_category_By_Criteria_InList.START_ROW = 0; }
if ((i_Params_Get_Favorite_category_By_Criteria_InList.END_ROW == null) || (i_Params_Get_Favorite_category_By_Criteria_InList.END_ROW == 0)) { i_Params_Get_Favorite_category_By_Criteria_InList.END_ROW = 1000000; }
oParams_Get_Favorite_category_By_Criteria_InList_SP.OWNER_ID = i_Params_Get_Favorite_category_By_Criteria_InList.OWNER_ID;
oParams_Get_Favorite_category_By_Criteria_InList_SP.DESCRIPTION = i_Params_Get_Favorite_category_By_Criteria_InList.DESCRIPTION;
if ( i_Params_Get_Favorite_category_By_Criteria_InList.STUDENT_ID_LIST == null)
{
i_Params_Get_Favorite_category_By_Criteria_InList.STUDENT_ID_LIST = new List<Int32?>();
}
oParams_Get_Favorite_category_By_Criteria_InList_SP.STUDENT_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Favorite_category_By_Criteria_InList.STUDENT_ID_LIST);
if ( i_Params_Get_Favorite_category_By_Criteria_InList.CATEGORY_ID_LIST == null)
{
i_Params_Get_Favorite_category_By_Criteria_InList.CATEGORY_ID_LIST = new List<Int32?>();
}
oParams_Get_Favorite_category_By_Criteria_InList_SP.CATEGORY_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Favorite_category_By_Criteria_InList.CATEGORY_ID_LIST);
oParams_Get_Favorite_category_By_Criteria_InList_SP.START_ROW = i_Params_Get_Favorite_category_By_Criteria_InList.START_ROW;
oParams_Get_Favorite_category_By_Criteria_InList_SP.END_ROW = i_Params_Get_Favorite_category_By_Criteria_InList.END_ROW;
oParams_Get_Favorite_category_By_Criteria_InList_SP.TOTAL_COUNT = i_Params_Get_Favorite_category_By_Criteria_InList.TOTAL_COUNT;
List<DALC.Favorite_category> oList_DBEntries = _AppContext.Get_Favorite_category_By_Criteria_InList(i_Params_Get_Favorite_category_By_Criteria_InList.DESCRIPTION,i_Params_Get_Favorite_category_By_Criteria_InList.STUDENT_ID_LIST,i_Params_Get_Favorite_category_By_Criteria_InList.CATEGORY_ID_LIST,i_Params_Get_Favorite_category_By_Criteria_InList.OWNER_ID,i_Params_Get_Favorite_category_By_Criteria_InList.START_ROW,i_Params_Get_Favorite_category_By_Criteria_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oFavorite_category = new Favorite_category();
oTools.CopyPropValues(oDBEntry, oFavorite_category);
oList.Add(oFavorite_category);
}
}
i_Params_Get_Favorite_category_By_Criteria_InList.TOTAL_COUNT = oParams_Get_Favorite_category_By_Criteria_InList_SP.TOTAL_COUNT;
i_Params_Get_Favorite_category_By_Criteria_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Favorite_category_By_Criteria_InList");}
return oList;
}
public List<Favorite_category> Get_Favorite_category_By_Where_InList(Params_Get_Favorite_category_By_Where_InList i_Params_Get_Favorite_category_By_Where_InList)
{
List<Favorite_category> oList = new List<Favorite_category>();
Tools.Tools oTools = new Tools.Tools();
Favorite_category oFavorite_category = new Favorite_category();
long? tmp_TOTAL_COUNT = 0;
Params_Get_Favorite_category_By_Where_InList_SP oParams_Get_Favorite_category_By_Where_InList_SP = new Params_Get_Favorite_category_By_Where_InList_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Favorite_category_By_Where_InList");}
#region Body Section.
if ((i_Params_Get_Favorite_category_By_Where_InList.OWNER_ID == null) || (i_Params_Get_Favorite_category_By_Where_InList.OWNER_ID == 0)) { i_Params_Get_Favorite_category_By_Where_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Favorite_category_By_Where_InList.START_ROW == null) { i_Params_Get_Favorite_category_By_Where_InList.START_ROW = 0; }
if ((i_Params_Get_Favorite_category_By_Where_InList.END_ROW == null) || (i_Params_Get_Favorite_category_By_Where_InList.END_ROW == 0)) { i_Params_Get_Favorite_category_By_Where_InList.END_ROW = 1000000; }
oParams_Get_Favorite_category_By_Where_InList_SP.OWNER_ID = i_Params_Get_Favorite_category_By_Where_InList.OWNER_ID;
oParams_Get_Favorite_category_By_Where_InList_SP.DESCRIPTION = i_Params_Get_Favorite_category_By_Where_InList.DESCRIPTION;
if ( i_Params_Get_Favorite_category_By_Where_InList.STUDENT_ID_LIST == null)
{
i_Params_Get_Favorite_category_By_Where_InList.STUDENT_ID_LIST = new List<Int32?>();
}
oParams_Get_Favorite_category_By_Where_InList_SP.STUDENT_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Favorite_category_By_Where_InList.STUDENT_ID_LIST);
if ( i_Params_Get_Favorite_category_By_Where_InList.CATEGORY_ID_LIST == null)
{
i_Params_Get_Favorite_category_By_Where_InList.CATEGORY_ID_LIST = new List<Int32?>();
}
oParams_Get_Favorite_category_By_Where_InList_SP.CATEGORY_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Favorite_category_By_Where_InList.CATEGORY_ID_LIST);
oParams_Get_Favorite_category_By_Where_InList_SP.START_ROW = i_Params_Get_Favorite_category_By_Where_InList.START_ROW;
oParams_Get_Favorite_category_By_Where_InList_SP.END_ROW = i_Params_Get_Favorite_category_By_Where_InList.END_ROW;
oParams_Get_Favorite_category_By_Where_InList_SP.TOTAL_COUNT = i_Params_Get_Favorite_category_By_Where_InList.TOTAL_COUNT;
List<DALC.Favorite_category> oList_DBEntries = _AppContext.Get_Favorite_category_By_Where_InList(i_Params_Get_Favorite_category_By_Where_InList.DESCRIPTION,i_Params_Get_Favorite_category_By_Where_InList.STUDENT_ID_LIST,i_Params_Get_Favorite_category_By_Where_InList.CATEGORY_ID_LIST,i_Params_Get_Favorite_category_By_Where_InList.OWNER_ID,i_Params_Get_Favorite_category_By_Where_InList.START_ROW,i_Params_Get_Favorite_category_By_Where_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oFavorite_category = new Favorite_category();
oTools.CopyPropValues(oDBEntry, oFavorite_category);
oList.Add(oFavorite_category);
}
}
i_Params_Get_Favorite_category_By_Where_InList.TOTAL_COUNT = oParams_Get_Favorite_category_By_Where_InList_SP.TOTAL_COUNT;
i_Params_Get_Favorite_category_By_Where_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Favorite_category_By_Where_InList");}
return oList;
}
public List<Favorite_teacher> Get_Favorite_teacher_By_Criteria_InList(Params_Get_Favorite_teacher_By_Criteria_InList i_Params_Get_Favorite_teacher_By_Criteria_InList)
{
List<Favorite_teacher> oList = new List<Favorite_teacher>();
Tools.Tools oTools = new Tools.Tools();
Favorite_teacher oFavorite_teacher = new Favorite_teacher();
long? tmp_TOTAL_COUNT = 0;
Params_Get_Favorite_teacher_By_Criteria_InList_SP oParams_Get_Favorite_teacher_By_Criteria_InList_SP = new Params_Get_Favorite_teacher_By_Criteria_InList_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Favorite_teacher_By_Criteria_InList");}
#region Body Section.
if ((i_Params_Get_Favorite_teacher_By_Criteria_InList.OWNER_ID == null) || (i_Params_Get_Favorite_teacher_By_Criteria_InList.OWNER_ID == 0)) { i_Params_Get_Favorite_teacher_By_Criteria_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Favorite_teacher_By_Criteria_InList.START_ROW == null) { i_Params_Get_Favorite_teacher_By_Criteria_InList.START_ROW = 0; }
if ((i_Params_Get_Favorite_teacher_By_Criteria_InList.END_ROW == null) || (i_Params_Get_Favorite_teacher_By_Criteria_InList.END_ROW == 0)) { i_Params_Get_Favorite_teacher_By_Criteria_InList.END_ROW = 1000000; }
oParams_Get_Favorite_teacher_By_Criteria_InList_SP.OWNER_ID = i_Params_Get_Favorite_teacher_By_Criteria_InList.OWNER_ID;
oParams_Get_Favorite_teacher_By_Criteria_InList_SP.DESCRIPTION = i_Params_Get_Favorite_teacher_By_Criteria_InList.DESCRIPTION;
if ( i_Params_Get_Favorite_teacher_By_Criteria_InList.TEACHER_ID_LIST == null)
{
i_Params_Get_Favorite_teacher_By_Criteria_InList.TEACHER_ID_LIST = new List<Int32?>();
}
oParams_Get_Favorite_teacher_By_Criteria_InList_SP.TEACHER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Favorite_teacher_By_Criteria_InList.TEACHER_ID_LIST);
if ( i_Params_Get_Favorite_teacher_By_Criteria_InList.STUDENT_ID_LIST == null)
{
i_Params_Get_Favorite_teacher_By_Criteria_InList.STUDENT_ID_LIST = new List<Int32?>();
}
oParams_Get_Favorite_teacher_By_Criteria_InList_SP.STUDENT_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Favorite_teacher_By_Criteria_InList.STUDENT_ID_LIST);
oParams_Get_Favorite_teacher_By_Criteria_InList_SP.START_ROW = i_Params_Get_Favorite_teacher_By_Criteria_InList.START_ROW;
oParams_Get_Favorite_teacher_By_Criteria_InList_SP.END_ROW = i_Params_Get_Favorite_teacher_By_Criteria_InList.END_ROW;
oParams_Get_Favorite_teacher_By_Criteria_InList_SP.TOTAL_COUNT = i_Params_Get_Favorite_teacher_By_Criteria_InList.TOTAL_COUNT;
List<DALC.Favorite_teacher> oList_DBEntries = _AppContext.Get_Favorite_teacher_By_Criteria_InList(i_Params_Get_Favorite_teacher_By_Criteria_InList.DESCRIPTION,i_Params_Get_Favorite_teacher_By_Criteria_InList.TEACHER_ID_LIST,i_Params_Get_Favorite_teacher_By_Criteria_InList.STUDENT_ID_LIST,i_Params_Get_Favorite_teacher_By_Criteria_InList.OWNER_ID,i_Params_Get_Favorite_teacher_By_Criteria_InList.START_ROW,i_Params_Get_Favorite_teacher_By_Criteria_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oFavorite_teacher = new Favorite_teacher();
oTools.CopyPropValues(oDBEntry, oFavorite_teacher);
oList.Add(oFavorite_teacher);
}
}
i_Params_Get_Favorite_teacher_By_Criteria_InList.TOTAL_COUNT = oParams_Get_Favorite_teacher_By_Criteria_InList_SP.TOTAL_COUNT;
i_Params_Get_Favorite_teacher_By_Criteria_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Favorite_teacher_By_Criteria_InList");}
return oList;
}
public List<Favorite_teacher> Get_Favorite_teacher_By_Where_InList(Params_Get_Favorite_teacher_By_Where_InList i_Params_Get_Favorite_teacher_By_Where_InList)
{
List<Favorite_teacher> oList = new List<Favorite_teacher>();
Tools.Tools oTools = new Tools.Tools();
Favorite_teacher oFavorite_teacher = new Favorite_teacher();
long? tmp_TOTAL_COUNT = 0;
Params_Get_Favorite_teacher_By_Where_InList_SP oParams_Get_Favorite_teacher_By_Where_InList_SP = new Params_Get_Favorite_teacher_By_Where_InList_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Favorite_teacher_By_Where_InList");}
#region Body Section.
if ((i_Params_Get_Favorite_teacher_By_Where_InList.OWNER_ID == null) || (i_Params_Get_Favorite_teacher_By_Where_InList.OWNER_ID == 0)) { i_Params_Get_Favorite_teacher_By_Where_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Favorite_teacher_By_Where_InList.START_ROW == null) { i_Params_Get_Favorite_teacher_By_Where_InList.START_ROW = 0; }
if ((i_Params_Get_Favorite_teacher_By_Where_InList.END_ROW == null) || (i_Params_Get_Favorite_teacher_By_Where_InList.END_ROW == 0)) { i_Params_Get_Favorite_teacher_By_Where_InList.END_ROW = 1000000; }
oParams_Get_Favorite_teacher_By_Where_InList_SP.OWNER_ID = i_Params_Get_Favorite_teacher_By_Where_InList.OWNER_ID;
oParams_Get_Favorite_teacher_By_Where_InList_SP.DESCRIPTION = i_Params_Get_Favorite_teacher_By_Where_InList.DESCRIPTION;
if ( i_Params_Get_Favorite_teacher_By_Where_InList.TEACHER_ID_LIST == null)
{
i_Params_Get_Favorite_teacher_By_Where_InList.TEACHER_ID_LIST = new List<Int32?>();
}
oParams_Get_Favorite_teacher_By_Where_InList_SP.TEACHER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Favorite_teacher_By_Where_InList.TEACHER_ID_LIST);
if ( i_Params_Get_Favorite_teacher_By_Where_InList.STUDENT_ID_LIST == null)
{
i_Params_Get_Favorite_teacher_By_Where_InList.STUDENT_ID_LIST = new List<Int32?>();
}
oParams_Get_Favorite_teacher_By_Where_InList_SP.STUDENT_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Favorite_teacher_By_Where_InList.STUDENT_ID_LIST);
oParams_Get_Favorite_teacher_By_Where_InList_SP.START_ROW = i_Params_Get_Favorite_teacher_By_Where_InList.START_ROW;
oParams_Get_Favorite_teacher_By_Where_InList_SP.END_ROW = i_Params_Get_Favorite_teacher_By_Where_InList.END_ROW;
oParams_Get_Favorite_teacher_By_Where_InList_SP.TOTAL_COUNT = i_Params_Get_Favorite_teacher_By_Where_InList.TOTAL_COUNT;
List<DALC.Favorite_teacher> oList_DBEntries = _AppContext.Get_Favorite_teacher_By_Where_InList(i_Params_Get_Favorite_teacher_By_Where_InList.DESCRIPTION,i_Params_Get_Favorite_teacher_By_Where_InList.TEACHER_ID_LIST,i_Params_Get_Favorite_teacher_By_Where_InList.STUDENT_ID_LIST,i_Params_Get_Favorite_teacher_By_Where_InList.OWNER_ID,i_Params_Get_Favorite_teacher_By_Where_InList.START_ROW,i_Params_Get_Favorite_teacher_By_Where_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oFavorite_teacher = new Favorite_teacher();
oTools.CopyPropValues(oDBEntry, oFavorite_teacher);
oList.Add(oFavorite_teacher);
}
}
i_Params_Get_Favorite_teacher_By_Where_InList.TOTAL_COUNT = oParams_Get_Favorite_teacher_By_Where_InList_SP.TOTAL_COUNT;
i_Params_Get_Favorite_teacher_By_Where_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Favorite_teacher_By_Where_InList");}
return oList;
}
public List<Mark_question> Get_Mark_question_By_Criteria_InList(Params_Get_Mark_question_By_Criteria_InList i_Params_Get_Mark_question_By_Criteria_InList)
{
List<Mark_question> oList = new List<Mark_question>();
Tools.Tools oTools = new Tools.Tools();
Mark_question oMark_question = new Mark_question();
long? tmp_TOTAL_COUNT = 0;
Params_Get_Mark_question_By_Criteria_InList_SP oParams_Get_Mark_question_By_Criteria_InList_SP = new Params_Get_Mark_question_By_Criteria_InList_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Mark_question_By_Criteria_InList");}
#region Body Section.
if ((i_Params_Get_Mark_question_By_Criteria_InList.OWNER_ID == null) || (i_Params_Get_Mark_question_By_Criteria_InList.OWNER_ID == 0)) { i_Params_Get_Mark_question_By_Criteria_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Mark_question_By_Criteria_InList.START_ROW == null) { i_Params_Get_Mark_question_By_Criteria_InList.START_ROW = 0; }
if ((i_Params_Get_Mark_question_By_Criteria_InList.END_ROW == null) || (i_Params_Get_Mark_question_By_Criteria_InList.END_ROW == 0)) { i_Params_Get_Mark_question_By_Criteria_InList.END_ROW = 1000000; }
oParams_Get_Mark_question_By_Criteria_InList_SP.OWNER_ID = i_Params_Get_Mark_question_By_Criteria_InList.OWNER_ID;
oParams_Get_Mark_question_By_Criteria_InList_SP.DESCRIPTION = i_Params_Get_Mark_question_By_Criteria_InList.DESCRIPTION;
if ( i_Params_Get_Mark_question_By_Criteria_InList.QUESTION_ID_LIST == null)
{
i_Params_Get_Mark_question_By_Criteria_InList.QUESTION_ID_LIST = new List<Int32?>();
}
oParams_Get_Mark_question_By_Criteria_InList_SP.QUESTION_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Mark_question_By_Criteria_InList.QUESTION_ID_LIST);
if ( i_Params_Get_Mark_question_By_Criteria_InList.STUDENT_ID_LIST == null)
{
i_Params_Get_Mark_question_By_Criteria_InList.STUDENT_ID_LIST = new List<Int32?>();
}
oParams_Get_Mark_question_By_Criteria_InList_SP.STUDENT_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Mark_question_By_Criteria_InList.STUDENT_ID_LIST);
oParams_Get_Mark_question_By_Criteria_InList_SP.START_ROW = i_Params_Get_Mark_question_By_Criteria_InList.START_ROW;
oParams_Get_Mark_question_By_Criteria_InList_SP.END_ROW = i_Params_Get_Mark_question_By_Criteria_InList.END_ROW;
oParams_Get_Mark_question_By_Criteria_InList_SP.TOTAL_COUNT = i_Params_Get_Mark_question_By_Criteria_InList.TOTAL_COUNT;
List<DALC.Mark_question> oList_DBEntries = _AppContext.Get_Mark_question_By_Criteria_InList(i_Params_Get_Mark_question_By_Criteria_InList.DESCRIPTION,i_Params_Get_Mark_question_By_Criteria_InList.QUESTION_ID_LIST,i_Params_Get_Mark_question_By_Criteria_InList.STUDENT_ID_LIST,i_Params_Get_Mark_question_By_Criteria_InList.OWNER_ID,i_Params_Get_Mark_question_By_Criteria_InList.START_ROW,i_Params_Get_Mark_question_By_Criteria_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oMark_question = new Mark_question();
oTools.CopyPropValues(oDBEntry, oMark_question);
oList.Add(oMark_question);
}
}
i_Params_Get_Mark_question_By_Criteria_InList.TOTAL_COUNT = oParams_Get_Mark_question_By_Criteria_InList_SP.TOTAL_COUNT;
i_Params_Get_Mark_question_By_Criteria_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Mark_question_By_Criteria_InList");}
return oList;
}
public List<Mark_question> Get_Mark_question_By_Where_InList(Params_Get_Mark_question_By_Where_InList i_Params_Get_Mark_question_By_Where_InList)
{
List<Mark_question> oList = new List<Mark_question>();
Tools.Tools oTools = new Tools.Tools();
Mark_question oMark_question = new Mark_question();
long? tmp_TOTAL_COUNT = 0;
Params_Get_Mark_question_By_Where_InList_SP oParams_Get_Mark_question_By_Where_InList_SP = new Params_Get_Mark_question_By_Where_InList_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Mark_question_By_Where_InList");}
#region Body Section.
if ((i_Params_Get_Mark_question_By_Where_InList.OWNER_ID == null) || (i_Params_Get_Mark_question_By_Where_InList.OWNER_ID == 0)) { i_Params_Get_Mark_question_By_Where_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Mark_question_By_Where_InList.START_ROW == null) { i_Params_Get_Mark_question_By_Where_InList.START_ROW = 0; }
if ((i_Params_Get_Mark_question_By_Where_InList.END_ROW == null) || (i_Params_Get_Mark_question_By_Where_InList.END_ROW == 0)) { i_Params_Get_Mark_question_By_Where_InList.END_ROW = 1000000; }
oParams_Get_Mark_question_By_Where_InList_SP.OWNER_ID = i_Params_Get_Mark_question_By_Where_InList.OWNER_ID;
oParams_Get_Mark_question_By_Where_InList_SP.DESCRIPTION = i_Params_Get_Mark_question_By_Where_InList.DESCRIPTION;
if ( i_Params_Get_Mark_question_By_Where_InList.QUESTION_ID_LIST == null)
{
i_Params_Get_Mark_question_By_Where_InList.QUESTION_ID_LIST = new List<Int32?>();
}
oParams_Get_Mark_question_By_Where_InList_SP.QUESTION_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Mark_question_By_Where_InList.QUESTION_ID_LIST);
if ( i_Params_Get_Mark_question_By_Where_InList.STUDENT_ID_LIST == null)
{
i_Params_Get_Mark_question_By_Where_InList.STUDENT_ID_LIST = new List<Int32?>();
}
oParams_Get_Mark_question_By_Where_InList_SP.STUDENT_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Mark_question_By_Where_InList.STUDENT_ID_LIST);
oParams_Get_Mark_question_By_Where_InList_SP.START_ROW = i_Params_Get_Mark_question_By_Where_InList.START_ROW;
oParams_Get_Mark_question_By_Where_InList_SP.END_ROW = i_Params_Get_Mark_question_By_Where_InList.END_ROW;
oParams_Get_Mark_question_By_Where_InList_SP.TOTAL_COUNT = i_Params_Get_Mark_question_By_Where_InList.TOTAL_COUNT;
List<DALC.Mark_question> oList_DBEntries = _AppContext.Get_Mark_question_By_Where_InList(i_Params_Get_Mark_question_By_Where_InList.DESCRIPTION,i_Params_Get_Mark_question_By_Where_InList.QUESTION_ID_LIST,i_Params_Get_Mark_question_By_Where_InList.STUDENT_ID_LIST,i_Params_Get_Mark_question_By_Where_InList.OWNER_ID,i_Params_Get_Mark_question_By_Where_InList.START_ROW,i_Params_Get_Mark_question_By_Where_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oMark_question = new Mark_question();
oTools.CopyPropValues(oDBEntry, oMark_question);
oList.Add(oMark_question);
}
}
i_Params_Get_Mark_question_By_Where_InList.TOTAL_COUNT = oParams_Get_Mark_question_By_Where_InList_SP.TOTAL_COUNT;
i_Params_Get_Mark_question_By_Where_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Mark_question_By_Where_InList");}
return oList;
}
public List<Notification> Get_Notification_By_Criteria_InList(Params_Get_Notification_By_Criteria_InList i_Params_Get_Notification_By_Criteria_InList)
{
List<Notification> oList = new List<Notification>();
Tools.Tools oTools = new Tools.Tools();
Notification oNotification = new Notification();
long? tmp_TOTAL_COUNT = 0;
Params_Get_Notification_By_Criteria_InList_SP oParams_Get_Notification_By_Criteria_InList_SP = new Params_Get_Notification_By_Criteria_InList_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Notification_By_Criteria_InList");}
#region Body Section.
if ((i_Params_Get_Notification_By_Criteria_InList.OWNER_ID == null) || (i_Params_Get_Notification_By_Criteria_InList.OWNER_ID == 0)) { i_Params_Get_Notification_By_Criteria_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Notification_By_Criteria_InList.START_ROW == null) { i_Params_Get_Notification_By_Criteria_InList.START_ROW = 0; }
if ((i_Params_Get_Notification_By_Criteria_InList.END_ROW == null) || (i_Params_Get_Notification_By_Criteria_InList.END_ROW == 0)) { i_Params_Get_Notification_By_Criteria_InList.END_ROW = 1000000; }
oParams_Get_Notification_By_Criteria_InList_SP.OWNER_ID = i_Params_Get_Notification_By_Criteria_InList.OWNER_ID;
oParams_Get_Notification_By_Criteria_InList_SP.DESCRIPTION = i_Params_Get_Notification_By_Criteria_InList.DESCRIPTION;
if ( i_Params_Get_Notification_By_Criteria_InList.QUESTION_ID_LIST == null)
{
i_Params_Get_Notification_By_Criteria_InList.QUESTION_ID_LIST = new List<Int32?>();
}
oParams_Get_Notification_By_Criteria_InList_SP.QUESTION_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Notification_By_Criteria_InList.QUESTION_ID_LIST);
if ( i_Params_Get_Notification_By_Criteria_InList.ANSWER_ID_LIST == null)
{
i_Params_Get_Notification_By_Criteria_InList.ANSWER_ID_LIST = new List<Int32?>();
}
oParams_Get_Notification_By_Criteria_InList_SP.ANSWER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Notification_By_Criteria_InList.ANSWER_ID_LIST);
oParams_Get_Notification_By_Criteria_InList_SP.START_ROW = i_Params_Get_Notification_By_Criteria_InList.START_ROW;
oParams_Get_Notification_By_Criteria_InList_SP.END_ROW = i_Params_Get_Notification_By_Criteria_InList.END_ROW;
oParams_Get_Notification_By_Criteria_InList_SP.TOTAL_COUNT = i_Params_Get_Notification_By_Criteria_InList.TOTAL_COUNT;
List<DALC.Notification> oList_DBEntries = _AppContext.Get_Notification_By_Criteria_InList(i_Params_Get_Notification_By_Criteria_InList.DESCRIPTION,i_Params_Get_Notification_By_Criteria_InList.QUESTION_ID_LIST,i_Params_Get_Notification_By_Criteria_InList.ANSWER_ID_LIST,i_Params_Get_Notification_By_Criteria_InList.OWNER_ID,i_Params_Get_Notification_By_Criteria_InList.START_ROW,i_Params_Get_Notification_By_Criteria_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oNotification = new Notification();
oTools.CopyPropValues(oDBEntry, oNotification);
oList.Add(oNotification);
}
}
i_Params_Get_Notification_By_Criteria_InList.TOTAL_COUNT = oParams_Get_Notification_By_Criteria_InList_SP.TOTAL_COUNT;
i_Params_Get_Notification_By_Criteria_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Notification_By_Criteria_InList");}
return oList;
}
public List<Notification> Get_Notification_By_Where_InList(Params_Get_Notification_By_Where_InList i_Params_Get_Notification_By_Where_InList)
{
List<Notification> oList = new List<Notification>();
Tools.Tools oTools = new Tools.Tools();
Notification oNotification = new Notification();
long? tmp_TOTAL_COUNT = 0;
Params_Get_Notification_By_Where_InList_SP oParams_Get_Notification_By_Where_InList_SP = new Params_Get_Notification_By_Where_InList_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Notification_By_Where_InList");}
#region Body Section.
if ((i_Params_Get_Notification_By_Where_InList.OWNER_ID == null) || (i_Params_Get_Notification_By_Where_InList.OWNER_ID == 0)) { i_Params_Get_Notification_By_Where_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Notification_By_Where_InList.START_ROW == null) { i_Params_Get_Notification_By_Where_InList.START_ROW = 0; }
if ((i_Params_Get_Notification_By_Where_InList.END_ROW == null) || (i_Params_Get_Notification_By_Where_InList.END_ROW == 0)) { i_Params_Get_Notification_By_Where_InList.END_ROW = 1000000; }
oParams_Get_Notification_By_Where_InList_SP.OWNER_ID = i_Params_Get_Notification_By_Where_InList.OWNER_ID;
oParams_Get_Notification_By_Where_InList_SP.DESCRIPTION = i_Params_Get_Notification_By_Where_InList.DESCRIPTION;
if ( i_Params_Get_Notification_By_Where_InList.QUESTION_ID_LIST == null)
{
i_Params_Get_Notification_By_Where_InList.QUESTION_ID_LIST = new List<Int32?>();
}
oParams_Get_Notification_By_Where_InList_SP.QUESTION_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Notification_By_Where_InList.QUESTION_ID_LIST);
if ( i_Params_Get_Notification_By_Where_InList.ANSWER_ID_LIST == null)
{
i_Params_Get_Notification_By_Where_InList.ANSWER_ID_LIST = new List<Int32?>();
}
oParams_Get_Notification_By_Where_InList_SP.ANSWER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Notification_By_Where_InList.ANSWER_ID_LIST);
oParams_Get_Notification_By_Where_InList_SP.START_ROW = i_Params_Get_Notification_By_Where_InList.START_ROW;
oParams_Get_Notification_By_Where_InList_SP.END_ROW = i_Params_Get_Notification_By_Where_InList.END_ROW;
oParams_Get_Notification_By_Where_InList_SP.TOTAL_COUNT = i_Params_Get_Notification_By_Where_InList.TOTAL_COUNT;
List<DALC.Notification> oList_DBEntries = _AppContext.Get_Notification_By_Where_InList(i_Params_Get_Notification_By_Where_InList.DESCRIPTION,i_Params_Get_Notification_By_Where_InList.QUESTION_ID_LIST,i_Params_Get_Notification_By_Where_InList.ANSWER_ID_LIST,i_Params_Get_Notification_By_Where_InList.OWNER_ID,i_Params_Get_Notification_By_Where_InList.START_ROW,i_Params_Get_Notification_By_Where_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oNotification = new Notification();
oTools.CopyPropValues(oDBEntry, oNotification);
oList.Add(oNotification);
}
}
i_Params_Get_Notification_By_Where_InList.TOTAL_COUNT = oParams_Get_Notification_By_Where_InList_SP.TOTAL_COUNT;
i_Params_Get_Notification_By_Where_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Notification_By_Where_InList");}
return oList;
}
public List<Question> Get_Question_By_Criteria_InList(Params_Get_Question_By_Criteria_InList i_Params_Get_Question_By_Criteria_InList)
{
List<Question> oList = new List<Question>();
Tools.Tools oTools = new Tools.Tools();
Question oQuestion = new Question();
long? tmp_TOTAL_COUNT = 0;
Params_Get_Question_By_Criteria_InList_SP oParams_Get_Question_By_Criteria_InList_SP = new Params_Get_Question_By_Criteria_InList_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Question_By_Criteria_InList");}
#region Body Section.
if ((i_Params_Get_Question_By_Criteria_InList.OWNER_ID == null) || (i_Params_Get_Question_By_Criteria_InList.OWNER_ID == 0)) { i_Params_Get_Question_By_Criteria_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Question_By_Criteria_InList.START_ROW == null) { i_Params_Get_Question_By_Criteria_InList.START_ROW = 0; }
if ((i_Params_Get_Question_By_Criteria_InList.END_ROW == null) || (i_Params_Get_Question_By_Criteria_InList.END_ROW == 0)) { i_Params_Get_Question_By_Criteria_InList.END_ROW = 1000000; }
oParams_Get_Question_By_Criteria_InList_SP.OWNER_ID = i_Params_Get_Question_By_Criteria_InList.OWNER_ID;
oParams_Get_Question_By_Criteria_InList_SP.DESCRIPTION = i_Params_Get_Question_By_Criteria_InList.DESCRIPTION;
if ( i_Params_Get_Question_By_Criteria_InList.STUDENT_ID_LIST == null)
{
i_Params_Get_Question_By_Criteria_InList.STUDENT_ID_LIST = new List<Int32?>();
}
oParams_Get_Question_By_Criteria_InList_SP.STUDENT_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Question_By_Criteria_InList.STUDENT_ID_LIST);
if ( i_Params_Get_Question_By_Criteria_InList.CATEGORY_ID_LIST == null)
{
i_Params_Get_Question_By_Criteria_InList.CATEGORY_ID_LIST = new List<Int32?>();
}
oParams_Get_Question_By_Criteria_InList_SP.CATEGORY_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Question_By_Criteria_InList.CATEGORY_ID_LIST);
if ( i_Params_Get_Question_By_Criteria_InList.TEACHER_ID_LIST == null)
{
i_Params_Get_Question_By_Criteria_InList.TEACHER_ID_LIST = new List<Int32?>();
}
oParams_Get_Question_By_Criteria_InList_SP.TEACHER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Question_By_Criteria_InList.TEACHER_ID_LIST);
oParams_Get_Question_By_Criteria_InList_SP.START_ROW = i_Params_Get_Question_By_Criteria_InList.START_ROW;
oParams_Get_Question_By_Criteria_InList_SP.END_ROW = i_Params_Get_Question_By_Criteria_InList.END_ROW;
oParams_Get_Question_By_Criteria_InList_SP.TOTAL_COUNT = i_Params_Get_Question_By_Criteria_InList.TOTAL_COUNT;
List<DALC.Question> oList_DBEntries = _AppContext.Get_Question_By_Criteria_InList(i_Params_Get_Question_By_Criteria_InList.DESCRIPTION,i_Params_Get_Question_By_Criteria_InList.STUDENT_ID_LIST,i_Params_Get_Question_By_Criteria_InList.CATEGORY_ID_LIST,i_Params_Get_Question_By_Criteria_InList.TEACHER_ID_LIST,i_Params_Get_Question_By_Criteria_InList.OWNER_ID,i_Params_Get_Question_By_Criteria_InList.START_ROW,i_Params_Get_Question_By_Criteria_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oQuestion = new Question();
oTools.CopyPropValues(oDBEntry, oQuestion);
oList.Add(oQuestion);
}
}
i_Params_Get_Question_By_Criteria_InList.TOTAL_COUNT = oParams_Get_Question_By_Criteria_InList_SP.TOTAL_COUNT;
i_Params_Get_Question_By_Criteria_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Question_By_Criteria_InList");}
return oList;
}
public List<Question> Get_Question_By_Where_InList(Params_Get_Question_By_Where_InList i_Params_Get_Question_By_Where_InList)
{
List<Question> oList = new List<Question>();
Tools.Tools oTools = new Tools.Tools();
Question oQuestion = new Question();
long? tmp_TOTAL_COUNT = 0;
Params_Get_Question_By_Where_InList_SP oParams_Get_Question_By_Where_InList_SP = new Params_Get_Question_By_Where_InList_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Question_By_Where_InList");}
#region Body Section.
if ((i_Params_Get_Question_By_Where_InList.OWNER_ID == null) || (i_Params_Get_Question_By_Where_InList.OWNER_ID == 0)) { i_Params_Get_Question_By_Where_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Question_By_Where_InList.START_ROW == null) { i_Params_Get_Question_By_Where_InList.START_ROW = 0; }
if ((i_Params_Get_Question_By_Where_InList.END_ROW == null) || (i_Params_Get_Question_By_Where_InList.END_ROW == 0)) { i_Params_Get_Question_By_Where_InList.END_ROW = 1000000; }
oParams_Get_Question_By_Where_InList_SP.OWNER_ID = i_Params_Get_Question_By_Where_InList.OWNER_ID;
oParams_Get_Question_By_Where_InList_SP.DESCRIPTION = i_Params_Get_Question_By_Where_InList.DESCRIPTION;
if ( i_Params_Get_Question_By_Where_InList.STUDENT_ID_LIST == null)
{
i_Params_Get_Question_By_Where_InList.STUDENT_ID_LIST = new List<Int32?>();
}
oParams_Get_Question_By_Where_InList_SP.STUDENT_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Question_By_Where_InList.STUDENT_ID_LIST);
if ( i_Params_Get_Question_By_Where_InList.CATEGORY_ID_LIST == null)
{
i_Params_Get_Question_By_Where_InList.CATEGORY_ID_LIST = new List<Int32?>();
}
oParams_Get_Question_By_Where_InList_SP.CATEGORY_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Question_By_Where_InList.CATEGORY_ID_LIST);
if ( i_Params_Get_Question_By_Where_InList.TEACHER_ID_LIST == null)
{
i_Params_Get_Question_By_Where_InList.TEACHER_ID_LIST = new List<Int32?>();
}
oParams_Get_Question_By_Where_InList_SP.TEACHER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Question_By_Where_InList.TEACHER_ID_LIST);
oParams_Get_Question_By_Where_InList_SP.START_ROW = i_Params_Get_Question_By_Where_InList.START_ROW;
oParams_Get_Question_By_Where_InList_SP.END_ROW = i_Params_Get_Question_By_Where_InList.END_ROW;
oParams_Get_Question_By_Where_InList_SP.TOTAL_COUNT = i_Params_Get_Question_By_Where_InList.TOTAL_COUNT;
List<DALC.Question> oList_DBEntries = _AppContext.Get_Question_By_Where_InList(i_Params_Get_Question_By_Where_InList.DESCRIPTION,i_Params_Get_Question_By_Where_InList.STUDENT_ID_LIST,i_Params_Get_Question_By_Where_InList.CATEGORY_ID_LIST,i_Params_Get_Question_By_Where_InList.TEACHER_ID_LIST,i_Params_Get_Question_By_Where_InList.OWNER_ID,i_Params_Get_Question_By_Where_InList.START_ROW,i_Params_Get_Question_By_Where_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oQuestion = new Question();
oTools.CopyPropValues(oDBEntry, oQuestion);
oList.Add(oQuestion);
}
}
i_Params_Get_Question_By_Where_InList.TOTAL_COUNT = oParams_Get_Question_By_Where_InList_SP.TOTAL_COUNT;
i_Params_Get_Question_By_Where_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Question_By_Where_InList");}
return oList;
}
public List<Question_report> Get_Question_report_By_Criteria_InList(Params_Get_Question_report_By_Criteria_InList i_Params_Get_Question_report_By_Criteria_InList)
{
List<Question_report> oList = new List<Question_report>();
Tools.Tools oTools = new Tools.Tools();
Question_report oQuestion_report = new Question_report();
long? tmp_TOTAL_COUNT = 0;
Params_Get_Question_report_By_Criteria_InList_SP oParams_Get_Question_report_By_Criteria_InList_SP = new Params_Get_Question_report_By_Criteria_InList_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Question_report_By_Criteria_InList");}
#region Body Section.
if ((i_Params_Get_Question_report_By_Criteria_InList.OWNER_ID == null) || (i_Params_Get_Question_report_By_Criteria_InList.OWNER_ID == 0)) { i_Params_Get_Question_report_By_Criteria_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Question_report_By_Criteria_InList.START_ROW == null) { i_Params_Get_Question_report_By_Criteria_InList.START_ROW = 0; }
if ((i_Params_Get_Question_report_By_Criteria_InList.END_ROW == null) || (i_Params_Get_Question_report_By_Criteria_InList.END_ROW == 0)) { i_Params_Get_Question_report_By_Criteria_InList.END_ROW = 1000000; }
oParams_Get_Question_report_By_Criteria_InList_SP.OWNER_ID = i_Params_Get_Question_report_By_Criteria_InList.OWNER_ID;
oParams_Get_Question_report_By_Criteria_InList_SP.DESCRIPTION = i_Params_Get_Question_report_By_Criteria_InList.DESCRIPTION;
if ( i_Params_Get_Question_report_By_Criteria_InList.STUDENT_ID_LIST == null)
{
i_Params_Get_Question_report_By_Criteria_InList.STUDENT_ID_LIST = new List<Int32?>();
}
oParams_Get_Question_report_By_Criteria_InList_SP.STUDENT_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Question_report_By_Criteria_InList.STUDENT_ID_LIST);
if ( i_Params_Get_Question_report_By_Criteria_InList.TEACHER_ID_LIST == null)
{
i_Params_Get_Question_report_By_Criteria_InList.TEACHER_ID_LIST = new List<Int32?>();
}
oParams_Get_Question_report_By_Criteria_InList_SP.TEACHER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Question_report_By_Criteria_InList.TEACHER_ID_LIST);
if ( i_Params_Get_Question_report_By_Criteria_InList.QUESTION_ID_LIST == null)
{
i_Params_Get_Question_report_By_Criteria_InList.QUESTION_ID_LIST = new List<Int32?>();
}
oParams_Get_Question_report_By_Criteria_InList_SP.QUESTION_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Question_report_By_Criteria_InList.QUESTION_ID_LIST);
oParams_Get_Question_report_By_Criteria_InList_SP.START_ROW = i_Params_Get_Question_report_By_Criteria_InList.START_ROW;
oParams_Get_Question_report_By_Criteria_InList_SP.END_ROW = i_Params_Get_Question_report_By_Criteria_InList.END_ROW;
oParams_Get_Question_report_By_Criteria_InList_SP.TOTAL_COUNT = i_Params_Get_Question_report_By_Criteria_InList.TOTAL_COUNT;
List<DALC.Question_report> oList_DBEntries = _AppContext.Get_Question_report_By_Criteria_InList(i_Params_Get_Question_report_By_Criteria_InList.DESCRIPTION,i_Params_Get_Question_report_By_Criteria_InList.STUDENT_ID_LIST,i_Params_Get_Question_report_By_Criteria_InList.TEACHER_ID_LIST,i_Params_Get_Question_report_By_Criteria_InList.QUESTION_ID_LIST,i_Params_Get_Question_report_By_Criteria_InList.OWNER_ID,i_Params_Get_Question_report_By_Criteria_InList.START_ROW,i_Params_Get_Question_report_By_Criteria_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oQuestion_report = new Question_report();
oTools.CopyPropValues(oDBEntry, oQuestion_report);
oList.Add(oQuestion_report);
}
}
i_Params_Get_Question_report_By_Criteria_InList.TOTAL_COUNT = oParams_Get_Question_report_By_Criteria_InList_SP.TOTAL_COUNT;
i_Params_Get_Question_report_By_Criteria_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Question_report_By_Criteria_InList");}
return oList;
}
public List<Question_report> Get_Question_report_By_Where_InList(Params_Get_Question_report_By_Where_InList i_Params_Get_Question_report_By_Where_InList)
{
List<Question_report> oList = new List<Question_report>();
Tools.Tools oTools = new Tools.Tools();
Question_report oQuestion_report = new Question_report();
long? tmp_TOTAL_COUNT = 0;
Params_Get_Question_report_By_Where_InList_SP oParams_Get_Question_report_By_Where_InList_SP = new Params_Get_Question_report_By_Where_InList_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Question_report_By_Where_InList");}
#region Body Section.
if ((i_Params_Get_Question_report_By_Where_InList.OWNER_ID == null) || (i_Params_Get_Question_report_By_Where_InList.OWNER_ID == 0)) { i_Params_Get_Question_report_By_Where_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Question_report_By_Where_InList.START_ROW == null) { i_Params_Get_Question_report_By_Where_InList.START_ROW = 0; }
if ((i_Params_Get_Question_report_By_Where_InList.END_ROW == null) || (i_Params_Get_Question_report_By_Where_InList.END_ROW == 0)) { i_Params_Get_Question_report_By_Where_InList.END_ROW = 1000000; }
oParams_Get_Question_report_By_Where_InList_SP.OWNER_ID = i_Params_Get_Question_report_By_Where_InList.OWNER_ID;
oParams_Get_Question_report_By_Where_InList_SP.DESCRIPTION = i_Params_Get_Question_report_By_Where_InList.DESCRIPTION;
if ( i_Params_Get_Question_report_By_Where_InList.STUDENT_ID_LIST == null)
{
i_Params_Get_Question_report_By_Where_InList.STUDENT_ID_LIST = new List<Int32?>();
}
oParams_Get_Question_report_By_Where_InList_SP.STUDENT_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Question_report_By_Where_InList.STUDENT_ID_LIST);
if ( i_Params_Get_Question_report_By_Where_InList.TEACHER_ID_LIST == null)
{
i_Params_Get_Question_report_By_Where_InList.TEACHER_ID_LIST = new List<Int32?>();
}
oParams_Get_Question_report_By_Where_InList_SP.TEACHER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Question_report_By_Where_InList.TEACHER_ID_LIST);
if ( i_Params_Get_Question_report_By_Where_InList.QUESTION_ID_LIST == null)
{
i_Params_Get_Question_report_By_Where_InList.QUESTION_ID_LIST = new List<Int32?>();
}
oParams_Get_Question_report_By_Where_InList_SP.QUESTION_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Question_report_By_Where_InList.QUESTION_ID_LIST);
oParams_Get_Question_report_By_Where_InList_SP.START_ROW = i_Params_Get_Question_report_By_Where_InList.START_ROW;
oParams_Get_Question_report_By_Where_InList_SP.END_ROW = i_Params_Get_Question_report_By_Where_InList.END_ROW;
oParams_Get_Question_report_By_Where_InList_SP.TOTAL_COUNT = i_Params_Get_Question_report_By_Where_InList.TOTAL_COUNT;
List<DALC.Question_report> oList_DBEntries = _AppContext.Get_Question_report_By_Where_InList(i_Params_Get_Question_report_By_Where_InList.DESCRIPTION,i_Params_Get_Question_report_By_Where_InList.STUDENT_ID_LIST,i_Params_Get_Question_report_By_Where_InList.TEACHER_ID_LIST,i_Params_Get_Question_report_By_Where_InList.QUESTION_ID_LIST,i_Params_Get_Question_report_By_Where_InList.OWNER_ID,i_Params_Get_Question_report_By_Where_InList.START_ROW,i_Params_Get_Question_report_By_Where_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oQuestion_report = new Question_report();
oTools.CopyPropValues(oDBEntry, oQuestion_report);
oList.Add(oQuestion_report);
}
}
i_Params_Get_Question_report_By_Where_InList.TOTAL_COUNT = oParams_Get_Question_report_By_Where_InList_SP.TOTAL_COUNT;
i_Params_Get_Question_report_By_Where_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Question_report_By_Where_InList");}
return oList;
}
public List<Report_article> Get_Report_article_By_Criteria_InList(Params_Get_Report_article_By_Criteria_InList i_Params_Get_Report_article_By_Criteria_InList)
{
List<Report_article> oList = new List<Report_article>();
Tools.Tools oTools = new Tools.Tools();
Report_article oReport_article = new Report_article();
long? tmp_TOTAL_COUNT = 0;
Params_Get_Report_article_By_Criteria_InList_SP oParams_Get_Report_article_By_Criteria_InList_SP = new Params_Get_Report_article_By_Criteria_InList_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Report_article_By_Criteria_InList");}
#region Body Section.
if ((i_Params_Get_Report_article_By_Criteria_InList.OWNER_ID == null) || (i_Params_Get_Report_article_By_Criteria_InList.OWNER_ID == 0)) { i_Params_Get_Report_article_By_Criteria_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Report_article_By_Criteria_InList.START_ROW == null) { i_Params_Get_Report_article_By_Criteria_InList.START_ROW = 0; }
if ((i_Params_Get_Report_article_By_Criteria_InList.END_ROW == null) || (i_Params_Get_Report_article_By_Criteria_InList.END_ROW == 0)) { i_Params_Get_Report_article_By_Criteria_InList.END_ROW = 1000000; }
oParams_Get_Report_article_By_Criteria_InList_SP.OWNER_ID = i_Params_Get_Report_article_By_Criteria_InList.OWNER_ID;
oParams_Get_Report_article_By_Criteria_InList_SP.DESCRIPTION = i_Params_Get_Report_article_By_Criteria_InList.DESCRIPTION;
if ( i_Params_Get_Report_article_By_Criteria_InList.ARTICLE_ID_LIST == null)
{
i_Params_Get_Report_article_By_Criteria_InList.ARTICLE_ID_LIST = new List<Int32?>();
}
oParams_Get_Report_article_By_Criteria_InList_SP.ARTICLE_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Report_article_By_Criteria_InList.ARTICLE_ID_LIST);
if ( i_Params_Get_Report_article_By_Criteria_InList.STUDENT_ID_LIST == null)
{
i_Params_Get_Report_article_By_Criteria_InList.STUDENT_ID_LIST = new List<Int32?>();
}
oParams_Get_Report_article_By_Criteria_InList_SP.STUDENT_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Report_article_By_Criteria_InList.STUDENT_ID_LIST);
oParams_Get_Report_article_By_Criteria_InList_SP.START_ROW = i_Params_Get_Report_article_By_Criteria_InList.START_ROW;
oParams_Get_Report_article_By_Criteria_InList_SP.END_ROW = i_Params_Get_Report_article_By_Criteria_InList.END_ROW;
oParams_Get_Report_article_By_Criteria_InList_SP.TOTAL_COUNT = i_Params_Get_Report_article_By_Criteria_InList.TOTAL_COUNT;
List<DALC.Report_article> oList_DBEntries = _AppContext.Get_Report_article_By_Criteria_InList(i_Params_Get_Report_article_By_Criteria_InList.DESCRIPTION,i_Params_Get_Report_article_By_Criteria_InList.ARTICLE_ID_LIST,i_Params_Get_Report_article_By_Criteria_InList.STUDENT_ID_LIST,i_Params_Get_Report_article_By_Criteria_InList.OWNER_ID,i_Params_Get_Report_article_By_Criteria_InList.START_ROW,i_Params_Get_Report_article_By_Criteria_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oReport_article = new Report_article();
oTools.CopyPropValues(oDBEntry, oReport_article);
oList.Add(oReport_article);
}
}
i_Params_Get_Report_article_By_Criteria_InList.TOTAL_COUNT = oParams_Get_Report_article_By_Criteria_InList_SP.TOTAL_COUNT;
i_Params_Get_Report_article_By_Criteria_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Report_article_By_Criteria_InList");}
return oList;
}
public List<Report_article> Get_Report_article_By_Where_InList(Params_Get_Report_article_By_Where_InList i_Params_Get_Report_article_By_Where_InList)
{
List<Report_article> oList = new List<Report_article>();
Tools.Tools oTools = new Tools.Tools();
Report_article oReport_article = new Report_article();
long? tmp_TOTAL_COUNT = 0;
Params_Get_Report_article_By_Where_InList_SP oParams_Get_Report_article_By_Where_InList_SP = new Params_Get_Report_article_By_Where_InList_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Report_article_By_Where_InList");}
#region Body Section.
if ((i_Params_Get_Report_article_By_Where_InList.OWNER_ID == null) || (i_Params_Get_Report_article_By_Where_InList.OWNER_ID == 0)) { i_Params_Get_Report_article_By_Where_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Report_article_By_Where_InList.START_ROW == null) { i_Params_Get_Report_article_By_Where_InList.START_ROW = 0; }
if ((i_Params_Get_Report_article_By_Where_InList.END_ROW == null) || (i_Params_Get_Report_article_By_Where_InList.END_ROW == 0)) { i_Params_Get_Report_article_By_Where_InList.END_ROW = 1000000; }
oParams_Get_Report_article_By_Where_InList_SP.OWNER_ID = i_Params_Get_Report_article_By_Where_InList.OWNER_ID;
oParams_Get_Report_article_By_Where_InList_SP.DESCRIPTION = i_Params_Get_Report_article_By_Where_InList.DESCRIPTION;
if ( i_Params_Get_Report_article_By_Where_InList.ARTICLE_ID_LIST == null)
{
i_Params_Get_Report_article_By_Where_InList.ARTICLE_ID_LIST = new List<Int32?>();
}
oParams_Get_Report_article_By_Where_InList_SP.ARTICLE_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Report_article_By_Where_InList.ARTICLE_ID_LIST);
if ( i_Params_Get_Report_article_By_Where_InList.STUDENT_ID_LIST == null)
{
i_Params_Get_Report_article_By_Where_InList.STUDENT_ID_LIST = new List<Int32?>();
}
oParams_Get_Report_article_By_Where_InList_SP.STUDENT_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Report_article_By_Where_InList.STUDENT_ID_LIST);
oParams_Get_Report_article_By_Where_InList_SP.START_ROW = i_Params_Get_Report_article_By_Where_InList.START_ROW;
oParams_Get_Report_article_By_Where_InList_SP.END_ROW = i_Params_Get_Report_article_By_Where_InList.END_ROW;
oParams_Get_Report_article_By_Where_InList_SP.TOTAL_COUNT = i_Params_Get_Report_article_By_Where_InList.TOTAL_COUNT;
List<DALC.Report_article> oList_DBEntries = _AppContext.Get_Report_article_By_Where_InList(i_Params_Get_Report_article_By_Where_InList.DESCRIPTION,i_Params_Get_Report_article_By_Where_InList.ARTICLE_ID_LIST,i_Params_Get_Report_article_By_Where_InList.STUDENT_ID_LIST,i_Params_Get_Report_article_By_Where_InList.OWNER_ID,i_Params_Get_Report_article_By_Where_InList.START_ROW,i_Params_Get_Report_article_By_Where_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oReport_article = new Report_article();
oTools.CopyPropValues(oDBEntry, oReport_article);
oList.Add(oReport_article);
}
}
i_Params_Get_Report_article_By_Where_InList.TOTAL_COUNT = oParams_Get_Report_article_By_Where_InList_SP.TOTAL_COUNT;
i_Params_Get_Report_article_By_Where_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Report_article_By_Where_InList");}
return oList;
}
public List<Teacher_category> Get_Teacher_category_By_Criteria_InList(Params_Get_Teacher_category_By_Criteria_InList i_Params_Get_Teacher_category_By_Criteria_InList)
{
List<Teacher_category> oList = new List<Teacher_category>();
Tools.Tools oTools = new Tools.Tools();
Teacher_category oTeacher_category = new Teacher_category();
long? tmp_TOTAL_COUNT = 0;
Params_Get_Teacher_category_By_Criteria_InList_SP oParams_Get_Teacher_category_By_Criteria_InList_SP = new Params_Get_Teacher_category_By_Criteria_InList_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_category_By_Criteria_InList");}
#region Body Section.
if ((i_Params_Get_Teacher_category_By_Criteria_InList.OWNER_ID == null) || (i_Params_Get_Teacher_category_By_Criteria_InList.OWNER_ID == 0)) { i_Params_Get_Teacher_category_By_Criteria_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Teacher_category_By_Criteria_InList.START_ROW == null) { i_Params_Get_Teacher_category_By_Criteria_InList.START_ROW = 0; }
if ((i_Params_Get_Teacher_category_By_Criteria_InList.END_ROW == null) || (i_Params_Get_Teacher_category_By_Criteria_InList.END_ROW == 0)) { i_Params_Get_Teacher_category_By_Criteria_InList.END_ROW = 1000000; }
oParams_Get_Teacher_category_By_Criteria_InList_SP.OWNER_ID = i_Params_Get_Teacher_category_By_Criteria_InList.OWNER_ID;
oParams_Get_Teacher_category_By_Criteria_InList_SP.DESCRIPTION = i_Params_Get_Teacher_category_By_Criteria_InList.DESCRIPTION;
if ( i_Params_Get_Teacher_category_By_Criteria_InList.TEACHER_ID_LIST == null)
{
i_Params_Get_Teacher_category_By_Criteria_InList.TEACHER_ID_LIST = new List<Int32?>();
}
oParams_Get_Teacher_category_By_Criteria_InList_SP.TEACHER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Teacher_category_By_Criteria_InList.TEACHER_ID_LIST);
if ( i_Params_Get_Teacher_category_By_Criteria_InList.CATEGORY_ID_LIST == null)
{
i_Params_Get_Teacher_category_By_Criteria_InList.CATEGORY_ID_LIST = new List<Int32?>();
}
oParams_Get_Teacher_category_By_Criteria_InList_SP.CATEGORY_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Teacher_category_By_Criteria_InList.CATEGORY_ID_LIST);
oParams_Get_Teacher_category_By_Criteria_InList_SP.START_ROW = i_Params_Get_Teacher_category_By_Criteria_InList.START_ROW;
oParams_Get_Teacher_category_By_Criteria_InList_SP.END_ROW = i_Params_Get_Teacher_category_By_Criteria_InList.END_ROW;
oParams_Get_Teacher_category_By_Criteria_InList_SP.TOTAL_COUNT = i_Params_Get_Teacher_category_By_Criteria_InList.TOTAL_COUNT;
List<DALC.Teacher_category> oList_DBEntries = _AppContext.Get_Teacher_category_By_Criteria_InList(i_Params_Get_Teacher_category_By_Criteria_InList.DESCRIPTION,i_Params_Get_Teacher_category_By_Criteria_InList.TEACHER_ID_LIST,i_Params_Get_Teacher_category_By_Criteria_InList.CATEGORY_ID_LIST,i_Params_Get_Teacher_category_By_Criteria_InList.OWNER_ID,i_Params_Get_Teacher_category_By_Criteria_InList.START_ROW,i_Params_Get_Teacher_category_By_Criteria_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_category = new Teacher_category();
oTools.CopyPropValues(oDBEntry, oTeacher_category);
oList.Add(oTeacher_category);
}
}
i_Params_Get_Teacher_category_By_Criteria_InList.TOTAL_COUNT = oParams_Get_Teacher_category_By_Criteria_InList_SP.TOTAL_COUNT;
i_Params_Get_Teacher_category_By_Criteria_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_category_By_Criteria_InList");}
return oList;
}
public List<Teacher_category> Get_Teacher_category_By_Where_InList(Params_Get_Teacher_category_By_Where_InList i_Params_Get_Teacher_category_By_Where_InList)
{
List<Teacher_category> oList = new List<Teacher_category>();
Tools.Tools oTools = new Tools.Tools();
Teacher_category oTeacher_category = new Teacher_category();
long? tmp_TOTAL_COUNT = 0;
Params_Get_Teacher_category_By_Where_InList_SP oParams_Get_Teacher_category_By_Where_InList_SP = new Params_Get_Teacher_category_By_Where_InList_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_category_By_Where_InList");}
#region Body Section.
if ((i_Params_Get_Teacher_category_By_Where_InList.OWNER_ID == null) || (i_Params_Get_Teacher_category_By_Where_InList.OWNER_ID == 0)) { i_Params_Get_Teacher_category_By_Where_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Teacher_category_By_Where_InList.START_ROW == null) { i_Params_Get_Teacher_category_By_Where_InList.START_ROW = 0; }
if ((i_Params_Get_Teacher_category_By_Where_InList.END_ROW == null) || (i_Params_Get_Teacher_category_By_Where_InList.END_ROW == 0)) { i_Params_Get_Teacher_category_By_Where_InList.END_ROW = 1000000; }
oParams_Get_Teacher_category_By_Where_InList_SP.OWNER_ID = i_Params_Get_Teacher_category_By_Where_InList.OWNER_ID;
oParams_Get_Teacher_category_By_Where_InList_SP.DESCRIPTION = i_Params_Get_Teacher_category_By_Where_InList.DESCRIPTION;
if ( i_Params_Get_Teacher_category_By_Where_InList.TEACHER_ID_LIST == null)
{
i_Params_Get_Teacher_category_By_Where_InList.TEACHER_ID_LIST = new List<Int32?>();
}
oParams_Get_Teacher_category_By_Where_InList_SP.TEACHER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Teacher_category_By_Where_InList.TEACHER_ID_LIST);
if ( i_Params_Get_Teacher_category_By_Where_InList.CATEGORY_ID_LIST == null)
{
i_Params_Get_Teacher_category_By_Where_InList.CATEGORY_ID_LIST = new List<Int32?>();
}
oParams_Get_Teacher_category_By_Where_InList_SP.CATEGORY_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Teacher_category_By_Where_InList.CATEGORY_ID_LIST);
oParams_Get_Teacher_category_By_Where_InList_SP.START_ROW = i_Params_Get_Teacher_category_By_Where_InList.START_ROW;
oParams_Get_Teacher_category_By_Where_InList_SP.END_ROW = i_Params_Get_Teacher_category_By_Where_InList.END_ROW;
oParams_Get_Teacher_category_By_Where_InList_SP.TOTAL_COUNT = i_Params_Get_Teacher_category_By_Where_InList.TOTAL_COUNT;
List<DALC.Teacher_category> oList_DBEntries = _AppContext.Get_Teacher_category_By_Where_InList(i_Params_Get_Teacher_category_By_Where_InList.DESCRIPTION,i_Params_Get_Teacher_category_By_Where_InList.TEACHER_ID_LIST,i_Params_Get_Teacher_category_By_Where_InList.CATEGORY_ID_LIST,i_Params_Get_Teacher_category_By_Where_InList.OWNER_ID,i_Params_Get_Teacher_category_By_Where_InList.START_ROW,i_Params_Get_Teacher_category_By_Where_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_category = new Teacher_category();
oTools.CopyPropValues(oDBEntry, oTeacher_category);
oList.Add(oTeacher_category);
}
}
i_Params_Get_Teacher_category_By_Where_InList.TOTAL_COUNT = oParams_Get_Teacher_category_By_Where_InList_SP.TOTAL_COUNT;
i_Params_Get_Teacher_category_By_Where_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_category_By_Where_InList");}
return oList;
}
public List<Teacher_favorite> Get_Teacher_favorite_By_Criteria_InList(Params_Get_Teacher_favorite_By_Criteria_InList i_Params_Get_Teacher_favorite_By_Criteria_InList)
{
List<Teacher_favorite> oList = new List<Teacher_favorite>();
Tools.Tools oTools = new Tools.Tools();
Teacher_favorite oTeacher_favorite = new Teacher_favorite();
long? tmp_TOTAL_COUNT = 0;
Params_Get_Teacher_favorite_By_Criteria_InList_SP oParams_Get_Teacher_favorite_By_Criteria_InList_SP = new Params_Get_Teacher_favorite_By_Criteria_InList_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_favorite_By_Criteria_InList");}
#region Body Section.
if ((i_Params_Get_Teacher_favorite_By_Criteria_InList.OWNER_ID == null) || (i_Params_Get_Teacher_favorite_By_Criteria_InList.OWNER_ID == 0)) { i_Params_Get_Teacher_favorite_By_Criteria_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Teacher_favorite_By_Criteria_InList.START_ROW == null) { i_Params_Get_Teacher_favorite_By_Criteria_InList.START_ROW = 0; }
if ((i_Params_Get_Teacher_favorite_By_Criteria_InList.END_ROW == null) || (i_Params_Get_Teacher_favorite_By_Criteria_InList.END_ROW == 0)) { i_Params_Get_Teacher_favorite_By_Criteria_InList.END_ROW = 1000000; }
oParams_Get_Teacher_favorite_By_Criteria_InList_SP.OWNER_ID = i_Params_Get_Teacher_favorite_By_Criteria_InList.OWNER_ID;
oParams_Get_Teacher_favorite_By_Criteria_InList_SP.DESCRIPTION = i_Params_Get_Teacher_favorite_By_Criteria_InList.DESCRIPTION;
if ( i_Params_Get_Teacher_favorite_By_Criteria_InList.TEACHER_ID_LIST == null)
{
i_Params_Get_Teacher_favorite_By_Criteria_InList.TEACHER_ID_LIST = new List<Int32?>();
}
oParams_Get_Teacher_favorite_By_Criteria_InList_SP.TEACHER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Teacher_favorite_By_Criteria_InList.TEACHER_ID_LIST);
if ( i_Params_Get_Teacher_favorite_By_Criteria_InList.STUDENT_ID_LIST == null)
{
i_Params_Get_Teacher_favorite_By_Criteria_InList.STUDENT_ID_LIST = new List<Int32?>();
}
oParams_Get_Teacher_favorite_By_Criteria_InList_SP.STUDENT_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Teacher_favorite_By_Criteria_InList.STUDENT_ID_LIST);
oParams_Get_Teacher_favorite_By_Criteria_InList_SP.START_ROW = i_Params_Get_Teacher_favorite_By_Criteria_InList.START_ROW;
oParams_Get_Teacher_favorite_By_Criteria_InList_SP.END_ROW = i_Params_Get_Teacher_favorite_By_Criteria_InList.END_ROW;
oParams_Get_Teacher_favorite_By_Criteria_InList_SP.TOTAL_COUNT = i_Params_Get_Teacher_favorite_By_Criteria_InList.TOTAL_COUNT;
List<DALC.Teacher_favorite> oList_DBEntries = _AppContext.Get_Teacher_favorite_By_Criteria_InList(i_Params_Get_Teacher_favorite_By_Criteria_InList.DESCRIPTION,i_Params_Get_Teacher_favorite_By_Criteria_InList.TEACHER_ID_LIST,i_Params_Get_Teacher_favorite_By_Criteria_InList.STUDENT_ID_LIST,i_Params_Get_Teacher_favorite_By_Criteria_InList.OWNER_ID,i_Params_Get_Teacher_favorite_By_Criteria_InList.START_ROW,i_Params_Get_Teacher_favorite_By_Criteria_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_favorite = new Teacher_favorite();
oTools.CopyPropValues(oDBEntry, oTeacher_favorite);
oList.Add(oTeacher_favorite);
}
}
i_Params_Get_Teacher_favorite_By_Criteria_InList.TOTAL_COUNT = oParams_Get_Teacher_favorite_By_Criteria_InList_SP.TOTAL_COUNT;
i_Params_Get_Teacher_favorite_By_Criteria_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_favorite_By_Criteria_InList");}
return oList;
}
public List<Teacher_favorite> Get_Teacher_favorite_By_Where_InList(Params_Get_Teacher_favorite_By_Where_InList i_Params_Get_Teacher_favorite_By_Where_InList)
{
List<Teacher_favorite> oList = new List<Teacher_favorite>();
Tools.Tools oTools = new Tools.Tools();
Teacher_favorite oTeacher_favorite = new Teacher_favorite();
long? tmp_TOTAL_COUNT = 0;
Params_Get_Teacher_favorite_By_Where_InList_SP oParams_Get_Teacher_favorite_By_Where_InList_SP = new Params_Get_Teacher_favorite_By_Where_InList_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_favorite_By_Where_InList");}
#region Body Section.
if ((i_Params_Get_Teacher_favorite_By_Where_InList.OWNER_ID == null) || (i_Params_Get_Teacher_favorite_By_Where_InList.OWNER_ID == 0)) { i_Params_Get_Teacher_favorite_By_Where_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Teacher_favorite_By_Where_InList.START_ROW == null) { i_Params_Get_Teacher_favorite_By_Where_InList.START_ROW = 0; }
if ((i_Params_Get_Teacher_favorite_By_Where_InList.END_ROW == null) || (i_Params_Get_Teacher_favorite_By_Where_InList.END_ROW == 0)) { i_Params_Get_Teacher_favorite_By_Where_InList.END_ROW = 1000000; }
oParams_Get_Teacher_favorite_By_Where_InList_SP.OWNER_ID = i_Params_Get_Teacher_favorite_By_Where_InList.OWNER_ID;
oParams_Get_Teacher_favorite_By_Where_InList_SP.DESCRIPTION = i_Params_Get_Teacher_favorite_By_Where_InList.DESCRIPTION;
if ( i_Params_Get_Teacher_favorite_By_Where_InList.TEACHER_ID_LIST == null)
{
i_Params_Get_Teacher_favorite_By_Where_InList.TEACHER_ID_LIST = new List<Int32?>();
}
oParams_Get_Teacher_favorite_By_Where_InList_SP.TEACHER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Teacher_favorite_By_Where_InList.TEACHER_ID_LIST);
if ( i_Params_Get_Teacher_favorite_By_Where_InList.STUDENT_ID_LIST == null)
{
i_Params_Get_Teacher_favorite_By_Where_InList.STUDENT_ID_LIST = new List<Int32?>();
}
oParams_Get_Teacher_favorite_By_Where_InList_SP.STUDENT_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Teacher_favorite_By_Where_InList.STUDENT_ID_LIST);
oParams_Get_Teacher_favorite_By_Where_InList_SP.START_ROW = i_Params_Get_Teacher_favorite_By_Where_InList.START_ROW;
oParams_Get_Teacher_favorite_By_Where_InList_SP.END_ROW = i_Params_Get_Teacher_favorite_By_Where_InList.END_ROW;
oParams_Get_Teacher_favorite_By_Where_InList_SP.TOTAL_COUNT = i_Params_Get_Teacher_favorite_By_Where_InList.TOTAL_COUNT;
List<DALC.Teacher_favorite> oList_DBEntries = _AppContext.Get_Teacher_favorite_By_Where_InList(i_Params_Get_Teacher_favorite_By_Where_InList.DESCRIPTION,i_Params_Get_Teacher_favorite_By_Where_InList.TEACHER_ID_LIST,i_Params_Get_Teacher_favorite_By_Where_InList.STUDENT_ID_LIST,i_Params_Get_Teacher_favorite_By_Where_InList.OWNER_ID,i_Params_Get_Teacher_favorite_By_Where_InList.START_ROW,i_Params_Get_Teacher_favorite_By_Where_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_favorite = new Teacher_favorite();
oTools.CopyPropValues(oDBEntry, oTeacher_favorite);
oList.Add(oTeacher_favorite);
}
}
i_Params_Get_Teacher_favorite_By_Where_InList.TOTAL_COUNT = oParams_Get_Teacher_favorite_By_Where_InList_SP.TOTAL_COUNT;
i_Params_Get_Teacher_favorite_By_Where_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_favorite_By_Where_InList");}
return oList;
}
public List<Teacher_rank> Get_Teacher_rank_By_Criteria_InList(Params_Get_Teacher_rank_By_Criteria_InList i_Params_Get_Teacher_rank_By_Criteria_InList)
{
List<Teacher_rank> oList = new List<Teacher_rank>();
Tools.Tools oTools = new Tools.Tools();
Teacher_rank oTeacher_rank = new Teacher_rank();
long? tmp_TOTAL_COUNT = 0;
Params_Get_Teacher_rank_By_Criteria_InList_SP oParams_Get_Teacher_rank_By_Criteria_InList_SP = new Params_Get_Teacher_rank_By_Criteria_InList_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_rank_By_Criteria_InList");}
#region Body Section.
if ((i_Params_Get_Teacher_rank_By_Criteria_InList.OWNER_ID == null) || (i_Params_Get_Teacher_rank_By_Criteria_InList.OWNER_ID == 0)) { i_Params_Get_Teacher_rank_By_Criteria_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Teacher_rank_By_Criteria_InList.START_ROW == null) { i_Params_Get_Teacher_rank_By_Criteria_InList.START_ROW = 0; }
if ((i_Params_Get_Teacher_rank_By_Criteria_InList.END_ROW == null) || (i_Params_Get_Teacher_rank_By_Criteria_InList.END_ROW == 0)) { i_Params_Get_Teacher_rank_By_Criteria_InList.END_ROW = 1000000; }
oParams_Get_Teacher_rank_By_Criteria_InList_SP.OWNER_ID = i_Params_Get_Teacher_rank_By_Criteria_InList.OWNER_ID;
oParams_Get_Teacher_rank_By_Criteria_InList_SP.DESCRIPTION = i_Params_Get_Teacher_rank_By_Criteria_InList.DESCRIPTION;
if ( i_Params_Get_Teacher_rank_By_Criteria_InList.TEACHER_ID_LIST == null)
{
i_Params_Get_Teacher_rank_By_Criteria_InList.TEACHER_ID_LIST = new List<Int32?>();
}
oParams_Get_Teacher_rank_By_Criteria_InList_SP.TEACHER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Teacher_rank_By_Criteria_InList.TEACHER_ID_LIST);
oParams_Get_Teacher_rank_By_Criteria_InList_SP.START_ROW = i_Params_Get_Teacher_rank_By_Criteria_InList.START_ROW;
oParams_Get_Teacher_rank_By_Criteria_InList_SP.END_ROW = i_Params_Get_Teacher_rank_By_Criteria_InList.END_ROW;
oParams_Get_Teacher_rank_By_Criteria_InList_SP.TOTAL_COUNT = i_Params_Get_Teacher_rank_By_Criteria_InList.TOTAL_COUNT;
List<DALC.Teacher_rank> oList_DBEntries = _AppContext.Get_Teacher_rank_By_Criteria_InList(i_Params_Get_Teacher_rank_By_Criteria_InList.DESCRIPTION,i_Params_Get_Teacher_rank_By_Criteria_InList.TEACHER_ID_LIST,i_Params_Get_Teacher_rank_By_Criteria_InList.OWNER_ID,i_Params_Get_Teacher_rank_By_Criteria_InList.START_ROW,i_Params_Get_Teacher_rank_By_Criteria_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_rank = new Teacher_rank();
oTools.CopyPropValues(oDBEntry, oTeacher_rank);
oList.Add(oTeacher_rank);
}
}
i_Params_Get_Teacher_rank_By_Criteria_InList.TOTAL_COUNT = oParams_Get_Teacher_rank_By_Criteria_InList_SP.TOTAL_COUNT;
i_Params_Get_Teacher_rank_By_Criteria_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_rank_By_Criteria_InList");}
return oList;
}
public List<Teacher_rank> Get_Teacher_rank_By_Where_InList(Params_Get_Teacher_rank_By_Where_InList i_Params_Get_Teacher_rank_By_Where_InList)
{
List<Teacher_rank> oList = new List<Teacher_rank>();
Tools.Tools oTools = new Tools.Tools();
Teacher_rank oTeacher_rank = new Teacher_rank();
long? tmp_TOTAL_COUNT = 0;
Params_Get_Teacher_rank_By_Where_InList_SP oParams_Get_Teacher_rank_By_Where_InList_SP = new Params_Get_Teacher_rank_By_Where_InList_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_rank_By_Where_InList");}
#region Body Section.
if ((i_Params_Get_Teacher_rank_By_Where_InList.OWNER_ID == null) || (i_Params_Get_Teacher_rank_By_Where_InList.OWNER_ID == 0)) { i_Params_Get_Teacher_rank_By_Where_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Teacher_rank_By_Where_InList.START_ROW == null) { i_Params_Get_Teacher_rank_By_Where_InList.START_ROW = 0; }
if ((i_Params_Get_Teacher_rank_By_Where_InList.END_ROW == null) || (i_Params_Get_Teacher_rank_By_Where_InList.END_ROW == 0)) { i_Params_Get_Teacher_rank_By_Where_InList.END_ROW = 1000000; }
oParams_Get_Teacher_rank_By_Where_InList_SP.OWNER_ID = i_Params_Get_Teacher_rank_By_Where_InList.OWNER_ID;
oParams_Get_Teacher_rank_By_Where_InList_SP.DESCRIPTION = i_Params_Get_Teacher_rank_By_Where_InList.DESCRIPTION;
if ( i_Params_Get_Teacher_rank_By_Where_InList.TEACHER_ID_LIST == null)
{
i_Params_Get_Teacher_rank_By_Where_InList.TEACHER_ID_LIST = new List<Int32?>();
}
oParams_Get_Teacher_rank_By_Where_InList_SP.TEACHER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Teacher_rank_By_Where_InList.TEACHER_ID_LIST);
oParams_Get_Teacher_rank_By_Where_InList_SP.START_ROW = i_Params_Get_Teacher_rank_By_Where_InList.START_ROW;
oParams_Get_Teacher_rank_By_Where_InList_SP.END_ROW = i_Params_Get_Teacher_rank_By_Where_InList.END_ROW;
oParams_Get_Teacher_rank_By_Where_InList_SP.TOTAL_COUNT = i_Params_Get_Teacher_rank_By_Where_InList.TOTAL_COUNT;
List<DALC.Teacher_rank> oList_DBEntries = _AppContext.Get_Teacher_rank_By_Where_InList(i_Params_Get_Teacher_rank_By_Where_InList.DESCRIPTION,i_Params_Get_Teacher_rank_By_Where_InList.TEACHER_ID_LIST,i_Params_Get_Teacher_rank_By_Where_InList.OWNER_ID,i_Params_Get_Teacher_rank_By_Where_InList.START_ROW,i_Params_Get_Teacher_rank_By_Where_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_rank = new Teacher_rank();
oTools.CopyPropValues(oDBEntry, oTeacher_rank);
oList.Add(oTeacher_rank);
}
}
i_Params_Get_Teacher_rank_By_Where_InList.TOTAL_COUNT = oParams_Get_Teacher_rank_By_Where_InList_SP.TOTAL_COUNT;
i_Params_Get_Teacher_rank_By_Where_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_rank_By_Where_InList");}
return oList;
}
public List<Teacher_report> Get_Teacher_report_By_Criteria_InList(Params_Get_Teacher_report_By_Criteria_InList i_Params_Get_Teacher_report_By_Criteria_InList)
{
List<Teacher_report> oList = new List<Teacher_report>();
Tools.Tools oTools = new Tools.Tools();
Teacher_report oTeacher_report = new Teacher_report();
long? tmp_TOTAL_COUNT = 0;
Params_Get_Teacher_report_By_Criteria_InList_SP oParams_Get_Teacher_report_By_Criteria_InList_SP = new Params_Get_Teacher_report_By_Criteria_InList_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_report_By_Criteria_InList");}
#region Body Section.
if ((i_Params_Get_Teacher_report_By_Criteria_InList.OWNER_ID == null) || (i_Params_Get_Teacher_report_By_Criteria_InList.OWNER_ID == 0)) { i_Params_Get_Teacher_report_By_Criteria_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Teacher_report_By_Criteria_InList.START_ROW == null) { i_Params_Get_Teacher_report_By_Criteria_InList.START_ROW = 0; }
if ((i_Params_Get_Teacher_report_By_Criteria_InList.END_ROW == null) || (i_Params_Get_Teacher_report_By_Criteria_InList.END_ROW == 0)) { i_Params_Get_Teacher_report_By_Criteria_InList.END_ROW = 1000000; }
oParams_Get_Teacher_report_By_Criteria_InList_SP.OWNER_ID = i_Params_Get_Teacher_report_By_Criteria_InList.OWNER_ID;
oParams_Get_Teacher_report_By_Criteria_InList_SP.DESCRIPTION = i_Params_Get_Teacher_report_By_Criteria_InList.DESCRIPTION;
if ( i_Params_Get_Teacher_report_By_Criteria_InList.TEACHER_ID_LIST == null)
{
i_Params_Get_Teacher_report_By_Criteria_InList.TEACHER_ID_LIST = new List<Int32?>();
}
oParams_Get_Teacher_report_By_Criteria_InList_SP.TEACHER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Teacher_report_By_Criteria_InList.TEACHER_ID_LIST);
if ( i_Params_Get_Teacher_report_By_Criteria_InList.STUDENT_ID_LIST == null)
{
i_Params_Get_Teacher_report_By_Criteria_InList.STUDENT_ID_LIST = new List<Int32?>();
}
oParams_Get_Teacher_report_By_Criteria_InList_SP.STUDENT_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Teacher_report_By_Criteria_InList.STUDENT_ID_LIST);
oParams_Get_Teacher_report_By_Criteria_InList_SP.START_ROW = i_Params_Get_Teacher_report_By_Criteria_InList.START_ROW;
oParams_Get_Teacher_report_By_Criteria_InList_SP.END_ROW = i_Params_Get_Teacher_report_By_Criteria_InList.END_ROW;
oParams_Get_Teacher_report_By_Criteria_InList_SP.TOTAL_COUNT = i_Params_Get_Teacher_report_By_Criteria_InList.TOTAL_COUNT;
List<DALC.Teacher_report> oList_DBEntries = _AppContext.Get_Teacher_report_By_Criteria_InList(i_Params_Get_Teacher_report_By_Criteria_InList.DESCRIPTION,i_Params_Get_Teacher_report_By_Criteria_InList.TEACHER_ID_LIST,i_Params_Get_Teacher_report_By_Criteria_InList.STUDENT_ID_LIST,i_Params_Get_Teacher_report_By_Criteria_InList.OWNER_ID,i_Params_Get_Teacher_report_By_Criteria_InList.START_ROW,i_Params_Get_Teacher_report_By_Criteria_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_report = new Teacher_report();
oTools.CopyPropValues(oDBEntry, oTeacher_report);
oList.Add(oTeacher_report);
}
}
i_Params_Get_Teacher_report_By_Criteria_InList.TOTAL_COUNT = oParams_Get_Teacher_report_By_Criteria_InList_SP.TOTAL_COUNT;
i_Params_Get_Teacher_report_By_Criteria_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_report_By_Criteria_InList");}
return oList;
}
public List<Teacher_report> Get_Teacher_report_By_Where_InList(Params_Get_Teacher_report_By_Where_InList i_Params_Get_Teacher_report_By_Where_InList)
{
List<Teacher_report> oList = new List<Teacher_report>();
Tools.Tools oTools = new Tools.Tools();
Teacher_report oTeacher_report = new Teacher_report();
long? tmp_TOTAL_COUNT = 0;
Params_Get_Teacher_report_By_Where_InList_SP oParams_Get_Teacher_report_By_Where_InList_SP = new Params_Get_Teacher_report_By_Where_InList_SP();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_report_By_Where_InList");}
#region Body Section.
if ((i_Params_Get_Teacher_report_By_Where_InList.OWNER_ID == null) || (i_Params_Get_Teacher_report_By_Where_InList.OWNER_ID == 0)) { i_Params_Get_Teacher_report_By_Where_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Teacher_report_By_Where_InList.START_ROW == null) { i_Params_Get_Teacher_report_By_Where_InList.START_ROW = 0; }
if ((i_Params_Get_Teacher_report_By_Where_InList.END_ROW == null) || (i_Params_Get_Teacher_report_By_Where_InList.END_ROW == 0)) { i_Params_Get_Teacher_report_By_Where_InList.END_ROW = 1000000; }
oParams_Get_Teacher_report_By_Where_InList_SP.OWNER_ID = i_Params_Get_Teacher_report_By_Where_InList.OWNER_ID;
oParams_Get_Teacher_report_By_Where_InList_SP.DESCRIPTION = i_Params_Get_Teacher_report_By_Where_InList.DESCRIPTION;
if ( i_Params_Get_Teacher_report_By_Where_InList.TEACHER_ID_LIST == null)
{
i_Params_Get_Teacher_report_By_Where_InList.TEACHER_ID_LIST = new List<Int32?>();
}
oParams_Get_Teacher_report_By_Where_InList_SP.TEACHER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Teacher_report_By_Where_InList.TEACHER_ID_LIST);
if ( i_Params_Get_Teacher_report_By_Where_InList.STUDENT_ID_LIST == null)
{
i_Params_Get_Teacher_report_By_Where_InList.STUDENT_ID_LIST = new List<Int32?>();
}
oParams_Get_Teacher_report_By_Where_InList_SP.STUDENT_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Teacher_report_By_Where_InList.STUDENT_ID_LIST);
oParams_Get_Teacher_report_By_Where_InList_SP.START_ROW = i_Params_Get_Teacher_report_By_Where_InList.START_ROW;
oParams_Get_Teacher_report_By_Where_InList_SP.END_ROW = i_Params_Get_Teacher_report_By_Where_InList.END_ROW;
oParams_Get_Teacher_report_By_Where_InList_SP.TOTAL_COUNT = i_Params_Get_Teacher_report_By_Where_InList.TOTAL_COUNT;
List<DALC.Teacher_report> oList_DBEntries = _AppContext.Get_Teacher_report_By_Where_InList(i_Params_Get_Teacher_report_By_Where_InList.DESCRIPTION,i_Params_Get_Teacher_report_By_Where_InList.TEACHER_ID_LIST,i_Params_Get_Teacher_report_By_Where_InList.STUDENT_ID_LIST,i_Params_Get_Teacher_report_By_Where_InList.OWNER_ID,i_Params_Get_Teacher_report_By_Where_InList.START_ROW,i_Params_Get_Teacher_report_By_Where_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_report = new Teacher_report();
oTools.CopyPropValues(oDBEntry, oTeacher_report);
oList.Add(oTeacher_report);
}
}
i_Params_Get_Teacher_report_By_Where_InList.TOTAL_COUNT = oParams_Get_Teacher_report_By_Where_InList_SP.TOTAL_COUNT;
i_Params_Get_Teacher_report_By_Where_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_report_By_Where_InList");}
return oList;
}
public void Delete_Answer(Params_Delete_Answer i_Params_Delete_Answer)
{
Params_Get_Answer_By_ANSWER_ID oParams_Get_Answer_By_ANSWER_ID = new Params_Get_Answer_By_ANSWER_ID();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Answer");}
#region Body Section.
try
{
oParams_Get_Answer_By_ANSWER_ID.ANSWER_ID = i_Params_Delete_Answer.ANSWER_ID;
_Answer = Get_Answer_By_ANSWER_ID_Adv(oParams_Get_Answer_By_ANSWER_ID);
if (_Answer != null)
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Answer_Execution)
{
_Stop_Delete_Answer_Execution = false;
return;
}
_AppContext.Delete_Answer(i_Params_Delete_Answer.ANSWER_ID);
oScope.Complete();
}
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Answer");}
}
public void Delete_Answer_report(Params_Delete_Answer_report i_Params_Delete_Answer_report)
{
Params_Get_Answer_report_By_ANSWER_REPORT_ID oParams_Get_Answer_report_By_ANSWER_REPORT_ID = new Params_Get_Answer_report_By_ANSWER_REPORT_ID();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Answer_report");}
#region Body Section.
try
{
oParams_Get_Answer_report_By_ANSWER_REPORT_ID.ANSWER_REPORT_ID = i_Params_Delete_Answer_report.ANSWER_REPORT_ID;
_Answer_report = Get_Answer_report_By_ANSWER_REPORT_ID_Adv(oParams_Get_Answer_report_By_ANSWER_REPORT_ID);
if (_Answer_report != null)
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Answer_report_Execution)
{
_Stop_Delete_Answer_report_Execution = false;
return;
}
_AppContext.Delete_Answer_report(i_Params_Delete_Answer_report.ANSWER_REPORT_ID);
oScope.Complete();
}
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Answer_report");}
}
public void Delete_Appreciate(Params_Delete_Appreciate i_Params_Delete_Appreciate)
{
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Appreciate");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Appreciate_Execution)
{
_Stop_Delete_Appreciate_Execution = false;
return;
}
_AppContext.Delete_Appreciate(i_Params_Delete_Appreciate.APPRECIATE_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Appreciate");}
}
public void Delete_Article(Params_Delete_Article i_Params_Delete_Article)
{
Params_Get_Article_By_ARTICLE_ID oParams_Get_Article_By_ARTICLE_ID = new Params_Get_Article_By_ARTICLE_ID();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Article");}
#region Body Section.
try
{
oParams_Get_Article_By_ARTICLE_ID.ARTICLE_ID = i_Params_Delete_Article.ARTICLE_ID;
_Article = Get_Article_By_ARTICLE_ID_Adv(oParams_Get_Article_By_ARTICLE_ID);
if (_Article != null)
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Article_Execution)
{
_Stop_Delete_Article_Execution = false;
return;
}
_AppContext.Delete_Article(i_Params_Delete_Article.ARTICLE_ID);
oScope.Complete();
}
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Article");}
}
public void Delete_Category(Params_Delete_Category i_Params_Delete_Category)
{
Params_Get_Category_By_CATEGORY_ID oParams_Get_Category_By_CATEGORY_ID = new Params_Get_Category_By_CATEGORY_ID();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Category");}
#region Body Section.
try
{
oParams_Get_Category_By_CATEGORY_ID.CATEGORY_ID = i_Params_Delete_Category.CATEGORY_ID;
_Category = Get_Category_By_CATEGORY_ID_Adv(oParams_Get_Category_By_CATEGORY_ID);
if (_Category != null)
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Category_Execution)
{
_Stop_Delete_Category_Execution = false;
return;
}
_AppContext.Delete_Category(i_Params_Delete_Category.CATEGORY_ID);
oScope.Complete();
}
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Category");}
}
public void Delete_Evaluation(Params_Delete_Evaluation i_Params_Delete_Evaluation)
{
Params_Get_Evaluation_By_EVALUATION_ID oParams_Get_Evaluation_By_EVALUATION_ID = new Params_Get_Evaluation_By_EVALUATION_ID();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Evaluation");}
#region Body Section.
try
{
oParams_Get_Evaluation_By_EVALUATION_ID.EVALUATION_ID = i_Params_Delete_Evaluation.EVALUATION_ID;
_Evaluation = Get_Evaluation_By_EVALUATION_ID_Adv(oParams_Get_Evaluation_By_EVALUATION_ID);
if (_Evaluation != null)
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Evaluation_Execution)
{
_Stop_Delete_Evaluation_Execution = false;
return;
}
_AppContext.Delete_Evaluation(i_Params_Delete_Evaluation.EVALUATION_ID);
oScope.Complete();
}
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Evaluation");}
}
public void Delete_Favorite_category(Params_Delete_Favorite_category i_Params_Delete_Favorite_category)
{
Params_Get_Favorite_category_By_FAVORITE_CATEGORY_ID oParams_Get_Favorite_category_By_FAVORITE_CATEGORY_ID = new Params_Get_Favorite_category_By_FAVORITE_CATEGORY_ID();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Favorite_category");}
#region Body Section.
try
{
oParams_Get_Favorite_category_By_FAVORITE_CATEGORY_ID.FAVORITE_CATEGORY_ID = i_Params_Delete_Favorite_category.FAVORITE_CATEGORY_ID;
_Favorite_category = Get_Favorite_category_By_FAVORITE_CATEGORY_ID_Adv(oParams_Get_Favorite_category_By_FAVORITE_CATEGORY_ID);
if (_Favorite_category != null)
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Favorite_category_Execution)
{
_Stop_Delete_Favorite_category_Execution = false;
return;
}
_AppContext.Delete_Favorite_category(i_Params_Delete_Favorite_category.FAVORITE_CATEGORY_ID);
oScope.Complete();
}
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Favorite_category");}
}
public void Delete_Favorite_teacher(Params_Delete_Favorite_teacher i_Params_Delete_Favorite_teacher)
{
Params_Get_Favorite_teacher_By_FAVORITE_TEACHER_ID oParams_Get_Favorite_teacher_By_FAVORITE_TEACHER_ID = new Params_Get_Favorite_teacher_By_FAVORITE_TEACHER_ID();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Favorite_teacher");}
#region Body Section.
try
{
oParams_Get_Favorite_teacher_By_FAVORITE_TEACHER_ID.FAVORITE_TEACHER_ID = i_Params_Delete_Favorite_teacher.FAVORITE_TEACHER_ID;
_Favorite_teacher = Get_Favorite_teacher_By_FAVORITE_TEACHER_ID_Adv(oParams_Get_Favorite_teacher_By_FAVORITE_TEACHER_ID);
if (_Favorite_teacher != null)
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Favorite_teacher_Execution)
{
_Stop_Delete_Favorite_teacher_Execution = false;
return;
}
_AppContext.Delete_Favorite_teacher(i_Params_Delete_Favorite_teacher.FAVORITE_TEACHER_ID);
oScope.Complete();
}
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Favorite_teacher");}
}
public void Delete_Mark_question(Params_Delete_Mark_question i_Params_Delete_Mark_question)
{
Params_Get_Mark_question_By_MARK_QUESTION_ID oParams_Get_Mark_question_By_MARK_QUESTION_ID = new Params_Get_Mark_question_By_MARK_QUESTION_ID();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Mark_question");}
#region Body Section.
try
{
oParams_Get_Mark_question_By_MARK_QUESTION_ID.MARK_QUESTION_ID = i_Params_Delete_Mark_question.MARK_QUESTION_ID;
_Mark_question = Get_Mark_question_By_MARK_QUESTION_ID_Adv(oParams_Get_Mark_question_By_MARK_QUESTION_ID);
if (_Mark_question != null)
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Mark_question_Execution)
{
_Stop_Delete_Mark_question_Execution = false;
return;
}
_AppContext.Delete_Mark_question(i_Params_Delete_Mark_question.MARK_QUESTION_ID);
oScope.Complete();
}
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Mark_question");}
}
public void Delete_Notification(Params_Delete_Notification i_Params_Delete_Notification)
{
Params_Get_Notification_By_NOTIFICATION_ID oParams_Get_Notification_By_NOTIFICATION_ID = new Params_Get_Notification_By_NOTIFICATION_ID();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Notification");}
#region Body Section.
try
{
oParams_Get_Notification_By_NOTIFICATION_ID.NOTIFICATION_ID = i_Params_Delete_Notification.NOTIFICATION_ID;
_Notification = Get_Notification_By_NOTIFICATION_ID_Adv(oParams_Get_Notification_By_NOTIFICATION_ID);
if (_Notification != null)
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Notification_Execution)
{
_Stop_Delete_Notification_Execution = false;
return;
}
_AppContext.Delete_Notification(i_Params_Delete_Notification.NOTIFICATION_ID);
oScope.Complete();
}
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Notification");}
}
public void Delete_Owner(Params_Delete_Owner i_Params_Delete_Owner)
{
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Owner");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Owner_Execution)
{
_Stop_Delete_Owner_Execution = false;
return;
}
_AppContext.Delete_Owner(i_Params_Delete_Owner.OWNER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Owner");}
}
public void Delete_Question(Params_Delete_Question i_Params_Delete_Question)
{
Params_Get_Question_By_QUESTION_ID oParams_Get_Question_By_QUESTION_ID = new Params_Get_Question_By_QUESTION_ID();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Question");}
#region Body Section.
try
{
oParams_Get_Question_By_QUESTION_ID.QUESTION_ID = i_Params_Delete_Question.QUESTION_ID;
_Question = Get_Question_By_QUESTION_ID_Adv(oParams_Get_Question_By_QUESTION_ID);
if (_Question != null)
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Question_Execution)
{
_Stop_Delete_Question_Execution = false;
return;
}
_AppContext.Delete_Question(i_Params_Delete_Question.QUESTION_ID);
oScope.Complete();
}
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Question");}
}
public void Delete_Question_report(Params_Delete_Question_report i_Params_Delete_Question_report)
{
Params_Get_Question_report_By_QUESTION_REPORT_ID oParams_Get_Question_report_By_QUESTION_REPORT_ID = new Params_Get_Question_report_By_QUESTION_REPORT_ID();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Question_report");}
#region Body Section.
try
{
oParams_Get_Question_report_By_QUESTION_REPORT_ID.QUESTION_REPORT_ID = i_Params_Delete_Question_report.QUESTION_REPORT_ID;
_Question_report = Get_Question_report_By_QUESTION_REPORT_ID_Adv(oParams_Get_Question_report_By_QUESTION_REPORT_ID);
if (_Question_report != null)
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Question_report_Execution)
{
_Stop_Delete_Question_report_Execution = false;
return;
}
_AppContext.Delete_Question_report(i_Params_Delete_Question_report.QUESTION_REPORT_ID);
oScope.Complete();
}
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Question_report");}
}
public void Delete_Question_token(Params_Delete_Question_token i_Params_Delete_Question_token)
{
Params_Get_Question_token_By_QUESTION_TOKEN_ID oParams_Get_Question_token_By_QUESTION_TOKEN_ID = new Params_Get_Question_token_By_QUESTION_TOKEN_ID();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Question_token");}
#region Body Section.
try
{
oParams_Get_Question_token_By_QUESTION_TOKEN_ID.QUESTION_TOKEN_ID = i_Params_Delete_Question_token.QUESTION_TOKEN_ID;
_Question_token = Get_Question_token_By_QUESTION_TOKEN_ID_Adv(oParams_Get_Question_token_By_QUESTION_TOKEN_ID);
if (_Question_token != null)
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Question_token_Execution)
{
_Stop_Delete_Question_token_Execution = false;
return;
}
_AppContext.Delete_Question_token(i_Params_Delete_Question_token.QUESTION_TOKEN_ID);
oScope.Complete();
}
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Question_token");}
}
public void Delete_Report_article(Params_Delete_Report_article i_Params_Delete_Report_article)
{
Params_Get_Report_article_By_REPORT_ARTICLE_ID oParams_Get_Report_article_By_REPORT_ARTICLE_ID = new Params_Get_Report_article_By_REPORT_ARTICLE_ID();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Report_article");}
#region Body Section.
try
{
oParams_Get_Report_article_By_REPORT_ARTICLE_ID.REPORT_ARTICLE_ID = i_Params_Delete_Report_article.REPORT_ARTICLE_ID;
_Report_article = Get_Report_article_By_REPORT_ARTICLE_ID_Adv(oParams_Get_Report_article_By_REPORT_ARTICLE_ID);
if (_Report_article != null)
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Report_article_Execution)
{
_Stop_Delete_Report_article_Execution = false;
return;
}
_AppContext.Delete_Report_article(i_Params_Delete_Report_article.REPORT_ARTICLE_ID);
oScope.Complete();
}
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Report_article");}
}
public void Delete_Student(Params_Delete_Student i_Params_Delete_Student)
{
Params_Get_Student_By_STUDENT_ID oParams_Get_Student_By_STUDENT_ID = new Params_Get_Student_By_STUDENT_ID();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Student");}
#region Body Section.
try
{
oParams_Get_Student_By_STUDENT_ID.STUDENT_ID = i_Params_Delete_Student.STUDENT_ID;
_Student = Get_Student_By_STUDENT_ID_Adv(oParams_Get_Student_By_STUDENT_ID);
if (_Student != null)
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Student_Execution)
{
_Stop_Delete_Student_Execution = false;
return;
}
_AppContext.Delete_Student(i_Params_Delete_Student.STUDENT_ID);
oScope.Complete();
}
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Student");}
}
public void Delete_Student_report(Params_Delete_Student_report i_Params_Delete_Student_report)
{
Params_Get_Student_report_By_STUDENT_REPORT_ID oParams_Get_Student_report_By_STUDENT_REPORT_ID = new Params_Get_Student_report_By_STUDENT_REPORT_ID();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Student_report");}
#region Body Section.
try
{
oParams_Get_Student_report_By_STUDENT_REPORT_ID.STUDENT_REPORT_ID = i_Params_Delete_Student_report.STUDENT_REPORT_ID;
_Student_report = Get_Student_report_By_STUDENT_REPORT_ID_Adv(oParams_Get_Student_report_By_STUDENT_REPORT_ID);
if (_Student_report != null)
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Student_report_Execution)
{
_Stop_Delete_Student_report_Execution = false;
return;
}
_AppContext.Delete_Student_report(i_Params_Delete_Student_report.STUDENT_REPORT_ID);
oScope.Complete();
}
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Student_report");}
}
public void Delete_Teacher(Params_Delete_Teacher i_Params_Delete_Teacher)
{
Params_Get_Teacher_By_TEACHER_ID oParams_Get_Teacher_By_TEACHER_ID = new Params_Get_Teacher_By_TEACHER_ID();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Teacher");}
#region Body Section.
try
{
oParams_Get_Teacher_By_TEACHER_ID.TEACHER_ID = i_Params_Delete_Teacher.TEACHER_ID;
_Teacher = Get_Teacher_By_TEACHER_ID_Adv(oParams_Get_Teacher_By_TEACHER_ID);
if (_Teacher != null)
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Teacher_Execution)
{
_Stop_Delete_Teacher_Execution = false;
return;
}
_AppContext.Delete_Teacher(i_Params_Delete_Teacher.TEACHER_ID);
oScope.Complete();
}
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Teacher");}
}
public void Delete_Teacher_category(Params_Delete_Teacher_category i_Params_Delete_Teacher_category)
{
Params_Get_Teacher_category_By_TEACHER_CATEGORY_ID oParams_Get_Teacher_category_By_TEACHER_CATEGORY_ID = new Params_Get_Teacher_category_By_TEACHER_CATEGORY_ID();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Teacher_category");}
#region Body Section.
try
{
oParams_Get_Teacher_category_By_TEACHER_CATEGORY_ID.TEACHER_CATEGORY_ID = i_Params_Delete_Teacher_category.TEACHER_CATEGORY_ID;
_Teacher_category = Get_Teacher_category_By_TEACHER_CATEGORY_ID_Adv(oParams_Get_Teacher_category_By_TEACHER_CATEGORY_ID);
if (_Teacher_category != null)
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Teacher_category_Execution)
{
_Stop_Delete_Teacher_category_Execution = false;
return;
}
_AppContext.Delete_Teacher_category(i_Params_Delete_Teacher_category.TEACHER_CATEGORY_ID);
oScope.Complete();
}
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Teacher_category");}
}
public void Delete_Teacher_favorite(Params_Delete_Teacher_favorite i_Params_Delete_Teacher_favorite)
{
Params_Get_Teacher_favorite_By_TEACHER_FAVORITE_ID oParams_Get_Teacher_favorite_By_TEACHER_FAVORITE_ID = new Params_Get_Teacher_favorite_By_TEACHER_FAVORITE_ID();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Teacher_favorite");}
#region Body Section.
try
{
oParams_Get_Teacher_favorite_By_TEACHER_FAVORITE_ID.TEACHER_FAVORITE_ID = i_Params_Delete_Teacher_favorite.TEACHER_FAVORITE_ID;
_Teacher_favorite = Get_Teacher_favorite_By_TEACHER_FAVORITE_ID_Adv(oParams_Get_Teacher_favorite_By_TEACHER_FAVORITE_ID);
if (_Teacher_favorite != null)
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Teacher_favorite_Execution)
{
_Stop_Delete_Teacher_favorite_Execution = false;
return;
}
_AppContext.Delete_Teacher_favorite(i_Params_Delete_Teacher_favorite.TEACHER_FAVORITE_ID);
oScope.Complete();
}
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Teacher_favorite");}
}
public void Delete_Teacher_rank(Params_Delete_Teacher_rank i_Params_Delete_Teacher_rank)
{
Params_Get_Teacher_rank_By_TEACHER_RANK_ID oParams_Get_Teacher_rank_By_TEACHER_RANK_ID = new Params_Get_Teacher_rank_By_TEACHER_RANK_ID();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Teacher_rank");}
#region Body Section.
try
{
oParams_Get_Teacher_rank_By_TEACHER_RANK_ID.TEACHER_RANK_ID = i_Params_Delete_Teacher_rank.TEACHER_RANK_ID;
_Teacher_rank = Get_Teacher_rank_By_TEACHER_RANK_ID_Adv(oParams_Get_Teacher_rank_By_TEACHER_RANK_ID);
if (_Teacher_rank != null)
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Teacher_rank_Execution)
{
_Stop_Delete_Teacher_rank_Execution = false;
return;
}
_AppContext.Delete_Teacher_rank(i_Params_Delete_Teacher_rank.TEACHER_RANK_ID);
oScope.Complete();
}
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Teacher_rank");}
}
public void Delete_Teacher_report(Params_Delete_Teacher_report i_Params_Delete_Teacher_report)
{
Params_Get_Teacher_report_By_TEACHER_REPORT_ID oParams_Get_Teacher_report_By_TEACHER_REPORT_ID = new Params_Get_Teacher_report_By_TEACHER_REPORT_ID();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Teacher_report");}
#region Body Section.
try
{
oParams_Get_Teacher_report_By_TEACHER_REPORT_ID.TEACHER_REPORT_ID = i_Params_Delete_Teacher_report.TEACHER_REPORT_ID;
_Teacher_report = Get_Teacher_report_By_TEACHER_REPORT_ID_Adv(oParams_Get_Teacher_report_By_TEACHER_REPORT_ID);
if (_Teacher_report != null)
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Teacher_report_Execution)
{
_Stop_Delete_Teacher_report_Execution = false;
return;
}
_AppContext.Delete_Teacher_report(i_Params_Delete_Teacher_report.TEACHER_REPORT_ID);
oScope.Complete();
}
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Teacher_report");}
}
public void Delete_User(Params_Delete_User i_Params_Delete_User)
{
Params_Get_User_By_USER_ID oParams_Get_User_By_USER_ID = new Params_Get_User_By_USER_ID();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_User");}
#region Body Section.
try
{
oParams_Get_User_By_USER_ID.USER_ID = i_Params_Delete_User.USER_ID;
_User = Get_User_By_USER_ID_Adv(oParams_Get_User_By_USER_ID);
if (_User != null)
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_User_Execution)
{
_Stop_Delete_User_Execution = false;
return;
}
_AppContext.Delete_User(i_Params_Delete_User.USER_ID);
oScope.Complete();
}
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_User");}
}
public void Delete_Answer_By_OWNER_ID(Params_Delete_Answer_By_OWNER_ID i_Params_Delete_Answer_By_OWNER_ID)
{
Params_Get_Answer_By_OWNER_ID oParams_Get_Answer_By_OWNER_ID = new Params_Get_Answer_By_OWNER_ID();
List<Answer> _List_Answer = new List<Answer>();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Answer_By_OWNER_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Answer_Execution)
{
_Stop_Delete_Answer_Execution = false;
return;
}
_AppContext.Delete_Answer_By_OWNER_ID(i_Params_Delete_Answer_By_OWNER_ID.OWNER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Answer_By_OWNER_ID");}
}
public void Delete_Answer_By_QUESTION_ID(Params_Delete_Answer_By_QUESTION_ID i_Params_Delete_Answer_By_QUESTION_ID)
{
Params_Get_Answer_By_QUESTION_ID oParams_Get_Answer_By_QUESTION_ID = new Params_Get_Answer_By_QUESTION_ID();
List<Answer> _List_Answer = new List<Answer>();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Answer_By_QUESTION_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Answer_Execution)
{
_Stop_Delete_Answer_Execution = false;
return;
}
_AppContext.Delete_Answer_By_QUESTION_ID(i_Params_Delete_Answer_By_QUESTION_ID.QUESTION_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Answer_By_QUESTION_ID");}
}
public void Delete_Answer_By_TEACHER_ID(Params_Delete_Answer_By_TEACHER_ID i_Params_Delete_Answer_By_TEACHER_ID)
{
Params_Get_Answer_By_TEACHER_ID oParams_Get_Answer_By_TEACHER_ID = new Params_Get_Answer_By_TEACHER_ID();
List<Answer> _List_Answer = new List<Answer>();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Answer_By_TEACHER_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Answer_Execution)
{
_Stop_Delete_Answer_Execution = false;
return;
}
_AppContext.Delete_Answer_By_TEACHER_ID(i_Params_Delete_Answer_By_TEACHER_ID.TEACHER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Answer_By_TEACHER_ID");}
}
public void Delete_Answer_report_By_OWNER_ID(Params_Delete_Answer_report_By_OWNER_ID i_Params_Delete_Answer_report_By_OWNER_ID)
{
Params_Get_Answer_report_By_OWNER_ID oParams_Get_Answer_report_By_OWNER_ID = new Params_Get_Answer_report_By_OWNER_ID();
List<Answer_report> _List_Answer_report = new List<Answer_report>();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Answer_report_By_OWNER_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Answer_report_Execution)
{
_Stop_Delete_Answer_report_Execution = false;
return;
}
_AppContext.Delete_Answer_report_By_OWNER_ID(i_Params_Delete_Answer_report_By_OWNER_ID.OWNER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Answer_report_By_OWNER_ID");}
}
public void Delete_Answer_report_By_TEACHER_ID(Params_Delete_Answer_report_By_TEACHER_ID i_Params_Delete_Answer_report_By_TEACHER_ID)
{
Params_Get_Answer_report_By_TEACHER_ID oParams_Get_Answer_report_By_TEACHER_ID = new Params_Get_Answer_report_By_TEACHER_ID();
List<Answer_report> _List_Answer_report = new List<Answer_report>();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Answer_report_By_TEACHER_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Answer_report_Execution)
{
_Stop_Delete_Answer_report_Execution = false;
return;
}
_AppContext.Delete_Answer_report_By_TEACHER_ID(i_Params_Delete_Answer_report_By_TEACHER_ID.TEACHER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Answer_report_By_TEACHER_ID");}
}
public void Delete_Answer_report_By_STUDENT_ID(Params_Delete_Answer_report_By_STUDENT_ID i_Params_Delete_Answer_report_By_STUDENT_ID)
{
Params_Get_Answer_report_By_STUDENT_ID oParams_Get_Answer_report_By_STUDENT_ID = new Params_Get_Answer_report_By_STUDENT_ID();
List<Answer_report> _List_Answer_report = new List<Answer_report>();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Answer_report_By_STUDENT_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Answer_report_Execution)
{
_Stop_Delete_Answer_report_Execution = false;
return;
}
_AppContext.Delete_Answer_report_By_STUDENT_ID(i_Params_Delete_Answer_report_By_STUDENT_ID.STUDENT_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Answer_report_By_STUDENT_ID");}
}
public void Delete_Answer_report_By_ANSWER_ID(Params_Delete_Answer_report_By_ANSWER_ID i_Params_Delete_Answer_report_By_ANSWER_ID)
{
Params_Get_Answer_report_By_ANSWER_ID oParams_Get_Answer_report_By_ANSWER_ID = new Params_Get_Answer_report_By_ANSWER_ID();
List<Answer_report> _List_Answer_report = new List<Answer_report>();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Answer_report_By_ANSWER_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Answer_report_Execution)
{
_Stop_Delete_Answer_report_Execution = false;
return;
}
_AppContext.Delete_Answer_report_By_ANSWER_ID(i_Params_Delete_Answer_report_By_ANSWER_ID.ANSWER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Answer_report_By_ANSWER_ID");}
}
public void Delete_Appreciate_By_OWNER_ID(Params_Delete_Appreciate_By_OWNER_ID i_Params_Delete_Appreciate_By_OWNER_ID)
{
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Appreciate_By_OWNER_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Appreciate_Execution)
{
_Stop_Delete_Appreciate_Execution = false;
return;
}
_AppContext.Delete_Appreciate_By_OWNER_ID(i_Params_Delete_Appreciate_By_OWNER_ID.OWNER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Appreciate_By_OWNER_ID");}
}
public void Delete_Appreciate_By_ARTICLE_ID(Params_Delete_Appreciate_By_ARTICLE_ID i_Params_Delete_Appreciate_By_ARTICLE_ID)
{
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Appreciate_By_ARTICLE_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Appreciate_Execution)
{
_Stop_Delete_Appreciate_Execution = false;
return;
}
_AppContext.Delete_Appreciate_By_ARTICLE_ID(i_Params_Delete_Appreciate_By_ARTICLE_ID.ARTICLE_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Appreciate_By_ARTICLE_ID");}
}
public void Delete_Appreciate_By_STUDENT_ID(Params_Delete_Appreciate_By_STUDENT_ID i_Params_Delete_Appreciate_By_STUDENT_ID)
{
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Appreciate_By_STUDENT_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Appreciate_Execution)
{
_Stop_Delete_Appreciate_Execution = false;
return;
}
_AppContext.Delete_Appreciate_By_STUDENT_ID(i_Params_Delete_Appreciate_By_STUDENT_ID.STUDENT_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Appreciate_By_STUDENT_ID");}
}
public void Delete_Article_By_OWNER_ID(Params_Delete_Article_By_OWNER_ID i_Params_Delete_Article_By_OWNER_ID)
{
Params_Get_Article_By_OWNER_ID oParams_Get_Article_By_OWNER_ID = new Params_Get_Article_By_OWNER_ID();
List<Article> _List_Article = new List<Article>();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Article_By_OWNER_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Article_Execution)
{
_Stop_Delete_Article_Execution = false;
return;
}
_AppContext.Delete_Article_By_OWNER_ID(i_Params_Delete_Article_By_OWNER_ID.OWNER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Article_By_OWNER_ID");}
}
public void Delete_Article_By_TEACHER_ID(Params_Delete_Article_By_TEACHER_ID i_Params_Delete_Article_By_TEACHER_ID)
{
Params_Get_Article_By_TEACHER_ID oParams_Get_Article_By_TEACHER_ID = new Params_Get_Article_By_TEACHER_ID();
List<Article> _List_Article = new List<Article>();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Article_By_TEACHER_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Article_Execution)
{
_Stop_Delete_Article_Execution = false;
return;
}
_AppContext.Delete_Article_By_TEACHER_ID(i_Params_Delete_Article_By_TEACHER_ID.TEACHER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Article_By_TEACHER_ID");}
}
public void Delete_Article_By_CATEGORY_ID(Params_Delete_Article_By_CATEGORY_ID i_Params_Delete_Article_By_CATEGORY_ID)
{
Params_Get_Article_By_CATEGORY_ID oParams_Get_Article_By_CATEGORY_ID = new Params_Get_Article_By_CATEGORY_ID();
List<Article> _List_Article = new List<Article>();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Article_By_CATEGORY_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Article_Execution)
{
_Stop_Delete_Article_Execution = false;
return;
}
_AppContext.Delete_Article_By_CATEGORY_ID(i_Params_Delete_Article_By_CATEGORY_ID.CATEGORY_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Article_By_CATEGORY_ID");}
}
public void Delete_Category_By_OWNER_ID(Params_Delete_Category_By_OWNER_ID i_Params_Delete_Category_By_OWNER_ID)
{
Params_Get_Category_By_OWNER_ID oParams_Get_Category_By_OWNER_ID = new Params_Get_Category_By_OWNER_ID();
List<Category> _List_Category = new List<Category>();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Category_By_OWNER_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Category_Execution)
{
_Stop_Delete_Category_Execution = false;
return;
}
_AppContext.Delete_Category_By_OWNER_ID(i_Params_Delete_Category_By_OWNER_ID.OWNER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Category_By_OWNER_ID");}
}
public void Delete_Evaluation_By_OWNER_ID(Params_Delete_Evaluation_By_OWNER_ID i_Params_Delete_Evaluation_By_OWNER_ID)
{
Params_Get_Evaluation_By_OWNER_ID oParams_Get_Evaluation_By_OWNER_ID = new Params_Get_Evaluation_By_OWNER_ID();
List<Evaluation> _List_Evaluation = new List<Evaluation>();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Evaluation_By_OWNER_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Evaluation_Execution)
{
_Stop_Delete_Evaluation_Execution = false;
return;
}
_AppContext.Delete_Evaluation_By_OWNER_ID(i_Params_Delete_Evaluation_By_OWNER_ID.OWNER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Evaluation_By_OWNER_ID");}
}
public void Delete_Evaluation_By_STUDENT_ID(Params_Delete_Evaluation_By_STUDENT_ID i_Params_Delete_Evaluation_By_STUDENT_ID)
{
Params_Get_Evaluation_By_STUDENT_ID oParams_Get_Evaluation_By_STUDENT_ID = new Params_Get_Evaluation_By_STUDENT_ID();
List<Evaluation> _List_Evaluation = new List<Evaluation>();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Evaluation_By_STUDENT_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Evaluation_Execution)
{
_Stop_Delete_Evaluation_Execution = false;
return;
}
_AppContext.Delete_Evaluation_By_STUDENT_ID(i_Params_Delete_Evaluation_By_STUDENT_ID.STUDENT_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Evaluation_By_STUDENT_ID");}
}
public void Delete_Evaluation_By_ANSWER_ID(Params_Delete_Evaluation_By_ANSWER_ID i_Params_Delete_Evaluation_By_ANSWER_ID)
{
Params_Get_Evaluation_By_ANSWER_ID oParams_Get_Evaluation_By_ANSWER_ID = new Params_Get_Evaluation_By_ANSWER_ID();
List<Evaluation> _List_Evaluation = new List<Evaluation>();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Evaluation_By_ANSWER_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Evaluation_Execution)
{
_Stop_Delete_Evaluation_Execution = false;
return;
}
_AppContext.Delete_Evaluation_By_ANSWER_ID(i_Params_Delete_Evaluation_By_ANSWER_ID.ANSWER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Evaluation_By_ANSWER_ID");}
}
public void Delete_Favorite_category_By_STUDENT_ID(Params_Delete_Favorite_category_By_STUDENT_ID i_Params_Delete_Favorite_category_By_STUDENT_ID)
{
Params_Get_Favorite_category_By_STUDENT_ID oParams_Get_Favorite_category_By_STUDENT_ID = new Params_Get_Favorite_category_By_STUDENT_ID();
List<Favorite_category> _List_Favorite_category = new List<Favorite_category>();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Favorite_category_By_STUDENT_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Favorite_category_Execution)
{
_Stop_Delete_Favorite_category_Execution = false;
return;
}
_AppContext.Delete_Favorite_category_By_STUDENT_ID(i_Params_Delete_Favorite_category_By_STUDENT_ID.STUDENT_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Favorite_category_By_STUDENT_ID");}
}
public void Delete_Favorite_category_By_CATEGORY_ID(Params_Delete_Favorite_category_By_CATEGORY_ID i_Params_Delete_Favorite_category_By_CATEGORY_ID)
{
Params_Get_Favorite_category_By_CATEGORY_ID oParams_Get_Favorite_category_By_CATEGORY_ID = new Params_Get_Favorite_category_By_CATEGORY_ID();
List<Favorite_category> _List_Favorite_category = new List<Favorite_category>();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Favorite_category_By_CATEGORY_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Favorite_category_Execution)
{
_Stop_Delete_Favorite_category_Execution = false;
return;
}
_AppContext.Delete_Favorite_category_By_CATEGORY_ID(i_Params_Delete_Favorite_category_By_CATEGORY_ID.CATEGORY_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Favorite_category_By_CATEGORY_ID");}
}
public void Delete_Favorite_category_By_OWNER_ID(Params_Delete_Favorite_category_By_OWNER_ID i_Params_Delete_Favorite_category_By_OWNER_ID)
{
Params_Get_Favorite_category_By_OWNER_ID oParams_Get_Favorite_category_By_OWNER_ID = new Params_Get_Favorite_category_By_OWNER_ID();
List<Favorite_category> _List_Favorite_category = new List<Favorite_category>();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Favorite_category_By_OWNER_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Favorite_category_Execution)
{
_Stop_Delete_Favorite_category_Execution = false;
return;
}
_AppContext.Delete_Favorite_category_By_OWNER_ID(i_Params_Delete_Favorite_category_By_OWNER_ID.OWNER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Favorite_category_By_OWNER_ID");}
}
public void Delete_Favorite_teacher_By_TEACHER_ID(Params_Delete_Favorite_teacher_By_TEACHER_ID i_Params_Delete_Favorite_teacher_By_TEACHER_ID)
{
Params_Get_Favorite_teacher_By_TEACHER_ID oParams_Get_Favorite_teacher_By_TEACHER_ID = new Params_Get_Favorite_teacher_By_TEACHER_ID();
List<Favorite_teacher> _List_Favorite_teacher = new List<Favorite_teacher>();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Favorite_teacher_By_TEACHER_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Favorite_teacher_Execution)
{
_Stop_Delete_Favorite_teacher_Execution = false;
return;
}
_AppContext.Delete_Favorite_teacher_By_TEACHER_ID(i_Params_Delete_Favorite_teacher_By_TEACHER_ID.TEACHER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Favorite_teacher_By_TEACHER_ID");}
}
public void Delete_Favorite_teacher_By_STUDENT_ID(Params_Delete_Favorite_teacher_By_STUDENT_ID i_Params_Delete_Favorite_teacher_By_STUDENT_ID)
{
Params_Get_Favorite_teacher_By_STUDENT_ID oParams_Get_Favorite_teacher_By_STUDENT_ID = new Params_Get_Favorite_teacher_By_STUDENT_ID();
List<Favorite_teacher> _List_Favorite_teacher = new List<Favorite_teacher>();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Favorite_teacher_By_STUDENT_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Favorite_teacher_Execution)
{
_Stop_Delete_Favorite_teacher_Execution = false;
return;
}
_AppContext.Delete_Favorite_teacher_By_STUDENT_ID(i_Params_Delete_Favorite_teacher_By_STUDENT_ID.STUDENT_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Favorite_teacher_By_STUDENT_ID");}
}
public void Delete_Favorite_teacher_By_OWNER_ID(Params_Delete_Favorite_teacher_By_OWNER_ID i_Params_Delete_Favorite_teacher_By_OWNER_ID)
{
Params_Get_Favorite_teacher_By_OWNER_ID oParams_Get_Favorite_teacher_By_OWNER_ID = new Params_Get_Favorite_teacher_By_OWNER_ID();
List<Favorite_teacher> _List_Favorite_teacher = new List<Favorite_teacher>();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Favorite_teacher_By_OWNER_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Favorite_teacher_Execution)
{
_Stop_Delete_Favorite_teacher_Execution = false;
return;
}
_AppContext.Delete_Favorite_teacher_By_OWNER_ID(i_Params_Delete_Favorite_teacher_By_OWNER_ID.OWNER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Favorite_teacher_By_OWNER_ID");}
}
public void Delete_Mark_question_By_OWNER_ID(Params_Delete_Mark_question_By_OWNER_ID i_Params_Delete_Mark_question_By_OWNER_ID)
{
Params_Get_Mark_question_By_OWNER_ID oParams_Get_Mark_question_By_OWNER_ID = new Params_Get_Mark_question_By_OWNER_ID();
List<Mark_question> _List_Mark_question = new List<Mark_question>();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Mark_question_By_OWNER_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Mark_question_Execution)
{
_Stop_Delete_Mark_question_Execution = false;
return;
}
_AppContext.Delete_Mark_question_By_OWNER_ID(i_Params_Delete_Mark_question_By_OWNER_ID.OWNER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Mark_question_By_OWNER_ID");}
}
public void Delete_Mark_question_By_QUESTION_ID(Params_Delete_Mark_question_By_QUESTION_ID i_Params_Delete_Mark_question_By_QUESTION_ID)
{
Params_Get_Mark_question_By_QUESTION_ID oParams_Get_Mark_question_By_QUESTION_ID = new Params_Get_Mark_question_By_QUESTION_ID();
List<Mark_question> _List_Mark_question = new List<Mark_question>();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Mark_question_By_QUESTION_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Mark_question_Execution)
{
_Stop_Delete_Mark_question_Execution = false;
return;
}
_AppContext.Delete_Mark_question_By_QUESTION_ID(i_Params_Delete_Mark_question_By_QUESTION_ID.QUESTION_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Mark_question_By_QUESTION_ID");}
}
public void Delete_Mark_question_By_STUDENT_ID(Params_Delete_Mark_question_By_STUDENT_ID i_Params_Delete_Mark_question_By_STUDENT_ID)
{
Params_Get_Mark_question_By_STUDENT_ID oParams_Get_Mark_question_By_STUDENT_ID = new Params_Get_Mark_question_By_STUDENT_ID();
List<Mark_question> _List_Mark_question = new List<Mark_question>();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Mark_question_By_STUDENT_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Mark_question_Execution)
{
_Stop_Delete_Mark_question_Execution = false;
return;
}
_AppContext.Delete_Mark_question_By_STUDENT_ID(i_Params_Delete_Mark_question_By_STUDENT_ID.STUDENT_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Mark_question_By_STUDENT_ID");}
}
public void Delete_Notification_By_OWNER_ID(Params_Delete_Notification_By_OWNER_ID i_Params_Delete_Notification_By_OWNER_ID)
{
Params_Get_Notification_By_OWNER_ID oParams_Get_Notification_By_OWNER_ID = new Params_Get_Notification_By_OWNER_ID();
List<Notification> _List_Notification = new List<Notification>();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Notification_By_OWNER_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Notification_Execution)
{
_Stop_Delete_Notification_Execution = false;
return;
}
_AppContext.Delete_Notification_By_OWNER_ID(i_Params_Delete_Notification_By_OWNER_ID.OWNER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Notification_By_OWNER_ID");}
}
public void Delete_Notification_By_USER_ID(Params_Delete_Notification_By_USER_ID i_Params_Delete_Notification_By_USER_ID)
{
Params_Get_Notification_By_USER_ID oParams_Get_Notification_By_USER_ID = new Params_Get_Notification_By_USER_ID();
List<Notification> _List_Notification = new List<Notification>();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Notification_By_USER_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Notification_Execution)
{
_Stop_Delete_Notification_Execution = false;
return;
}
_AppContext.Delete_Notification_By_USER_ID(i_Params_Delete_Notification_By_USER_ID.USER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Notification_By_USER_ID");}
}
public void Delete_Notification_By_QUESTION_ID(Params_Delete_Notification_By_QUESTION_ID i_Params_Delete_Notification_By_QUESTION_ID)
{
Params_Get_Notification_By_QUESTION_ID oParams_Get_Notification_By_QUESTION_ID = new Params_Get_Notification_By_QUESTION_ID();
List<Notification> _List_Notification = new List<Notification>();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Notification_By_QUESTION_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Notification_Execution)
{
_Stop_Delete_Notification_Execution = false;
return;
}
_AppContext.Delete_Notification_By_QUESTION_ID(i_Params_Delete_Notification_By_QUESTION_ID.QUESTION_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Notification_By_QUESTION_ID");}
}
public void Delete_Notification_By_ANSWER_ID(Params_Delete_Notification_By_ANSWER_ID i_Params_Delete_Notification_By_ANSWER_ID)
{
Params_Get_Notification_By_ANSWER_ID oParams_Get_Notification_By_ANSWER_ID = new Params_Get_Notification_By_ANSWER_ID();
List<Notification> _List_Notification = new List<Notification>();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Notification_By_ANSWER_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Notification_Execution)
{
_Stop_Delete_Notification_Execution = false;
return;
}
_AppContext.Delete_Notification_By_ANSWER_ID(i_Params_Delete_Notification_By_ANSWER_ID.ANSWER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Notification_By_ANSWER_ID");}
}
public void Delete_Question_By_OWNER_ID(Params_Delete_Question_By_OWNER_ID i_Params_Delete_Question_By_OWNER_ID)
{
Params_Get_Question_By_OWNER_ID oParams_Get_Question_By_OWNER_ID = new Params_Get_Question_By_OWNER_ID();
List<Question> _List_Question = new List<Question>();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Question_By_OWNER_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Question_Execution)
{
_Stop_Delete_Question_Execution = false;
return;
}
_AppContext.Delete_Question_By_OWNER_ID(i_Params_Delete_Question_By_OWNER_ID.OWNER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Question_By_OWNER_ID");}
}
public void Delete_Question_By_STUDENT_ID(Params_Delete_Question_By_STUDENT_ID i_Params_Delete_Question_By_STUDENT_ID)
{
Params_Get_Question_By_STUDENT_ID oParams_Get_Question_By_STUDENT_ID = new Params_Get_Question_By_STUDENT_ID();
List<Question> _List_Question = new List<Question>();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Question_By_STUDENT_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Question_Execution)
{
_Stop_Delete_Question_Execution = false;
return;
}
_AppContext.Delete_Question_By_STUDENT_ID(i_Params_Delete_Question_By_STUDENT_ID.STUDENT_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Question_By_STUDENT_ID");}
}
public void Delete_Question_By_CATEGORY_ID(Params_Delete_Question_By_CATEGORY_ID i_Params_Delete_Question_By_CATEGORY_ID)
{
Params_Get_Question_By_CATEGORY_ID oParams_Get_Question_By_CATEGORY_ID = new Params_Get_Question_By_CATEGORY_ID();
List<Question> _List_Question = new List<Question>();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Question_By_CATEGORY_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Question_Execution)
{
_Stop_Delete_Question_Execution = false;
return;
}
_AppContext.Delete_Question_By_CATEGORY_ID(i_Params_Delete_Question_By_CATEGORY_ID.CATEGORY_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Question_By_CATEGORY_ID");}
}
public void Delete_Question_By_TEACHER_ID(Params_Delete_Question_By_TEACHER_ID i_Params_Delete_Question_By_TEACHER_ID)
{
Params_Get_Question_By_TEACHER_ID oParams_Get_Question_By_TEACHER_ID = new Params_Get_Question_By_TEACHER_ID();
List<Question> _List_Question = new List<Question>();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Question_By_TEACHER_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Question_Execution)
{
_Stop_Delete_Question_Execution = false;
return;
}
_AppContext.Delete_Question_By_TEACHER_ID(i_Params_Delete_Question_By_TEACHER_ID.TEACHER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Question_By_TEACHER_ID");}
}
public void Delete_Question_report_By_OWNER_ID(Params_Delete_Question_report_By_OWNER_ID i_Params_Delete_Question_report_By_OWNER_ID)
{
Params_Get_Question_report_By_OWNER_ID oParams_Get_Question_report_By_OWNER_ID = new Params_Get_Question_report_By_OWNER_ID();
List<Question_report> _List_Question_report = new List<Question_report>();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Question_report_By_OWNER_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Question_report_Execution)
{
_Stop_Delete_Question_report_Execution = false;
return;
}
_AppContext.Delete_Question_report_By_OWNER_ID(i_Params_Delete_Question_report_By_OWNER_ID.OWNER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Question_report_By_OWNER_ID");}
}
public void Delete_Question_report_By_STUDENT_ID(Params_Delete_Question_report_By_STUDENT_ID i_Params_Delete_Question_report_By_STUDENT_ID)
{
Params_Get_Question_report_By_STUDENT_ID oParams_Get_Question_report_By_STUDENT_ID = new Params_Get_Question_report_By_STUDENT_ID();
List<Question_report> _List_Question_report = new List<Question_report>();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Question_report_By_STUDENT_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Question_report_Execution)
{
_Stop_Delete_Question_report_Execution = false;
return;
}
_AppContext.Delete_Question_report_By_STUDENT_ID(i_Params_Delete_Question_report_By_STUDENT_ID.STUDENT_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Question_report_By_STUDENT_ID");}
}
public void Delete_Question_report_By_TEACHER_ID(Params_Delete_Question_report_By_TEACHER_ID i_Params_Delete_Question_report_By_TEACHER_ID)
{
Params_Get_Question_report_By_TEACHER_ID oParams_Get_Question_report_By_TEACHER_ID = new Params_Get_Question_report_By_TEACHER_ID();
List<Question_report> _List_Question_report = new List<Question_report>();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Question_report_By_TEACHER_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Question_report_Execution)
{
_Stop_Delete_Question_report_Execution = false;
return;
}
_AppContext.Delete_Question_report_By_TEACHER_ID(i_Params_Delete_Question_report_By_TEACHER_ID.TEACHER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Question_report_By_TEACHER_ID");}
}
public void Delete_Question_report_By_QUESTION_ID(Params_Delete_Question_report_By_QUESTION_ID i_Params_Delete_Question_report_By_QUESTION_ID)
{
Params_Get_Question_report_By_QUESTION_ID oParams_Get_Question_report_By_QUESTION_ID = new Params_Get_Question_report_By_QUESTION_ID();
List<Question_report> _List_Question_report = new List<Question_report>();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Question_report_By_QUESTION_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Question_report_Execution)
{
_Stop_Delete_Question_report_Execution = false;
return;
}
_AppContext.Delete_Question_report_By_QUESTION_ID(i_Params_Delete_Question_report_By_QUESTION_ID.QUESTION_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Question_report_By_QUESTION_ID");}
}
public void Delete_Question_token_By_PART(Params_Delete_Question_token_By_PART i_Params_Delete_Question_token_By_PART)
{
Params_Get_Question_token_By_PART oParams_Get_Question_token_By_PART = new Params_Get_Question_token_By_PART();
List<Question_token> _List_Question_token = new List<Question_token>();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Question_token_By_PART");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Question_token_Execution)
{
_Stop_Delete_Question_token_Execution = false;
return;
}
_AppContext.Delete_Question_token_By_PART(i_Params_Delete_Question_token_By_PART.PART);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Question_token_By_PART");}
}
public void Delete_Question_token_By_OWNER_ID(Params_Delete_Question_token_By_OWNER_ID i_Params_Delete_Question_token_By_OWNER_ID)
{
Params_Get_Question_token_By_OWNER_ID oParams_Get_Question_token_By_OWNER_ID = new Params_Get_Question_token_By_OWNER_ID();
List<Question_token> _List_Question_token = new List<Question_token>();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Question_token_By_OWNER_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Question_token_Execution)
{
_Stop_Delete_Question_token_Execution = false;
return;
}
_AppContext.Delete_Question_token_By_OWNER_ID(i_Params_Delete_Question_token_By_OWNER_ID.OWNER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Question_token_By_OWNER_ID");}
}
public void Delete_Question_token_By_QUESTION_ID(Params_Delete_Question_token_By_QUESTION_ID i_Params_Delete_Question_token_By_QUESTION_ID)
{
Params_Get_Question_token_By_QUESTION_ID oParams_Get_Question_token_By_QUESTION_ID = new Params_Get_Question_token_By_QUESTION_ID();
List<Question_token> _List_Question_token = new List<Question_token>();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Question_token_By_QUESTION_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Question_token_Execution)
{
_Stop_Delete_Question_token_Execution = false;
return;
}
_AppContext.Delete_Question_token_By_QUESTION_ID(i_Params_Delete_Question_token_By_QUESTION_ID.QUESTION_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Question_token_By_QUESTION_ID");}
}
public void Delete_Report_article_By_OWNER_ID(Params_Delete_Report_article_By_OWNER_ID i_Params_Delete_Report_article_By_OWNER_ID)
{
Params_Get_Report_article_By_OWNER_ID oParams_Get_Report_article_By_OWNER_ID = new Params_Get_Report_article_By_OWNER_ID();
List<Report_article> _List_Report_article = new List<Report_article>();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Report_article_By_OWNER_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Report_article_Execution)
{
_Stop_Delete_Report_article_Execution = false;
return;
}
_AppContext.Delete_Report_article_By_OWNER_ID(i_Params_Delete_Report_article_By_OWNER_ID.OWNER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Report_article_By_OWNER_ID");}
}
public void Delete_Report_article_By_ARTICLE_ID(Params_Delete_Report_article_By_ARTICLE_ID i_Params_Delete_Report_article_By_ARTICLE_ID)
{
Params_Get_Report_article_By_ARTICLE_ID oParams_Get_Report_article_By_ARTICLE_ID = new Params_Get_Report_article_By_ARTICLE_ID();
List<Report_article> _List_Report_article = new List<Report_article>();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Report_article_By_ARTICLE_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Report_article_Execution)
{
_Stop_Delete_Report_article_Execution = false;
return;
}
_AppContext.Delete_Report_article_By_ARTICLE_ID(i_Params_Delete_Report_article_By_ARTICLE_ID.ARTICLE_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Report_article_By_ARTICLE_ID");}
}
public void Delete_Report_article_By_STUDENT_ID(Params_Delete_Report_article_By_STUDENT_ID i_Params_Delete_Report_article_By_STUDENT_ID)
{
Params_Get_Report_article_By_STUDENT_ID oParams_Get_Report_article_By_STUDENT_ID = new Params_Get_Report_article_By_STUDENT_ID();
List<Report_article> _List_Report_article = new List<Report_article>();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Report_article_By_STUDENT_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Report_article_Execution)
{
_Stop_Delete_Report_article_Execution = false;
return;
}
_AppContext.Delete_Report_article_By_STUDENT_ID(i_Params_Delete_Report_article_By_STUDENT_ID.STUDENT_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Report_article_By_STUDENT_ID");}
}
public void Delete_Student_By_OWNER_ID(Params_Delete_Student_By_OWNER_ID i_Params_Delete_Student_By_OWNER_ID)
{
Params_Get_Student_By_OWNER_ID oParams_Get_Student_By_OWNER_ID = new Params_Get_Student_By_OWNER_ID();
List<Student> _List_Student = new List<Student>();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Student_By_OWNER_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Student_Execution)
{
_Stop_Delete_Student_Execution = false;
return;
}
_AppContext.Delete_Student_By_OWNER_ID(i_Params_Delete_Student_By_OWNER_ID.OWNER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Student_By_OWNER_ID");}
}
public void Delete_Student_By_USER_ID(Params_Delete_Student_By_USER_ID i_Params_Delete_Student_By_USER_ID)
{
Params_Get_Student_By_USER_ID oParams_Get_Student_By_USER_ID = new Params_Get_Student_By_USER_ID();
List<Student> _List_Student = new List<Student>();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Student_By_USER_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Student_Execution)
{
_Stop_Delete_Student_Execution = false;
return;
}
_AppContext.Delete_Student_By_USER_ID(i_Params_Delete_Student_By_USER_ID.USER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Student_By_USER_ID");}
}
public void Delete_Student_report_By_OWNER_ID(Params_Delete_Student_report_By_OWNER_ID i_Params_Delete_Student_report_By_OWNER_ID)
{
Params_Get_Student_report_By_OWNER_ID oParams_Get_Student_report_By_OWNER_ID = new Params_Get_Student_report_By_OWNER_ID();
List<Student_report> _List_Student_report = new List<Student_report>();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Student_report_By_OWNER_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Student_report_Execution)
{
_Stop_Delete_Student_report_Execution = false;
return;
}
_AppContext.Delete_Student_report_By_OWNER_ID(i_Params_Delete_Student_report_By_OWNER_ID.OWNER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Student_report_By_OWNER_ID");}
}
public void Delete_Student_report_By_REPORTED_BY_STUDENT_ID(Params_Delete_Student_report_By_REPORTED_BY_STUDENT_ID i_Params_Delete_Student_report_By_REPORTED_BY_STUDENT_ID)
{
Params_Get_Student_report_By_REPORTED_BY_STUDENT_ID oParams_Get_Student_report_By_REPORTED_BY_STUDENT_ID = new Params_Get_Student_report_By_REPORTED_BY_STUDENT_ID();
List<Student_report> _List_Student_report = new List<Student_report>();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Student_report_By_REPORTED_BY_STUDENT_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Student_report_Execution)
{
_Stop_Delete_Student_report_Execution = false;
return;
}
_AppContext.Delete_Student_report_By_REPORTED_BY_STUDENT_ID(i_Params_Delete_Student_report_By_REPORTED_BY_STUDENT_ID.REPORTED_BY_STUDENT_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Student_report_By_REPORTED_BY_STUDENT_ID");}
}
public void Delete_Student_report_By_REPORTED_STUDENT_ID(Params_Delete_Student_report_By_REPORTED_STUDENT_ID i_Params_Delete_Student_report_By_REPORTED_STUDENT_ID)
{
Params_Get_Student_report_By_REPORTED_STUDENT_ID oParams_Get_Student_report_By_REPORTED_STUDENT_ID = new Params_Get_Student_report_By_REPORTED_STUDENT_ID();
List<Student_report> _List_Student_report = new List<Student_report>();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Student_report_By_REPORTED_STUDENT_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Student_report_Execution)
{
_Stop_Delete_Student_report_Execution = false;
return;
}
_AppContext.Delete_Student_report_By_REPORTED_STUDENT_ID(i_Params_Delete_Student_report_By_REPORTED_STUDENT_ID.REPORTED_STUDENT_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Student_report_By_REPORTED_STUDENT_ID");}
}
public void Delete_Teacher_By_OWNER_ID(Params_Delete_Teacher_By_OWNER_ID i_Params_Delete_Teacher_By_OWNER_ID)
{
Params_Get_Teacher_By_OWNER_ID oParams_Get_Teacher_By_OWNER_ID = new Params_Get_Teacher_By_OWNER_ID();
List<Teacher> _List_Teacher = new List<Teacher>();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Teacher_By_OWNER_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Teacher_Execution)
{
_Stop_Delete_Teacher_Execution = false;
return;
}
_AppContext.Delete_Teacher_By_OWNER_ID(i_Params_Delete_Teacher_By_OWNER_ID.OWNER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Teacher_By_OWNER_ID");}
}
public void Delete_Teacher_By_USER_ID(Params_Delete_Teacher_By_USER_ID i_Params_Delete_Teacher_By_USER_ID)
{
Params_Get_Teacher_By_USER_ID oParams_Get_Teacher_By_USER_ID = new Params_Get_Teacher_By_USER_ID();
List<Teacher> _List_Teacher = new List<Teacher>();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Teacher_By_USER_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Teacher_Execution)
{
_Stop_Delete_Teacher_Execution = false;
return;
}
_AppContext.Delete_Teacher_By_USER_ID(i_Params_Delete_Teacher_By_USER_ID.USER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Teacher_By_USER_ID");}
}
public void Delete_Teacher_category_By_OWNER_ID(Params_Delete_Teacher_category_By_OWNER_ID i_Params_Delete_Teacher_category_By_OWNER_ID)
{
Params_Get_Teacher_category_By_OWNER_ID oParams_Get_Teacher_category_By_OWNER_ID = new Params_Get_Teacher_category_By_OWNER_ID();
List<Teacher_category> _List_Teacher_category = new List<Teacher_category>();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Teacher_category_By_OWNER_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Teacher_category_Execution)
{
_Stop_Delete_Teacher_category_Execution = false;
return;
}
_AppContext.Delete_Teacher_category_By_OWNER_ID(i_Params_Delete_Teacher_category_By_OWNER_ID.OWNER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Teacher_category_By_OWNER_ID");}
}
public void Delete_Teacher_category_By_TEACHER_ID(Params_Delete_Teacher_category_By_TEACHER_ID i_Params_Delete_Teacher_category_By_TEACHER_ID)
{
Params_Get_Teacher_category_By_TEACHER_ID oParams_Get_Teacher_category_By_TEACHER_ID = new Params_Get_Teacher_category_By_TEACHER_ID();
List<Teacher_category> _List_Teacher_category = new List<Teacher_category>();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Teacher_category_By_TEACHER_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Teacher_category_Execution)
{
_Stop_Delete_Teacher_category_Execution = false;
return;
}
_AppContext.Delete_Teacher_category_By_TEACHER_ID(i_Params_Delete_Teacher_category_By_TEACHER_ID.TEACHER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Teacher_category_By_TEACHER_ID");}
}
public void Delete_Teacher_category_By_CATEGORY_ID(Params_Delete_Teacher_category_By_CATEGORY_ID i_Params_Delete_Teacher_category_By_CATEGORY_ID)
{
Params_Get_Teacher_category_By_CATEGORY_ID oParams_Get_Teacher_category_By_CATEGORY_ID = new Params_Get_Teacher_category_By_CATEGORY_ID();
List<Teacher_category> _List_Teacher_category = new List<Teacher_category>();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Teacher_category_By_CATEGORY_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Teacher_category_Execution)
{
_Stop_Delete_Teacher_category_Execution = false;
return;
}
_AppContext.Delete_Teacher_category_By_CATEGORY_ID(i_Params_Delete_Teacher_category_By_CATEGORY_ID.CATEGORY_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Teacher_category_By_CATEGORY_ID");}
}
public void Delete_Teacher_favorite_By_OWNER_ID(Params_Delete_Teacher_favorite_By_OWNER_ID i_Params_Delete_Teacher_favorite_By_OWNER_ID)
{
Params_Get_Teacher_favorite_By_OWNER_ID oParams_Get_Teacher_favorite_By_OWNER_ID = new Params_Get_Teacher_favorite_By_OWNER_ID();
List<Teacher_favorite> _List_Teacher_favorite = new List<Teacher_favorite>();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Teacher_favorite_By_OWNER_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Teacher_favorite_Execution)
{
_Stop_Delete_Teacher_favorite_Execution = false;
return;
}
_AppContext.Delete_Teacher_favorite_By_OWNER_ID(i_Params_Delete_Teacher_favorite_By_OWNER_ID.OWNER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Teacher_favorite_By_OWNER_ID");}
}
public void Delete_Teacher_favorite_By_TEACHER_ID(Params_Delete_Teacher_favorite_By_TEACHER_ID i_Params_Delete_Teacher_favorite_By_TEACHER_ID)
{
Params_Get_Teacher_favorite_By_TEACHER_ID oParams_Get_Teacher_favorite_By_TEACHER_ID = new Params_Get_Teacher_favorite_By_TEACHER_ID();
List<Teacher_favorite> _List_Teacher_favorite = new List<Teacher_favorite>();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Teacher_favorite_By_TEACHER_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Teacher_favorite_Execution)
{
_Stop_Delete_Teacher_favorite_Execution = false;
return;
}
_AppContext.Delete_Teacher_favorite_By_TEACHER_ID(i_Params_Delete_Teacher_favorite_By_TEACHER_ID.TEACHER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Teacher_favorite_By_TEACHER_ID");}
}
public void Delete_Teacher_favorite_By_STUDENT_ID(Params_Delete_Teacher_favorite_By_STUDENT_ID i_Params_Delete_Teacher_favorite_By_STUDENT_ID)
{
Params_Get_Teacher_favorite_By_STUDENT_ID oParams_Get_Teacher_favorite_By_STUDENT_ID = new Params_Get_Teacher_favorite_By_STUDENT_ID();
List<Teacher_favorite> _List_Teacher_favorite = new List<Teacher_favorite>();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Teacher_favorite_By_STUDENT_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Teacher_favorite_Execution)
{
_Stop_Delete_Teacher_favorite_Execution = false;
return;
}
_AppContext.Delete_Teacher_favorite_By_STUDENT_ID(i_Params_Delete_Teacher_favorite_By_STUDENT_ID.STUDENT_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Teacher_favorite_By_STUDENT_ID");}
}
public void Delete_Teacher_rank_By_TEACHER_ID(Params_Delete_Teacher_rank_By_TEACHER_ID i_Params_Delete_Teacher_rank_By_TEACHER_ID)
{
Params_Get_Teacher_rank_By_TEACHER_ID oParams_Get_Teacher_rank_By_TEACHER_ID = new Params_Get_Teacher_rank_By_TEACHER_ID();
List<Teacher_rank> _List_Teacher_rank = new List<Teacher_rank>();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Teacher_rank_By_TEACHER_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Teacher_rank_Execution)
{
_Stop_Delete_Teacher_rank_Execution = false;
return;
}
_AppContext.Delete_Teacher_rank_By_TEACHER_ID(i_Params_Delete_Teacher_rank_By_TEACHER_ID.TEACHER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Teacher_rank_By_TEACHER_ID");}
}
public void Delete_Teacher_rank_By_OWNER_ID(Params_Delete_Teacher_rank_By_OWNER_ID i_Params_Delete_Teacher_rank_By_OWNER_ID)
{
Params_Get_Teacher_rank_By_OWNER_ID oParams_Get_Teacher_rank_By_OWNER_ID = new Params_Get_Teacher_rank_By_OWNER_ID();
List<Teacher_rank> _List_Teacher_rank = new List<Teacher_rank>();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Teacher_rank_By_OWNER_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Teacher_rank_Execution)
{
_Stop_Delete_Teacher_rank_Execution = false;
return;
}
_AppContext.Delete_Teacher_rank_By_OWNER_ID(i_Params_Delete_Teacher_rank_By_OWNER_ID.OWNER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Teacher_rank_By_OWNER_ID");}
}
public void Delete_Teacher_report_By_OWNER_ID(Params_Delete_Teacher_report_By_OWNER_ID i_Params_Delete_Teacher_report_By_OWNER_ID)
{
Params_Get_Teacher_report_By_OWNER_ID oParams_Get_Teacher_report_By_OWNER_ID = new Params_Get_Teacher_report_By_OWNER_ID();
List<Teacher_report> _List_Teacher_report = new List<Teacher_report>();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Teacher_report_By_OWNER_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Teacher_report_Execution)
{
_Stop_Delete_Teacher_report_Execution = false;
return;
}
_AppContext.Delete_Teacher_report_By_OWNER_ID(i_Params_Delete_Teacher_report_By_OWNER_ID.OWNER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Teacher_report_By_OWNER_ID");}
}
public void Delete_Teacher_report_By_TEACHER_ID(Params_Delete_Teacher_report_By_TEACHER_ID i_Params_Delete_Teacher_report_By_TEACHER_ID)
{
Params_Get_Teacher_report_By_TEACHER_ID oParams_Get_Teacher_report_By_TEACHER_ID = new Params_Get_Teacher_report_By_TEACHER_ID();
List<Teacher_report> _List_Teacher_report = new List<Teacher_report>();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Teacher_report_By_TEACHER_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Teacher_report_Execution)
{
_Stop_Delete_Teacher_report_Execution = false;
return;
}
_AppContext.Delete_Teacher_report_By_TEACHER_ID(i_Params_Delete_Teacher_report_By_TEACHER_ID.TEACHER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Teacher_report_By_TEACHER_ID");}
}
public void Delete_Teacher_report_By_STUDENT_ID(Params_Delete_Teacher_report_By_STUDENT_ID i_Params_Delete_Teacher_report_By_STUDENT_ID)
{
Params_Get_Teacher_report_By_STUDENT_ID oParams_Get_Teacher_report_By_STUDENT_ID = new Params_Get_Teacher_report_By_STUDENT_ID();
List<Teacher_report> _List_Teacher_report = new List<Teacher_report>();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Teacher_report_By_STUDENT_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_Teacher_report_Execution)
{
_Stop_Delete_Teacher_report_Execution = false;
return;
}
_AppContext.Delete_Teacher_report_By_STUDENT_ID(i_Params_Delete_Teacher_report_By_STUDENT_ID.STUDENT_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Teacher_report_By_STUDENT_ID");}
}
public void Delete_User_By_OWNER_ID(Params_Delete_User_By_OWNER_ID i_Params_Delete_User_By_OWNER_ID)
{
Params_Get_User_By_OWNER_ID oParams_Get_User_By_OWNER_ID = new Params_Get_User_By_OWNER_ID();
List<User> _List_User = new List<User>();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_User_By_OWNER_ID");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_User_Execution)
{
_Stop_Delete_User_Execution = false;
return;
}
_AppContext.Delete_User_By_OWNER_ID(i_Params_Delete_User_By_OWNER_ID.OWNER_ID);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_User_By_OWNER_ID");}
}
public void Delete_User_By_USERNAME(Params_Delete_User_By_USERNAME i_Params_Delete_User_By_USERNAME)
{
Params_Get_User_By_USERNAME oParams_Get_User_By_USERNAME = new Params_Get_User_By_USERNAME();
List<User> _List_User = new List<User>();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Delete_User_By_USERNAME");}
#region Body Section.
try
{
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Delete_User_Execution)
{
_Stop_Delete_User_Execution = false;
return;
}
_AppContext.Delete_User_By_USERNAME(i_Params_Delete_User_By_USERNAME.USERNAME);
oScope.Complete();
}
}
catch (BLCException blcex)
{
throw new BLCException(blcex.Message);
}
catch (Exception ex)
{
if (ex.Message.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
{
throw new BLCException("Cannot be deleted because of related records in other tables");
}
else
{
throw new Exception(ex.Message);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_User_By_USERNAME");}
}
public void Edit_Answer(Answer i_Answer) 
{
Tools.Tools oTools = new Tools.Tools();
Enum_EditMode oEditMode_Flag = Enum_EditMode.Update;
if (i_Answer.ANSWER_ID == -1)
{
oEditMode_Flag = Enum_EditMode.Add;
}
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Answer");}
#region Body Section.
if ((i_Answer.ANSWER_ID == null) || (i_Answer.ANSWER_ID == 0)) { throw new BLCException("Missing primary key while calling Edit_Answer"); }
i_Answer.ENTRY_USER_ID = this.UserID;
i_Answer.ENTRY_DATE    = oTools.GetDateString(DateTime.Today);
i_Answer.OWNER_ID      = this.OwnerID;
using (TransactionScope oScope = new TransactionScope())
{
#region PreEvent_Edit_Answer
if (OnPreEvent_Edit_Answer != null)
{
OnPreEvent_Edit_Answer(i_Answer,oEditMode_Flag);
}
#endregion
if (_Stop_Edit_Answer_Execution)
{
_Stop_Edit_Answer_Execution = false;
return;
}
i_Answer.ANSWER_ID = _AppContext.Edit_Answer
(
i_Answer.ANSWER_ID
,i_Answer.QUESTION_ID
,i_Answer.TEACHER_ID
,i_Answer.DESCRIPTION
,i_Answer.SCORE
,i_Answer.REVIEWS
,i_Answer.REPORTS
,i_Answer.IS_ACTIVE
,i_Answer.ENTRY_USER_ID
,i_Answer.ENTRY_DATE
,i_Answer.OWNER_ID
);
#region PostEvent_Edit_Answer
if (OnPostEvent_Edit_Answer != null)
{
OnPostEvent_Edit_Answer(i_Answer,oEditMode_Flag);
}
#endregion
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Answer");}
}
public void Edit_Answer_report(Answer_report i_Answer_report) 
{
Tools.Tools oTools = new Tools.Tools();
Enum_EditMode oEditMode_Flag = Enum_EditMode.Update;
if (i_Answer_report.ANSWER_REPORT_ID == -1)
{
oEditMode_Flag = Enum_EditMode.Add;
}
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Answer_report");}
#region Body Section.
if ((i_Answer_report.ANSWER_REPORT_ID == null) || (i_Answer_report.ANSWER_REPORT_ID == 0)) { throw new BLCException("Missing primary key while calling Edit_Answer_report"); }
i_Answer_report.ENTRY_USER_ID = this.UserID;
i_Answer_report.ENTRY_DATE    = oTools.GetDateString(DateTime.Today);
i_Answer_report.OWNER_ID      = this.OwnerID;
using (TransactionScope oScope = new TransactionScope())
{
#region PreEvent_Edit_Answer_report
if (OnPreEvent_Edit_Answer_report != null)
{
OnPreEvent_Edit_Answer_report(i_Answer_report,oEditMode_Flag);
}
#endregion
if (_Stop_Edit_Answer_report_Execution)
{
_Stop_Edit_Answer_report_Execution = false;
return;
}
i_Answer_report.ANSWER_REPORT_ID = _AppContext.Edit_Answer_report
(
i_Answer_report.ANSWER_REPORT_ID
,i_Answer_report.TEACHER_ID
,i_Answer_report.STUDENT_ID
,i_Answer_report.ANSWER_ID
,i_Answer_report.DESCRIPTION
,i_Answer_report.ENTRY_USER_ID
,i_Answer_report.ENTRY_DATE
,i_Answer_report.OWNER_ID
);
#region PostEvent_Edit_Answer_report
if (OnPostEvent_Edit_Answer_report != null)
{
OnPostEvent_Edit_Answer_report(i_Answer_report,oEditMode_Flag);
}
#endregion
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Answer_report");}
}
public void Edit_Appreciate(Appreciate i_Appreciate) 
{
Tools.Tools oTools = new Tools.Tools();
Enum_EditMode oEditMode_Flag = Enum_EditMode.Update;
if (i_Appreciate.APPRECIATE_ID == -1)
{
oEditMode_Flag = Enum_EditMode.Add;
}
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Appreciate");}
#region Body Section.
if ((i_Appreciate.APPRECIATE_ID == null) || (i_Appreciate.APPRECIATE_ID == 0)) { throw new BLCException("Missing primary key while calling Edit_Appreciate"); }
i_Appreciate.ENTRY_USER_ID = this.UserID;
i_Appreciate.ENTRY_DATE    = oTools.GetDateString(DateTime.Today);
i_Appreciate.OWNER_ID      = this.OwnerID;
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Edit_Appreciate_Execution)
{
_Stop_Edit_Appreciate_Execution = false;
return;
}
i_Appreciate.APPRECIATE_ID = _AppContext.Edit_Appreciate
(
i_Appreciate.APPRECIATE_ID
,i_Appreciate.ARTICLE_ID
,i_Appreciate.STUDENT_ID
,i_Appreciate.DESCRIPTION
,i_Appreciate.ENTRY_USER_ID
,i_Appreciate.ENTRY_DATE
,i_Appreciate.OWNER_ID
);
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Appreciate");}
}
public void Edit_Article(Article i_Article) 
{
Tools.Tools oTools = new Tools.Tools();
Enum_EditMode oEditMode_Flag = Enum_EditMode.Update;
if (i_Article.ARTICLE_ID == -1)
{
oEditMode_Flag = Enum_EditMode.Add;
}
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Article");}
#region Body Section.
if ((i_Article.ARTICLE_ID == null) || (i_Article.ARTICLE_ID == 0)) { throw new BLCException("Missing primary key while calling Edit_Article"); }
i_Article.ENTRY_USER_ID = this.UserID;
i_Article.ENTRY_DATE    = oTools.GetDateString(DateTime.Today);
i_Article.OWNER_ID      = this.OwnerID;
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Edit_Article_Execution)
{
_Stop_Edit_Article_Execution = false;
return;
}
i_Article.ARTICLE_ID = _AppContext.Edit_Article
(
i_Article.ARTICLE_ID
,i_Article.TEACHER_ID
,i_Article.CATEGORY_ID
,i_Article.TITLE
,i_Article.DESCRIPTION
,i_Article.APPLAUDS
,i_Article.REPORTS
,i_Article.IS_BLOCKED
,i_Article.ENTRY_USER_ID
,i_Article.ENTRY_DATE
,i_Article.OWNER_ID
);
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Article");}
}
public void Edit_Category(Category i_Category) 
{
Tools.Tools oTools = new Tools.Tools();
Enum_EditMode oEditMode_Flag = Enum_EditMode.Update;
if (i_Category.CATEGORY_ID == -1)
{
oEditMode_Flag = Enum_EditMode.Add;
}
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Category");}
#region Body Section.
if ((i_Category.CATEGORY_ID == null) || (i_Category.CATEGORY_ID == 0)) { throw new BLCException("Missing primary key while calling Edit_Category"); }
i_Category.ENTRY_USER_ID = this.UserID;
i_Category.ENTRY_DATE    = oTools.GetDateString(DateTime.Today);
i_Category.OWNER_ID      = this.OwnerID;
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Edit_Category_Execution)
{
_Stop_Edit_Category_Execution = false;
return;
}
i_Category.CATEGORY_ID = _AppContext.Edit_Category
(
i_Category.CATEGORY_ID
,i_Category.NAME
,i_Category.DECRIPTION
,i_Category.ENTRY_USER_ID
,i_Category.ENTRY_DATE
,i_Category.OWNER_ID
);
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Category");}
}
public void Edit_Evaluation(Evaluation i_Evaluation) 
{
Tools.Tools oTools = new Tools.Tools();
Enum_EditMode oEditMode_Flag = Enum_EditMode.Update;
if (i_Evaluation.EVALUATION_ID == -1)
{
oEditMode_Flag = Enum_EditMode.Add;
}
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Evaluation");}
#region Body Section.
if ((i_Evaluation.EVALUATION_ID == null) || (i_Evaluation.EVALUATION_ID == 0)) { throw new BLCException("Missing primary key while calling Edit_Evaluation"); }
i_Evaluation.ENTRY_USER_ID = this.UserID;
i_Evaluation.ENTRY_DATE    = oTools.GetDateString(DateTime.Today);
i_Evaluation.OWNER_ID      = this.OwnerID;
using (TransactionScope oScope = new TransactionScope())
{
#region PreEvent_Edit_Evaluation
if (OnPreEvent_Edit_Evaluation != null)
{
OnPreEvent_Edit_Evaluation(i_Evaluation,oEditMode_Flag);
}
#endregion
if (_Stop_Edit_Evaluation_Execution)
{
_Stop_Edit_Evaluation_Execution = false;
return;
}
i_Evaluation.EVALUATION_ID = _AppContext.Edit_Evaluation
(
i_Evaluation.EVALUATION_ID
,i_Evaluation.STUDENT_ID
,i_Evaluation.ANSWER_ID
,i_Evaluation.SCORE
,i_Evaluation.ENTRY_USER_ID
,i_Evaluation.ENTRY_DATE
,i_Evaluation.OWNER_ID
,i_Evaluation.DESCRIPTION
);
#region PostEvent_Edit_Evaluation
if (OnPostEvent_Edit_Evaluation != null)
{
OnPostEvent_Edit_Evaluation(i_Evaluation,oEditMode_Flag);
}
#endregion
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Evaluation");}
}
public void Edit_Favorite_category(Favorite_category i_Favorite_category) 
{
Tools.Tools oTools = new Tools.Tools();
Enum_EditMode oEditMode_Flag = Enum_EditMode.Update;
if (i_Favorite_category.FAVORITE_CATEGORY_ID == -1)
{
oEditMode_Flag = Enum_EditMode.Add;
}
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Favorite_category");}
#region Body Section.
if ((i_Favorite_category.FAVORITE_CATEGORY_ID == null) || (i_Favorite_category.FAVORITE_CATEGORY_ID == 0)) { throw new BLCException("Missing primary key while calling Edit_Favorite_category"); }
i_Favorite_category.ENTRY_USER_ID = this.UserID;
i_Favorite_category.ENTRY_DATE    = oTools.GetDateString(DateTime.Today);
i_Favorite_category.OWNER_ID      = this.OwnerID;
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Edit_Favorite_category_Execution)
{
_Stop_Edit_Favorite_category_Execution = false;
return;
}
i_Favorite_category.FAVORITE_CATEGORY_ID = _AppContext.Edit_Favorite_category
(
i_Favorite_category.FAVORITE_CATEGORY_ID
,i_Favorite_category.STUDENT_ID
,i_Favorite_category.CATEGORY_ID
,i_Favorite_category.DESCRIPTION
,i_Favorite_category.ENTRY_USER_ID
,i_Favorite_category.OWNER_ID
,i_Favorite_category.ENTRY_DATE
);
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Favorite_category");}
}
public void Edit_Favorite_teacher(Favorite_teacher i_Favorite_teacher) 
{
Tools.Tools oTools = new Tools.Tools();
Enum_EditMode oEditMode_Flag = Enum_EditMode.Update;
if (i_Favorite_teacher.FAVORITE_TEACHER_ID == -1)
{
oEditMode_Flag = Enum_EditMode.Add;
}
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Favorite_teacher");}
#region Body Section.
if ((i_Favorite_teacher.FAVORITE_TEACHER_ID == null) || (i_Favorite_teacher.FAVORITE_TEACHER_ID == 0)) { throw new BLCException("Missing primary key while calling Edit_Favorite_teacher"); }
i_Favorite_teacher.ENTRY_USER_ID = this.UserID;
i_Favorite_teacher.ENTRY_DATE    = oTools.GetDateString(DateTime.Today);
i_Favorite_teacher.OWNER_ID      = this.OwnerID;
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Edit_Favorite_teacher_Execution)
{
_Stop_Edit_Favorite_teacher_Execution = false;
return;
}
i_Favorite_teacher.FAVORITE_TEACHER_ID = _AppContext.Edit_Favorite_teacher
(
i_Favorite_teacher.FAVORITE_TEACHER_ID
,i_Favorite_teacher.TEACHER_ID
,i_Favorite_teacher.STUDENT_ID
,i_Favorite_teacher.DESCRIPTION
,i_Favorite_teacher.ENTRY_USER_ID
,i_Favorite_teacher.OWNER_ID
,i_Favorite_teacher.ENTRY_DATE
);
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Favorite_teacher");}
}
public void Edit_Mark_question(Mark_question i_Mark_question) 
{
Tools.Tools oTools = new Tools.Tools();
Enum_EditMode oEditMode_Flag = Enum_EditMode.Update;
if (i_Mark_question.MARK_QUESTION_ID == -1)
{
oEditMode_Flag = Enum_EditMode.Add;
}
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Mark_question");}
#region Body Section.
if ((i_Mark_question.MARK_QUESTION_ID == null) || (i_Mark_question.MARK_QUESTION_ID == 0)) { throw new BLCException("Missing primary key while calling Edit_Mark_question"); }
i_Mark_question.ENTRY_USER_ID = this.UserID;
i_Mark_question.ENTRY_DATE    = oTools.GetDateString(DateTime.Today);
i_Mark_question.OWNER_ID      = this.OwnerID;
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Edit_Mark_question_Execution)
{
_Stop_Edit_Mark_question_Execution = false;
return;
}
i_Mark_question.MARK_QUESTION_ID = _AppContext.Edit_Mark_question
(
i_Mark_question.MARK_QUESTION_ID
,i_Mark_question.QUESTION_ID
,i_Mark_question.STUDENT_ID
,i_Mark_question.ENTRY_USER_ID
,i_Mark_question.ENTRY_DATE
,i_Mark_question.OWNER_ID
,i_Mark_question.DESCRIPTION
);
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Mark_question");}
}
public void Edit_Notification(Notification i_Notification) 
{
Tools.Tools oTools = new Tools.Tools();
Enum_EditMode oEditMode_Flag = Enum_EditMode.Update;
if (i_Notification.NOTIFICATION_ID == -1)
{
oEditMode_Flag = Enum_EditMode.Add;
}
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Notification");}
#region Body Section.
if ((i_Notification.NOTIFICATION_ID == null) || (i_Notification.NOTIFICATION_ID == 0)) { throw new BLCException("Missing primary key while calling Edit_Notification"); }
i_Notification.ENTRY_USER_ID = this.UserID;
i_Notification.ENTRY_DATE    = oTools.GetDateString(DateTime.Today);
i_Notification.OWNER_ID      = this.OwnerID;
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Edit_Notification_Execution)
{
_Stop_Edit_Notification_Execution = false;
return;
}
i_Notification.NOTIFICATION_ID = _AppContext.Edit_Notification
(
i_Notification.NOTIFICATION_ID
,i_Notification.USER_ID
,i_Notification.DESCRIPTION
,i_Notification.QUESTION_ID
,i_Notification.ANSWER_ID
,i_Notification.ENTRY_USER_ID
,i_Notification.ENTRY_DATE
,i_Notification.OWNER_ID
);
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Notification");}
}
public void Edit_Owner(Owner i_Owner) 
{
Tools.Tools oTools = new Tools.Tools();
Enum_EditMode oEditMode_Flag = Enum_EditMode.Update;
if (i_Owner.OWNER_ID == -1)
{
oEditMode_Flag = Enum_EditMode.Add;
}
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Owner");}
#region Body Section.
if ((i_Owner.OWNER_ID == null) || (i_Owner.OWNER_ID == 0)) { throw new BLCException("Missing primary key while calling Edit_Owner"); }
i_Owner.ENTRY_DATE    = oTools.GetDateTimeString(DateTime.Now);
i_Owner.OWNER_ID      = this.OwnerID;
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Edit_Owner_Execution)
{
_Stop_Edit_Owner_Execution = false;
return;
}
i_Owner.OWNER_ID = _AppContext.Edit_Owner
(
i_Owner.OWNER_ID
,i_Owner.CODE
,i_Owner.MAINTENANCE_DUE_DATE
,i_Owner.DESCRIPTION
,i_Owner.ENTRY_DATE
);
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Owner");}
}
public void Edit_Question(Question i_Question) 
{
Tools.Tools oTools = new Tools.Tools();
Enum_EditMode oEditMode_Flag = Enum_EditMode.Update;
if (i_Question.QUESTION_ID == -1)
{
oEditMode_Flag = Enum_EditMode.Add;
}
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Question");}
#region Body Section.
if ((i_Question.QUESTION_ID == null) || (i_Question.QUESTION_ID == 0)) { throw new BLCException("Missing primary key while calling Edit_Question"); }
i_Question.ENTRY_USER_ID = this.UserID;
i_Question.ENTRY_DATE    = oTools.GetDateString(DateTime.Today);
i_Question.OWNER_ID      = this.OwnerID;
using (TransactionScope oScope = new TransactionScope())
{
#region PreEvent_Edit_Question
if (OnPreEvent_Edit_Question != null)
{
OnPreEvent_Edit_Question(i_Question,oEditMode_Flag);
}
#endregion
if (_Stop_Edit_Question_Execution)
{
_Stop_Edit_Question_Execution = false;
return;
}
i_Question.QUESTION_ID = _AppContext.Edit_Question
(
i_Question.QUESTION_ID
,i_Question.STUDENT_ID
,i_Question.CATEGORY_ID
,i_Question.TEACHER_ID
,i_Question.DESCRIPTION
,i_Question.IS_ANSWERED
,i_Question.IS_ACTIVE
,i_Question.REPORTS
,i_Question.ENTRY_USER_ID
,i_Question.ENTRY_DATE
,i_Question.OWNER_ID
);
#region PostEvent_Edit_Question
if (OnPostEvent_Edit_Question != null)
{
OnPostEvent_Edit_Question(i_Question,oEditMode_Flag);
}
#endregion
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Question");}
}
public void Edit_Question_report(Question_report i_Question_report) 
{
Tools.Tools oTools = new Tools.Tools();
Enum_EditMode oEditMode_Flag = Enum_EditMode.Update;
if (i_Question_report.QUESTION_REPORT_ID == -1)
{
oEditMode_Flag = Enum_EditMode.Add;
}
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Question_report");}
#region Body Section.
if ((i_Question_report.QUESTION_REPORT_ID == null) || (i_Question_report.QUESTION_REPORT_ID == 0)) { throw new BLCException("Missing primary key while calling Edit_Question_report"); }
i_Question_report.ENTRY_USER_ID = this.UserID;
i_Question_report.ENTRY_DATE    = oTools.GetDateString(DateTime.Today);
i_Question_report.OWNER_ID      = this.OwnerID;
using (TransactionScope oScope = new TransactionScope())
{
#region PreEvent_Edit_Question_report
if (OnPreEvent_Edit_Question_report != null)
{
OnPreEvent_Edit_Question_report(i_Question_report,oEditMode_Flag);
}
#endregion
if (_Stop_Edit_Question_report_Execution)
{
_Stop_Edit_Question_report_Execution = false;
return;
}
i_Question_report.QUESTION_REPORT_ID = _AppContext.Edit_Question_report
(
i_Question_report.QUESTION_REPORT_ID
,i_Question_report.STUDENT_ID
,i_Question_report.TEACHER_ID
,i_Question_report.QUESTION_ID
,i_Question_report.DESCRIPTION
,i_Question_report.ENTRY_USER_ID
,i_Question_report.ENTRY_DATE
,i_Question_report.OWNER_ID
);
#region PostEvent_Edit_Question_report
if (OnPostEvent_Edit_Question_report != null)
{
OnPostEvent_Edit_Question_report(i_Question_report,oEditMode_Flag);
}
#endregion
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Question_report");}
}
public void Edit_Question_token(Question_token i_Question_token) 
{
Tools.Tools oTools = new Tools.Tools();
Enum_EditMode oEditMode_Flag = Enum_EditMode.Update;
if (i_Question_token.QUESTION_TOKEN_ID == -1)
{
oEditMode_Flag = Enum_EditMode.Add;
}
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Question_token");}
#region Body Section.
if ((i_Question_token.QUESTION_TOKEN_ID == null) || (i_Question_token.QUESTION_TOKEN_ID == 0)) { throw new BLCException("Missing primary key while calling Edit_Question_token"); }
i_Question_token.ENTRY_USER_ID = this.UserID;
i_Question_token.ENTRY_DATE    = oTools.GetDateString(DateTime.Today);
i_Question_token.OWNER_ID      = this.OwnerID;
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Edit_Question_token_Execution)
{
_Stop_Edit_Question_token_Execution = false;
return;
}
i_Question_token.QUESTION_TOKEN_ID = _AppContext.Edit_Question_token
(
i_Question_token.QUESTION_TOKEN_ID
,i_Question_token.QUESTION_ID
,i_Question_token.PART
,i_Question_token.ENTRY_USER_ID
,i_Question_token.ENTRY_DATE
,i_Question_token.OWNER_ID
);
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Question_token");}
}
public void Edit_Report_article(Report_article i_Report_article) 
{
Tools.Tools oTools = new Tools.Tools();
Enum_EditMode oEditMode_Flag = Enum_EditMode.Update;
if (i_Report_article.REPORT_ARTICLE_ID == -1)
{
oEditMode_Flag = Enum_EditMode.Add;
}
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Report_article");}
#region Body Section.
if ((i_Report_article.REPORT_ARTICLE_ID == null) || (i_Report_article.REPORT_ARTICLE_ID == 0)) { throw new BLCException("Missing primary key while calling Edit_Report_article"); }
i_Report_article.ENTRY_USER_ID = this.UserID;
i_Report_article.ENTRY_DATE    = oTools.GetDateString(DateTime.Today);
i_Report_article.OWNER_ID      = this.OwnerID;
using (TransactionScope oScope = new TransactionScope())
{
#region PreEvent_Edit_Report_article
if (OnPreEvent_Edit_Report_article != null)
{
OnPreEvent_Edit_Report_article(i_Report_article,oEditMode_Flag);
}
#endregion
if (_Stop_Edit_Report_article_Execution)
{
_Stop_Edit_Report_article_Execution = false;
return;
}
i_Report_article.REPORT_ARTICLE_ID = _AppContext.Edit_Report_article
(
i_Report_article.REPORT_ARTICLE_ID
,i_Report_article.ARTICLE_ID
,i_Report_article.STUDENT_ID
,i_Report_article.DESCRIPTION
,i_Report_article.ENTRY_USER_ID
,i_Report_article.ENTRY_DATE
,i_Report_article.OWNER_ID
);
#region PostEvent_Edit_Report_article
if (OnPostEvent_Edit_Report_article != null)
{
OnPostEvent_Edit_Report_article(i_Report_article,oEditMode_Flag);
}
#endregion
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Report_article");}
}
public void Edit_Student(Student i_Student) 
{
Tools.Tools oTools = new Tools.Tools();
Enum_EditMode oEditMode_Flag = Enum_EditMode.Update;
if (i_Student.STUDENT_ID == -1)
{
oEditMode_Flag = Enum_EditMode.Add;
}
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Student");}
#region Body Section.
if ((i_Student.STUDENT_ID == null) || (i_Student.STUDENT_ID == 0)) { throw new BLCException("Missing primary key while calling Edit_Student"); }
i_Student.ENTRY_USER_ID = this.UserID;
i_Student.ENTRY_DATE    = oTools.GetDateString(DateTime.Today);
i_Student.OWNER_ID      = this.OwnerID;
using (TransactionScope oScope = new TransactionScope())
{
#region PreEvent_Edit_Student
if (OnPreEvent_Edit_Student != null)
{
OnPreEvent_Edit_Student(i_Student,oEditMode_Flag);
}
#endregion
if (_Stop_Edit_Student_Execution)
{
_Stop_Edit_Student_Execution = false;
return;
}
i_Student.STUDENT_ID = _AppContext.Edit_Student
(
i_Student.STUDENT_ID
,i_Student.USER_ID
,i_Student.FIRST_NAME
,i_Student.LAST_NAME
,i_Student.EMAIL
,i_Student.IS_BLOCKED
,i_Student.PENDING_QUESTIONS
,i_Student.ENTRY_USER_ID
,i_Student.ENTRY_DATE
,i_Student.OWNER_ID
);
#region PostEvent_Edit_Student
if (OnPostEvent_Edit_Student != null)
{
OnPostEvent_Edit_Student(i_Student,oEditMode_Flag);
}
#endregion
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Student");}
}
public void Edit_Student_report(Student_report i_Student_report) 
{
Tools.Tools oTools = new Tools.Tools();
Enum_EditMode oEditMode_Flag = Enum_EditMode.Update;
if (i_Student_report.STUDENT_REPORT_ID == -1)
{
oEditMode_Flag = Enum_EditMode.Add;
}
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Student_report");}
#region Body Section.
if ((i_Student_report.STUDENT_REPORT_ID == null) || (i_Student_report.STUDENT_REPORT_ID == 0)) { throw new BLCException("Missing primary key while calling Edit_Student_report"); }
i_Student_report.ENTRY_USER_ID = this.UserID;
i_Student_report.ENTRY_DATE    = oTools.GetDateString(DateTime.Today);
i_Student_report.OWNER_ID      = this.OwnerID;
using (TransactionScope oScope = new TransactionScope())
{
#region PreEvent_Edit_Student_report
if (OnPreEvent_Edit_Student_report != null)
{
OnPreEvent_Edit_Student_report(i_Student_report,oEditMode_Flag);
}
#endregion
if (_Stop_Edit_Student_report_Execution)
{
_Stop_Edit_Student_report_Execution = false;
return;
}
i_Student_report.STUDENT_REPORT_ID = _AppContext.Edit_Student_report
(
i_Student_report.STUDENT_REPORT_ID
,i_Student_report.REPORTED_BY_STUDENT_ID
,i_Student_report.REPORTED_STUDENT_ID
,i_Student_report.DESCRIPTION
,i_Student_report.ENTRY_USER_ID
,i_Student_report.ENTRY_DATE
,i_Student_report.OWNER_ID
);
#region PostEvent_Edit_Student_report
if (OnPostEvent_Edit_Student_report != null)
{
OnPostEvent_Edit_Student_report(i_Student_report,oEditMode_Flag);
}
#endregion
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Student_report");}
}
public void Edit_Teacher(Teacher i_Teacher) 
{
Tools.Tools oTools = new Tools.Tools();
Enum_EditMode oEditMode_Flag = Enum_EditMode.Update;
if (i_Teacher.TEACHER_ID == -1)
{
oEditMode_Flag = Enum_EditMode.Add;
}
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Teacher");}
#region Body Section.
if ((i_Teacher.TEACHER_ID == null) || (i_Teacher.TEACHER_ID == 0)) { throw new BLCException("Missing primary key while calling Edit_Teacher"); }
i_Teacher.ENTRY_USER_ID = this.UserID;
i_Teacher.ENTRY_DATE    = oTools.GetDateString(DateTime.Today);
i_Teacher.OWNER_ID      = this.OwnerID;
using (TransactionScope oScope = new TransactionScope())
{
#region PreEvent_Edit_Teacher
if (OnPreEvent_Edit_Teacher != null)
{
OnPreEvent_Edit_Teacher(i_Teacher,oEditMode_Flag);
}
#endregion
if (_Stop_Edit_Teacher_Execution)
{
_Stop_Edit_Teacher_Execution = false;
return;
}
i_Teacher.TEACHER_ID = _AppContext.Edit_Teacher
(
i_Teacher.TEACHER_ID
,i_Teacher.USER_ID
,i_Teacher.FIRST_NAME
,i_Teacher.LAST_NAME
,i_Teacher.SCORE
,i_Teacher.DESCRIPTION
,i_Teacher.IS_BLOCKED
,i_Teacher.EMAIL
,i_Teacher.MOBILE
,i_Teacher.ENTRY_USER_ID
,i_Teacher.ENTRY_DATE
,i_Teacher.OWNER_ID
);
#region PostEvent_Edit_Teacher
if (OnPostEvent_Edit_Teacher != null)
{
OnPostEvent_Edit_Teacher(i_Teacher,oEditMode_Flag);
}
#endregion
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Teacher");}
}
public void Edit_Teacher_category(Teacher_category i_Teacher_category) 
{
Tools.Tools oTools = new Tools.Tools();
Enum_EditMode oEditMode_Flag = Enum_EditMode.Update;
if (i_Teacher_category.TEACHER_CATEGORY_ID == -1)
{
oEditMode_Flag = Enum_EditMode.Add;
}
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Teacher_category");}
#region Body Section.
if ((i_Teacher_category.TEACHER_CATEGORY_ID == null) || (i_Teacher_category.TEACHER_CATEGORY_ID == 0)) { throw new BLCException("Missing primary key while calling Edit_Teacher_category"); }
i_Teacher_category.ENTRY_USER_ID = this.UserID;
i_Teacher_category.ENTRY_DATE    = oTools.GetDateString(DateTime.Today);
i_Teacher_category.OWNER_ID      = this.OwnerID;
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Edit_Teacher_category_Execution)
{
_Stop_Edit_Teacher_category_Execution = false;
return;
}
i_Teacher_category.TEACHER_CATEGORY_ID = _AppContext.Edit_Teacher_category
(
i_Teacher_category.TEACHER_CATEGORY_ID
,i_Teacher_category.TEACHER_ID
,i_Teacher_category.CATEGORY_ID
,i_Teacher_category.DESCRIPTION
,i_Teacher_category.ENTRY_USER_ID
,i_Teacher_category.ENTRY_DATE
,i_Teacher_category.OWNER_ID
);
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Teacher_category");}
}
public void Edit_Teacher_favorite(Teacher_favorite i_Teacher_favorite) 
{
Tools.Tools oTools = new Tools.Tools();
Enum_EditMode oEditMode_Flag = Enum_EditMode.Update;
if (i_Teacher_favorite.TEACHER_FAVORITE_ID == -1)
{
oEditMode_Flag = Enum_EditMode.Add;
}
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Teacher_favorite");}
#region Body Section.
if ((i_Teacher_favorite.TEACHER_FAVORITE_ID == null) || (i_Teacher_favorite.TEACHER_FAVORITE_ID == 0)) { throw new BLCException("Missing primary key while calling Edit_Teacher_favorite"); }
i_Teacher_favorite.ENTRY_USER_ID = this.UserID;
i_Teacher_favorite.ENTRY_DATE    = oTools.GetDateString(DateTime.Today);
i_Teacher_favorite.OWNER_ID      = this.OwnerID;
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Edit_Teacher_favorite_Execution)
{
_Stop_Edit_Teacher_favorite_Execution = false;
return;
}
i_Teacher_favorite.TEACHER_FAVORITE_ID = _AppContext.Edit_Teacher_favorite
(
i_Teacher_favorite.TEACHER_FAVORITE_ID
,i_Teacher_favorite.TEACHER_ID
,i_Teacher_favorite.STUDENT_ID
,i_Teacher_favorite.DESCRIPTION
,i_Teacher_favorite.ENTRY_USER_ID
,i_Teacher_favorite.ENTRY_DATE
,i_Teacher_favorite.OWNER_ID
);
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Teacher_favorite");}
}
public void Edit_Teacher_rank(Teacher_rank i_Teacher_rank) 
{
Tools.Tools oTools = new Tools.Tools();
Enum_EditMode oEditMode_Flag = Enum_EditMode.Update;
if (i_Teacher_rank.TEACHER_RANK_ID == -1)
{
oEditMode_Flag = Enum_EditMode.Add;
}
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Teacher_rank");}
#region Body Section.
if ((i_Teacher_rank.TEACHER_RANK_ID == null) || (i_Teacher_rank.TEACHER_RANK_ID == 0)) { throw new BLCException("Missing primary key while calling Edit_Teacher_rank"); }
i_Teacher_rank.ENTRY_USER_ID = this.UserID;
i_Teacher_rank.ENTRY_DATE    = oTools.GetDateString(DateTime.Today);
i_Teacher_rank.OWNER_ID      = this.OwnerID;
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Edit_Teacher_rank_Execution)
{
_Stop_Edit_Teacher_rank_Execution = false;
return;
}
i_Teacher_rank.TEACHER_RANK_ID = _AppContext.Edit_Teacher_rank
(
i_Teacher_rank.TEACHER_RANK_ID
,i_Teacher_rank.TEACHER_ID
,i_Teacher_rank.SCORE
,i_Teacher_rank.OVERALL_RANKING
,i_Teacher_rank.ENTRY_USER_ID
,i_Teacher_rank.OWNER_ID
,i_Teacher_rank.ENTRY_DATE
,i_Teacher_rank.DESCRIPTION
);
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Teacher_rank");}
}
public void Edit_Teacher_report(Teacher_report i_Teacher_report) 
{
Tools.Tools oTools = new Tools.Tools();
Enum_EditMode oEditMode_Flag = Enum_EditMode.Update;
if (i_Teacher_report.TEACHER_REPORT_ID == -1)
{
oEditMode_Flag = Enum_EditMode.Add;
}
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Teacher_report");}
#region Body Section.
if ((i_Teacher_report.TEACHER_REPORT_ID == null) || (i_Teacher_report.TEACHER_REPORT_ID == 0)) { throw new BLCException("Missing primary key while calling Edit_Teacher_report"); }
i_Teacher_report.ENTRY_USER_ID = this.UserID;
i_Teacher_report.ENTRY_DATE    = oTools.GetDateString(DateTime.Today);
i_Teacher_report.OWNER_ID      = this.OwnerID;
using (TransactionScope oScope = new TransactionScope())
{
#region PreEvent_Edit_Teacher_report
if (OnPreEvent_Edit_Teacher_report != null)
{
OnPreEvent_Edit_Teacher_report(i_Teacher_report,oEditMode_Flag);
}
#endregion
if (_Stop_Edit_Teacher_report_Execution)
{
_Stop_Edit_Teacher_report_Execution = false;
return;
}
i_Teacher_report.TEACHER_REPORT_ID = _AppContext.Edit_Teacher_report
(
i_Teacher_report.TEACHER_REPORT_ID
,i_Teacher_report.TEACHER_ID
,i_Teacher_report.STUDENT_ID
,i_Teacher_report.DESCRIPTION
,i_Teacher_report.ENTRY_USER_ID
,i_Teacher_report.ENTRY_DATE
,i_Teacher_report.OWNER_ID
);
#region PostEvent_Edit_Teacher_report
if (OnPostEvent_Edit_Teacher_report != null)
{
OnPostEvent_Edit_Teacher_report(i_Teacher_report,oEditMode_Flag);
}
#endregion
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Teacher_report");}
}
public void Edit_User(User i_User) 
{
Tools.Tools oTools = new Tools.Tools();
Enum_EditMode oEditMode_Flag = Enum_EditMode.Update;
if (i_User.USER_ID == -1)
{
oEditMode_Flag = Enum_EditMode.Add;
}
if (OnPreEvent_General != null){OnPreEvent_General("Edit_User");}
#region Body Section.
if ((i_User.USER_ID == null) || (i_User.USER_ID == 0)) { throw new BLCException("Missing primary key while calling Edit_User"); }
i_User.ENTRY_DATE    = oTools.GetDateString(DateTime.Today);
i_User.OWNER_ID      = this.OwnerID;
using (TransactionScope oScope = new TransactionScope())
{
if (_Stop_Edit_User_Execution)
{
_Stop_Edit_User_Execution = false;
return;
}
i_User.USER_ID = _AppContext.Edit_User
(
i_User.USER_ID
,i_User.OWNER_ID
,i_User.USERNAME
,i_User.PASSWORD
,i_User.USER_TYPE_CODE
,i_User.IS_LOGGED_IN
,i_User.IS_ACTIVE
,i_User.ENTRY_DATE
);
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_User");}
}
public void Edit_Answer_List(List<Answer> i_List_Answer)
{
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Answer_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_List_Answer != null)
{
foreach (var oRow in i_List_Answer)
{
Edit_Answer(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Answer_List");}
}
public void Edit_Answer_List(Params_Edit_Answer_List i_Params_Edit_Answer_List)
{
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Answer_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_Params_Edit_Answer_List.My_List_To_Delete != null)
{
foreach (var oRow in i_Params_Edit_Answer_List.My_List_To_Delete)
{
Delete_Answer(new Params_Delete_Answer() { ANSWER_ID = oRow.ANSWER_ID });
}
}
if (i_Params_Edit_Answer_List.My_List_To_Edit != null)
{
foreach (var oRow in i_Params_Edit_Answer_List.My_List_To_Edit)
{
Edit_Answer(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Answer_List");}
}
public void Edit_Answer_report_List(List<Answer_report> i_List_Answer_report)
{
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Answer_report_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_List_Answer_report != null)
{
foreach (var oRow in i_List_Answer_report)
{
Edit_Answer_report(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Answer_report_List");}
}
public void Edit_Answer_report_List(Params_Edit_Answer_report_List i_Params_Edit_Answer_report_List)
{
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Answer_report_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_Params_Edit_Answer_report_List.My_List_To_Delete != null)
{
foreach (var oRow in i_Params_Edit_Answer_report_List.My_List_To_Delete)
{
Delete_Answer_report(new Params_Delete_Answer_report() { ANSWER_REPORT_ID = oRow.ANSWER_REPORT_ID });
}
}
if (i_Params_Edit_Answer_report_List.My_List_To_Edit != null)
{
foreach (var oRow in i_Params_Edit_Answer_report_List.My_List_To_Edit)
{
Edit_Answer_report(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Answer_report_List");}
}
public void Edit_Appreciate_List(List<Appreciate> i_List_Appreciate)
{
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Appreciate_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_List_Appreciate != null)
{
foreach (var oRow in i_List_Appreciate)
{
Edit_Appreciate(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Appreciate_List");}
}
public void Edit_Appreciate_List(Params_Edit_Appreciate_List i_Params_Edit_Appreciate_List)
{
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Appreciate_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_Params_Edit_Appreciate_List.My_List_To_Delete != null)
{
foreach (var oRow in i_Params_Edit_Appreciate_List.My_List_To_Delete)
{
Delete_Appreciate(new Params_Delete_Appreciate() { APPRECIATE_ID = oRow.APPRECIATE_ID });
}
}
if (i_Params_Edit_Appreciate_List.My_List_To_Edit != null)
{
foreach (var oRow in i_Params_Edit_Appreciate_List.My_List_To_Edit)
{
Edit_Appreciate(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Appreciate_List");}
}
public void Edit_Article_List(List<Article> i_List_Article)
{
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Article_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_List_Article != null)
{
foreach (var oRow in i_List_Article)
{
Edit_Article(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Article_List");}
}
public void Edit_Article_List(Params_Edit_Article_List i_Params_Edit_Article_List)
{
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Article_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_Params_Edit_Article_List.My_List_To_Delete != null)
{
foreach (var oRow in i_Params_Edit_Article_List.My_List_To_Delete)
{
Delete_Article(new Params_Delete_Article() { ARTICLE_ID = oRow.ARTICLE_ID });
}
}
if (i_Params_Edit_Article_List.My_List_To_Edit != null)
{
foreach (var oRow in i_Params_Edit_Article_List.My_List_To_Edit)
{
Edit_Article(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Article_List");}
}
public void Edit_Category_List(List<Category> i_List_Category)
{
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Category_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_List_Category != null)
{
foreach (var oRow in i_List_Category)
{
Edit_Category(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Category_List");}
}
public void Edit_Category_List(Params_Edit_Category_List i_Params_Edit_Category_List)
{
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Category_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_Params_Edit_Category_List.My_List_To_Delete != null)
{
foreach (var oRow in i_Params_Edit_Category_List.My_List_To_Delete)
{
Delete_Category(new Params_Delete_Category() { CATEGORY_ID = oRow.CATEGORY_ID });
}
}
if (i_Params_Edit_Category_List.My_List_To_Edit != null)
{
foreach (var oRow in i_Params_Edit_Category_List.My_List_To_Edit)
{
Edit_Category(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Category_List");}
}
public void Edit_Evaluation_List(List<Evaluation> i_List_Evaluation)
{
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Evaluation_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_List_Evaluation != null)
{
foreach (var oRow in i_List_Evaluation)
{
Edit_Evaluation(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Evaluation_List");}
}
public void Edit_Evaluation_List(Params_Edit_Evaluation_List i_Params_Edit_Evaluation_List)
{
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Evaluation_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_Params_Edit_Evaluation_List.My_List_To_Delete != null)
{
foreach (var oRow in i_Params_Edit_Evaluation_List.My_List_To_Delete)
{
Delete_Evaluation(new Params_Delete_Evaluation() { EVALUATION_ID = oRow.EVALUATION_ID });
}
}
if (i_Params_Edit_Evaluation_List.My_List_To_Edit != null)
{
foreach (var oRow in i_Params_Edit_Evaluation_List.My_List_To_Edit)
{
Edit_Evaluation(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Evaluation_List");}
}
public void Edit_Favorite_category_List(List<Favorite_category> i_List_Favorite_category)
{
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Favorite_category_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_List_Favorite_category != null)
{
foreach (var oRow in i_List_Favorite_category)
{
Edit_Favorite_category(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Favorite_category_List");}
}
public void Edit_Favorite_category_List(Params_Edit_Favorite_category_List i_Params_Edit_Favorite_category_List)
{
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Favorite_category_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_Params_Edit_Favorite_category_List.My_List_To_Delete != null)
{
foreach (var oRow in i_Params_Edit_Favorite_category_List.My_List_To_Delete)
{
Delete_Favorite_category(new Params_Delete_Favorite_category() { FAVORITE_CATEGORY_ID = oRow.FAVORITE_CATEGORY_ID });
}
}
if (i_Params_Edit_Favorite_category_List.My_List_To_Edit != null)
{
foreach (var oRow in i_Params_Edit_Favorite_category_List.My_List_To_Edit)
{
Edit_Favorite_category(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Favorite_category_List");}
}
public void Edit_Favorite_teacher_List(List<Favorite_teacher> i_List_Favorite_teacher)
{
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Favorite_teacher_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_List_Favorite_teacher != null)
{
foreach (var oRow in i_List_Favorite_teacher)
{
Edit_Favorite_teacher(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Favorite_teacher_List");}
}
public void Edit_Favorite_teacher_List(Params_Edit_Favorite_teacher_List i_Params_Edit_Favorite_teacher_List)
{
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Favorite_teacher_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_Params_Edit_Favorite_teacher_List.My_List_To_Delete != null)
{
foreach (var oRow in i_Params_Edit_Favorite_teacher_List.My_List_To_Delete)
{
Delete_Favorite_teacher(new Params_Delete_Favorite_teacher() { FAVORITE_TEACHER_ID = oRow.FAVORITE_TEACHER_ID });
}
}
if (i_Params_Edit_Favorite_teacher_List.My_List_To_Edit != null)
{
foreach (var oRow in i_Params_Edit_Favorite_teacher_List.My_List_To_Edit)
{
Edit_Favorite_teacher(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Favorite_teacher_List");}
}
public void Edit_Mark_question_List(List<Mark_question> i_List_Mark_question)
{
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Mark_question_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_List_Mark_question != null)
{
foreach (var oRow in i_List_Mark_question)
{
Edit_Mark_question(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Mark_question_List");}
}
public void Edit_Mark_question_List(Params_Edit_Mark_question_List i_Params_Edit_Mark_question_List)
{
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Mark_question_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_Params_Edit_Mark_question_List.My_List_To_Delete != null)
{
foreach (var oRow in i_Params_Edit_Mark_question_List.My_List_To_Delete)
{
Delete_Mark_question(new Params_Delete_Mark_question() { MARK_QUESTION_ID = oRow.MARK_QUESTION_ID });
}
}
if (i_Params_Edit_Mark_question_List.My_List_To_Edit != null)
{
foreach (var oRow in i_Params_Edit_Mark_question_List.My_List_To_Edit)
{
Edit_Mark_question(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Mark_question_List");}
}
public void Edit_Notification_List(List<Notification> i_List_Notification)
{
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Notification_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_List_Notification != null)
{
foreach (var oRow in i_List_Notification)
{
Edit_Notification(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Notification_List");}
}
public void Edit_Notification_List(Params_Edit_Notification_List i_Params_Edit_Notification_List)
{
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Notification_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_Params_Edit_Notification_List.My_List_To_Delete != null)
{
foreach (var oRow in i_Params_Edit_Notification_List.My_List_To_Delete)
{
Delete_Notification(new Params_Delete_Notification() { NOTIFICATION_ID = oRow.NOTIFICATION_ID });
}
}
if (i_Params_Edit_Notification_List.My_List_To_Edit != null)
{
foreach (var oRow in i_Params_Edit_Notification_List.My_List_To_Edit)
{
Edit_Notification(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Notification_List");}
}
public void Edit_Owner_List(List<Owner> i_List_Owner)
{
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Owner_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_List_Owner != null)
{
foreach (var oRow in i_List_Owner)
{
Edit_Owner(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Owner_List");}
}
public void Edit_Owner_List(Params_Edit_Owner_List i_Params_Edit_Owner_List)
{
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Owner_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_Params_Edit_Owner_List.My_List_To_Delete != null)
{
foreach (var oRow in i_Params_Edit_Owner_List.My_List_To_Delete)
{
Delete_Owner(new Params_Delete_Owner() { OWNER_ID = oRow.OWNER_ID });
}
}
if (i_Params_Edit_Owner_List.My_List_To_Edit != null)
{
foreach (var oRow in i_Params_Edit_Owner_List.My_List_To_Edit)
{
Edit_Owner(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Owner_List");}
}
public void Edit_Question_List(List<Question> i_List_Question)
{
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Question_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_List_Question != null)
{
foreach (var oRow in i_List_Question)
{
Edit_Question(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Question_List");}
}
public void Edit_Question_List(Params_Edit_Question_List i_Params_Edit_Question_List)
{
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Question_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_Params_Edit_Question_List.My_List_To_Delete != null)
{
foreach (var oRow in i_Params_Edit_Question_List.My_List_To_Delete)
{
Delete_Question(new Params_Delete_Question() { QUESTION_ID = oRow.QUESTION_ID });
}
}
if (i_Params_Edit_Question_List.My_List_To_Edit != null)
{
foreach (var oRow in i_Params_Edit_Question_List.My_List_To_Edit)
{
Edit_Question(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Question_List");}
}
public void Edit_Question_report_List(List<Question_report> i_List_Question_report)
{
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Question_report_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_List_Question_report != null)
{
foreach (var oRow in i_List_Question_report)
{
Edit_Question_report(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Question_report_List");}
}
public void Edit_Question_report_List(Params_Edit_Question_report_List i_Params_Edit_Question_report_List)
{
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Question_report_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_Params_Edit_Question_report_List.My_List_To_Delete != null)
{
foreach (var oRow in i_Params_Edit_Question_report_List.My_List_To_Delete)
{
Delete_Question_report(new Params_Delete_Question_report() { QUESTION_REPORT_ID = oRow.QUESTION_REPORT_ID });
}
}
if (i_Params_Edit_Question_report_List.My_List_To_Edit != null)
{
foreach (var oRow in i_Params_Edit_Question_report_List.My_List_To_Edit)
{
Edit_Question_report(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Question_report_List");}
}
public void Edit_Question_token_List(List<Question_token> i_List_Question_token)
{
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Question_token_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_List_Question_token != null)
{
foreach (var oRow in i_List_Question_token)
{
Edit_Question_token(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Question_token_List");}
}
public void Edit_Question_token_List(Params_Edit_Question_token_List i_Params_Edit_Question_token_List)
{
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Question_token_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_Params_Edit_Question_token_List.My_List_To_Delete != null)
{
foreach (var oRow in i_Params_Edit_Question_token_List.My_List_To_Delete)
{
Delete_Question_token(new Params_Delete_Question_token() { QUESTION_TOKEN_ID = oRow.QUESTION_TOKEN_ID });
}
}
if (i_Params_Edit_Question_token_List.My_List_To_Edit != null)
{
foreach (var oRow in i_Params_Edit_Question_token_List.My_List_To_Edit)
{
Edit_Question_token(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Question_token_List");}
}
public void Edit_Report_article_List(List<Report_article> i_List_Report_article)
{
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Report_article_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_List_Report_article != null)
{
foreach (var oRow in i_List_Report_article)
{
Edit_Report_article(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Report_article_List");}
}
public void Edit_Report_article_List(Params_Edit_Report_article_List i_Params_Edit_Report_article_List)
{
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Report_article_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_Params_Edit_Report_article_List.My_List_To_Delete != null)
{
foreach (var oRow in i_Params_Edit_Report_article_List.My_List_To_Delete)
{
Delete_Report_article(new Params_Delete_Report_article() { REPORT_ARTICLE_ID = oRow.REPORT_ARTICLE_ID });
}
}
if (i_Params_Edit_Report_article_List.My_List_To_Edit != null)
{
foreach (var oRow in i_Params_Edit_Report_article_List.My_List_To_Edit)
{
Edit_Report_article(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Report_article_List");}
}
public void Edit_Student_List(List<Student> i_List_Student)
{
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Student_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_List_Student != null)
{
foreach (var oRow in i_List_Student)
{
Edit_Student(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Student_List");}
}
public void Edit_Student_List(Params_Edit_Student_List i_Params_Edit_Student_List)
{
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Student_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_Params_Edit_Student_List.My_List_To_Delete != null)
{
foreach (var oRow in i_Params_Edit_Student_List.My_List_To_Delete)
{
Delete_Student(new Params_Delete_Student() { STUDENT_ID = oRow.STUDENT_ID });
}
}
if (i_Params_Edit_Student_List.My_List_To_Edit != null)
{
foreach (var oRow in i_Params_Edit_Student_List.My_List_To_Edit)
{
Edit_Student(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Student_List");}
}
public void Edit_Student_report_List(List<Student_report> i_List_Student_report)
{
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Student_report_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_List_Student_report != null)
{
foreach (var oRow in i_List_Student_report)
{
Edit_Student_report(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Student_report_List");}
}
public void Edit_Student_report_List(Params_Edit_Student_report_List i_Params_Edit_Student_report_List)
{
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Student_report_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_Params_Edit_Student_report_List.My_List_To_Delete != null)
{
foreach (var oRow in i_Params_Edit_Student_report_List.My_List_To_Delete)
{
Delete_Student_report(new Params_Delete_Student_report() { STUDENT_REPORT_ID = oRow.STUDENT_REPORT_ID });
}
}
if (i_Params_Edit_Student_report_List.My_List_To_Edit != null)
{
foreach (var oRow in i_Params_Edit_Student_report_List.My_List_To_Edit)
{
Edit_Student_report(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Student_report_List");}
}
public void Edit_Teacher_List(List<Teacher> i_List_Teacher)
{
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Teacher_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_List_Teacher != null)
{
foreach (var oRow in i_List_Teacher)
{
Edit_Teacher(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Teacher_List");}
}
public void Edit_Teacher_List(Params_Edit_Teacher_List i_Params_Edit_Teacher_List)
{
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Teacher_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_Params_Edit_Teacher_List.My_List_To_Delete != null)
{
foreach (var oRow in i_Params_Edit_Teacher_List.My_List_To_Delete)
{
Delete_Teacher(new Params_Delete_Teacher() { TEACHER_ID = oRow.TEACHER_ID });
}
}
if (i_Params_Edit_Teacher_List.My_List_To_Edit != null)
{
foreach (var oRow in i_Params_Edit_Teacher_List.My_List_To_Edit)
{
Edit_Teacher(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Teacher_List");}
}
public void Edit_Teacher_category_List(List<Teacher_category> i_List_Teacher_category)
{
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Teacher_category_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_List_Teacher_category != null)
{
foreach (var oRow in i_List_Teacher_category)
{
Edit_Teacher_category(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Teacher_category_List");}
}
public void Edit_Teacher_category_List(Params_Edit_Teacher_category_List i_Params_Edit_Teacher_category_List)
{
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Teacher_category_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_Params_Edit_Teacher_category_List.My_List_To_Delete != null)
{
foreach (var oRow in i_Params_Edit_Teacher_category_List.My_List_To_Delete)
{
Delete_Teacher_category(new Params_Delete_Teacher_category() { TEACHER_CATEGORY_ID = oRow.TEACHER_CATEGORY_ID });
}
}
if (i_Params_Edit_Teacher_category_List.My_List_To_Edit != null)
{
foreach (var oRow in i_Params_Edit_Teacher_category_List.My_List_To_Edit)
{
Edit_Teacher_category(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Teacher_category_List");}
}
public void Edit_Teacher_favorite_List(List<Teacher_favorite> i_List_Teacher_favorite)
{
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Teacher_favorite_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_List_Teacher_favorite != null)
{
foreach (var oRow in i_List_Teacher_favorite)
{
Edit_Teacher_favorite(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Teacher_favorite_List");}
}
public void Edit_Teacher_favorite_List(Params_Edit_Teacher_favorite_List i_Params_Edit_Teacher_favorite_List)
{
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Teacher_favorite_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_Params_Edit_Teacher_favorite_List.My_List_To_Delete != null)
{
foreach (var oRow in i_Params_Edit_Teacher_favorite_List.My_List_To_Delete)
{
Delete_Teacher_favorite(new Params_Delete_Teacher_favorite() { TEACHER_FAVORITE_ID = oRow.TEACHER_FAVORITE_ID });
}
}
if (i_Params_Edit_Teacher_favorite_List.My_List_To_Edit != null)
{
foreach (var oRow in i_Params_Edit_Teacher_favorite_List.My_List_To_Edit)
{
Edit_Teacher_favorite(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Teacher_favorite_List");}
}
public void Edit_Teacher_rank_List(List<Teacher_rank> i_List_Teacher_rank)
{
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Teacher_rank_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_List_Teacher_rank != null)
{
foreach (var oRow in i_List_Teacher_rank)
{
Edit_Teacher_rank(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Teacher_rank_List");}
}
public void Edit_Teacher_rank_List(Params_Edit_Teacher_rank_List i_Params_Edit_Teacher_rank_List)
{
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Teacher_rank_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_Params_Edit_Teacher_rank_List.My_List_To_Delete != null)
{
foreach (var oRow in i_Params_Edit_Teacher_rank_List.My_List_To_Delete)
{
Delete_Teacher_rank(new Params_Delete_Teacher_rank() { TEACHER_RANK_ID = oRow.TEACHER_RANK_ID });
}
}
if (i_Params_Edit_Teacher_rank_List.My_List_To_Edit != null)
{
foreach (var oRow in i_Params_Edit_Teacher_rank_List.My_List_To_Edit)
{
Edit_Teacher_rank(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Teacher_rank_List");}
}
public void Edit_Teacher_report_List(List<Teacher_report> i_List_Teacher_report)
{
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Teacher_report_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_List_Teacher_report != null)
{
foreach (var oRow in i_List_Teacher_report)
{
Edit_Teacher_report(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Teacher_report_List");}
}
public void Edit_Teacher_report_List(Params_Edit_Teacher_report_List i_Params_Edit_Teacher_report_List)
{
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Teacher_report_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_Params_Edit_Teacher_report_List.My_List_To_Delete != null)
{
foreach (var oRow in i_Params_Edit_Teacher_report_List.My_List_To_Delete)
{
Delete_Teacher_report(new Params_Delete_Teacher_report() { TEACHER_REPORT_ID = oRow.TEACHER_REPORT_ID });
}
}
if (i_Params_Edit_Teacher_report_List.My_List_To_Edit != null)
{
foreach (var oRow in i_Params_Edit_Teacher_report_List.My_List_To_Edit)
{
Edit_Teacher_report(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Teacher_report_List");}
}
public void Edit_User_List(List<User> i_List_User)
{
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Edit_User_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_List_User != null)
{
foreach (var oRow in i_List_User)
{
Edit_User(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_User_List");}
}
public void Edit_User_List(Params_Edit_User_List i_Params_Edit_User_List)
{
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Edit_User_List");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
if (i_Params_Edit_User_List.My_List_To_Delete != null)
{
foreach (var oRow in i_Params_Edit_User_List.My_List_To_Delete)
{
Delete_User(new Params_Delete_User() { USER_ID = oRow.USER_ID });
}
}
if (i_Params_Edit_User_List.My_List_To_Edit != null)
{
foreach (var oRow in i_Params_Edit_User_List.My_List_To_Edit)
{
Edit_User(oRow);
}
}
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_User_List");}
}
}
}
