using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;
using System.Configuration;
using DALC;
//using System.Data.Linq;
using System.Text.RegularExpressions;
using System.Transactions;
using System.Reflection;
using System.Diagnostics;
using System.Data.SqlClient;
using System.Threading;







namespace BLC
{
public partial class BLC
{
#region Reset_Article_By_Category
public void Reset_Article_By_Category(Category i_Category, List<Article> i_Article_List)
{
#region Declaration And Initialization Section.
Params_Delete_Article_By_CATEGORY_ID oParams_Delete_Article_By_CATEGORY_ID = new Params_Delete_Article_By_CATEGORY_ID();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Article_By_Category");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Existing Article
//---------------------------------
oParams_Delete_Article_By_CATEGORY_ID.CATEGORY_ID = i_Category.CATEGORY_ID;
Delete_Article_By_CATEGORY_ID(oParams_Delete_Article_By_CATEGORY_ID);
//---------------------------------
// Edit Article
//---------------------------------
Edit_Category_WithArticle(i_Category, i_Article_List);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Article_By_Category");}
}
#endregion
#region Reset_Article_By_Category
public void Reset_Article_By_Category(Category i_Category, List<Article> i_Article_List_To_Delete,List<Article> i_Article_List_To_Create)
{
#region Declaration And Initialization Section.
Params_Delete_Article oParams_Delete_Article = new Params_Delete_Article();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Article_By_Category");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Specified Items 
//---------------------------------
 if (i_Article_List_To_Delete != null)
{
foreach (var oRow in i_Article_List_To_Delete)
{
oParams_Delete_Article.ARTICLE_ID = oRow.ARTICLE_ID;
Delete_Article(oParams_Delete_Article);
}
}
//---------------------------------
// Edit Article
//---------------------------------
Edit_Category_WithArticle(i_Category, i_Article_List_To_Create);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Article_By_Category");}
}
#endregion
#region Edit_Category_With_Article(Category i_Category,List<Article> i_ArticleList)
public void Edit_Category_WithArticle(Category i_Category,List<Article> i_List_Article)
{
#region Declaration And Initialization Section.
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Category_WithArticle");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Business Operation.
//-------------------------------
Edit_Category(i_Category);
if (i_List_Article != null)
{
foreach(Article oArticle in i_List_Article)
{
oArticle.CATEGORY_ID = i_Category.CATEGORY_ID;
Edit_Article(oArticle);
}
}
//-------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Category_WithArticle");}
}
#endregion
#region Reset_Favorite_category_By_Category
public void Reset_Favorite_category_By_Category(Category i_Category, List<Favorite_category> i_Favorite_category_List)
{
#region Declaration And Initialization Section.
Params_Delete_Favorite_category_By_CATEGORY_ID oParams_Delete_Favorite_category_By_CATEGORY_ID = new Params_Delete_Favorite_category_By_CATEGORY_ID();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Favorite_category_By_Category");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Existing Favorite_category
//---------------------------------
oParams_Delete_Favorite_category_By_CATEGORY_ID.CATEGORY_ID = i_Category.CATEGORY_ID;
Delete_Favorite_category_By_CATEGORY_ID(oParams_Delete_Favorite_category_By_CATEGORY_ID);
//---------------------------------
// Edit Favorite_category
//---------------------------------
Edit_Category_WithFavorite_category(i_Category, i_Favorite_category_List);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Favorite_category_By_Category");}
}
#endregion
#region Reset_Favorite_category_By_Category
public void Reset_Favorite_category_By_Category(Category i_Category, List<Favorite_category> i_Favorite_category_List_To_Delete,List<Favorite_category> i_Favorite_category_List_To_Create)
{
#region Declaration And Initialization Section.
Params_Delete_Favorite_category oParams_Delete_Favorite_category = new Params_Delete_Favorite_category();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Favorite_category_By_Category");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Specified Items 
//---------------------------------
 if (i_Favorite_category_List_To_Delete != null)
{
foreach (var oRow in i_Favorite_category_List_To_Delete)
{
oParams_Delete_Favorite_category.FAVORITE_CATEGORY_ID = oRow.FAVORITE_CATEGORY_ID;
Delete_Favorite_category(oParams_Delete_Favorite_category);
}
}
//---------------------------------
// Edit Favorite_category
//---------------------------------
Edit_Category_WithFavorite_category(i_Category, i_Favorite_category_List_To_Create);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Favorite_category_By_Category");}
}
#endregion
#region Edit_Category_With_Favorite_category(Category i_Category,List<Favorite_category> i_Favorite_categoryList)
public void Edit_Category_WithFavorite_category(Category i_Category,List<Favorite_category> i_List_Favorite_category)
{
#region Declaration And Initialization Section.
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Category_WithFavorite_category");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Business Operation.
//-------------------------------
Edit_Category(i_Category);
if (i_List_Favorite_category != null)
{
foreach(Favorite_category oFavorite_category in i_List_Favorite_category)
{
oFavorite_category.CATEGORY_ID = i_Category.CATEGORY_ID;
Edit_Favorite_category(oFavorite_category);
}
}
//-------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Category_WithFavorite_category");}
}
#endregion
#region Reset_Question_By_Category
public void Reset_Question_By_Category(Category i_Category, List<Question> i_Question_List)
{
#region Declaration And Initialization Section.
Params_Delete_Question_By_CATEGORY_ID oParams_Delete_Question_By_CATEGORY_ID = new Params_Delete_Question_By_CATEGORY_ID();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Question_By_Category");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Existing Question
//---------------------------------
oParams_Delete_Question_By_CATEGORY_ID.CATEGORY_ID = i_Category.CATEGORY_ID;
Delete_Question_By_CATEGORY_ID(oParams_Delete_Question_By_CATEGORY_ID);
//---------------------------------
// Edit Question
//---------------------------------
Edit_Category_WithQuestion(i_Category, i_Question_List);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Question_By_Category");}
}
#endregion
#region Reset_Question_By_Category
public void Reset_Question_By_Category(Category i_Category, List<Question> i_Question_List_To_Delete,List<Question> i_Question_List_To_Create)
{
#region Declaration And Initialization Section.
Params_Delete_Question oParams_Delete_Question = new Params_Delete_Question();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Question_By_Category");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Specified Items 
//---------------------------------
 if (i_Question_List_To_Delete != null)
{
foreach (var oRow in i_Question_List_To_Delete)
{
oParams_Delete_Question.QUESTION_ID = oRow.QUESTION_ID;
Delete_Question(oParams_Delete_Question);
}
}
//---------------------------------
// Edit Question
//---------------------------------
Edit_Category_WithQuestion(i_Category, i_Question_List_To_Create);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Question_By_Category");}
}
#endregion
#region Edit_Category_With_Question(Category i_Category,List<Question> i_QuestionList)
public void Edit_Category_WithQuestion(Category i_Category,List<Question> i_List_Question)
{
#region Declaration And Initialization Section.
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Category_WithQuestion");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Business Operation.
//-------------------------------
Edit_Category(i_Category);
if (i_List_Question != null)
{
foreach(Question oQuestion in i_List_Question)
{
oQuestion.CATEGORY_ID = i_Category.CATEGORY_ID;
Edit_Question(oQuestion);
}
}
//-------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Category_WithQuestion");}
}
#endregion
#region Reset_Teacher_category_By_Category
public void Reset_Teacher_category_By_Category(Category i_Category, List<Teacher_category> i_Teacher_category_List)
{
#region Declaration And Initialization Section.
Params_Delete_Teacher_category_By_CATEGORY_ID oParams_Delete_Teacher_category_By_CATEGORY_ID = new Params_Delete_Teacher_category_By_CATEGORY_ID();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Teacher_category_By_Category");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Existing Teacher_category
//---------------------------------
oParams_Delete_Teacher_category_By_CATEGORY_ID.CATEGORY_ID = i_Category.CATEGORY_ID;
Delete_Teacher_category_By_CATEGORY_ID(oParams_Delete_Teacher_category_By_CATEGORY_ID);
//---------------------------------
// Edit Teacher_category
//---------------------------------
Edit_Category_WithTeacher_category(i_Category, i_Teacher_category_List);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Teacher_category_By_Category");}
}
#endregion
#region Reset_Teacher_category_By_Category
public void Reset_Teacher_category_By_Category(Category i_Category, List<Teacher_category> i_Teacher_category_List_To_Delete,List<Teacher_category> i_Teacher_category_List_To_Create)
{
#region Declaration And Initialization Section.
Params_Delete_Teacher_category oParams_Delete_Teacher_category = new Params_Delete_Teacher_category();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Teacher_category_By_Category");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Specified Items 
//---------------------------------
 if (i_Teacher_category_List_To_Delete != null)
{
foreach (var oRow in i_Teacher_category_List_To_Delete)
{
oParams_Delete_Teacher_category.TEACHER_CATEGORY_ID = oRow.TEACHER_CATEGORY_ID;
Delete_Teacher_category(oParams_Delete_Teacher_category);
}
}
//---------------------------------
// Edit Teacher_category
//---------------------------------
Edit_Category_WithTeacher_category(i_Category, i_Teacher_category_List_To_Create);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Teacher_category_By_Category");}
}
#endregion
#region Edit_Category_With_Teacher_category(Category i_Category,List<Teacher_category> i_Teacher_categoryList)
public void Edit_Category_WithTeacher_category(Category i_Category,List<Teacher_category> i_List_Teacher_category)
{
#region Declaration And Initialization Section.
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Category_WithTeacher_category");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Business Operation.
//-------------------------------
Edit_Category(i_Category);
if (i_List_Teacher_category != null)
{
foreach(Teacher_category oTeacher_category in i_List_Teacher_category)
{
oTeacher_category.CATEGORY_ID = i_Category.CATEGORY_ID;
Edit_Teacher_category(oTeacher_category);
}
}
//-------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Category_WithTeacher_category");}
}
#endregion
#region Edit_Category_WithRelatedData(Category i_Category,List<Article> i_List_Article,List<Favorite_category> i_List_Favorite_category,List<Question> i_List_Question,List<Teacher_category> i_List_Teacher_category)
public void Edit_Category_WithRelatedData(Category i_Category,List<Article> i_List_Article,List<Favorite_category> i_List_Favorite_category,List<Question> i_List_Question,List<Teacher_category> i_List_Teacher_category)
{
#region Declaration And Initialization Section.
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Category_WithRelatedData");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Business Operation.
//-------------------------------
Edit_Category(i_Category);
if (i_List_Article != null)
{
foreach(Article oArticle in i_List_Article)
{
oArticle.CATEGORY_ID = i_Category.CATEGORY_ID;
Edit_Article(oArticle);
}
}
if (i_List_Favorite_category != null)
{
foreach(Favorite_category oFavorite_category in i_List_Favorite_category)
{
oFavorite_category.CATEGORY_ID = i_Category.CATEGORY_ID;
Edit_Favorite_category(oFavorite_category);
}
}
if (i_List_Question != null)
{
foreach(Question oQuestion in i_List_Question)
{
oQuestion.CATEGORY_ID = i_Category.CATEGORY_ID;
Edit_Question(oQuestion);
}
}
if (i_List_Teacher_category != null)
{
foreach(Teacher_category oTeacher_category in i_List_Teacher_category)
{
oTeacher_category.CATEGORY_ID = i_Category.CATEGORY_ID;
Edit_Teacher_category(oTeacher_category);
}
}
//-------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Category_WithRelatedData");}
}
#endregion
#region Delete_Category_With_Children(Category i_Category)
public void Delete_Category_With_Children(Category i_Category)
{
 #region Declaration And Initialization Section.
Params_Delete_Category oParams_Delete_Category = new Params_Delete_Category();
Params_Delete_Article_By_CATEGORY_ID oParams_Delete_Article_By_CATEGORY_ID = new Params_Delete_Article_By_CATEGORY_ID();
Params_Delete_Favorite_category_By_CATEGORY_ID oParams_Delete_Favorite_category_By_CATEGORY_ID = new Params_Delete_Favorite_category_By_CATEGORY_ID();
Params_Delete_Question_By_CATEGORY_ID oParams_Delete_Question_By_CATEGORY_ID = new Params_Delete_Question_By_CATEGORY_ID();
Params_Delete_Teacher_category_By_CATEGORY_ID oParams_Delete_Teacher_category_By_CATEGORY_ID = new Params_Delete_Teacher_category_By_CATEGORY_ID();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Category_With_Children");}
 #region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
//-------------------------
oParams_Delete_Article_By_CATEGORY_ID.CATEGORY_ID = i_Category.CATEGORY_ID;
Delete_Article_By_CATEGORY_ID(oParams_Delete_Article_By_CATEGORY_ID);
oParams_Delete_Favorite_category_By_CATEGORY_ID.CATEGORY_ID = i_Category.CATEGORY_ID;
Delete_Favorite_category_By_CATEGORY_ID(oParams_Delete_Favorite_category_By_CATEGORY_ID);
oParams_Delete_Question_By_CATEGORY_ID.CATEGORY_ID = i_Category.CATEGORY_ID;
Delete_Question_By_CATEGORY_ID(oParams_Delete_Question_By_CATEGORY_ID);
oParams_Delete_Teacher_category_By_CATEGORY_ID.CATEGORY_ID = i_Category.CATEGORY_ID;
Delete_Teacher_category_By_CATEGORY_ID(oParams_Delete_Teacher_category_By_CATEGORY_ID);
//-------------------------

//-------------------------
oParams_Delete_Category.CATEGORY_ID = i_Category.CATEGORY_ID;
Delete_Category(oParams_Delete_Category);
//-------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Category_With_Children");}
}
#endregion
#region Reset_Answer_By_Question
public void Reset_Answer_By_Question(Question i_Question, List<Answer> i_Answer_List)
{
#region Declaration And Initialization Section.
Params_Delete_Answer_By_QUESTION_ID oParams_Delete_Answer_By_QUESTION_ID = new Params_Delete_Answer_By_QUESTION_ID();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Answer_By_Question");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Existing Answer
//---------------------------------
oParams_Delete_Answer_By_QUESTION_ID.QUESTION_ID = i_Question.QUESTION_ID;
Delete_Answer_By_QUESTION_ID(oParams_Delete_Answer_By_QUESTION_ID);
//---------------------------------
// Edit Answer
//---------------------------------
Edit_Question_WithAnswer(i_Question, i_Answer_List);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Answer_By_Question");}
}
#endregion
#region Reset_Answer_By_Question
public void Reset_Answer_By_Question(Question i_Question, List<Answer> i_Answer_List_To_Delete,List<Answer> i_Answer_List_To_Create)
{
#region Declaration And Initialization Section.
Params_Delete_Answer oParams_Delete_Answer = new Params_Delete_Answer();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Answer_By_Question");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Specified Items 
//---------------------------------
 if (i_Answer_List_To_Delete != null)
{
foreach (var oRow in i_Answer_List_To_Delete)
{
oParams_Delete_Answer.ANSWER_ID = oRow.ANSWER_ID;
Delete_Answer(oParams_Delete_Answer);
}
}
//---------------------------------
// Edit Answer
//---------------------------------
Edit_Question_WithAnswer(i_Question, i_Answer_List_To_Create);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Answer_By_Question");}
}
#endregion
#region Edit_Question_With_Answer(Question i_Question,List<Answer> i_AnswerList)
public void Edit_Question_WithAnswer(Question i_Question,List<Answer> i_List_Answer)
{
#region Declaration And Initialization Section.
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Question_WithAnswer");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Business Operation.
//-------------------------------
Edit_Question(i_Question);
if (i_List_Answer != null)
{
foreach(Answer oAnswer in i_List_Answer)
{
oAnswer.QUESTION_ID = i_Question.QUESTION_ID;
Edit_Answer(oAnswer);
}
}
//-------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Question_WithAnswer");}
}
#endregion
#region Reset_Mark_question_By_Question
public void Reset_Mark_question_By_Question(Question i_Question, List<Mark_question> i_Mark_question_List)
{
#region Declaration And Initialization Section.
Params_Delete_Mark_question_By_QUESTION_ID oParams_Delete_Mark_question_By_QUESTION_ID = new Params_Delete_Mark_question_By_QUESTION_ID();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Mark_question_By_Question");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Existing Mark_question
//---------------------------------
oParams_Delete_Mark_question_By_QUESTION_ID.QUESTION_ID = i_Question.QUESTION_ID;
Delete_Mark_question_By_QUESTION_ID(oParams_Delete_Mark_question_By_QUESTION_ID);
//---------------------------------
// Edit Mark_question
//---------------------------------
Edit_Question_WithMark_question(i_Question, i_Mark_question_List);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Mark_question_By_Question");}
}
#endregion
#region Reset_Mark_question_By_Question
public void Reset_Mark_question_By_Question(Question i_Question, List<Mark_question> i_Mark_question_List_To_Delete,List<Mark_question> i_Mark_question_List_To_Create)
{
#region Declaration And Initialization Section.
Params_Delete_Mark_question oParams_Delete_Mark_question = new Params_Delete_Mark_question();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Mark_question_By_Question");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Specified Items 
//---------------------------------
 if (i_Mark_question_List_To_Delete != null)
{
foreach (var oRow in i_Mark_question_List_To_Delete)
{
oParams_Delete_Mark_question.MARK_QUESTION_ID = oRow.MARK_QUESTION_ID;
Delete_Mark_question(oParams_Delete_Mark_question);
}
}
//---------------------------------
// Edit Mark_question
//---------------------------------
Edit_Question_WithMark_question(i_Question, i_Mark_question_List_To_Create);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Mark_question_By_Question");}
}
#endregion
#region Edit_Question_With_Mark_question(Question i_Question,List<Mark_question> i_Mark_questionList)
public void Edit_Question_WithMark_question(Question i_Question,List<Mark_question> i_List_Mark_question)
{
#region Declaration And Initialization Section.
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Question_WithMark_question");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Business Operation.
//-------------------------------
Edit_Question(i_Question);
if (i_List_Mark_question != null)
{
foreach(Mark_question oMark_question in i_List_Mark_question)
{
oMark_question.QUESTION_ID = i_Question.QUESTION_ID;
Edit_Mark_question(oMark_question);
}
}
//-------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Question_WithMark_question");}
}
#endregion
#region Reset_Notification_By_Question
public void Reset_Notification_By_Question(Question i_Question, List<Notification> i_Notification_List)
{
#region Declaration And Initialization Section.
Params_Delete_Notification_By_QUESTION_ID oParams_Delete_Notification_By_QUESTION_ID = new Params_Delete_Notification_By_QUESTION_ID();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Notification_By_Question");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Existing Notification
//---------------------------------
oParams_Delete_Notification_By_QUESTION_ID.QUESTION_ID = i_Question.QUESTION_ID;
Delete_Notification_By_QUESTION_ID(oParams_Delete_Notification_By_QUESTION_ID);
//---------------------------------
// Edit Notification
//---------------------------------
Edit_Question_WithNotification(i_Question, i_Notification_List);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Notification_By_Question");}
}
#endregion
#region Reset_Notification_By_Question
public void Reset_Notification_By_Question(Question i_Question, List<Notification> i_Notification_List_To_Delete,List<Notification> i_Notification_List_To_Create)
{
#region Declaration And Initialization Section.
Params_Delete_Notification oParams_Delete_Notification = new Params_Delete_Notification();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Notification_By_Question");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Specified Items 
//---------------------------------
 if (i_Notification_List_To_Delete != null)
{
foreach (var oRow in i_Notification_List_To_Delete)
{
oParams_Delete_Notification.NOTIFICATION_ID = oRow.NOTIFICATION_ID;
Delete_Notification(oParams_Delete_Notification);
}
}
//---------------------------------
// Edit Notification
//---------------------------------
Edit_Question_WithNotification(i_Question, i_Notification_List_To_Create);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Notification_By_Question");}
}
#endregion
#region Edit_Question_With_Notification(Question i_Question,List<Notification> i_NotificationList)
public void Edit_Question_WithNotification(Question i_Question,List<Notification> i_List_Notification)
{
#region Declaration And Initialization Section.
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Question_WithNotification");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Business Operation.
//-------------------------------
Edit_Question(i_Question);
if (i_List_Notification != null)
{
foreach(Notification oNotification in i_List_Notification)
{
oNotification.QUESTION_ID = i_Question.QUESTION_ID;
Edit_Notification(oNotification);
}
}
//-------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Question_WithNotification");}
}
#endregion
#region Reset_Question_report_By_Question
public void Reset_Question_report_By_Question(Question i_Question, List<Question_report> i_Question_report_List)
{
#region Declaration And Initialization Section.
Params_Delete_Question_report_By_QUESTION_ID oParams_Delete_Question_report_By_QUESTION_ID = new Params_Delete_Question_report_By_QUESTION_ID();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Question_report_By_Question");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Existing Question_report
//---------------------------------
oParams_Delete_Question_report_By_QUESTION_ID.QUESTION_ID = i_Question.QUESTION_ID;
Delete_Question_report_By_QUESTION_ID(oParams_Delete_Question_report_By_QUESTION_ID);
//---------------------------------
// Edit Question_report
//---------------------------------
Edit_Question_WithQuestion_report(i_Question, i_Question_report_List);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Question_report_By_Question");}
}
#endregion
#region Reset_Question_report_By_Question
public void Reset_Question_report_By_Question(Question i_Question, List<Question_report> i_Question_report_List_To_Delete,List<Question_report> i_Question_report_List_To_Create)
{
#region Declaration And Initialization Section.
Params_Delete_Question_report oParams_Delete_Question_report = new Params_Delete_Question_report();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Question_report_By_Question");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Specified Items 
//---------------------------------
 if (i_Question_report_List_To_Delete != null)
{
foreach (var oRow in i_Question_report_List_To_Delete)
{
oParams_Delete_Question_report.QUESTION_REPORT_ID = oRow.QUESTION_REPORT_ID;
Delete_Question_report(oParams_Delete_Question_report);
}
}
//---------------------------------
// Edit Question_report
//---------------------------------
Edit_Question_WithQuestion_report(i_Question, i_Question_report_List_To_Create);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Question_report_By_Question");}
}
#endregion
#region Edit_Question_With_Question_report(Question i_Question,List<Question_report> i_Question_reportList)
public void Edit_Question_WithQuestion_report(Question i_Question,List<Question_report> i_List_Question_report)
{
#region Declaration And Initialization Section.
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Question_WithQuestion_report");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Business Operation.
//-------------------------------
Edit_Question(i_Question);
if (i_List_Question_report != null)
{
foreach(Question_report oQuestion_report in i_List_Question_report)
{
oQuestion_report.QUESTION_ID = i_Question.QUESTION_ID;
Edit_Question_report(oQuestion_report);
}
}
//-------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Question_WithQuestion_report");}
}
#endregion
#region Reset_Question_token_By_Question
public void Reset_Question_token_By_Question(Question i_Question, List<Question_token> i_Question_token_List)
{
#region Declaration And Initialization Section.
Params_Delete_Question_token_By_QUESTION_ID oParams_Delete_Question_token_By_QUESTION_ID = new Params_Delete_Question_token_By_QUESTION_ID();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Question_token_By_Question");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Existing Question_token
//---------------------------------
oParams_Delete_Question_token_By_QUESTION_ID.QUESTION_ID = i_Question.QUESTION_ID;
Delete_Question_token_By_QUESTION_ID(oParams_Delete_Question_token_By_QUESTION_ID);
//---------------------------------
// Edit Question_token
//---------------------------------
Edit_Question_WithQuestion_token(i_Question, i_Question_token_List);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Question_token_By_Question");}
}
#endregion
#region Reset_Question_token_By_Question
public void Reset_Question_token_By_Question(Question i_Question, List<Question_token> i_Question_token_List_To_Delete,List<Question_token> i_Question_token_List_To_Create)
{
#region Declaration And Initialization Section.
Params_Delete_Question_token oParams_Delete_Question_token = new Params_Delete_Question_token();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Question_token_By_Question");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Specified Items 
//---------------------------------
 if (i_Question_token_List_To_Delete != null)
{
foreach (var oRow in i_Question_token_List_To_Delete)
{
oParams_Delete_Question_token.QUESTION_TOKEN_ID = oRow.QUESTION_TOKEN_ID;
Delete_Question_token(oParams_Delete_Question_token);
}
}
//---------------------------------
// Edit Question_token
//---------------------------------
Edit_Question_WithQuestion_token(i_Question, i_Question_token_List_To_Create);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Question_token_By_Question");}
}
#endregion
#region Edit_Question_With_Question_token(Question i_Question,List<Question_token> i_Question_tokenList)
public void Edit_Question_WithQuestion_token(Question i_Question,List<Question_token> i_List_Question_token)
{
#region Declaration And Initialization Section.
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Question_WithQuestion_token");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Business Operation.
//-------------------------------
Edit_Question(i_Question);
if (i_List_Question_token != null)
{
foreach(Question_token oQuestion_token in i_List_Question_token)
{
oQuestion_token.QUESTION_ID = i_Question.QUESTION_ID;
Edit_Question_token(oQuestion_token);
}
}
//-------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Question_WithQuestion_token");}
}
#endregion
#region Edit_Question_WithRelatedData(Question i_Question,List<Answer> i_List_Answer,List<Mark_question> i_List_Mark_question,List<Notification> i_List_Notification,List<Question_report> i_List_Question_report,List<Question_token> i_List_Question_token)
public void Edit_Question_WithRelatedData(Question i_Question,List<Answer> i_List_Answer,List<Mark_question> i_List_Mark_question,List<Notification> i_List_Notification,List<Question_report> i_List_Question_report,List<Question_token> i_List_Question_token)
{
#region Declaration And Initialization Section.
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Question_WithRelatedData");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Business Operation.
//-------------------------------
Edit_Question(i_Question);
if (i_List_Answer != null)
{
foreach(Answer oAnswer in i_List_Answer)
{
oAnswer.QUESTION_ID = i_Question.QUESTION_ID;
Edit_Answer(oAnswer);
}
}
if (i_List_Mark_question != null)
{
foreach(Mark_question oMark_question in i_List_Mark_question)
{
oMark_question.QUESTION_ID = i_Question.QUESTION_ID;
Edit_Mark_question(oMark_question);
}
}
if (i_List_Notification != null)
{
foreach(Notification oNotification in i_List_Notification)
{
oNotification.QUESTION_ID = i_Question.QUESTION_ID;
Edit_Notification(oNotification);
}
}
if (i_List_Question_report != null)
{
foreach(Question_report oQuestion_report in i_List_Question_report)
{
oQuestion_report.QUESTION_ID = i_Question.QUESTION_ID;
Edit_Question_report(oQuestion_report);
}
}
if (i_List_Question_token != null)
{
foreach(Question_token oQuestion_token in i_List_Question_token)
{
oQuestion_token.QUESTION_ID = i_Question.QUESTION_ID;
Edit_Question_token(oQuestion_token);
}
}
//-------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Question_WithRelatedData");}
}
#endregion
#region Delete_Question_With_Children(Question i_Question)
public void Delete_Question_With_Children(Question i_Question)
{
 #region Declaration And Initialization Section.
Params_Delete_Question oParams_Delete_Question = new Params_Delete_Question();
Params_Delete_Answer_By_QUESTION_ID oParams_Delete_Answer_By_QUESTION_ID = new Params_Delete_Answer_By_QUESTION_ID();
Params_Delete_Mark_question_By_QUESTION_ID oParams_Delete_Mark_question_By_QUESTION_ID = new Params_Delete_Mark_question_By_QUESTION_ID();
Params_Delete_Notification_By_QUESTION_ID oParams_Delete_Notification_By_QUESTION_ID = new Params_Delete_Notification_By_QUESTION_ID();
Params_Delete_Question_report_By_QUESTION_ID oParams_Delete_Question_report_By_QUESTION_ID = new Params_Delete_Question_report_By_QUESTION_ID();
Params_Delete_Question_token_By_QUESTION_ID oParams_Delete_Question_token_By_QUESTION_ID = new Params_Delete_Question_token_By_QUESTION_ID();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Question_With_Children");}
 #region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
//-------------------------
oParams_Delete_Answer_By_QUESTION_ID.QUESTION_ID = i_Question.QUESTION_ID;
Delete_Answer_By_QUESTION_ID(oParams_Delete_Answer_By_QUESTION_ID);
oParams_Delete_Mark_question_By_QUESTION_ID.QUESTION_ID = i_Question.QUESTION_ID;
Delete_Mark_question_By_QUESTION_ID(oParams_Delete_Mark_question_By_QUESTION_ID);
oParams_Delete_Notification_By_QUESTION_ID.QUESTION_ID = i_Question.QUESTION_ID;
Delete_Notification_By_QUESTION_ID(oParams_Delete_Notification_By_QUESTION_ID);
oParams_Delete_Question_report_By_QUESTION_ID.QUESTION_ID = i_Question.QUESTION_ID;
Delete_Question_report_By_QUESTION_ID(oParams_Delete_Question_report_By_QUESTION_ID);
oParams_Delete_Question_token_By_QUESTION_ID.QUESTION_ID = i_Question.QUESTION_ID;
Delete_Question_token_By_QUESTION_ID(oParams_Delete_Question_token_By_QUESTION_ID);
//-------------------------

//-------------------------
oParams_Delete_Question.QUESTION_ID = i_Question.QUESTION_ID;
Delete_Question(oParams_Delete_Question);
//-------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Question_With_Children");}
}
#endregion
#region Reset_Appreciate_By_Article
public void Reset_Appreciate_By_Article(Article i_Article, List<Appreciate> i_Appreciate_List)
{
#region Declaration And Initialization Section.
Params_Delete_Appreciate_By_ARTICLE_ID oParams_Delete_Appreciate_By_ARTICLE_ID = new Params_Delete_Appreciate_By_ARTICLE_ID();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Appreciate_By_Article");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Existing Appreciate
//---------------------------------
oParams_Delete_Appreciate_By_ARTICLE_ID.ARTICLE_ID = i_Article.ARTICLE_ID;
Delete_Appreciate_By_ARTICLE_ID(oParams_Delete_Appreciate_By_ARTICLE_ID);
//---------------------------------
// Edit Appreciate
//---------------------------------
Edit_Article_WithAppreciate(i_Article, i_Appreciate_List);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Appreciate_By_Article");}
}
#endregion
#region Reset_Appreciate_By_Article
public void Reset_Appreciate_By_Article(Article i_Article, List<Appreciate> i_Appreciate_List_To_Delete,List<Appreciate> i_Appreciate_List_To_Create)
{
#region Declaration And Initialization Section.
Params_Delete_Appreciate oParams_Delete_Appreciate = new Params_Delete_Appreciate();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Appreciate_By_Article");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Specified Items 
//---------------------------------
 if (i_Appreciate_List_To_Delete != null)
{
foreach (var oRow in i_Appreciate_List_To_Delete)
{
oParams_Delete_Appreciate.APPRECIATE_ID = oRow.APPRECIATE_ID;
Delete_Appreciate(oParams_Delete_Appreciate);
}
}
//---------------------------------
// Edit Appreciate
//---------------------------------
Edit_Article_WithAppreciate(i_Article, i_Appreciate_List_To_Create);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Appreciate_By_Article");}
}
#endregion
#region Edit_Article_With_Appreciate(Article i_Article,List<Appreciate> i_AppreciateList)
public void Edit_Article_WithAppreciate(Article i_Article,List<Appreciate> i_List_Appreciate)
{
#region Declaration And Initialization Section.
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Article_WithAppreciate");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Business Operation.
//-------------------------------
Edit_Article(i_Article);
if (i_List_Appreciate != null)
{
foreach(Appreciate oAppreciate in i_List_Appreciate)
{
oAppreciate.ARTICLE_ID = i_Article.ARTICLE_ID;
Edit_Appreciate(oAppreciate);
}
}
//-------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Article_WithAppreciate");}
}
#endregion
#region Reset_Notification_By_Article
public void Reset_Notification_By_Article(Article i_Article, List<Notification> i_Notification_List)
{
#region Declaration And Initialization Section.
Params_Delete_Notification_By_ARTICLE_ID oParams_Delete_Notification_By_ARTICLE_ID = new Params_Delete_Notification_By_ARTICLE_ID();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Notification_By_Article");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Existing Notification
//---------------------------------
oParams_Delete_Notification_By_ARTICLE_ID.ARTICLE_ID = i_Article.ARTICLE_ID;
Delete_Notification_By_ARTICLE_ID(oParams_Delete_Notification_By_ARTICLE_ID);
//---------------------------------
// Edit Notification
//---------------------------------
Edit_Article_WithNotification(i_Article, i_Notification_List);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Notification_By_Article");}
}
#endregion
#region Reset_Notification_By_Article
public void Reset_Notification_By_Article(Article i_Article, List<Notification> i_Notification_List_To_Delete,List<Notification> i_Notification_List_To_Create)
{
#region Declaration And Initialization Section.
Params_Delete_Notification oParams_Delete_Notification = new Params_Delete_Notification();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Notification_By_Article");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Specified Items 
//---------------------------------
 if (i_Notification_List_To_Delete != null)
{
foreach (var oRow in i_Notification_List_To_Delete)
{
oParams_Delete_Notification.NOTIFICATION_ID = oRow.NOTIFICATION_ID;
Delete_Notification(oParams_Delete_Notification);
}
}
//---------------------------------
// Edit Notification
//---------------------------------
Edit_Article_WithNotification(i_Article, i_Notification_List_To_Create);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Notification_By_Article");}
}
#endregion
#region Edit_Article_With_Notification(Article i_Article,List<Notification> i_NotificationList)
public void Edit_Article_WithNotification(Article i_Article,List<Notification> i_List_Notification)
{
#region Declaration And Initialization Section.
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Article_WithNotification");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Business Operation.
//-------------------------------
Edit_Article(i_Article);
if (i_List_Notification != null)
{
foreach(Notification oNotification in i_List_Notification)
{
oNotification.ARTICLE_ID = i_Article.ARTICLE_ID;
Edit_Notification(oNotification);
}
}
//-------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Article_WithNotification");}
}
#endregion
#region Reset_Report_article_By_Article
public void Reset_Report_article_By_Article(Article i_Article, List<Report_article> i_Report_article_List)
{
#region Declaration And Initialization Section.
Params_Delete_Report_article_By_ARTICLE_ID oParams_Delete_Report_article_By_ARTICLE_ID = new Params_Delete_Report_article_By_ARTICLE_ID();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Report_article_By_Article");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Existing Report_article
//---------------------------------
oParams_Delete_Report_article_By_ARTICLE_ID.ARTICLE_ID = i_Article.ARTICLE_ID;
Delete_Report_article_By_ARTICLE_ID(oParams_Delete_Report_article_By_ARTICLE_ID);
//---------------------------------
// Edit Report_article
//---------------------------------
Edit_Article_WithReport_article(i_Article, i_Report_article_List);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Report_article_By_Article");}
}
#endregion
#region Reset_Report_article_By_Article
public void Reset_Report_article_By_Article(Article i_Article, List<Report_article> i_Report_article_List_To_Delete,List<Report_article> i_Report_article_List_To_Create)
{
#region Declaration And Initialization Section.
Params_Delete_Report_article oParams_Delete_Report_article = new Params_Delete_Report_article();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Report_article_By_Article");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Specified Items 
//---------------------------------
 if (i_Report_article_List_To_Delete != null)
{
foreach (var oRow in i_Report_article_List_To_Delete)
{
oParams_Delete_Report_article.REPORT_ARTICLE_ID = oRow.REPORT_ARTICLE_ID;
Delete_Report_article(oParams_Delete_Report_article);
}
}
//---------------------------------
// Edit Report_article
//---------------------------------
Edit_Article_WithReport_article(i_Article, i_Report_article_List_To_Create);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Report_article_By_Article");}
}
#endregion
#region Edit_Article_With_Report_article(Article i_Article,List<Report_article> i_Report_articleList)
public void Edit_Article_WithReport_article(Article i_Article,List<Report_article> i_List_Report_article)
{
#region Declaration And Initialization Section.
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Article_WithReport_article");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Business Operation.
//-------------------------------
Edit_Article(i_Article);
if (i_List_Report_article != null)
{
foreach(Report_article oReport_article in i_List_Report_article)
{
oReport_article.ARTICLE_ID = i_Article.ARTICLE_ID;
Edit_Report_article(oReport_article);
}
}
//-------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Article_WithReport_article");}
}
#endregion
#region Edit_Article_WithRelatedData(Article i_Article,List<Appreciate> i_List_Appreciate,List<Notification> i_List_Notification,List<Report_article> i_List_Report_article)
public void Edit_Article_WithRelatedData(Article i_Article,List<Appreciate> i_List_Appreciate,List<Notification> i_List_Notification,List<Report_article> i_List_Report_article)
{
#region Declaration And Initialization Section.
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Article_WithRelatedData");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Business Operation.
//-------------------------------
Edit_Article(i_Article);
if (i_List_Appreciate != null)
{
foreach(Appreciate oAppreciate in i_List_Appreciate)
{
oAppreciate.ARTICLE_ID = i_Article.ARTICLE_ID;
Edit_Appreciate(oAppreciate);
}
}
if (i_List_Notification != null)
{
foreach(Notification oNotification in i_List_Notification)
{
oNotification.ARTICLE_ID = i_Article.ARTICLE_ID;
Edit_Notification(oNotification);
}
}
if (i_List_Report_article != null)
{
foreach(Report_article oReport_article in i_List_Report_article)
{
oReport_article.ARTICLE_ID = i_Article.ARTICLE_ID;
Edit_Report_article(oReport_article);
}
}
//-------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Article_WithRelatedData");}
}
#endregion
#region Delete_Article_With_Children(Article i_Article)
public void Delete_Article_With_Children(Article i_Article)
{
 #region Declaration And Initialization Section.
Params_Delete_Article oParams_Delete_Article = new Params_Delete_Article();
Params_Delete_Appreciate_By_ARTICLE_ID oParams_Delete_Appreciate_By_ARTICLE_ID = new Params_Delete_Appreciate_By_ARTICLE_ID();
Params_Delete_Notification_By_ARTICLE_ID oParams_Delete_Notification_By_ARTICLE_ID = new Params_Delete_Notification_By_ARTICLE_ID();
Params_Delete_Report_article_By_ARTICLE_ID oParams_Delete_Report_article_By_ARTICLE_ID = new Params_Delete_Report_article_By_ARTICLE_ID();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Article_With_Children");}
 #region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
//-------------------------
oParams_Delete_Appreciate_By_ARTICLE_ID.ARTICLE_ID = i_Article.ARTICLE_ID;
Delete_Appreciate_By_ARTICLE_ID(oParams_Delete_Appreciate_By_ARTICLE_ID);
oParams_Delete_Notification_By_ARTICLE_ID.ARTICLE_ID = i_Article.ARTICLE_ID;
Delete_Notification_By_ARTICLE_ID(oParams_Delete_Notification_By_ARTICLE_ID);
oParams_Delete_Report_article_By_ARTICLE_ID.ARTICLE_ID = i_Article.ARTICLE_ID;
Delete_Report_article_By_ARTICLE_ID(oParams_Delete_Report_article_By_ARTICLE_ID);
//-------------------------

//-------------------------
oParams_Delete_Article.ARTICLE_ID = i_Article.ARTICLE_ID;
Delete_Article(oParams_Delete_Article);
//-------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Article_With_Children");}
}
#endregion
#region Reset_Answer_report_By_Answer
public void Reset_Answer_report_By_Answer(Answer i_Answer, List<Answer_report> i_Answer_report_List)
{
#region Declaration And Initialization Section.
Params_Delete_Answer_report_By_ANSWER_ID oParams_Delete_Answer_report_By_ANSWER_ID = new Params_Delete_Answer_report_By_ANSWER_ID();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Answer_report_By_Answer");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Existing Answer_report
//---------------------------------
oParams_Delete_Answer_report_By_ANSWER_ID.ANSWER_ID = i_Answer.ANSWER_ID;
Delete_Answer_report_By_ANSWER_ID(oParams_Delete_Answer_report_By_ANSWER_ID);
//---------------------------------
// Edit Answer_report
//---------------------------------
Edit_Answer_WithAnswer_report(i_Answer, i_Answer_report_List);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Answer_report_By_Answer");}
}
#endregion
#region Reset_Answer_report_By_Answer
public void Reset_Answer_report_By_Answer(Answer i_Answer, List<Answer_report> i_Answer_report_List_To_Delete,List<Answer_report> i_Answer_report_List_To_Create)
{
#region Declaration And Initialization Section.
Params_Delete_Answer_report oParams_Delete_Answer_report = new Params_Delete_Answer_report();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Answer_report_By_Answer");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Specified Items 
//---------------------------------
 if (i_Answer_report_List_To_Delete != null)
{
foreach (var oRow in i_Answer_report_List_To_Delete)
{
oParams_Delete_Answer_report.ANSWER_REPORT_ID = oRow.ANSWER_REPORT_ID;
Delete_Answer_report(oParams_Delete_Answer_report);
}
}
//---------------------------------
// Edit Answer_report
//---------------------------------
Edit_Answer_WithAnswer_report(i_Answer, i_Answer_report_List_To_Create);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Answer_report_By_Answer");}
}
#endregion
#region Edit_Answer_With_Answer_report(Answer i_Answer,List<Answer_report> i_Answer_reportList)
public void Edit_Answer_WithAnswer_report(Answer i_Answer,List<Answer_report> i_List_Answer_report)
{
#region Declaration And Initialization Section.
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Answer_WithAnswer_report");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Business Operation.
//-------------------------------
Edit_Answer(i_Answer);
if (i_List_Answer_report != null)
{
foreach(Answer_report oAnswer_report in i_List_Answer_report)
{
oAnswer_report.ANSWER_ID = i_Answer.ANSWER_ID;
Edit_Answer_report(oAnswer_report);
}
}
//-------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Answer_WithAnswer_report");}
}
#endregion
#region Reset_Evaluation_By_Answer
public void Reset_Evaluation_By_Answer(Answer i_Answer, List<Evaluation> i_Evaluation_List)
{
#region Declaration And Initialization Section.
Params_Delete_Evaluation_By_ANSWER_ID oParams_Delete_Evaluation_By_ANSWER_ID = new Params_Delete_Evaluation_By_ANSWER_ID();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Evaluation_By_Answer");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Existing Evaluation
//---------------------------------
oParams_Delete_Evaluation_By_ANSWER_ID.ANSWER_ID = i_Answer.ANSWER_ID;
Delete_Evaluation_By_ANSWER_ID(oParams_Delete_Evaluation_By_ANSWER_ID);
//---------------------------------
// Edit Evaluation
//---------------------------------
Edit_Answer_WithEvaluation(i_Answer, i_Evaluation_List);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Evaluation_By_Answer");}
}
#endregion
#region Reset_Evaluation_By_Answer
public void Reset_Evaluation_By_Answer(Answer i_Answer, List<Evaluation> i_Evaluation_List_To_Delete,List<Evaluation> i_Evaluation_List_To_Create)
{
#region Declaration And Initialization Section.
Params_Delete_Evaluation oParams_Delete_Evaluation = new Params_Delete_Evaluation();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Evaluation_By_Answer");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Specified Items 
//---------------------------------
 if (i_Evaluation_List_To_Delete != null)
{
foreach (var oRow in i_Evaluation_List_To_Delete)
{
oParams_Delete_Evaluation.EVALUATION_ID = oRow.EVALUATION_ID;
Delete_Evaluation(oParams_Delete_Evaluation);
}
}
//---------------------------------
// Edit Evaluation
//---------------------------------
Edit_Answer_WithEvaluation(i_Answer, i_Evaluation_List_To_Create);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Evaluation_By_Answer");}
}
#endregion
#region Edit_Answer_With_Evaluation(Answer i_Answer,List<Evaluation> i_EvaluationList)
public void Edit_Answer_WithEvaluation(Answer i_Answer,List<Evaluation> i_List_Evaluation)
{
#region Declaration And Initialization Section.
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Answer_WithEvaluation");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Business Operation.
//-------------------------------
Edit_Answer(i_Answer);
if (i_List_Evaluation != null)
{
foreach(Evaluation oEvaluation in i_List_Evaluation)
{
oEvaluation.ANSWER_ID = i_Answer.ANSWER_ID;
Edit_Evaluation(oEvaluation);
}
}
//-------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Answer_WithEvaluation");}
}
#endregion
#region Reset_Notification_By_Answer
public void Reset_Notification_By_Answer(Answer i_Answer, List<Notification> i_Notification_List)
{
#region Declaration And Initialization Section.
Params_Delete_Notification_By_ANSWER_ID oParams_Delete_Notification_By_ANSWER_ID = new Params_Delete_Notification_By_ANSWER_ID();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Notification_By_Answer");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Existing Notification
//---------------------------------
oParams_Delete_Notification_By_ANSWER_ID.ANSWER_ID = i_Answer.ANSWER_ID;
Delete_Notification_By_ANSWER_ID(oParams_Delete_Notification_By_ANSWER_ID);
//---------------------------------
// Edit Notification
//---------------------------------
Edit_Answer_WithNotification(i_Answer, i_Notification_List);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Notification_By_Answer");}
}
#endregion
#region Reset_Notification_By_Answer
public void Reset_Notification_By_Answer(Answer i_Answer, List<Notification> i_Notification_List_To_Delete,List<Notification> i_Notification_List_To_Create)
{
#region Declaration And Initialization Section.
Params_Delete_Notification oParams_Delete_Notification = new Params_Delete_Notification();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Notification_By_Answer");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Specified Items 
//---------------------------------
 if (i_Notification_List_To_Delete != null)
{
foreach (var oRow in i_Notification_List_To_Delete)
{
oParams_Delete_Notification.NOTIFICATION_ID = oRow.NOTIFICATION_ID;
Delete_Notification(oParams_Delete_Notification);
}
}
//---------------------------------
// Edit Notification
//---------------------------------
Edit_Answer_WithNotification(i_Answer, i_Notification_List_To_Create);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Notification_By_Answer");}
}
#endregion
#region Edit_Answer_With_Notification(Answer i_Answer,List<Notification> i_NotificationList)
public void Edit_Answer_WithNotification(Answer i_Answer,List<Notification> i_List_Notification)
{
#region Declaration And Initialization Section.
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Answer_WithNotification");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Business Operation.
//-------------------------------
Edit_Answer(i_Answer);
if (i_List_Notification != null)
{
foreach(Notification oNotification in i_List_Notification)
{
oNotification.ANSWER_ID = i_Answer.ANSWER_ID;
Edit_Notification(oNotification);
}
}
//-------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Answer_WithNotification");}
}
#endregion
#region Edit_Answer_WithRelatedData(Answer i_Answer,List<Answer_report> i_List_Answer_report,List<Evaluation> i_List_Evaluation,List<Notification> i_List_Notification)
public void Edit_Answer_WithRelatedData(Answer i_Answer,List<Answer_report> i_List_Answer_report,List<Evaluation> i_List_Evaluation,List<Notification> i_List_Notification)
{
#region Declaration And Initialization Section.
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Answer_WithRelatedData");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Business Operation.
//-------------------------------
Edit_Answer(i_Answer);
if (i_List_Answer_report != null)
{
foreach(Answer_report oAnswer_report in i_List_Answer_report)
{
oAnswer_report.ANSWER_ID = i_Answer.ANSWER_ID;
Edit_Answer_report(oAnswer_report);
}
}
if (i_List_Evaluation != null)
{
foreach(Evaluation oEvaluation in i_List_Evaluation)
{
oEvaluation.ANSWER_ID = i_Answer.ANSWER_ID;
Edit_Evaluation(oEvaluation);
}
}
if (i_List_Notification != null)
{
foreach(Notification oNotification in i_List_Notification)
{
oNotification.ANSWER_ID = i_Answer.ANSWER_ID;
Edit_Notification(oNotification);
}
}
//-------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Answer_WithRelatedData");}
}
#endregion
#region Delete_Answer_With_Children(Answer i_Answer)
public void Delete_Answer_With_Children(Answer i_Answer)
{
 #region Declaration And Initialization Section.
Params_Delete_Answer oParams_Delete_Answer = new Params_Delete_Answer();
Params_Delete_Answer_report_By_ANSWER_ID oParams_Delete_Answer_report_By_ANSWER_ID = new Params_Delete_Answer_report_By_ANSWER_ID();
Params_Delete_Evaluation_By_ANSWER_ID oParams_Delete_Evaluation_By_ANSWER_ID = new Params_Delete_Evaluation_By_ANSWER_ID();
Params_Delete_Notification_By_ANSWER_ID oParams_Delete_Notification_By_ANSWER_ID = new Params_Delete_Notification_By_ANSWER_ID();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Answer_With_Children");}
 #region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
//-------------------------
oParams_Delete_Answer_report_By_ANSWER_ID.ANSWER_ID = i_Answer.ANSWER_ID;
Delete_Answer_report_By_ANSWER_ID(oParams_Delete_Answer_report_By_ANSWER_ID);
oParams_Delete_Evaluation_By_ANSWER_ID.ANSWER_ID = i_Answer.ANSWER_ID;
Delete_Evaluation_By_ANSWER_ID(oParams_Delete_Evaluation_By_ANSWER_ID);
oParams_Delete_Notification_By_ANSWER_ID.ANSWER_ID = i_Answer.ANSWER_ID;
Delete_Notification_By_ANSWER_ID(oParams_Delete_Notification_By_ANSWER_ID);
//-------------------------

//-------------------------
oParams_Delete_Answer.ANSWER_ID = i_Answer.ANSWER_ID;
Delete_Answer(oParams_Delete_Answer);
//-------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Answer_With_Children");}
}
#endregion
#region Reset_Answer_report_By_Student
public void Reset_Answer_report_By_Student(Student i_Student, List<Answer_report> i_Answer_report_List)
{
#region Declaration And Initialization Section.
Params_Delete_Answer_report_By_STUDENT_ID oParams_Delete_Answer_report_By_STUDENT_ID = new Params_Delete_Answer_report_By_STUDENT_ID();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Answer_report_By_Student");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Existing Answer_report
//---------------------------------
oParams_Delete_Answer_report_By_STUDENT_ID.STUDENT_ID = i_Student.STUDENT_ID;
Delete_Answer_report_By_STUDENT_ID(oParams_Delete_Answer_report_By_STUDENT_ID);
//---------------------------------
// Edit Answer_report
//---------------------------------
Edit_Student_WithAnswer_report(i_Student, i_Answer_report_List);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Answer_report_By_Student");}
}
#endregion
#region Reset_Answer_report_By_Student
public void Reset_Answer_report_By_Student(Student i_Student, List<Answer_report> i_Answer_report_List_To_Delete,List<Answer_report> i_Answer_report_List_To_Create)
{
#region Declaration And Initialization Section.
Params_Delete_Answer_report oParams_Delete_Answer_report = new Params_Delete_Answer_report();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Answer_report_By_Student");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Specified Items 
//---------------------------------
 if (i_Answer_report_List_To_Delete != null)
{
foreach (var oRow in i_Answer_report_List_To_Delete)
{
oParams_Delete_Answer_report.ANSWER_REPORT_ID = oRow.ANSWER_REPORT_ID;
Delete_Answer_report(oParams_Delete_Answer_report);
}
}
//---------------------------------
// Edit Answer_report
//---------------------------------
Edit_Student_WithAnswer_report(i_Student, i_Answer_report_List_To_Create);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Answer_report_By_Student");}
}
#endregion
#region Edit_Student_With_Answer_report(Student i_Student,List<Answer_report> i_Answer_reportList)
public void Edit_Student_WithAnswer_report(Student i_Student,List<Answer_report> i_List_Answer_report)
{
#region Declaration And Initialization Section.
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Student_WithAnswer_report");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Business Operation.
//-------------------------------
Edit_Student(i_Student);
if (i_List_Answer_report != null)
{
foreach(Answer_report oAnswer_report in i_List_Answer_report)
{
oAnswer_report.STUDENT_ID = i_Student.STUDENT_ID;
Edit_Answer_report(oAnswer_report);
}
}
//-------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Student_WithAnswer_report");}
}
#endregion
#region Reset_Appreciate_By_Student
public void Reset_Appreciate_By_Student(Student i_Student, List<Appreciate> i_Appreciate_List)
{
#region Declaration And Initialization Section.
Params_Delete_Appreciate_By_STUDENT_ID oParams_Delete_Appreciate_By_STUDENT_ID = new Params_Delete_Appreciate_By_STUDENT_ID();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Appreciate_By_Student");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Existing Appreciate
//---------------------------------
oParams_Delete_Appreciate_By_STUDENT_ID.STUDENT_ID = i_Student.STUDENT_ID;
Delete_Appreciate_By_STUDENT_ID(oParams_Delete_Appreciate_By_STUDENT_ID);
//---------------------------------
// Edit Appreciate
//---------------------------------
Edit_Student_WithAppreciate(i_Student, i_Appreciate_List);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Appreciate_By_Student");}
}
#endregion
#region Reset_Appreciate_By_Student
public void Reset_Appreciate_By_Student(Student i_Student, List<Appreciate> i_Appreciate_List_To_Delete,List<Appreciate> i_Appreciate_List_To_Create)
{
#region Declaration And Initialization Section.
Params_Delete_Appreciate oParams_Delete_Appreciate = new Params_Delete_Appreciate();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Appreciate_By_Student");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Specified Items 
//---------------------------------
 if (i_Appreciate_List_To_Delete != null)
{
foreach (var oRow in i_Appreciate_List_To_Delete)
{
oParams_Delete_Appreciate.APPRECIATE_ID = oRow.APPRECIATE_ID;
Delete_Appreciate(oParams_Delete_Appreciate);
}
}
//---------------------------------
// Edit Appreciate
//---------------------------------
Edit_Student_WithAppreciate(i_Student, i_Appreciate_List_To_Create);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Appreciate_By_Student");}
}
#endregion
#region Edit_Student_With_Appreciate(Student i_Student,List<Appreciate> i_AppreciateList)
public void Edit_Student_WithAppreciate(Student i_Student,List<Appreciate> i_List_Appreciate)
{
#region Declaration And Initialization Section.
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Student_WithAppreciate");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Business Operation.
//-------------------------------
Edit_Student(i_Student);
if (i_List_Appreciate != null)
{
foreach(Appreciate oAppreciate in i_List_Appreciate)
{
oAppreciate.STUDENT_ID = i_Student.STUDENT_ID;
Edit_Appreciate(oAppreciate);
}
}
//-------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Student_WithAppreciate");}
}
#endregion
#region Reset_Evaluation_By_Student
public void Reset_Evaluation_By_Student(Student i_Student, List<Evaluation> i_Evaluation_List)
{
#region Declaration And Initialization Section.
Params_Delete_Evaluation_By_STUDENT_ID oParams_Delete_Evaluation_By_STUDENT_ID = new Params_Delete_Evaluation_By_STUDENT_ID();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Evaluation_By_Student");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Existing Evaluation
//---------------------------------
oParams_Delete_Evaluation_By_STUDENT_ID.STUDENT_ID = i_Student.STUDENT_ID;
Delete_Evaluation_By_STUDENT_ID(oParams_Delete_Evaluation_By_STUDENT_ID);
//---------------------------------
// Edit Evaluation
//---------------------------------
Edit_Student_WithEvaluation(i_Student, i_Evaluation_List);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Evaluation_By_Student");}
}
#endregion
#region Reset_Evaluation_By_Student
public void Reset_Evaluation_By_Student(Student i_Student, List<Evaluation> i_Evaluation_List_To_Delete,List<Evaluation> i_Evaluation_List_To_Create)
{
#region Declaration And Initialization Section.
Params_Delete_Evaluation oParams_Delete_Evaluation = new Params_Delete_Evaluation();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Evaluation_By_Student");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Specified Items 
//---------------------------------
 if (i_Evaluation_List_To_Delete != null)
{
foreach (var oRow in i_Evaluation_List_To_Delete)
{
oParams_Delete_Evaluation.EVALUATION_ID = oRow.EVALUATION_ID;
Delete_Evaluation(oParams_Delete_Evaluation);
}
}
//---------------------------------
// Edit Evaluation
//---------------------------------
Edit_Student_WithEvaluation(i_Student, i_Evaluation_List_To_Create);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Evaluation_By_Student");}
}
#endregion
#region Edit_Student_With_Evaluation(Student i_Student,List<Evaluation> i_EvaluationList)
public void Edit_Student_WithEvaluation(Student i_Student,List<Evaluation> i_List_Evaluation)
{
#region Declaration And Initialization Section.
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Student_WithEvaluation");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Business Operation.
//-------------------------------
Edit_Student(i_Student);
if (i_List_Evaluation != null)
{
foreach(Evaluation oEvaluation in i_List_Evaluation)
{
oEvaluation.STUDENT_ID = i_Student.STUDENT_ID;
Edit_Evaluation(oEvaluation);
}
}
//-------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Student_WithEvaluation");}
}
#endregion
#region Reset_Favorite_category_By_Student
public void Reset_Favorite_category_By_Student(Student i_Student, List<Favorite_category> i_Favorite_category_List)
{
#region Declaration And Initialization Section.
Params_Delete_Favorite_category_By_STUDENT_ID oParams_Delete_Favorite_category_By_STUDENT_ID = new Params_Delete_Favorite_category_By_STUDENT_ID();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Favorite_category_By_Student");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Existing Favorite_category
//---------------------------------
oParams_Delete_Favorite_category_By_STUDENT_ID.STUDENT_ID = i_Student.STUDENT_ID;
Delete_Favorite_category_By_STUDENT_ID(oParams_Delete_Favorite_category_By_STUDENT_ID);
//---------------------------------
// Edit Favorite_category
//---------------------------------
Edit_Student_WithFavorite_category(i_Student, i_Favorite_category_List);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Favorite_category_By_Student");}
}
#endregion
#region Reset_Favorite_category_By_Student
public void Reset_Favorite_category_By_Student(Student i_Student, List<Favorite_category> i_Favorite_category_List_To_Delete,List<Favorite_category> i_Favorite_category_List_To_Create)
{
#region Declaration And Initialization Section.
Params_Delete_Favorite_category oParams_Delete_Favorite_category = new Params_Delete_Favorite_category();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Favorite_category_By_Student");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Specified Items 
//---------------------------------
 if (i_Favorite_category_List_To_Delete != null)
{
foreach (var oRow in i_Favorite_category_List_To_Delete)
{
oParams_Delete_Favorite_category.FAVORITE_CATEGORY_ID = oRow.FAVORITE_CATEGORY_ID;
Delete_Favorite_category(oParams_Delete_Favorite_category);
}
}
//---------------------------------
// Edit Favorite_category
//---------------------------------
Edit_Student_WithFavorite_category(i_Student, i_Favorite_category_List_To_Create);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Favorite_category_By_Student");}
}
#endregion
#region Edit_Student_With_Favorite_category(Student i_Student,List<Favorite_category> i_Favorite_categoryList)
public void Edit_Student_WithFavorite_category(Student i_Student,List<Favorite_category> i_List_Favorite_category)
{
#region Declaration And Initialization Section.
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Student_WithFavorite_category");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Business Operation.
//-------------------------------
Edit_Student(i_Student);
if (i_List_Favorite_category != null)
{
foreach(Favorite_category oFavorite_category in i_List_Favorite_category)
{
oFavorite_category.STUDENT_ID = i_Student.STUDENT_ID;
Edit_Favorite_category(oFavorite_category);
}
}
//-------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Student_WithFavorite_category");}
}
#endregion
#region Reset_Favorite_teacher_By_Student
public void Reset_Favorite_teacher_By_Student(Student i_Student, List<Favorite_teacher> i_Favorite_teacher_List)
{
#region Declaration And Initialization Section.
Params_Delete_Favorite_teacher_By_STUDENT_ID oParams_Delete_Favorite_teacher_By_STUDENT_ID = new Params_Delete_Favorite_teacher_By_STUDENT_ID();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Favorite_teacher_By_Student");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Existing Favorite_teacher
//---------------------------------
oParams_Delete_Favorite_teacher_By_STUDENT_ID.STUDENT_ID = i_Student.STUDENT_ID;
Delete_Favorite_teacher_By_STUDENT_ID(oParams_Delete_Favorite_teacher_By_STUDENT_ID);
//---------------------------------
// Edit Favorite_teacher
//---------------------------------
Edit_Student_WithFavorite_teacher(i_Student, i_Favorite_teacher_List);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Favorite_teacher_By_Student");}
}
#endregion
#region Reset_Favorite_teacher_By_Student
public void Reset_Favorite_teacher_By_Student(Student i_Student, List<Favorite_teacher> i_Favorite_teacher_List_To_Delete,List<Favorite_teacher> i_Favorite_teacher_List_To_Create)
{
#region Declaration And Initialization Section.
Params_Delete_Favorite_teacher oParams_Delete_Favorite_teacher = new Params_Delete_Favorite_teacher();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Favorite_teacher_By_Student");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Specified Items 
//---------------------------------
 if (i_Favorite_teacher_List_To_Delete != null)
{
foreach (var oRow in i_Favorite_teacher_List_To_Delete)
{
oParams_Delete_Favorite_teacher.FAVORITE_TEACHER_ID = oRow.FAVORITE_TEACHER_ID;
Delete_Favorite_teacher(oParams_Delete_Favorite_teacher);
}
}
//---------------------------------
// Edit Favorite_teacher
//---------------------------------
Edit_Student_WithFavorite_teacher(i_Student, i_Favorite_teacher_List_To_Create);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Favorite_teacher_By_Student");}
}
#endregion
#region Edit_Student_With_Favorite_teacher(Student i_Student,List<Favorite_teacher> i_Favorite_teacherList)
public void Edit_Student_WithFavorite_teacher(Student i_Student,List<Favorite_teacher> i_List_Favorite_teacher)
{
#region Declaration And Initialization Section.
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Student_WithFavorite_teacher");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Business Operation.
//-------------------------------
Edit_Student(i_Student);
if (i_List_Favorite_teacher != null)
{
foreach(Favorite_teacher oFavorite_teacher in i_List_Favorite_teacher)
{
oFavorite_teacher.STUDENT_ID = i_Student.STUDENT_ID;
Edit_Favorite_teacher(oFavorite_teacher);
}
}
//-------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Student_WithFavorite_teacher");}
}
#endregion
#region Reset_Mark_question_By_Student
public void Reset_Mark_question_By_Student(Student i_Student, List<Mark_question> i_Mark_question_List)
{
#region Declaration And Initialization Section.
Params_Delete_Mark_question_By_STUDENT_ID oParams_Delete_Mark_question_By_STUDENT_ID = new Params_Delete_Mark_question_By_STUDENT_ID();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Mark_question_By_Student");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Existing Mark_question
//---------------------------------
oParams_Delete_Mark_question_By_STUDENT_ID.STUDENT_ID = i_Student.STUDENT_ID;
Delete_Mark_question_By_STUDENT_ID(oParams_Delete_Mark_question_By_STUDENT_ID);
//---------------------------------
// Edit Mark_question
//---------------------------------
Edit_Student_WithMark_question(i_Student, i_Mark_question_List);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Mark_question_By_Student");}
}
#endregion
#region Reset_Mark_question_By_Student
public void Reset_Mark_question_By_Student(Student i_Student, List<Mark_question> i_Mark_question_List_To_Delete,List<Mark_question> i_Mark_question_List_To_Create)
{
#region Declaration And Initialization Section.
Params_Delete_Mark_question oParams_Delete_Mark_question = new Params_Delete_Mark_question();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Mark_question_By_Student");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Specified Items 
//---------------------------------
 if (i_Mark_question_List_To_Delete != null)
{
foreach (var oRow in i_Mark_question_List_To_Delete)
{
oParams_Delete_Mark_question.MARK_QUESTION_ID = oRow.MARK_QUESTION_ID;
Delete_Mark_question(oParams_Delete_Mark_question);
}
}
//---------------------------------
// Edit Mark_question
//---------------------------------
Edit_Student_WithMark_question(i_Student, i_Mark_question_List_To_Create);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Mark_question_By_Student");}
}
#endregion
#region Edit_Student_With_Mark_question(Student i_Student,List<Mark_question> i_Mark_questionList)
public void Edit_Student_WithMark_question(Student i_Student,List<Mark_question> i_List_Mark_question)
{
#region Declaration And Initialization Section.
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Student_WithMark_question");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Business Operation.
//-------------------------------
Edit_Student(i_Student);
if (i_List_Mark_question != null)
{
foreach(Mark_question oMark_question in i_List_Mark_question)
{
oMark_question.STUDENT_ID = i_Student.STUDENT_ID;
Edit_Mark_question(oMark_question);
}
}
//-------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Student_WithMark_question");}
}
#endregion
#region Reset_Question_By_Student
public void Reset_Question_By_Student(Student i_Student, List<Question> i_Question_List)
{
#region Declaration And Initialization Section.
Params_Delete_Question_By_STUDENT_ID oParams_Delete_Question_By_STUDENT_ID = new Params_Delete_Question_By_STUDENT_ID();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Question_By_Student");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Existing Question
//---------------------------------
oParams_Delete_Question_By_STUDENT_ID.STUDENT_ID = i_Student.STUDENT_ID;
Delete_Question_By_STUDENT_ID(oParams_Delete_Question_By_STUDENT_ID);
//---------------------------------
// Edit Question
//---------------------------------
Edit_Student_WithQuestion(i_Student, i_Question_List);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Question_By_Student");}
}
#endregion
#region Reset_Question_By_Student
public void Reset_Question_By_Student(Student i_Student, List<Question> i_Question_List_To_Delete,List<Question> i_Question_List_To_Create)
{
#region Declaration And Initialization Section.
Params_Delete_Question oParams_Delete_Question = new Params_Delete_Question();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Question_By_Student");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Specified Items 
//---------------------------------
 if (i_Question_List_To_Delete != null)
{
foreach (var oRow in i_Question_List_To_Delete)
{
oParams_Delete_Question.QUESTION_ID = oRow.QUESTION_ID;
Delete_Question(oParams_Delete_Question);
}
}
//---------------------------------
// Edit Question
//---------------------------------
Edit_Student_WithQuestion(i_Student, i_Question_List_To_Create);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Question_By_Student");}
}
#endregion
#region Edit_Student_With_Question(Student i_Student,List<Question> i_QuestionList)
public void Edit_Student_WithQuestion(Student i_Student,List<Question> i_List_Question)
{
#region Declaration And Initialization Section.
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Student_WithQuestion");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Business Operation.
//-------------------------------
Edit_Student(i_Student);
if (i_List_Question != null)
{
foreach(Question oQuestion in i_List_Question)
{
oQuestion.STUDENT_ID = i_Student.STUDENT_ID;
Edit_Question(oQuestion);
}
}
//-------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Student_WithQuestion");}
}
#endregion
#region Reset_Question_report_By_Student
public void Reset_Question_report_By_Student(Student i_Student, List<Question_report> i_Question_report_List)
{
#region Declaration And Initialization Section.
Params_Delete_Question_report_By_STUDENT_ID oParams_Delete_Question_report_By_STUDENT_ID = new Params_Delete_Question_report_By_STUDENT_ID();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Question_report_By_Student");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Existing Question_report
//---------------------------------
oParams_Delete_Question_report_By_STUDENT_ID.STUDENT_ID = i_Student.STUDENT_ID;
Delete_Question_report_By_STUDENT_ID(oParams_Delete_Question_report_By_STUDENT_ID);
//---------------------------------
// Edit Question_report
//---------------------------------
Edit_Student_WithQuestion_report(i_Student, i_Question_report_List);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Question_report_By_Student");}
}
#endregion
#region Reset_Question_report_By_Student
public void Reset_Question_report_By_Student(Student i_Student, List<Question_report> i_Question_report_List_To_Delete,List<Question_report> i_Question_report_List_To_Create)
{
#region Declaration And Initialization Section.
Params_Delete_Question_report oParams_Delete_Question_report = new Params_Delete_Question_report();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Question_report_By_Student");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Specified Items 
//---------------------------------
 if (i_Question_report_List_To_Delete != null)
{
foreach (var oRow in i_Question_report_List_To_Delete)
{
oParams_Delete_Question_report.QUESTION_REPORT_ID = oRow.QUESTION_REPORT_ID;
Delete_Question_report(oParams_Delete_Question_report);
}
}
//---------------------------------
// Edit Question_report
//---------------------------------
Edit_Student_WithQuestion_report(i_Student, i_Question_report_List_To_Create);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Question_report_By_Student");}
}
#endregion
#region Edit_Student_With_Question_report(Student i_Student,List<Question_report> i_Question_reportList)
public void Edit_Student_WithQuestion_report(Student i_Student,List<Question_report> i_List_Question_report)
{
#region Declaration And Initialization Section.
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Student_WithQuestion_report");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Business Operation.
//-------------------------------
Edit_Student(i_Student);
if (i_List_Question_report != null)
{
foreach(Question_report oQuestion_report in i_List_Question_report)
{
oQuestion_report.STUDENT_ID = i_Student.STUDENT_ID;
Edit_Question_report(oQuestion_report);
}
}
//-------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Student_WithQuestion_report");}
}
#endregion
#region Reset_Report_article_By_Student
public void Reset_Report_article_By_Student(Student i_Student, List<Report_article> i_Report_article_List)
{
#region Declaration And Initialization Section.
Params_Delete_Report_article_By_STUDENT_ID oParams_Delete_Report_article_By_STUDENT_ID = new Params_Delete_Report_article_By_STUDENT_ID();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Report_article_By_Student");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Existing Report_article
//---------------------------------
oParams_Delete_Report_article_By_STUDENT_ID.STUDENT_ID = i_Student.STUDENT_ID;
Delete_Report_article_By_STUDENT_ID(oParams_Delete_Report_article_By_STUDENT_ID);
//---------------------------------
// Edit Report_article
//---------------------------------
Edit_Student_WithReport_article(i_Student, i_Report_article_List);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Report_article_By_Student");}
}
#endregion
#region Reset_Report_article_By_Student
public void Reset_Report_article_By_Student(Student i_Student, List<Report_article> i_Report_article_List_To_Delete,List<Report_article> i_Report_article_List_To_Create)
{
#region Declaration And Initialization Section.
Params_Delete_Report_article oParams_Delete_Report_article = new Params_Delete_Report_article();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Report_article_By_Student");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Specified Items 
//---------------------------------
 if (i_Report_article_List_To_Delete != null)
{
foreach (var oRow in i_Report_article_List_To_Delete)
{
oParams_Delete_Report_article.REPORT_ARTICLE_ID = oRow.REPORT_ARTICLE_ID;
Delete_Report_article(oParams_Delete_Report_article);
}
}
//---------------------------------
// Edit Report_article
//---------------------------------
Edit_Student_WithReport_article(i_Student, i_Report_article_List_To_Create);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Report_article_By_Student");}
}
#endregion
#region Edit_Student_With_Report_article(Student i_Student,List<Report_article> i_Report_articleList)
public void Edit_Student_WithReport_article(Student i_Student,List<Report_article> i_List_Report_article)
{
#region Declaration And Initialization Section.
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Student_WithReport_article");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Business Operation.
//-------------------------------
Edit_Student(i_Student);
if (i_List_Report_article != null)
{
foreach(Report_article oReport_article in i_List_Report_article)
{
oReport_article.STUDENT_ID = i_Student.STUDENT_ID;
Edit_Report_article(oReport_article);
}
}
//-------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Student_WithReport_article");}
}
#endregion
#region Reset_Teacher_favorite_By_Student
public void Reset_Teacher_favorite_By_Student(Student i_Student, List<Teacher_favorite> i_Teacher_favorite_List)
{
#region Declaration And Initialization Section.
Params_Delete_Teacher_favorite_By_STUDENT_ID oParams_Delete_Teacher_favorite_By_STUDENT_ID = new Params_Delete_Teacher_favorite_By_STUDENT_ID();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Teacher_favorite_By_Student");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Existing Teacher_favorite
//---------------------------------
oParams_Delete_Teacher_favorite_By_STUDENT_ID.STUDENT_ID = i_Student.STUDENT_ID;
Delete_Teacher_favorite_By_STUDENT_ID(oParams_Delete_Teacher_favorite_By_STUDENT_ID);
//---------------------------------
// Edit Teacher_favorite
//---------------------------------
Edit_Student_WithTeacher_favorite(i_Student, i_Teacher_favorite_List);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Teacher_favorite_By_Student");}
}
#endregion
#region Reset_Teacher_favorite_By_Student
public void Reset_Teacher_favorite_By_Student(Student i_Student, List<Teacher_favorite> i_Teacher_favorite_List_To_Delete,List<Teacher_favorite> i_Teacher_favorite_List_To_Create)
{
#region Declaration And Initialization Section.
Params_Delete_Teacher_favorite oParams_Delete_Teacher_favorite = new Params_Delete_Teacher_favorite();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Teacher_favorite_By_Student");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Specified Items 
//---------------------------------
 if (i_Teacher_favorite_List_To_Delete != null)
{
foreach (var oRow in i_Teacher_favorite_List_To_Delete)
{
oParams_Delete_Teacher_favorite.TEACHER_FAVORITE_ID = oRow.TEACHER_FAVORITE_ID;
Delete_Teacher_favorite(oParams_Delete_Teacher_favorite);
}
}
//---------------------------------
// Edit Teacher_favorite
//---------------------------------
Edit_Student_WithTeacher_favorite(i_Student, i_Teacher_favorite_List_To_Create);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Teacher_favorite_By_Student");}
}
#endregion
#region Edit_Student_With_Teacher_favorite(Student i_Student,List<Teacher_favorite> i_Teacher_favoriteList)
public void Edit_Student_WithTeacher_favorite(Student i_Student,List<Teacher_favorite> i_List_Teacher_favorite)
{
#region Declaration And Initialization Section.
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Student_WithTeacher_favorite");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Business Operation.
//-------------------------------
Edit_Student(i_Student);
if (i_List_Teacher_favorite != null)
{
foreach(Teacher_favorite oTeacher_favorite in i_List_Teacher_favorite)
{
oTeacher_favorite.STUDENT_ID = i_Student.STUDENT_ID;
Edit_Teacher_favorite(oTeacher_favorite);
}
}
//-------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Student_WithTeacher_favorite");}
}
#endregion
#region Reset_Teacher_report_By_Student
public void Reset_Teacher_report_By_Student(Student i_Student, List<Teacher_report> i_Teacher_report_List)
{
#region Declaration And Initialization Section.
Params_Delete_Teacher_report_By_STUDENT_ID oParams_Delete_Teacher_report_By_STUDENT_ID = new Params_Delete_Teacher_report_By_STUDENT_ID();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Teacher_report_By_Student");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Existing Teacher_report
//---------------------------------
oParams_Delete_Teacher_report_By_STUDENT_ID.STUDENT_ID = i_Student.STUDENT_ID;
Delete_Teacher_report_By_STUDENT_ID(oParams_Delete_Teacher_report_By_STUDENT_ID);
//---------------------------------
// Edit Teacher_report
//---------------------------------
Edit_Student_WithTeacher_report(i_Student, i_Teacher_report_List);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Teacher_report_By_Student");}
}
#endregion
#region Reset_Teacher_report_By_Student
public void Reset_Teacher_report_By_Student(Student i_Student, List<Teacher_report> i_Teacher_report_List_To_Delete,List<Teacher_report> i_Teacher_report_List_To_Create)
{
#region Declaration And Initialization Section.
Params_Delete_Teacher_report oParams_Delete_Teacher_report = new Params_Delete_Teacher_report();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Teacher_report_By_Student");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Specified Items 
//---------------------------------
 if (i_Teacher_report_List_To_Delete != null)
{
foreach (var oRow in i_Teacher_report_List_To_Delete)
{
oParams_Delete_Teacher_report.TEACHER_REPORT_ID = oRow.TEACHER_REPORT_ID;
Delete_Teacher_report(oParams_Delete_Teacher_report);
}
}
//---------------------------------
// Edit Teacher_report
//---------------------------------
Edit_Student_WithTeacher_report(i_Student, i_Teacher_report_List_To_Create);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Teacher_report_By_Student");}
}
#endregion
#region Edit_Student_With_Teacher_report(Student i_Student,List<Teacher_report> i_Teacher_reportList)
public void Edit_Student_WithTeacher_report(Student i_Student,List<Teacher_report> i_List_Teacher_report)
{
#region Declaration And Initialization Section.
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Student_WithTeacher_report");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Business Operation.
//-------------------------------
Edit_Student(i_Student);
if (i_List_Teacher_report != null)
{
foreach(Teacher_report oTeacher_report in i_List_Teacher_report)
{
oTeacher_report.STUDENT_ID = i_Student.STUDENT_ID;
Edit_Teacher_report(oTeacher_report);
}
}
//-------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Student_WithTeacher_report");}
}
#endregion
#region Edit_Student_WithRelatedData(Student i_Student,List<Answer_report> i_List_Answer_report,List<Appreciate> i_List_Appreciate,List<Evaluation> i_List_Evaluation,List<Favorite_category> i_List_Favorite_category,List<Favorite_teacher> i_List_Favorite_teacher,List<Mark_question> i_List_Mark_question,List<Question> i_List_Question,List<Question_report> i_List_Question_report,List<Report_article> i_List_Report_article,List<Teacher_favorite> i_List_Teacher_favorite,List<Teacher_report> i_List_Teacher_report)
public void Edit_Student_WithRelatedData(Student i_Student,List<Answer_report> i_List_Answer_report,List<Appreciate> i_List_Appreciate,List<Evaluation> i_List_Evaluation,List<Favorite_category> i_List_Favorite_category,List<Favorite_teacher> i_List_Favorite_teacher,List<Mark_question> i_List_Mark_question,List<Question> i_List_Question,List<Question_report> i_List_Question_report,List<Report_article> i_List_Report_article,List<Teacher_favorite> i_List_Teacher_favorite,List<Teacher_report> i_List_Teacher_report)
{
#region Declaration And Initialization Section.
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Student_WithRelatedData");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Business Operation.
//-------------------------------
Edit_Student(i_Student);
if (i_List_Answer_report != null)
{
foreach(Answer_report oAnswer_report in i_List_Answer_report)
{
oAnswer_report.STUDENT_ID = i_Student.STUDENT_ID;
Edit_Answer_report(oAnswer_report);
}
}
if (i_List_Appreciate != null)
{
foreach(Appreciate oAppreciate in i_List_Appreciate)
{
oAppreciate.STUDENT_ID = i_Student.STUDENT_ID;
Edit_Appreciate(oAppreciate);
}
}
if (i_List_Evaluation != null)
{
foreach(Evaluation oEvaluation in i_List_Evaluation)
{
oEvaluation.STUDENT_ID = i_Student.STUDENT_ID;
Edit_Evaluation(oEvaluation);
}
}
if (i_List_Favorite_category != null)
{
foreach(Favorite_category oFavorite_category in i_List_Favorite_category)
{
oFavorite_category.STUDENT_ID = i_Student.STUDENT_ID;
Edit_Favorite_category(oFavorite_category);
}
}
if (i_List_Favorite_teacher != null)
{
foreach(Favorite_teacher oFavorite_teacher in i_List_Favorite_teacher)
{
oFavorite_teacher.STUDENT_ID = i_Student.STUDENT_ID;
Edit_Favorite_teacher(oFavorite_teacher);
}
}
if (i_List_Mark_question != null)
{
foreach(Mark_question oMark_question in i_List_Mark_question)
{
oMark_question.STUDENT_ID = i_Student.STUDENT_ID;
Edit_Mark_question(oMark_question);
}
}
if (i_List_Question != null)
{
foreach(Question oQuestion in i_List_Question)
{
oQuestion.STUDENT_ID = i_Student.STUDENT_ID;
Edit_Question(oQuestion);
}
}
if (i_List_Question_report != null)
{
foreach(Question_report oQuestion_report in i_List_Question_report)
{
oQuestion_report.STUDENT_ID = i_Student.STUDENT_ID;
Edit_Question_report(oQuestion_report);
}
}
if (i_List_Report_article != null)
{
foreach(Report_article oReport_article in i_List_Report_article)
{
oReport_article.STUDENT_ID = i_Student.STUDENT_ID;
Edit_Report_article(oReport_article);
}
}
if (i_List_Teacher_favorite != null)
{
foreach(Teacher_favorite oTeacher_favorite in i_List_Teacher_favorite)
{
oTeacher_favorite.STUDENT_ID = i_Student.STUDENT_ID;
Edit_Teacher_favorite(oTeacher_favorite);
}
}
if (i_List_Teacher_report != null)
{
foreach(Teacher_report oTeacher_report in i_List_Teacher_report)
{
oTeacher_report.STUDENT_ID = i_Student.STUDENT_ID;
Edit_Teacher_report(oTeacher_report);
}
}
//-------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Student_WithRelatedData");}
}
#endregion
#region Delete_Student_With_Children(Student i_Student)
public void Delete_Student_With_Children(Student i_Student)
{
 #region Declaration And Initialization Section.
Params_Delete_Student oParams_Delete_Student = new Params_Delete_Student();
Params_Delete_Answer_report_By_STUDENT_ID oParams_Delete_Answer_report_By_STUDENT_ID = new Params_Delete_Answer_report_By_STUDENT_ID();
Params_Delete_Appreciate_By_STUDENT_ID oParams_Delete_Appreciate_By_STUDENT_ID = new Params_Delete_Appreciate_By_STUDENT_ID();
Params_Delete_Evaluation_By_STUDENT_ID oParams_Delete_Evaluation_By_STUDENT_ID = new Params_Delete_Evaluation_By_STUDENT_ID();
Params_Delete_Favorite_category_By_STUDENT_ID oParams_Delete_Favorite_category_By_STUDENT_ID = new Params_Delete_Favorite_category_By_STUDENT_ID();
Params_Delete_Favorite_teacher_By_STUDENT_ID oParams_Delete_Favorite_teacher_By_STUDENT_ID = new Params_Delete_Favorite_teacher_By_STUDENT_ID();
Params_Delete_Mark_question_By_STUDENT_ID oParams_Delete_Mark_question_By_STUDENT_ID = new Params_Delete_Mark_question_By_STUDENT_ID();
Params_Delete_Question_By_STUDENT_ID oParams_Delete_Question_By_STUDENT_ID = new Params_Delete_Question_By_STUDENT_ID();
Params_Delete_Question_report_By_STUDENT_ID oParams_Delete_Question_report_By_STUDENT_ID = new Params_Delete_Question_report_By_STUDENT_ID();
Params_Delete_Report_article_By_STUDENT_ID oParams_Delete_Report_article_By_STUDENT_ID = new Params_Delete_Report_article_By_STUDENT_ID();
Params_Delete_Teacher_favorite_By_STUDENT_ID oParams_Delete_Teacher_favorite_By_STUDENT_ID = new Params_Delete_Teacher_favorite_By_STUDENT_ID();
Params_Delete_Teacher_report_By_STUDENT_ID oParams_Delete_Teacher_report_By_STUDENT_ID = new Params_Delete_Teacher_report_By_STUDENT_ID();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Student_With_Children");}
 #region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
//-------------------------
oParams_Delete_Answer_report_By_STUDENT_ID.STUDENT_ID = i_Student.STUDENT_ID;
Delete_Answer_report_By_STUDENT_ID(oParams_Delete_Answer_report_By_STUDENT_ID);
oParams_Delete_Appreciate_By_STUDENT_ID.STUDENT_ID = i_Student.STUDENT_ID;
Delete_Appreciate_By_STUDENT_ID(oParams_Delete_Appreciate_By_STUDENT_ID);
oParams_Delete_Evaluation_By_STUDENT_ID.STUDENT_ID = i_Student.STUDENT_ID;
Delete_Evaluation_By_STUDENT_ID(oParams_Delete_Evaluation_By_STUDENT_ID);
oParams_Delete_Favorite_category_By_STUDENT_ID.STUDENT_ID = i_Student.STUDENT_ID;
Delete_Favorite_category_By_STUDENT_ID(oParams_Delete_Favorite_category_By_STUDENT_ID);
oParams_Delete_Favorite_teacher_By_STUDENT_ID.STUDENT_ID = i_Student.STUDENT_ID;
Delete_Favorite_teacher_By_STUDENT_ID(oParams_Delete_Favorite_teacher_By_STUDENT_ID);
oParams_Delete_Mark_question_By_STUDENT_ID.STUDENT_ID = i_Student.STUDENT_ID;
Delete_Mark_question_By_STUDENT_ID(oParams_Delete_Mark_question_By_STUDENT_ID);
oParams_Delete_Question_By_STUDENT_ID.STUDENT_ID = i_Student.STUDENT_ID;
Delete_Question_By_STUDENT_ID(oParams_Delete_Question_By_STUDENT_ID);
oParams_Delete_Question_report_By_STUDENT_ID.STUDENT_ID = i_Student.STUDENT_ID;
Delete_Question_report_By_STUDENT_ID(oParams_Delete_Question_report_By_STUDENT_ID);
oParams_Delete_Report_article_By_STUDENT_ID.STUDENT_ID = i_Student.STUDENT_ID;
Delete_Report_article_By_STUDENT_ID(oParams_Delete_Report_article_By_STUDENT_ID);
oParams_Delete_Teacher_favorite_By_STUDENT_ID.STUDENT_ID = i_Student.STUDENT_ID;
Delete_Teacher_favorite_By_STUDENT_ID(oParams_Delete_Teacher_favorite_By_STUDENT_ID);
oParams_Delete_Teacher_report_By_STUDENT_ID.STUDENT_ID = i_Student.STUDENT_ID;
Delete_Teacher_report_By_STUDENT_ID(oParams_Delete_Teacher_report_By_STUDENT_ID);
//-------------------------

//-------------------------
oParams_Delete_Student.STUDENT_ID = i_Student.STUDENT_ID;
Delete_Student(oParams_Delete_Student);
//-------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Student_With_Children");}
}
#endregion
#region Reset_Answer_By_Teacher
public void Reset_Answer_By_Teacher(Teacher i_Teacher, List<Answer> i_Answer_List)
{
#region Declaration And Initialization Section.
Params_Delete_Answer_By_TEACHER_ID oParams_Delete_Answer_By_TEACHER_ID = new Params_Delete_Answer_By_TEACHER_ID();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Answer_By_Teacher");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Existing Answer
//---------------------------------
oParams_Delete_Answer_By_TEACHER_ID.TEACHER_ID = i_Teacher.TEACHER_ID;
Delete_Answer_By_TEACHER_ID(oParams_Delete_Answer_By_TEACHER_ID);
//---------------------------------
// Edit Answer
//---------------------------------
Edit_Teacher_WithAnswer(i_Teacher, i_Answer_List);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Answer_By_Teacher");}
}
#endregion
#region Reset_Answer_By_Teacher
public void Reset_Answer_By_Teacher(Teacher i_Teacher, List<Answer> i_Answer_List_To_Delete,List<Answer> i_Answer_List_To_Create)
{
#region Declaration And Initialization Section.
Params_Delete_Answer oParams_Delete_Answer = new Params_Delete_Answer();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Answer_By_Teacher");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Specified Items 
//---------------------------------
 if (i_Answer_List_To_Delete != null)
{
foreach (var oRow in i_Answer_List_To_Delete)
{
oParams_Delete_Answer.ANSWER_ID = oRow.ANSWER_ID;
Delete_Answer(oParams_Delete_Answer);
}
}
//---------------------------------
// Edit Answer
//---------------------------------
Edit_Teacher_WithAnswer(i_Teacher, i_Answer_List_To_Create);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Answer_By_Teacher");}
}
#endregion
#region Edit_Teacher_With_Answer(Teacher i_Teacher,List<Answer> i_AnswerList)
public void Edit_Teacher_WithAnswer(Teacher i_Teacher,List<Answer> i_List_Answer)
{
#region Declaration And Initialization Section.
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Teacher_WithAnswer");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Business Operation.
//-------------------------------
Edit_Teacher(i_Teacher);
if (i_List_Answer != null)
{
foreach(Answer oAnswer in i_List_Answer)
{
oAnswer.TEACHER_ID = i_Teacher.TEACHER_ID;
Edit_Answer(oAnswer);
}
}
//-------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Teacher_WithAnswer");}
}
#endregion
#region Reset_Answer_report_By_Teacher
public void Reset_Answer_report_By_Teacher(Teacher i_Teacher, List<Answer_report> i_Answer_report_List)
{
#region Declaration And Initialization Section.
Params_Delete_Answer_report_By_TEACHER_ID oParams_Delete_Answer_report_By_TEACHER_ID = new Params_Delete_Answer_report_By_TEACHER_ID();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Answer_report_By_Teacher");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Existing Answer_report
//---------------------------------
oParams_Delete_Answer_report_By_TEACHER_ID.TEACHER_ID = i_Teacher.TEACHER_ID;
Delete_Answer_report_By_TEACHER_ID(oParams_Delete_Answer_report_By_TEACHER_ID);
//---------------------------------
// Edit Answer_report
//---------------------------------
Edit_Teacher_WithAnswer_report(i_Teacher, i_Answer_report_List);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Answer_report_By_Teacher");}
}
#endregion
#region Reset_Answer_report_By_Teacher
public void Reset_Answer_report_By_Teacher(Teacher i_Teacher, List<Answer_report> i_Answer_report_List_To_Delete,List<Answer_report> i_Answer_report_List_To_Create)
{
#region Declaration And Initialization Section.
Params_Delete_Answer_report oParams_Delete_Answer_report = new Params_Delete_Answer_report();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Answer_report_By_Teacher");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Specified Items 
//---------------------------------
 if (i_Answer_report_List_To_Delete != null)
{
foreach (var oRow in i_Answer_report_List_To_Delete)
{
oParams_Delete_Answer_report.ANSWER_REPORT_ID = oRow.ANSWER_REPORT_ID;
Delete_Answer_report(oParams_Delete_Answer_report);
}
}
//---------------------------------
// Edit Answer_report
//---------------------------------
Edit_Teacher_WithAnswer_report(i_Teacher, i_Answer_report_List_To_Create);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Answer_report_By_Teacher");}
}
#endregion
#region Edit_Teacher_With_Answer_report(Teacher i_Teacher,List<Answer_report> i_Answer_reportList)
public void Edit_Teacher_WithAnswer_report(Teacher i_Teacher,List<Answer_report> i_List_Answer_report)
{
#region Declaration And Initialization Section.
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Teacher_WithAnswer_report");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Business Operation.
//-------------------------------
Edit_Teacher(i_Teacher);
if (i_List_Answer_report != null)
{
foreach(Answer_report oAnswer_report in i_List_Answer_report)
{
oAnswer_report.TEACHER_ID = i_Teacher.TEACHER_ID;
Edit_Answer_report(oAnswer_report);
}
}
//-------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Teacher_WithAnswer_report");}
}
#endregion
#region Reset_Article_By_Teacher
public void Reset_Article_By_Teacher(Teacher i_Teacher, List<Article> i_Article_List)
{
#region Declaration And Initialization Section.
Params_Delete_Article_By_TEACHER_ID oParams_Delete_Article_By_TEACHER_ID = new Params_Delete_Article_By_TEACHER_ID();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Article_By_Teacher");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Existing Article
//---------------------------------
oParams_Delete_Article_By_TEACHER_ID.TEACHER_ID = i_Teacher.TEACHER_ID;
Delete_Article_By_TEACHER_ID(oParams_Delete_Article_By_TEACHER_ID);
//---------------------------------
// Edit Article
//---------------------------------
Edit_Teacher_WithArticle(i_Teacher, i_Article_List);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Article_By_Teacher");}
}
#endregion
#region Reset_Article_By_Teacher
public void Reset_Article_By_Teacher(Teacher i_Teacher, List<Article> i_Article_List_To_Delete,List<Article> i_Article_List_To_Create)
{
#region Declaration And Initialization Section.
Params_Delete_Article oParams_Delete_Article = new Params_Delete_Article();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Article_By_Teacher");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Specified Items 
//---------------------------------
 if (i_Article_List_To_Delete != null)
{
foreach (var oRow in i_Article_List_To_Delete)
{
oParams_Delete_Article.ARTICLE_ID = oRow.ARTICLE_ID;
Delete_Article(oParams_Delete_Article);
}
}
//---------------------------------
// Edit Article
//---------------------------------
Edit_Teacher_WithArticle(i_Teacher, i_Article_List_To_Create);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Article_By_Teacher");}
}
#endregion
#region Edit_Teacher_With_Article(Teacher i_Teacher,List<Article> i_ArticleList)
public void Edit_Teacher_WithArticle(Teacher i_Teacher,List<Article> i_List_Article)
{
#region Declaration And Initialization Section.
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Teacher_WithArticle");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Business Operation.
//-------------------------------
Edit_Teacher(i_Teacher);
if (i_List_Article != null)
{
foreach(Article oArticle in i_List_Article)
{
oArticle.TEACHER_ID = i_Teacher.TEACHER_ID;
Edit_Article(oArticle);
}
}
//-------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Teacher_WithArticle");}
}
#endregion
#region Reset_Favorite_teacher_By_Teacher
public void Reset_Favorite_teacher_By_Teacher(Teacher i_Teacher, List<Favorite_teacher> i_Favorite_teacher_List)
{
#region Declaration And Initialization Section.
Params_Delete_Favorite_teacher_By_TEACHER_ID oParams_Delete_Favorite_teacher_By_TEACHER_ID = new Params_Delete_Favorite_teacher_By_TEACHER_ID();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Favorite_teacher_By_Teacher");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Existing Favorite_teacher
//---------------------------------
oParams_Delete_Favorite_teacher_By_TEACHER_ID.TEACHER_ID = i_Teacher.TEACHER_ID;
Delete_Favorite_teacher_By_TEACHER_ID(oParams_Delete_Favorite_teacher_By_TEACHER_ID);
//---------------------------------
// Edit Favorite_teacher
//---------------------------------
Edit_Teacher_WithFavorite_teacher(i_Teacher, i_Favorite_teacher_List);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Favorite_teacher_By_Teacher");}
}
#endregion
#region Reset_Favorite_teacher_By_Teacher
public void Reset_Favorite_teacher_By_Teacher(Teacher i_Teacher, List<Favorite_teacher> i_Favorite_teacher_List_To_Delete,List<Favorite_teacher> i_Favorite_teacher_List_To_Create)
{
#region Declaration And Initialization Section.
Params_Delete_Favorite_teacher oParams_Delete_Favorite_teacher = new Params_Delete_Favorite_teacher();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Favorite_teacher_By_Teacher");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Specified Items 
//---------------------------------
 if (i_Favorite_teacher_List_To_Delete != null)
{
foreach (var oRow in i_Favorite_teacher_List_To_Delete)
{
oParams_Delete_Favorite_teacher.FAVORITE_TEACHER_ID = oRow.FAVORITE_TEACHER_ID;
Delete_Favorite_teacher(oParams_Delete_Favorite_teacher);
}
}
//---------------------------------
// Edit Favorite_teacher
//---------------------------------
Edit_Teacher_WithFavorite_teacher(i_Teacher, i_Favorite_teacher_List_To_Create);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Favorite_teacher_By_Teacher");}
}
#endregion
#region Edit_Teacher_With_Favorite_teacher(Teacher i_Teacher,List<Favorite_teacher> i_Favorite_teacherList)
public void Edit_Teacher_WithFavorite_teacher(Teacher i_Teacher,List<Favorite_teacher> i_List_Favorite_teacher)
{
#region Declaration And Initialization Section.
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Teacher_WithFavorite_teacher");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Business Operation.
//-------------------------------
Edit_Teacher(i_Teacher);
if (i_List_Favorite_teacher != null)
{
foreach(Favorite_teacher oFavorite_teacher in i_List_Favorite_teacher)
{
oFavorite_teacher.TEACHER_ID = i_Teacher.TEACHER_ID;
Edit_Favorite_teacher(oFavorite_teacher);
}
}
//-------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Teacher_WithFavorite_teacher");}
}
#endregion
#region Reset_Question_By_Teacher
public void Reset_Question_By_Teacher(Teacher i_Teacher, List<Question> i_Question_List)
{
#region Declaration And Initialization Section.
Params_Delete_Question_By_TEACHER_ID oParams_Delete_Question_By_TEACHER_ID = new Params_Delete_Question_By_TEACHER_ID();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Question_By_Teacher");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Existing Question
//---------------------------------
oParams_Delete_Question_By_TEACHER_ID.TEACHER_ID = i_Teacher.TEACHER_ID;
Delete_Question_By_TEACHER_ID(oParams_Delete_Question_By_TEACHER_ID);
//---------------------------------
// Edit Question
//---------------------------------
Edit_Teacher_WithQuestion(i_Teacher, i_Question_List);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Question_By_Teacher");}
}
#endregion
#region Reset_Question_By_Teacher
public void Reset_Question_By_Teacher(Teacher i_Teacher, List<Question> i_Question_List_To_Delete,List<Question> i_Question_List_To_Create)
{
#region Declaration And Initialization Section.
Params_Delete_Question oParams_Delete_Question = new Params_Delete_Question();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Question_By_Teacher");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Specified Items 
//---------------------------------
 if (i_Question_List_To_Delete != null)
{
foreach (var oRow in i_Question_List_To_Delete)
{
oParams_Delete_Question.QUESTION_ID = oRow.QUESTION_ID;
Delete_Question(oParams_Delete_Question);
}
}
//---------------------------------
// Edit Question
//---------------------------------
Edit_Teacher_WithQuestion(i_Teacher, i_Question_List_To_Create);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Question_By_Teacher");}
}
#endregion
#region Edit_Teacher_With_Question(Teacher i_Teacher,List<Question> i_QuestionList)
public void Edit_Teacher_WithQuestion(Teacher i_Teacher,List<Question> i_List_Question)
{
#region Declaration And Initialization Section.
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Teacher_WithQuestion");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Business Operation.
//-------------------------------
Edit_Teacher(i_Teacher);
if (i_List_Question != null)
{
foreach(Question oQuestion in i_List_Question)
{
oQuestion.TEACHER_ID = i_Teacher.TEACHER_ID;
Edit_Question(oQuestion);
}
}
//-------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Teacher_WithQuestion");}
}
#endregion
#region Reset_Question_report_By_Teacher
public void Reset_Question_report_By_Teacher(Teacher i_Teacher, List<Question_report> i_Question_report_List)
{
#region Declaration And Initialization Section.
Params_Delete_Question_report_By_TEACHER_ID oParams_Delete_Question_report_By_TEACHER_ID = new Params_Delete_Question_report_By_TEACHER_ID();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Question_report_By_Teacher");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Existing Question_report
//---------------------------------
oParams_Delete_Question_report_By_TEACHER_ID.TEACHER_ID = i_Teacher.TEACHER_ID;
Delete_Question_report_By_TEACHER_ID(oParams_Delete_Question_report_By_TEACHER_ID);
//---------------------------------
// Edit Question_report
//---------------------------------
Edit_Teacher_WithQuestion_report(i_Teacher, i_Question_report_List);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Question_report_By_Teacher");}
}
#endregion
#region Reset_Question_report_By_Teacher
public void Reset_Question_report_By_Teacher(Teacher i_Teacher, List<Question_report> i_Question_report_List_To_Delete,List<Question_report> i_Question_report_List_To_Create)
{
#region Declaration And Initialization Section.
Params_Delete_Question_report oParams_Delete_Question_report = new Params_Delete_Question_report();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Question_report_By_Teacher");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Specified Items 
//---------------------------------
 if (i_Question_report_List_To_Delete != null)
{
foreach (var oRow in i_Question_report_List_To_Delete)
{
oParams_Delete_Question_report.QUESTION_REPORT_ID = oRow.QUESTION_REPORT_ID;
Delete_Question_report(oParams_Delete_Question_report);
}
}
//---------------------------------
// Edit Question_report
//---------------------------------
Edit_Teacher_WithQuestion_report(i_Teacher, i_Question_report_List_To_Create);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Question_report_By_Teacher");}
}
#endregion
#region Edit_Teacher_With_Question_report(Teacher i_Teacher,List<Question_report> i_Question_reportList)
public void Edit_Teacher_WithQuestion_report(Teacher i_Teacher,List<Question_report> i_List_Question_report)
{
#region Declaration And Initialization Section.
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Teacher_WithQuestion_report");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Business Operation.
//-------------------------------
Edit_Teacher(i_Teacher);
if (i_List_Question_report != null)
{
foreach(Question_report oQuestion_report in i_List_Question_report)
{
oQuestion_report.TEACHER_ID = i_Teacher.TEACHER_ID;
Edit_Question_report(oQuestion_report);
}
}
//-------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Teacher_WithQuestion_report");}
}
#endregion
#region Reset_Teacher_category_By_Teacher
public void Reset_Teacher_category_By_Teacher(Teacher i_Teacher, List<Teacher_category> i_Teacher_category_List)
{
#region Declaration And Initialization Section.
Params_Delete_Teacher_category_By_TEACHER_ID oParams_Delete_Teacher_category_By_TEACHER_ID = new Params_Delete_Teacher_category_By_TEACHER_ID();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Teacher_category_By_Teacher");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Existing Teacher_category
//---------------------------------
oParams_Delete_Teacher_category_By_TEACHER_ID.TEACHER_ID = i_Teacher.TEACHER_ID;
Delete_Teacher_category_By_TEACHER_ID(oParams_Delete_Teacher_category_By_TEACHER_ID);
//---------------------------------
// Edit Teacher_category
//---------------------------------
Edit_Teacher_WithTeacher_category(i_Teacher, i_Teacher_category_List);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Teacher_category_By_Teacher");}
}
#endregion
#region Reset_Teacher_category_By_Teacher
public void Reset_Teacher_category_By_Teacher(Teacher i_Teacher, List<Teacher_category> i_Teacher_category_List_To_Delete,List<Teacher_category> i_Teacher_category_List_To_Create)
{
#region Declaration And Initialization Section.
Params_Delete_Teacher_category oParams_Delete_Teacher_category = new Params_Delete_Teacher_category();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Teacher_category_By_Teacher");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Specified Items 
//---------------------------------
 if (i_Teacher_category_List_To_Delete != null)
{
foreach (var oRow in i_Teacher_category_List_To_Delete)
{
oParams_Delete_Teacher_category.TEACHER_CATEGORY_ID = oRow.TEACHER_CATEGORY_ID;
Delete_Teacher_category(oParams_Delete_Teacher_category);
}
}
//---------------------------------
// Edit Teacher_category
//---------------------------------
Edit_Teacher_WithTeacher_category(i_Teacher, i_Teacher_category_List_To_Create);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Teacher_category_By_Teacher");}
}
#endregion
#region Edit_Teacher_With_Teacher_category(Teacher i_Teacher,List<Teacher_category> i_Teacher_categoryList)
public void Edit_Teacher_WithTeacher_category(Teacher i_Teacher,List<Teacher_category> i_List_Teacher_category)
{
#region Declaration And Initialization Section.
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Teacher_WithTeacher_category");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Business Operation.
//-------------------------------
Edit_Teacher(i_Teacher);
if (i_List_Teacher_category != null)
{
foreach(Teacher_category oTeacher_category in i_List_Teacher_category)
{
oTeacher_category.TEACHER_ID = i_Teacher.TEACHER_ID;
Edit_Teacher_category(oTeacher_category);
}
}
//-------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Teacher_WithTeacher_category");}
}
#endregion
#region Reset_Teacher_favorite_By_Teacher
public void Reset_Teacher_favorite_By_Teacher(Teacher i_Teacher, List<Teacher_favorite> i_Teacher_favorite_List)
{
#region Declaration And Initialization Section.
Params_Delete_Teacher_favorite_By_TEACHER_ID oParams_Delete_Teacher_favorite_By_TEACHER_ID = new Params_Delete_Teacher_favorite_By_TEACHER_ID();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Teacher_favorite_By_Teacher");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Existing Teacher_favorite
//---------------------------------
oParams_Delete_Teacher_favorite_By_TEACHER_ID.TEACHER_ID = i_Teacher.TEACHER_ID;
Delete_Teacher_favorite_By_TEACHER_ID(oParams_Delete_Teacher_favorite_By_TEACHER_ID);
//---------------------------------
// Edit Teacher_favorite
//---------------------------------
Edit_Teacher_WithTeacher_favorite(i_Teacher, i_Teacher_favorite_List);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Teacher_favorite_By_Teacher");}
}
#endregion
#region Reset_Teacher_favorite_By_Teacher
public void Reset_Teacher_favorite_By_Teacher(Teacher i_Teacher, List<Teacher_favorite> i_Teacher_favorite_List_To_Delete,List<Teacher_favorite> i_Teacher_favorite_List_To_Create)
{
#region Declaration And Initialization Section.
Params_Delete_Teacher_favorite oParams_Delete_Teacher_favorite = new Params_Delete_Teacher_favorite();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Teacher_favorite_By_Teacher");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Specified Items 
//---------------------------------
 if (i_Teacher_favorite_List_To_Delete != null)
{
foreach (var oRow in i_Teacher_favorite_List_To_Delete)
{
oParams_Delete_Teacher_favorite.TEACHER_FAVORITE_ID = oRow.TEACHER_FAVORITE_ID;
Delete_Teacher_favorite(oParams_Delete_Teacher_favorite);
}
}
//---------------------------------
// Edit Teacher_favorite
//---------------------------------
Edit_Teacher_WithTeacher_favorite(i_Teacher, i_Teacher_favorite_List_To_Create);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Teacher_favorite_By_Teacher");}
}
#endregion
#region Edit_Teacher_With_Teacher_favorite(Teacher i_Teacher,List<Teacher_favorite> i_Teacher_favoriteList)
public void Edit_Teacher_WithTeacher_favorite(Teacher i_Teacher,List<Teacher_favorite> i_List_Teacher_favorite)
{
#region Declaration And Initialization Section.
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Teacher_WithTeacher_favorite");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Business Operation.
//-------------------------------
Edit_Teacher(i_Teacher);
if (i_List_Teacher_favorite != null)
{
foreach(Teacher_favorite oTeacher_favorite in i_List_Teacher_favorite)
{
oTeacher_favorite.TEACHER_ID = i_Teacher.TEACHER_ID;
Edit_Teacher_favorite(oTeacher_favorite);
}
}
//-------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Teacher_WithTeacher_favorite");}
}
#endregion
#region Reset_Teacher_rank_By_Teacher
public void Reset_Teacher_rank_By_Teacher(Teacher i_Teacher, List<Teacher_rank> i_Teacher_rank_List)
{
#region Declaration And Initialization Section.
Params_Delete_Teacher_rank_By_TEACHER_ID oParams_Delete_Teacher_rank_By_TEACHER_ID = new Params_Delete_Teacher_rank_By_TEACHER_ID();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Teacher_rank_By_Teacher");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Existing Teacher_rank
//---------------------------------
oParams_Delete_Teacher_rank_By_TEACHER_ID.TEACHER_ID = i_Teacher.TEACHER_ID;
Delete_Teacher_rank_By_TEACHER_ID(oParams_Delete_Teacher_rank_By_TEACHER_ID);
//---------------------------------
// Edit Teacher_rank
//---------------------------------
Edit_Teacher_WithTeacher_rank(i_Teacher, i_Teacher_rank_List);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Teacher_rank_By_Teacher");}
}
#endregion
#region Reset_Teacher_rank_By_Teacher
public void Reset_Teacher_rank_By_Teacher(Teacher i_Teacher, List<Teacher_rank> i_Teacher_rank_List_To_Delete,List<Teacher_rank> i_Teacher_rank_List_To_Create)
{
#region Declaration And Initialization Section.
Params_Delete_Teacher_rank oParams_Delete_Teacher_rank = new Params_Delete_Teacher_rank();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Teacher_rank_By_Teacher");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Specified Items 
//---------------------------------
 if (i_Teacher_rank_List_To_Delete != null)
{
foreach (var oRow in i_Teacher_rank_List_To_Delete)
{
oParams_Delete_Teacher_rank.TEACHER_RANK_ID = oRow.TEACHER_RANK_ID;
Delete_Teacher_rank(oParams_Delete_Teacher_rank);
}
}
//---------------------------------
// Edit Teacher_rank
//---------------------------------
Edit_Teacher_WithTeacher_rank(i_Teacher, i_Teacher_rank_List_To_Create);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Teacher_rank_By_Teacher");}
}
#endregion
#region Edit_Teacher_With_Teacher_rank(Teacher i_Teacher,List<Teacher_rank> i_Teacher_rankList)
public void Edit_Teacher_WithTeacher_rank(Teacher i_Teacher,List<Teacher_rank> i_List_Teacher_rank)
{
#region Declaration And Initialization Section.
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Teacher_WithTeacher_rank");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Business Operation.
//-------------------------------
Edit_Teacher(i_Teacher);
if (i_List_Teacher_rank != null)
{
foreach(Teacher_rank oTeacher_rank in i_List_Teacher_rank)
{
oTeacher_rank.TEACHER_ID = i_Teacher.TEACHER_ID;
Edit_Teacher_rank(oTeacher_rank);
}
}
//-------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Teacher_WithTeacher_rank");}
}
#endregion
#region Reset_Teacher_report_By_Teacher
public void Reset_Teacher_report_By_Teacher(Teacher i_Teacher, List<Teacher_report> i_Teacher_report_List)
{
#region Declaration And Initialization Section.
Params_Delete_Teacher_report_By_TEACHER_ID oParams_Delete_Teacher_report_By_TEACHER_ID = new Params_Delete_Teacher_report_By_TEACHER_ID();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Teacher_report_By_Teacher");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Existing Teacher_report
//---------------------------------
oParams_Delete_Teacher_report_By_TEACHER_ID.TEACHER_ID = i_Teacher.TEACHER_ID;
Delete_Teacher_report_By_TEACHER_ID(oParams_Delete_Teacher_report_By_TEACHER_ID);
//---------------------------------
// Edit Teacher_report
//---------------------------------
Edit_Teacher_WithTeacher_report(i_Teacher, i_Teacher_report_List);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Teacher_report_By_Teacher");}
}
#endregion
#region Reset_Teacher_report_By_Teacher
public void Reset_Teacher_report_By_Teacher(Teacher i_Teacher, List<Teacher_report> i_Teacher_report_List_To_Delete,List<Teacher_report> i_Teacher_report_List_To_Create)
{
#region Declaration And Initialization Section.
Params_Delete_Teacher_report oParams_Delete_Teacher_report = new Params_Delete_Teacher_report();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Reset_Teacher_report_By_Teacher");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Delete Specified Items 
//---------------------------------
 if (i_Teacher_report_List_To_Delete != null)
{
foreach (var oRow in i_Teacher_report_List_To_Delete)
{
oParams_Delete_Teacher_report.TEACHER_REPORT_ID = oRow.TEACHER_REPORT_ID;
Delete_Teacher_report(oParams_Delete_Teacher_report);
}
}
//---------------------------------
// Edit Teacher_report
//---------------------------------
Edit_Teacher_WithTeacher_report(i_Teacher, i_Teacher_report_List_To_Create);
//---------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Reset_Teacher_report_By_Teacher");}
}
#endregion
#region Edit_Teacher_With_Teacher_report(Teacher i_Teacher,List<Teacher_report> i_Teacher_reportList)
public void Edit_Teacher_WithTeacher_report(Teacher i_Teacher,List<Teacher_report> i_List_Teacher_report)
{
#region Declaration And Initialization Section.
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Teacher_WithTeacher_report");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Business Operation.
//-------------------------------
Edit_Teacher(i_Teacher);
if (i_List_Teacher_report != null)
{
foreach(Teacher_report oTeacher_report in i_List_Teacher_report)
{
oTeacher_report.TEACHER_ID = i_Teacher.TEACHER_ID;
Edit_Teacher_report(oTeacher_report);
}
}
//-------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Teacher_WithTeacher_report");}
}
#endregion
#region Edit_Teacher_WithRelatedData(Teacher i_Teacher,List<Answer> i_List_Answer,List<Answer_report> i_List_Answer_report,List<Article> i_List_Article,List<Favorite_teacher> i_List_Favorite_teacher,List<Question> i_List_Question,List<Question_report> i_List_Question_report,List<Teacher_category> i_List_Teacher_category,List<Teacher_favorite> i_List_Teacher_favorite,List<Teacher_rank> i_List_Teacher_rank,List<Teacher_report> i_List_Teacher_report)
public void Edit_Teacher_WithRelatedData(Teacher i_Teacher,List<Answer> i_List_Answer,List<Answer_report> i_List_Answer_report,List<Article> i_List_Article,List<Favorite_teacher> i_List_Favorite_teacher,List<Question> i_List_Question,List<Question_report> i_List_Question_report,List<Teacher_category> i_List_Teacher_category,List<Teacher_favorite> i_List_Teacher_favorite,List<Teacher_rank> i_List_Teacher_rank,List<Teacher_report> i_List_Teacher_report)
{
#region Declaration And Initialization Section.
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Edit_Teacher_WithRelatedData");}
#region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
// Business Operation.
//-------------------------------
Edit_Teacher(i_Teacher);
if (i_List_Answer != null)
{
foreach(Answer oAnswer in i_List_Answer)
{
oAnswer.TEACHER_ID = i_Teacher.TEACHER_ID;
Edit_Answer(oAnswer);
}
}
if (i_List_Answer_report != null)
{
foreach(Answer_report oAnswer_report in i_List_Answer_report)
{
oAnswer_report.TEACHER_ID = i_Teacher.TEACHER_ID;
Edit_Answer_report(oAnswer_report);
}
}
if (i_List_Article != null)
{
foreach(Article oArticle in i_List_Article)
{
oArticle.TEACHER_ID = i_Teacher.TEACHER_ID;
Edit_Article(oArticle);
}
}
if (i_List_Favorite_teacher != null)
{
foreach(Favorite_teacher oFavorite_teacher in i_List_Favorite_teacher)
{
oFavorite_teacher.TEACHER_ID = i_Teacher.TEACHER_ID;
Edit_Favorite_teacher(oFavorite_teacher);
}
}
if (i_List_Question != null)
{
foreach(Question oQuestion in i_List_Question)
{
oQuestion.TEACHER_ID = i_Teacher.TEACHER_ID;
Edit_Question(oQuestion);
}
}
if (i_List_Question_report != null)
{
foreach(Question_report oQuestion_report in i_List_Question_report)
{
oQuestion_report.TEACHER_ID = i_Teacher.TEACHER_ID;
Edit_Question_report(oQuestion_report);
}
}
if (i_List_Teacher_category != null)
{
foreach(Teacher_category oTeacher_category in i_List_Teacher_category)
{
oTeacher_category.TEACHER_ID = i_Teacher.TEACHER_ID;
Edit_Teacher_category(oTeacher_category);
}
}
if (i_List_Teacher_favorite != null)
{
foreach(Teacher_favorite oTeacher_favorite in i_List_Teacher_favorite)
{
oTeacher_favorite.TEACHER_ID = i_Teacher.TEACHER_ID;
Edit_Teacher_favorite(oTeacher_favorite);
}
}
if (i_List_Teacher_rank != null)
{
foreach(Teacher_rank oTeacher_rank in i_List_Teacher_rank)
{
oTeacher_rank.TEACHER_ID = i_Teacher.TEACHER_ID;
Edit_Teacher_rank(oTeacher_rank);
}
}
if (i_List_Teacher_report != null)
{
foreach(Teacher_report oTeacher_report in i_List_Teacher_report)
{
oTeacher_report.TEACHER_ID = i_Teacher.TEACHER_ID;
Edit_Teacher_report(oTeacher_report);
}
}
//-------------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Edit_Teacher_WithRelatedData");}
}
#endregion
#region Delete_Teacher_With_Children(Teacher i_Teacher)
public void Delete_Teacher_With_Children(Teacher i_Teacher)
{
 #region Declaration And Initialization Section.
Params_Delete_Teacher oParams_Delete_Teacher = new Params_Delete_Teacher();
Params_Delete_Answer_By_TEACHER_ID oParams_Delete_Answer_By_TEACHER_ID = new Params_Delete_Answer_By_TEACHER_ID();
Params_Delete_Answer_report_By_TEACHER_ID oParams_Delete_Answer_report_By_TEACHER_ID = new Params_Delete_Answer_report_By_TEACHER_ID();
Params_Delete_Article_By_TEACHER_ID oParams_Delete_Article_By_TEACHER_ID = new Params_Delete_Article_By_TEACHER_ID();
Params_Delete_Favorite_teacher_By_TEACHER_ID oParams_Delete_Favorite_teacher_By_TEACHER_ID = new Params_Delete_Favorite_teacher_By_TEACHER_ID();
Params_Delete_Question_By_TEACHER_ID oParams_Delete_Question_By_TEACHER_ID = new Params_Delete_Question_By_TEACHER_ID();
Params_Delete_Question_report_By_TEACHER_ID oParams_Delete_Question_report_By_TEACHER_ID = new Params_Delete_Question_report_By_TEACHER_ID();
Params_Delete_Teacher_category_By_TEACHER_ID oParams_Delete_Teacher_category_By_TEACHER_ID = new Params_Delete_Teacher_category_By_TEACHER_ID();
Params_Delete_Teacher_favorite_By_TEACHER_ID oParams_Delete_Teacher_favorite_By_TEACHER_ID = new Params_Delete_Teacher_favorite_By_TEACHER_ID();
Params_Delete_Teacher_rank_By_TEACHER_ID oParams_Delete_Teacher_rank_By_TEACHER_ID = new Params_Delete_Teacher_rank_By_TEACHER_ID();
Params_Delete_Teacher_report_By_TEACHER_ID oParams_Delete_Teacher_report_By_TEACHER_ID = new Params_Delete_Teacher_report_By_TEACHER_ID();
#endregion
if (OnPreEvent_General != null){OnPreEvent_General("Delete_Teacher_With_Children");}
 #region Body Section.
using (TransactionScope oScope = new TransactionScope())
{
//-------------------------
oParams_Delete_Answer_By_TEACHER_ID.TEACHER_ID = i_Teacher.TEACHER_ID;
Delete_Answer_By_TEACHER_ID(oParams_Delete_Answer_By_TEACHER_ID);
oParams_Delete_Answer_report_By_TEACHER_ID.TEACHER_ID = i_Teacher.TEACHER_ID;
Delete_Answer_report_By_TEACHER_ID(oParams_Delete_Answer_report_By_TEACHER_ID);
oParams_Delete_Article_By_TEACHER_ID.TEACHER_ID = i_Teacher.TEACHER_ID;
Delete_Article_By_TEACHER_ID(oParams_Delete_Article_By_TEACHER_ID);
oParams_Delete_Favorite_teacher_By_TEACHER_ID.TEACHER_ID = i_Teacher.TEACHER_ID;
Delete_Favorite_teacher_By_TEACHER_ID(oParams_Delete_Favorite_teacher_By_TEACHER_ID);
oParams_Delete_Question_By_TEACHER_ID.TEACHER_ID = i_Teacher.TEACHER_ID;
Delete_Question_By_TEACHER_ID(oParams_Delete_Question_By_TEACHER_ID);
oParams_Delete_Question_report_By_TEACHER_ID.TEACHER_ID = i_Teacher.TEACHER_ID;
Delete_Question_report_By_TEACHER_ID(oParams_Delete_Question_report_By_TEACHER_ID);
oParams_Delete_Teacher_category_By_TEACHER_ID.TEACHER_ID = i_Teacher.TEACHER_ID;
Delete_Teacher_category_By_TEACHER_ID(oParams_Delete_Teacher_category_By_TEACHER_ID);
oParams_Delete_Teacher_favorite_By_TEACHER_ID.TEACHER_ID = i_Teacher.TEACHER_ID;
Delete_Teacher_favorite_By_TEACHER_ID(oParams_Delete_Teacher_favorite_By_TEACHER_ID);
oParams_Delete_Teacher_rank_By_TEACHER_ID.TEACHER_ID = i_Teacher.TEACHER_ID;
Delete_Teacher_rank_By_TEACHER_ID(oParams_Delete_Teacher_rank_By_TEACHER_ID);
oParams_Delete_Teacher_report_By_TEACHER_ID.TEACHER_ID = i_Teacher.TEACHER_ID;
Delete_Teacher_report_By_TEACHER_ID(oParams_Delete_Teacher_report_By_TEACHER_ID);
//-------------------------

//-------------------------
oParams_Delete_Teacher.TEACHER_ID = i_Teacher.TEACHER_ID;
Delete_Teacher(oParams_Delete_Teacher);
//-------------------------
oScope.Complete();
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Delete_Teacher_With_Children");}
}
#endregion
}
}
