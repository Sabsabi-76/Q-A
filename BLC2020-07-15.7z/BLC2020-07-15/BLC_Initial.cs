﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Xml.Linq;

namespace BLC
{
    #region BLC
    public partial class BLC : IDisposable
    {
        #region Enumeration
        public enum Enum_Language
        {
            English = 0,
            French = 1,
            Arabic = 2
        }
        public enum Enum_BR_Codes
        {
            BR_9999,  // Invalid Credentials
            BR_0000,  // Uniqueness Violation                      
            BR_0001,   // Password should be at least 4 characters
            BR_0002,   // Teacher don't teach this subject
            BR_0003, //Blocked studetn can't question
            BR_0004,
            BR_0005,
            BR_0006,
            BR_0007,
            BR_0008,
            BR_0009,
            BR_0010,
            BR_0011, //Change username 
            BR_0012, // Account is inactive
            BR_0013,  //Only studetn asks question
            BR_0014,  // Pending questions = 4
            BR_0015,  // You don't teach this category can;t answer
            BR_0016,  // Only teacher publish article
            BR_0017   // Can't publish article # category
        }
        public enum Enum_EditMode
        {
            Add,
            Update
        }
        public enum Enum_Environment
        {
            BHS = 0,
            MS  = 1
        }
        public enum Enum_GradeMode
        {
            Over_One_Hundred = 0,
            Assignment = 1
        }
        #endregion
        #region Members
        private string _ConnectionString = string.Empty;
        DALC.IDALC _AppContext = null;
        Tools.Tools _Tools = new Tools.Tools();        
        #endregion
        #region Properties
        public string ConnectionString
        {
            get
            {
                return _ConnectionString;
            }
            set
            {
                _ConnectionString = value;
            }
        }
        public long? UserID { get; set; }
        public Int32? OwnerID { get; set; }
        public Enum_Language Language { get; set; }
        public string Messages_FilePath { get; set; }
        public List<Message> Messages { get; set; }
        public Enum_Environment Environment { get; set; }
        #endregion       
        #region Constructor
        public BLC()
        {
            #region Declaration And Initialization Section.
            #endregion
            #region Body Section.
            #endregion
        }
        public BLC(BLCInitializer i_BLCInitializer)
        {
            #region Declaration And Initialization Section.    
            Tools.Tools oTools = new Tools.Tools(); 
            #endregion
            #region Body Section.
            // ---------------------
            ConnectionString = i_BLCInitializer.ConnectionString;
            UserID = i_BLCInitializer.UserID;
            OwnerID = i_BLCInitializer.OwnerID;
            Language = i_BLCInitializer.Language;
            Messages_FilePath = i_BLCInitializer.Messages_FilePath;
            _AppContext = new DALC.MSSQL_DALC(_ConnectionString);
            // ---------------------

            // ---------------------
            LoadMessages();
            SubscribeToEvents();
            //Initialize_Audit_Mechanism();
            // ---------------------
                      

            #endregion
        }
        #endregion
        #region Subscribe To Events
        public void SubscribeToEvents()
        {
            #region Declaration And Initialization Section.
            #endregion
            #region Body Section.
            //General
            this.OnPreEvent_General += BLC_OnPreEvent_General_Prevent_if_Blocked;
            this.OnPreEvent_General += _Prevent_if_Blocked_Student;

            //Questions
            this.OnPostEvent_Edit_Question += BLC_OnPostEvent_Edit_Question_Notifie_Teachers;
            this.OnPreEvent_Edit_Question += BLC_OnPreEvent_Edit_Question_Prevent_if_Blocked;
            this.OnPreEvent_Edit_Question += BLC_OnPreEvent_Edit_Question_Prevent_Teacher_From_Asking;
            this.OnPostEvent_Edit_Question += BLC_OnPostEvent_Edit_Question_Pending_Question;
            this.OnPostEvent_Edit_Question += BLC_OnPostEvent_Edit_Question_Private_Question;

            //Answer
            this.OnPreEvent_Edit_Answer += BLC_OnPreEvent_Edit_Answer_Only_Teacher_Answers;
            this.OnPreEvent_Edit_Answer += BLC_OnPreEvent_Edit_Answer_Same_Category;
            this.OnPostEvent_Edit_Answer += BLC_OnPostEvent_Edit_Answer_Marked_Question; ;
            // Question/Question Report
            this.OnPostEvent_Edit_Question_report += BLC_OnPostEvent_Edit_Question_report;
            this.OnPostEvent_Edit_Answer_report  += BLC_OnPostEvent_Edit_Answer_report;

            //Evaluation for Answer
            this.OnPreEvent_Edit_Evaluation += BLC_OnPreEvent_Edit_Evaluation_Valid_Score;
            this.OnPostEvent_Edit_Evaluation += BLC_OnPostEvent_Edit_Evaluation_Answer_Score;

            //Article
            this.OnPreEvent_Edit_Article += BLC_OnPreEvent_Edit_Article_Same_Category;
            this.OnPreEvent_Edit_Article += BLC_OnPreEvent_Edit_Article_Only_Teacher;

            //Article Report
            this.OnPostEvent_Edit_Report_article += BLC_OnPostEvent_Edit_Report_article;

            //Appalud/Appreciate Article
            this.OnPreEvent_Edit_Appreciate += BLC_OnPreEvent_Edit_Appreciate_Once;
            this.OnPostEvent_Edit_Appreciate += BLC_OnPostEvent_Edit_Appreciate_Article_Applauds;
            #endregion
        }

        private void BLC_OnPreEvent_Edit_Appreciate_Once(Appreciate i_Appreciate, Enum_EditMode i_Enum_EditMode)
        {
            Params_Get_Appreciate_By_ARTICLE_ID_STUDENT_ID params_Get_Appreciate_By_ARTICLE_ID_STUDENT_ID = new Params_Get_Appreciate_By_ARTICLE_ID_STUDENT_ID();
            params_Get_Appreciate_By_ARTICLE_ID_STUDENT_ID.ARTICLE_ID = i_Appreciate.ARTICLE_ID;
            params_Get_Appreciate_By_ARTICLE_ID_STUDENT_ID.STUDENT_ID = i_Appreciate.STUDENT_ID;
            List<Appreciate> oAppList = Get_Appreciate_By_ARTICLE_ID_STUDENT_ID(params_Get_Appreciate_By_ARTICLE_ID_STUDENT_ID);
            if (oAppList.Count() > 0)
            {
                return;
            }
            
        }

        private void BLC_OnPostEvent_Edit_Appreciate_Article_Applauds(Appreciate i_Appreciate, Enum_EditMode i_Enum_EditMode)
        {
            Params_Get_Article_By_ARTICLE_ID params_Get_Article_By_ARTICLE_ID = new Params_Get_Article_By_ARTICLE_ID();
            params_Get_Article_By_ARTICLE_ID.ARTICLE_ID = i_Appreciate.ARTICLE_ID;
            Article oArticle = Get_Article_By_ARTICLE_ID(params_Get_Article_By_ARTICLE_ID);
            if (oArticle.APPLAUDS== null)
            {
                oArticle.APPLAUDS = 0;
            }
            oArticle.APPLAUDS++;
            Edit_Article(oArticle);
        }

        private void BLC_OnPostEvent_Edit_Answer_Marked_Question(Answer i_Answer, Enum_EditMode i_Enum_EditMode)
        {
            if (i_Enum_EditMode == Enum_EditMode.Add)
            {
                Params_Get_Mark_question_By_QUESTION_ID params_Get_Mark_Question_By_QUESTION_ID = new Params_Get_Mark_question_By_QUESTION_ID();
                params_Get_Mark_Question_By_QUESTION_ID.QUESTION_ID = i_Answer.QUESTION_ID;
                List<Mark_question> oList = Get_Mark_question_By_QUESTION_ID(params_Get_Mark_Question_By_QUESTION_ID);
                if (oList.Count() > 0)
                {
                    foreach (var item in oList)
                    {
                        Params_Get_Student_By_STUDENT_ID params_Get_Student_By_STUDENT_ID = new Params_Get_Student_By_STUDENT_ID();
                        params_Get_Student_By_STUDENT_ID.STUDENT_ID = item.STUDENT_ID;
                        Student oStudent = Get_Student_By_STUDENT_ID(params_Get_Student_By_STUDENT_ID);
                        Notification oNote = new Notification();
                        oNote.OWNER_ID = this.OwnerID;
                        oNote.NOTIFICATION_ID = -1;
                        oNote.USER_ID = oStudent.USER_ID;
                        oNote.ANSWER_ID = i_Answer.ANSWER_ID;
                        oNote.DESCRIPTION = String.Format("A question you have marked have a new answer, check it out! {0}",
                            i_Answer.DESCRIPTION);
                    }
                }

            }
        }

        private void BLC_OnPostEvent_Edit_Report_article(Report_article i_Report_article, Enum_EditMode i_Enum_EditMode)
        {
            Params_Get_Article_By_ARTICLE_ID params_Get_Article_By_ARTICLE_ID = new Params_Get_Article_By_ARTICLE_ID();
            params_Get_Article_By_ARTICLE_ID.ARTICLE_ID = i_Report_article.ARTICLE_ID;
            Article oArticle = Get_Article_By_ARTICLE_ID(params_Get_Article_By_ARTICLE_ID);
            if(oArticle.REPORTS == null)
            {
                oArticle.REPORTS = 0;
            }
            oArticle.REPORTS++;
            if (oArticle.REPORTS == 5)
            {
                Notification oNote = new Notification();
                oNote.NOTIFICATION_ID = -1;
                oNote.USER_ID = 1;
                oNote.ARTICLE_ID = i_Report_article.ARTICLE_ID;
                oNote.OWNER_ID = this.OwnerID;
                oNote.DESCRIPTION = String.Format("An article has been reported many times by students. Please take necessary actions: {0}", oArticle.TITLE);
                Edit_Notification(oNote);
                
            }
        }

        private void BLC_OnPreEvent_Edit_Article_Only_Teacher(Article i_Article, Enum_EditMode i_Enum_EditMode)
        {
            Params_Get_User_By_USER_ID params_Get_User_By_USER_ID = new Params_Get_User_By_USER_ID();
            params_Get_User_By_USER_ID.USER_ID = this.UserID;
            User oUser = Get_User_By_USER_ID(params_Get_User_By_USER_ID);
            if(oUser.USER_TYPE_CODE != "002")
            {
                throw new BLCException(GetMessageContent(Enum_BR_Codes.BR_0016));
            }
        }

        private void BLC_OnPreEvent_Edit_Article_Same_Category(Article i_Article, Enum_EditMode i_Enum_EditMode)
        {
            Params_Get_Teacher_category_By_TEACHER_ID params_Get_Teacher_Category_By_TEACHER_ID = 
                new Params_Get_Teacher_category_By_TEACHER_ID();
            params_Get_Teacher_Category_By_TEACHER_ID.TEACHER_ID = i_Article.TEACHER_ID;
            List<Teacher_category> oTCatList = Get_Teacher_category_By_TEACHER_ID(params_Get_Teacher_Category_By_TEACHER_ID);
            if (oTCatList.Count() > 0)
            {
                bool found = false;
                foreach (var item in oTCatList)
                {
                    if(item.CATEGORY_ID == i_Article.CATEGORY_ID)
                    {
                        found = true;
                        break;
                    }
                    if(found == false)
                    {
                        throw new BLCException(GetMessageContent(Enum_BR_Codes.BR_0017));
                    }
                }
            }
        }

        private void BLC_OnPostEvent_Edit_Evaluation_Answer_Score(Evaluation i_Evaluation, Enum_EditMode i_Enum_EditMode)
        {
            Params_Get_Answer_By_ANSWER_ID params_Get_Answer_By_ANSWER_ID = new Params_Get_Answer_By_ANSWER_ID();
            params_Get_Answer_By_ANSWER_ID.ANSWER_ID = i_Evaluation.ANSWER_ID;
            Answer oAnswer = Get_Answer_By_ANSWER_ID(params_Get_Answer_By_ANSWER_ID);
            //Params_Get_Evaluation_By_ANSWER_ID params_Get_Evaluation_By_ANSWER_ID = new Params_Get_Evaluation_By_ANSWER_ID ();
            //params_Get_Evaluation_By_ANSWER_ID.ANSWER_ID = i_Evaluation.ANSWER_ID;
            //List<Evaluation> oEvalList = Get_Evaluation_By_ANSWER_ID(params_Get_Evaluation_By_ANSWER_ID);
            if(oAnswer.REVIEWS == null)
            {
                oAnswer.REVIEWS = 0;
            }
            oAnswer.REVIEWS++;
            if (oAnswer.REVIEWS == 1)
            {
                oAnswer.SCORE = i_Evaluation.SCORE;
                
                Edit_Answer(oAnswer);
            }
            else
            {
                oAnswer.SCORE = ((oAnswer.SCORE * (oAnswer.REVIEWS - 1)) + i_Evaluation.SCORE) / oAnswer.REVIEWS;
                Edit_Answer(oAnswer);
            }
            if (oAnswer.SCORE >= 7)
            {
                Params_Get_Question_By_QUESTION_ID params_Get_Question_By_QUESTION_ID = new Params_Get_Question_By_QUESTION_ID();
                params_Get_Question_By_QUESTION_ID.QUESTION_ID = oAnswer.QUESTION_ID;
                Question oQ = Get_Question_By_QUESTION_ID(params_Get_Question_By_QUESTION_ID);
                oQ.IS_ANSWERED = true;
                Edit_Question(oQ);
            }

        }

        private void BLC_OnPreEvent_Edit_Evaluation_Valid_Score(Evaluation i_Evaluation, Enum_EditMode i_Enum_EditMode)
        {
            if((i_Evaluation.SCORE < 0) &&(i_Evaluation.SCORE>10))
            {
                throw new BLCException(GetMessageContent(Enum_BR_Codes.BR_0006));
            }
        }

        private void BLC_OnPostEvent_Edit_Answer_report(Answer_report i_Answer_report, Enum_EditMode i_Enum_EditMode)
        {
            //check whether teacher reporting
            if(i_Answer_report.TEACHER_ID != null)
            {
                Params_Get_Answer_By_ANSWER_ID params_Get_Answer_By_ANSWER_ID = new Params_Get_Answer_By_ANSWER_ID();
                params_Get_Answer_By_ANSWER_ID.ANSWER_ID = i_Answer_report.ANSWER_ID;
                Answer oAnswer = Get_Answer_By_ANSWER_ID(params_Get_Answer_By_ANSWER_ID);
                Notification oNote = new Notification();
                oNote.NOTIFICATION_ID = -1;
                oNote.USER_ID = 1;
                oNote.ANSWER_ID = i_Answer_report.ANSWER_ID;
                oNote.DESCRIPTION = String.Format("An answer have been reported by a teacher, please take necessary action: {0}", oAnswer.DESCRIPTION);
                Edit_Notification(oNote);
            }
            else if (i_Answer_report.STUDENT_ID != null)
            {
                Params_Get_Answer_By_ANSWER_ID params_Get_Answer_By_ANSWER_ID = new Params_Get_Answer_By_ANSWER_ID();
                params_Get_Answer_By_ANSWER_ID.ANSWER_ID = i_Answer_report.ANSWER_ID;
                Answer oAnswer = Get_Answer_By_ANSWER_ID(params_Get_Answer_By_ANSWER_ID);
                if (oAnswer.REPORTS == null)
                {
                    oAnswer.REPORTS = 0;
                }
                oAnswer.REPORTS++;
                Edit_Answer(oAnswer);
                if (oAnswer.REPORTS == 5)
                {
                    Notification oNote = new Notification();
                    oNote.NOTIFICATION_ID = -1;
                    oNote.USER_ID = 1;
                    oNote.ANSWER_ID = i_Answer_report.ANSWER_ID;
                    oNote.DESCRIPTION = String.Format("An answer have been reported many times by students, please take necessary action: {0}", oAnswer.DESCRIPTION);
                    Edit_Notification(oNote);
                }
            }
        }

        private void BLC_OnPostEvent_Edit_Question_report(Question_report i_Question_report, Enum_EditMode i_Enum_EditMode)
        {
            //check if teacher reporting
            if (i_Question_report.TEACHER_ID != null)
            {
                Params_Get_Question_By_QUESTION_ID params_Get_Question_By_QUESTION_ID = new Params_Get_Question_By_QUESTION_ID();
                params_Get_Question_By_QUESTION_ID.QUESTION_ID = i_Question_report.QUESTION_ID;
                Params_Get_Student_By_STUDENT_ID params_Get_Student_By_STUDENT_ID = new Params_Get_Student_By_STUDENT_ID();
                params_Get_Student_By_STUDENT_ID.STUDENT_ID = i_Question_report.STUDENT_ID;
                Student oStudent = Get_Student_By_STUDENT_ID(params_Get_Student_By_STUDENT_ID);
                Question oQ = Get_Question_By_QUESTION_ID(params_Get_Question_By_QUESTION_ID);
                oQ.IS_ACTIVE = false;
                Edit_Question(oQ);
                oStudent.IS_BLOCKED = true;
                Edit_Student(oStudent);
            }

            else if (i_Question_report.STUDENT_ID != null)
            {
                Params_Get_Question_By_QUESTION_ID params_Get_Question_By_QUESTION_ID = new Params_Get_Question_By_QUESTION_ID();
                params_Get_Question_By_QUESTION_ID.QUESTION_ID = i_Question_report.QUESTION_ID;
                Question oQ = Get_Question_By_QUESTION_ID(params_Get_Question_By_QUESTION_ID);
                if(oQ.REPORTS == null)
                {
                    oQ.REPORTS = 0;
                }
                oQ.REPORTS++;
                if(oQ.REPORTS == 5)
                {
                   
                    //Params_Get_Student_By_STUDENT_ID params_Get_Student_By_STUDENT_ID = new Params_Get_Student_By_STUDENT_ID();
                    //params_Get_Student_By_STUDENT_ID.STUDENT_ID = i_Question_report.STUDENT_ID;
                    //Student oStudent = Get_Student_By_STUDENT_ID(params_Get_Student_By_STUDENT_ID);
                    Notification oNote = new Notification();
                    oNote.NOTIFICATION_ID = -1;
                    oNote.USER_ID = 1;
                    oNote.QUESTION_ID = i_Question_report.QUESTION_ID;
                    oNote.DESCRIPTION = String.Format("A question have been reported many times by students, please take necessary action: {0}", oQ.DESCRIPTION);
                    Edit_Notification(oNote);
                }
            }
        }

        private void BLC_OnPreEvent_Edit_Answer_Same_Category(Answer i_Answer, Enum_EditMode i_Enum_EditMode)
        {
            Params_Get_Teacher_category_By_TEACHER_ID params_Get_Teacher_Category_By_TEACHER_ID = new Params_Get_Teacher_category_By_TEACHER_ID();
            params_Get_Teacher_Category_By_TEACHER_ID.TEACHER_ID = i_Answer.TEACHER_ID;
            Params_Get_Question_By_QUESTION_ID params_Get_Question_By_QUESTION_ID = new Params_Get_Question_By_QUESTION_ID();
            params_Get_Question_By_QUESTION_ID.QUESTION_ID = i_Answer.QUESTION_ID;
            Question oQ = Get_Question_By_QUESTION_ID(params_Get_Question_By_QUESTION_ID);
            List<Teacher_category> otCatList = Get_Teacher_category_By_TEACHER_ID(params_Get_Teacher_Category_By_TEACHER_ID);
            if (otCatList.Count() > 0)
            {
                bool found = false;
                foreach (var item in otCatList)
                {
                    if(item.CATEGORY_ID == oQ.CATEGORY_ID)
                    {
                        found = true;
                        break;
                    }
                }
                if (found == false)
                {
                    throw new BLCException(GetMessageContent(Enum_BR_Codes.BR_0015));
                }
            }
        }

        private BLCInitializer BLC_OnPreEvent_BLC_Init(string i_Ticket, Enum_API_Method i_Enum_API_Method)
        {
            throw new NotImplementedException();
        }

        private void BLC_OnPreEvent_Edit_Answer_Only_Teacher_Answers(Answer i_Answer, Enum_EditMode i_Enum_EditMode)
        {
            Params_Get_User_By_USER_ID params_Get_User_By_USER_ID = new Params_Get_User_By_USER_ID();
            params_Get_User_By_USER_ID.USER_ID = this.UserID;
            User oUser = Get_User_By_USER_ID(params_Get_User_By_USER_ID);
            if(oUser.USER_TYPE_CODE != "002")
            {
                throw new BLCException(GetMessageContent(Enum_BR_Codes.BR_0004));
            }
        }

        private void BLC_OnPostEvent_Edit_Question_Private_Question(Question i_Question, Enum_EditMode i_Enum_EditMode)
        {
            if(i_Question.TEACHER_ID != null)
            {
                Params_Get_Teacher_category_By_TEACHER_ID params_Get_Teacher_Category_By_TEACHER_ID = new Params_Get_Teacher_category_By_TEACHER_ID();
                params_Get_Teacher_Category_By_TEACHER_ID.TEACHER_ID = i_Question.TEACHER_ID;
                List<Teacher_category> otcatList = Get_Teacher_category_By_TEACHER_ID(params_Get_Teacher_Category_By_TEACHER_ID);
                if (otcatList.Count() > 0)
                {
                    bool found = false; 
                    foreach(Teacher_category tCat in otcatList)
                    {
                        if(tCat.CATEGORY_ID == i_Question.CATEGORY_ID)
                        {
                            found = true;
                        }

                    }
                    if (found == true)
                    {
                        Params_Get_Teacher_By_TEACHER_ID params_Get_Teacher_By_TEACHER_ID = new Params_Get_Teacher_By_TEACHER_ID();
                        params_Get_Teacher_By_TEACHER_ID.TEACHER_ID = i_Question.TEACHER_ID;
                        Teacher oTeacher = Get_Teacher_By_TEACHER_ID(params_Get_Teacher_By_TEACHER_ID);
                        Notification oNote = new Notification();
                        oNote.NOTIFICATION_ID = -1;
                        oNote.QUESTION_ID = i_Question.QUESTION_ID;
                        oNote.USER_ID = oTeacher.USER_ID;
                        oNote.OWNER_ID = this.OwnerID;
                        oNote.DESCRIPTION = String.Format("A student asked you a private question: {0}", i_Question.DESCRIPTION);
                        Edit_Notification(oNote);
                    }

                    else
                    {
                        //Teacher you are asking don't teach subjects
                        throw new BLCException(GetMessageContent(Enum_BR_Codes.BR_0002));
                    }

                }
            }
        }

        private void BLC_OnPostEvent_Edit_Question_Pending_Question(Question i_Question, Enum_EditMode i_Enum_EditMode)
        {
            Params_Get_Student_By_STUDENT_ID params_Get_Student_By_STUDENT_ID = new Params_Get_Student_By_STUDENT_ID();
            params_Get_Student_By_STUDENT_ID.STUDENT_ID = i_Question.STUDENT_ID;
            Student oStudent = Get_Student_By_STUDENT_ID(params_Get_Student_By_STUDENT_ID);
            if (oStudent.PENDING_QUESTIONS == null)
            {
                oStudent.PENDING_QUESTIONS = 0;
            }
            oStudent.PENDING_QUESTIONS++;
            if(oStudent.PENDING_QUESTIONS == 5)
            {
                throw new BLCException(GetMessageContent(Enum_BR_Codes.BR_0014));
            }
            
        }

        private void BLC_OnPreEvent_Edit_Question_Prevent_Teacher_From_Asking(Question i_Question, Enum_EditMode i_Enum_EditMode)
        {

            Params_Get_User_By_USER_ID params_Get_User_By_USER_ID = new Params_Get_User_By_USER_ID();
            params_Get_User_By_USER_ID.USER_ID = this.UserID;
            User oUser = Get_User_By_USER_ID(params_Get_User_By_USER_ID);
            //check if teacher
            if(oUser.USER_TYPE_CODE == "002")
            {
                throw new BLCException(GetMessageContent(Enum_BR_Codes.BR_0013));
            }
            
        }

        private void BLC_OnPreEvent_Edit_Question_Prevent_if_Blocked(Question i_Question, Enum_EditMode i_Enum_EditMode)
        {
            Params_Get_Student_By_STUDENT_ID params_Get_Student_By_STUDENT_ID = new Params_Get_Student_By_STUDENT_ID();
            params_Get_Student_By_STUDENT_ID.STUDENT_ID = i_Question.STUDENT_ID;
            Student oStudent = Get_Student_By_STUDENT_ID(params_Get_Student_By_STUDENT_ID);
            if (oStudent.IS_BLOCKED == true)
            {
                throw new BLCException(GetMessageContent(Enum_BR_Codes.BR_0003));
            }
        }

        private void BLC_OnPostEvent_Edit_Question_Notifie_Teachers(Question i_Question, Enum_EditMode i_Enum_EditMode)
        {
            // check if private question
            if (i_Question.TEACHER_ID == null)
            {
                Params_Get_Teacher_category_By_CATEGORY_ID params_Get_Teacher_Category_By_CATEGORY_ID = new Params_Get_Teacher_category_By_CATEGORY_ID();
                params_Get_Teacher_Category_By_CATEGORY_ID.CATEGORY_ID = i_Question.CATEGORY_ID;
                List<Teacher_category> oTCatList = Get_Teacher_category_By_CATEGORY_ID(params_Get_Teacher_Category_By_CATEGORY_ID);
                if (oTCatList.Count() > 0)
                {

                    foreach (Teacher_category otCat in oTCatList)
                    {
                        Params_Get_Teacher_By_TEACHER_ID params_Get_Teacher_By_TEACHER_ID = new Params_Get_Teacher_By_TEACHER_ID();
                        params_Get_Teacher_By_TEACHER_ID.TEACHER_ID = otCat.TEACHER_ID;
                        Teacher oT = Get_Teacher_By_TEACHER_ID(params_Get_Teacher_By_TEACHER_ID);
                        Notification oNote = new Notification();
                        oNote.NOTIFICATION_ID = -1;
                        oNote.QUESTION_ID = i_Question.QUESTION_ID;
                        oNote.USER_ID = oT.USER_ID;
                        oNote.DESCRIPTION = String.Format("A student asked a question in your subject : {0}", i_Question.DESCRIPTION);
                        Edit_Notification(oNote);
                    }
                }
            }

        }

        private void _Prevent_if_Blocked_Student(string i_MethodName)
        {
            Params_Get_Student_By_USER_ID params_Get_Student_By_USER_ID = new Params_Get_Student_By_USER_ID();
            params_Get_Student_By_USER_ID.USER_ID =Convert.ToInt32(this.UserID);
            List<Student> oStudent = Get_Student_By_USER_ID(params_Get_Student_By_USER_ID);

            if ((oStudent.Count > 0) && (oStudent != null))
            {
                if (oStudent[0].IS_BLOCKED == true)
                {
                    switch (i_MethodName)
                    {
                        case "Edit_Question":
                            throw new BLCException(GetMessageContent(Enum_BR_Codes.BR_0012));
                    }
                }
            }
        }

        private void BLC_OnPreEvent_General_Prevent_if_Blocked(string i_MethodName)
        {
            Params_Get_Teacher_By_USER_ID params_Get_Teacher_By_USER_ID = new Params_Get_Teacher_By_USER_ID();
            params_Get_Teacher_By_USER_ID.USER_ID =Convert.ToInt32( this.UserID);
            List<Teacher> oteacherList = Get_Teacher_By_USER_ID(params_Get_Teacher_By_USER_ID);
            if ((oteacherList.Count > 0) && (oteacherList != null))
            {
                if (oteacherList[0].IS_BLOCKED == true)
                {
                    switch (i_MethodName)
                    {
                        case "Edit_Answer":
                            throw new BLCException(GetMessageContent(Enum_BR_Codes.BR_0012));
                    }
                }
            }

        }
        #endregion
        #region IDisposable Members
        public void Dispose()
        {
            #region Body Section.
            #endregion
        }
        #endregion
        #region LoadMessages
        public void LoadMessages()
        {
            #region Declaration And Initialization Section.
            XElement oRoot = null;
            XElement oLanguage = null;
            #endregion
            #region Body Section.
            this.Messages = new List<Message>();

            if (!string.IsNullOrEmpty(this.Messages_FilePath))
            {
                oRoot = XElement.Load(this.Messages_FilePath);
                if (oRoot != null)
                {
                    switch (Language)
                    {
                        case Enum_Language.English:
                            oLanguage = oRoot.Element("ENGLISH");
                            break;
                        case Enum_Language.Arabic:
                            oLanguage = oRoot.Element("ARABIC");
                            break;
                        default:
                            oLanguage = oRoot.Element("ENGLISH");
                            break;
                    }

                    foreach (var oItem in oLanguage.Elements("MESSAGE"))
                    {
                        this.Messages.Add(new Message() { Code = oItem.Attribute("CODE").Value, Content = oItem.Attribute("CONTENT").Value });
                    }
                }
            }
            #endregion
        }
        #endregion
        #region GetMessageContent
        public string GetMessageContent(Enum_BR_Codes i_BR_Code)
        {
            #region Declaration And Initialization Section.
            string str_ReturnValue = string.Empty;
            #endregion
            #region Body Section.
            var oResult = this.Messages.First(x => x.Code == i_BR_Code.ToString());
            str_ReturnValue = oResult.Content;
            #endregion
            #region Return Section.
            return str_ReturnValue;
            #endregion
        }
        #endregion
        #region GetMessageContent
        public string GetMessageContent(Enum_BR_Codes i_BR_Code, Dictionary<string, string> i_PlaceHolders)
        {
            #region Declaration And Initialization Section.
            string str_ReturnValue = string.Empty;
            #endregion
            #region Body Section.
            var oResult = this.Messages.First(x => x.Code == i_BR_Code.ToString());
            str_ReturnValue = oResult.Content;

            foreach (var oItem in i_PlaceHolders)
            {
                str_ReturnValue = str_ReturnValue.Replace(oItem.Key, oItem.Value);
            }
            #endregion
            #region Return Section.
            return str_ReturnValue;
            #endregion
        }
        #endregion
        #region Events Implementation

        #endregion
    }
    #endregion
    #region BLCInitializer
    public class BLCInitializer
    {
        #region Properties
        public string ConnectionString { get; set; }
        public long? UserID { get; set; }
        public Int32? OwnerID { get; set; }
        public BLC.Enum_Language Language { get; set; }
        public string Messages_FilePath { get; set; }
        #endregion
    }
    #endregion
    #region Message
    public class Message
    {
        #region Properties
        public string Code { get; set; }
        public string Content { get; set; }
        #endregion
    }
    #endregion
    #region EnvCode Attribute
    #region EnvCode
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method | AttributeTargets.Constructor, AllowMultiple = true)]
    public class EnvCode : System.Attribute
    {
        #region Properties
        public BLC.Enum_Environment Environment { get; set; }
        public string MethodName { get; set; }
        #endregion
        #region Constructor
        public EnvCode(BLC.Enum_Environment i_Environment, string i_MethodName)
        {
            #region Body Section.
            Environment = i_Environment;
            MethodName = i_MethodName;
            #endregion
        }
        #endregion
        #region Behavior
        #region GetEnvCode
        public static MethodInfo GetEnvCode(Params_GetEnvCode i_Params_GetEnvCode)
        {
            #region Declaration And Initialization Section.
            MethodInfo[] oMethods = null;
            MethodInfo oMethodInfo = null;
            object[] oAttributes = null;
            EnvCode oEnvCode = null;

            bool Is_AlreadyFound = false;
            MethodInfo oMethodInfo_ReturnValue = null;
            #endregion
            #region Body Section.

            // ----------------------
            oMethods = i_Params_GetEnvCode.My_Type.GetMethods();
            // ----------------------

            // ----------------------
            for (int i = 0; i < oMethods.GetLength(0); i++)
            {
                // ----------------------
                if (Is_AlreadyFound == true)
                {
                    break;
                }
                // ----------------------

                // ----------------------
                oMethodInfo = oMethods[i];
                oAttributes = oMethodInfo.GetCustomAttributes(true);
                // ----------------------

                // ----------------------
                foreach (Attribute oAttribute in oAttributes)
                {
                    if (oAttribute is EnvCode)
                    {
                        oEnvCode = oAttribute as EnvCode;
                        if (oEnvCode != null)
                        {
                            if ((oEnvCode.Environment == i_Params_GetEnvCode.My_Environment) && (oEnvCode.MethodName == i_Params_GetEnvCode.My_MethodName))
                            {
                                oMethodInfo_ReturnValue = oMethodInfo;
                                Is_AlreadyFound = true;
                                break;
                            }
                        }
                    }
                }
                // ----------------------
            }
            // ----------------------
            #endregion
            #region Return Section.
            return oMethodInfo_ReturnValue;
            #endregion
        }
        #endregion
        #endregion
    }
    #endregion
    #region Params_GetEnvCode
    public class Params_GetEnvCode
    {
        #region Properties.
        public System.Type My_Type { get; set; }
        public BLC.Enum_Environment My_Environment { get; set; }
        public string My_MethodName { get; set; }
        #endregion
    }
    #endregion
    #endregion
}


