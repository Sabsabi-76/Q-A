using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;
using System.Configuration;
using DALC;
//using System.Data.Linq;
using System.Text.RegularExpressions;
using System.Transactions;
using System.Reflection;
using System.Diagnostics;
using System.Data.SqlClient;
using System.Threading;







namespace BLC
{
#region Params_Get_Favorite_category_By_FAVORITE_CATEGORY_ID
public partial class Params_Get_Favorite_category_By_FAVORITE_CATEGORY_ID
{
#region Properties
public Int32? FAVORITE_CATEGORY_ID {get;set;}

#endregion
}
#endregion
#region Params_Get_Category_By_CATEGORY_ID
public partial class Params_Get_Category_By_CATEGORY_ID
{
#region Properties
public Int32? CATEGORY_ID {get;set;}

#endregion
}
#endregion
#region Params_Get_Owner_By_OWNER_ID
public partial class Params_Get_Owner_By_OWNER_ID
{
#region Properties
public Int32? OWNER_ID {get;set;}

#endregion
}
#endregion
#region Params_Get_Question_By_QUESTION_ID
public partial class Params_Get_Question_By_QUESTION_ID
{
#region Properties
public Int32? QUESTION_ID {get;set;}

#endregion
}
#endregion
#region Params_Get_Report_article_By_REPORT_ARTICLE_ID
public partial class Params_Get_Report_article_By_REPORT_ARTICLE_ID
{
#region Properties
public Int32? REPORT_ARTICLE_ID {get;set;}

#endregion
}
#endregion
#region Params_Get_Mark_question_By_MARK_QUESTION_ID
public partial class Params_Get_Mark_question_By_MARK_QUESTION_ID
{
#region Properties
public Int32? MARK_QUESTION_ID {get;set;}

#endregion
}
#endregion
#region Params_Get_Article_By_ARTICLE_ID
public partial class Params_Get_Article_By_ARTICLE_ID
{
#region Properties
public Int32? ARTICLE_ID {get;set;}

#endregion
}
#endregion
#region Params_Get_Answer_By_ANSWER_ID
public partial class Params_Get_Answer_By_ANSWER_ID
{
#region Properties
public Int32? ANSWER_ID {get;set;}

#endregion
}
#endregion
#region Params_Get_Student_By_STUDENT_ID
public partial class Params_Get_Student_By_STUDENT_ID
{
#region Properties
public Int32? STUDENT_ID {get;set;}

#endregion
}
#endregion
#region Params_Get_Notification_By_NOTIFICATION_ID
public partial class Params_Get_Notification_By_NOTIFICATION_ID
{
#region Properties
public Int32? NOTIFICATION_ID {get;set;}

#endregion
}
#endregion
#region Params_Get_User_By_USER_ID
public partial class Params_Get_User_By_USER_ID
{
#region Properties
public long? USER_ID {get;set;}

#endregion
}
#endregion
#region Params_Get_Evaluation_By_EVALUATION_ID
public partial class Params_Get_Evaluation_By_EVALUATION_ID
{
#region Properties
public Int32? EVALUATION_ID {get;set;}

#endregion
}
#endregion
#region Params_Get_Student_report_By_STUDENT_REPORT_ID
public partial class Params_Get_Student_report_By_STUDENT_REPORT_ID
{
#region Properties
public Int32? STUDENT_REPORT_ID {get;set;}

#endregion
}
#endregion
#region Params_Get_Appreciate_By_APPRECIATE_ID
public partial class Params_Get_Appreciate_By_APPRECIATE_ID
{
#region Properties
public Int32? APPRECIATE_ID {get;set;}

#endregion
}
#endregion
#region Params_Get_Teacher_report_By_TEACHER_REPORT_ID
public partial class Params_Get_Teacher_report_By_TEACHER_REPORT_ID
{
#region Properties
public Int32? TEACHER_REPORT_ID {get;set;}

#endregion
}
#endregion
#region Params_Get_Question_report_By_QUESTION_REPORT_ID
public partial class Params_Get_Question_report_By_QUESTION_REPORT_ID
{
#region Properties
public Int32? QUESTION_REPORT_ID {get;set;}

#endregion
}
#endregion
#region Params_Get_Answer_report_By_ANSWER_REPORT_ID
public partial class Params_Get_Answer_report_By_ANSWER_REPORT_ID
{
#region Properties
public Int32? ANSWER_REPORT_ID {get;set;}

#endregion
}
#endregion
#region Params_Get_Teacher_rank_By_TEACHER_RANK_ID
public partial class Params_Get_Teacher_rank_By_TEACHER_RANK_ID
{
#region Properties
public Int32? TEACHER_RANK_ID {get;set;}

#endregion
}
#endregion
#region Params_Get_Teacher_By_TEACHER_ID
public partial class Params_Get_Teacher_By_TEACHER_ID
{
#region Properties
public Int32? TEACHER_ID {get;set;}

#endregion
}
#endregion
#region Params_Get_Question_token_By_QUESTION_TOKEN_ID
public partial class Params_Get_Question_token_By_QUESTION_TOKEN_ID
{
#region Properties
public long? QUESTION_TOKEN_ID {get;set;}

#endregion
}
#endregion
#region Params_Get_Teacher_category_By_TEACHER_CATEGORY_ID
public partial class Params_Get_Teacher_category_By_TEACHER_CATEGORY_ID
{
#region Properties
public Int32? TEACHER_CATEGORY_ID {get;set;}

#endregion
}
#endregion
#region Params_Get_Favorite_teacher_By_FAVORITE_TEACHER_ID
public partial class Params_Get_Favorite_teacher_By_FAVORITE_TEACHER_ID
{
#region Properties
public Int32? FAVORITE_TEACHER_ID {get;set;}

#endregion
}
#endregion
#region Params_Get_Teacher_favorite_By_TEACHER_FAVORITE_ID
public partial class Params_Get_Teacher_favorite_By_TEACHER_FAVORITE_ID
{
#region Properties
public Int32? TEACHER_FAVORITE_ID {get;set;}

#endregion
}
#endregion
public partial class Params_Get_Favorite_category_By_FAVORITE_CATEGORY_ID_List
{
public List<Int32?> FAVORITE_CATEGORY_ID_LIST {get;set;}
}
public partial class Params_Get_Favorite_category_By_FAVORITE_CATEGORY_ID_List_SP
{
public string FAVORITE_CATEGORY_ID_LIST {get;set;}

}
public partial class Params_Get_Category_By_CATEGORY_ID_List
{
public List<Int32?> CATEGORY_ID_LIST {get;set;}
}
public partial class Params_Get_Category_By_CATEGORY_ID_List_SP
{
public string CATEGORY_ID_LIST {get;set;}

}
public partial class Params_Get_Owner_By_OWNER_ID_List
{
public List<Int32?> OWNER_ID_LIST {get;set;}
}
public partial class Params_Get_Owner_By_OWNER_ID_List_SP
{
public string OWNER_ID_LIST {get;set;}

}
public partial class Params_Get_Question_By_QUESTION_ID_List
{
public List<Int32?> QUESTION_ID_LIST {get;set;}
}
public partial class Params_Get_Question_By_QUESTION_ID_List_SP
{
public string QUESTION_ID_LIST {get;set;}

}
public partial class Params_Get_Report_article_By_REPORT_ARTICLE_ID_List
{
public List<Int32?> REPORT_ARTICLE_ID_LIST {get;set;}
}
public partial class Params_Get_Report_article_By_REPORT_ARTICLE_ID_List_SP
{
public string REPORT_ARTICLE_ID_LIST {get;set;}

}
public partial class Params_Get_Mark_question_By_MARK_QUESTION_ID_List
{
public List<Int32?> MARK_QUESTION_ID_LIST {get;set;}
}
public partial class Params_Get_Mark_question_By_MARK_QUESTION_ID_List_SP
{
public string MARK_QUESTION_ID_LIST {get;set;}

}
public partial class Params_Get_Article_By_ARTICLE_ID_List
{
public List<Int32?> ARTICLE_ID_LIST {get;set;}
}
public partial class Params_Get_Article_By_ARTICLE_ID_List_SP
{
public string ARTICLE_ID_LIST {get;set;}

}
public partial class Params_Get_Answer_By_ANSWER_ID_List
{
public List<Int32?> ANSWER_ID_LIST {get;set;}
}
public partial class Params_Get_Answer_By_ANSWER_ID_List_SP
{
public string ANSWER_ID_LIST {get;set;}

}
public partial class Params_Get_Student_By_STUDENT_ID_List
{
public List<Int32?> STUDENT_ID_LIST {get;set;}
}
public partial class Params_Get_Student_By_STUDENT_ID_List_SP
{
public string STUDENT_ID_LIST {get;set;}

}
public partial class Params_Get_Notification_By_NOTIFICATION_ID_List
{
public List<Int32?> NOTIFICATION_ID_LIST {get;set;}
}
public partial class Params_Get_Notification_By_NOTIFICATION_ID_List_SP
{
public string NOTIFICATION_ID_LIST {get;set;}

}
public partial class Params_Get_User_By_USER_ID_List
{
public List<long?> USER_ID_LIST {get;set;}
}
public partial class Params_Get_User_By_USER_ID_List_SP
{
public string USER_ID_LIST {get;set;}

}
public partial class Params_Get_Evaluation_By_EVALUATION_ID_List
{
public List<Int32?> EVALUATION_ID_LIST {get;set;}
}
public partial class Params_Get_Evaluation_By_EVALUATION_ID_List_SP
{
public string EVALUATION_ID_LIST {get;set;}

}
public partial class Params_Get_Student_report_By_STUDENT_REPORT_ID_List
{
public List<Int32?> STUDENT_REPORT_ID_LIST {get;set;}
}
public partial class Params_Get_Student_report_By_STUDENT_REPORT_ID_List_SP
{
public string STUDENT_REPORT_ID_LIST {get;set;}

}
public partial class Params_Get_Appreciate_By_APPRECIATE_ID_List
{
public List<Int32?> APPRECIATE_ID_LIST {get;set;}
}
public partial class Params_Get_Appreciate_By_APPRECIATE_ID_List_SP
{
public string APPRECIATE_ID_LIST {get;set;}

}
public partial class Params_Get_Teacher_report_By_TEACHER_REPORT_ID_List
{
public List<Int32?> TEACHER_REPORT_ID_LIST {get;set;}
}
public partial class Params_Get_Teacher_report_By_TEACHER_REPORT_ID_List_SP
{
public string TEACHER_REPORT_ID_LIST {get;set;}

}
public partial class Params_Get_Question_report_By_QUESTION_REPORT_ID_List
{
public List<Int32?> QUESTION_REPORT_ID_LIST {get;set;}
}
public partial class Params_Get_Question_report_By_QUESTION_REPORT_ID_List_SP
{
public string QUESTION_REPORT_ID_LIST {get;set;}

}
public partial class Params_Get_Answer_report_By_ANSWER_REPORT_ID_List
{
public List<Int32?> ANSWER_REPORT_ID_LIST {get;set;}
}
public partial class Params_Get_Answer_report_By_ANSWER_REPORT_ID_List_SP
{
public string ANSWER_REPORT_ID_LIST {get;set;}

}
public partial class Params_Get_Teacher_rank_By_TEACHER_RANK_ID_List
{
public List<Int32?> TEACHER_RANK_ID_LIST {get;set;}
}
public partial class Params_Get_Teacher_rank_By_TEACHER_RANK_ID_List_SP
{
public string TEACHER_RANK_ID_LIST {get;set;}

}
public partial class Params_Get_Teacher_By_TEACHER_ID_List
{
public List<Int32?> TEACHER_ID_LIST {get;set;}
}
public partial class Params_Get_Teacher_By_TEACHER_ID_List_SP
{
public string TEACHER_ID_LIST {get;set;}

}
public partial class Params_Get_Question_token_By_QUESTION_TOKEN_ID_List
{
public List<long?> QUESTION_TOKEN_ID_LIST {get;set;}
}
public partial class Params_Get_Question_token_By_QUESTION_TOKEN_ID_List_SP
{
public string QUESTION_TOKEN_ID_LIST {get;set;}

}
public partial class Params_Get_Teacher_category_By_TEACHER_CATEGORY_ID_List
{
public List<Int32?> TEACHER_CATEGORY_ID_LIST {get;set;}
}
public partial class Params_Get_Teacher_category_By_TEACHER_CATEGORY_ID_List_SP
{
public string TEACHER_CATEGORY_ID_LIST {get;set;}

}
public partial class Params_Get_Favorite_teacher_By_FAVORITE_TEACHER_ID_List
{
public List<Int32?> FAVORITE_TEACHER_ID_LIST {get;set;}
}
public partial class Params_Get_Favorite_teacher_By_FAVORITE_TEACHER_ID_List_SP
{
public string FAVORITE_TEACHER_ID_LIST {get;set;}

}
public partial class Params_Get_Teacher_favorite_By_TEACHER_FAVORITE_ID_List
{
public List<Int32?> TEACHER_FAVORITE_ID_LIST {get;set;}
}
public partial class Params_Get_Teacher_favorite_By_TEACHER_FAVORITE_ID_List_SP
{
public string TEACHER_FAVORITE_ID_LIST {get;set;}

}
public partial class Params_Get_Favorite_category_By_STUDENT_ID
{
public Int32? STUDENT_ID {get;set;}

}
public partial class Params_Get_Favorite_category_By_CATEGORY_ID
{
public Int32? CATEGORY_ID {get;set;}

}
public partial class Params_Get_Favorite_category_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}

}
public partial class Params_Get_Category_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}

}
public partial class Params_Get_Question_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}

}
public partial class Params_Get_Question_By_STUDENT_ID
{
public Int32? STUDENT_ID {get;set;}

}
public partial class Params_Get_Question_By_CATEGORY_ID
{
public Int32? CATEGORY_ID {get;set;}

}
public partial class Params_Get_Question_By_TEACHER_ID
{
public Int32? TEACHER_ID {get;set;}

}
public partial class Params_Get_Report_article_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}

}
public partial class Params_Get_Report_article_By_ARTICLE_ID
{
public Int32? ARTICLE_ID {get;set;}

}
public partial class Params_Get_Report_article_By_STUDENT_ID
{
public Int32? STUDENT_ID {get;set;}

}
public partial class Params_Get_Mark_question_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}

}
public partial class Params_Get_Mark_question_By_QUESTION_ID
{
public Int32? QUESTION_ID {get;set;}

}
public partial class Params_Get_Mark_question_By_STUDENT_ID
{
public Int32? STUDENT_ID {get;set;}

}
public partial class Params_Get_Article_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}

}
public partial class Params_Get_Article_By_TEACHER_ID
{
public Int32? TEACHER_ID {get;set;}

}
public partial class Params_Get_Article_By_CATEGORY_ID
{
public Int32? CATEGORY_ID {get;set;}

}
public partial class Params_Get_Answer_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}

}
public partial class Params_Get_Answer_By_QUESTION_ID
{
public Int32? QUESTION_ID {get;set;}

}
public partial class Params_Get_Answer_By_TEACHER_ID
{
public Int32? TEACHER_ID {get;set;}

}
public partial class Params_Get_Student_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}

}
public partial class Params_Get_Student_By_USER_ID
{
public Int32? USER_ID {get;set;}

}
public partial class Params_Get_Notification_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}

}
public partial class Params_Get_Notification_By_USER_ID
{
public Int32? USER_ID {get;set;}

}
public partial class Params_Get_Notification_By_QUESTION_ID
{
public Int32? QUESTION_ID {get;set;}

}
public partial class Params_Get_Notification_By_ANSWER_ID
{
public Int32? ANSWER_ID {get;set;}

}
public partial class Params_Get_Notification_By_ARTICLE_ID
{
public Int32? ARTICLE_ID {get;set;}

}
public partial class Params_Get_User_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}

}
public partial class Params_Get_User_By_USERNAME
{
public string USERNAME {get;set;}

}
public partial class Params_Get_Evaluation_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}

}
public partial class Params_Get_Evaluation_By_STUDENT_ID
{
public Int32? STUDENT_ID {get;set;}

}
public partial class Params_Get_Evaluation_By_ANSWER_ID
{
public Int32? ANSWER_ID {get;set;}

}
public partial class Params_Get_Student_report_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}

}
public partial class Params_Get_Student_report_By_REPORTED_BY_STUDENT_ID
{
public Int32? REPORTED_BY_STUDENT_ID {get;set;}

}
public partial class Params_Get_Student_report_By_REPORTED_STUDENT_ID
{
public Int32? REPORTED_STUDENT_ID {get;set;}

}
public partial class Params_Get_Appreciate_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}

}
public partial class Params_Get_Appreciate_By_ARTICLE_ID
{
public Int32? ARTICLE_ID {get;set;}

}
public partial class Params_Get_Appreciate_By_STUDENT_ID
{
public Int32? STUDENT_ID {get;set;}

}
public partial class Params_Get_Appreciate_By_ARTICLE_ID_STUDENT_ID
{
public Int32? ARTICLE_ID {get;set;}
public Int32? STUDENT_ID {get;set;}

}
public partial class Params_Get_Teacher_report_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}

}
public partial class Params_Get_Teacher_report_By_TEACHER_ID
{
public Int32? TEACHER_ID {get;set;}

}
public partial class Params_Get_Teacher_report_By_STUDENT_ID
{
public Int32? STUDENT_ID {get;set;}

}
public partial class Params_Get_Question_report_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}

}
public partial class Params_Get_Question_report_By_STUDENT_ID
{
public Int32? STUDENT_ID {get;set;}

}
public partial class Params_Get_Question_report_By_TEACHER_ID
{
public Int32? TEACHER_ID {get;set;}

}
public partial class Params_Get_Question_report_By_QUESTION_ID
{
public Int32? QUESTION_ID {get;set;}

}
public partial class Params_Get_Answer_report_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}

}
public partial class Params_Get_Answer_report_By_TEACHER_ID
{
public Int32? TEACHER_ID {get;set;}

}
public partial class Params_Get_Answer_report_By_STUDENT_ID
{
public Int32? STUDENT_ID {get;set;}

}
public partial class Params_Get_Answer_report_By_ANSWER_ID
{
public Int32? ANSWER_ID {get;set;}

}
public partial class Params_Get_Teacher_rank_By_TEACHER_ID
{
public Int32? TEACHER_ID {get;set;}

}
public partial class Params_Get_Teacher_rank_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}

}
public partial class Params_Get_Teacher_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}

}
public partial class Params_Get_Teacher_By_USER_ID
{
public Int32? USER_ID {get;set;}

}
public partial class Params_Get_Question_token_By_PART
{
public string PART {get;set;}

}
public partial class Params_Get_Question_token_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}

}
public partial class Params_Get_Question_token_By_QUESTION_ID
{
public long? QUESTION_ID {get;set;}

}
public partial class Params_Get_Teacher_category_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}

}
public partial class Params_Get_Teacher_category_By_TEACHER_ID
{
public Int32? TEACHER_ID {get;set;}

}
public partial class Params_Get_Teacher_category_By_CATEGORY_ID
{
public Int32? CATEGORY_ID {get;set;}

}
public partial class Params_Get_Favorite_teacher_By_TEACHER_ID
{
public Int32? TEACHER_ID {get;set;}

}
public partial class Params_Get_Favorite_teacher_By_STUDENT_ID
{
public Int32? STUDENT_ID {get;set;}

}
public partial class Params_Get_Favorite_teacher_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}

}
public partial class Params_Get_Teacher_favorite_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}

}
public partial class Params_Get_Teacher_favorite_By_TEACHER_ID
{
public Int32? TEACHER_ID {get;set;}

}
public partial class Params_Get_Teacher_favorite_By_STUDENT_ID
{
public Int32? STUDENT_ID {get;set;}

}
public partial class Params_Get_Favorite_category_By_STUDENT_ID_List
{
public List<Int32?> STUDENT_ID_LIST {get;set;}

}
public partial class Params_Get_Favorite_category_By_CATEGORY_ID_List
{
public List<Int32?> CATEGORY_ID_LIST {get;set;}

}
public partial class Params_Get_Question_By_STUDENT_ID_List
{
public List<Int32?> STUDENT_ID_LIST {get;set;}

}
public partial class Params_Get_Question_By_CATEGORY_ID_List
{
public List<Int32?> CATEGORY_ID_LIST {get;set;}

}
public partial class Params_Get_Question_By_TEACHER_ID_List
{
public List<Int32?> TEACHER_ID_LIST {get;set;}

}
public partial class Params_Get_Report_article_By_ARTICLE_ID_List
{
public List<Int32?> ARTICLE_ID_LIST {get;set;}

}
public partial class Params_Get_Report_article_By_STUDENT_ID_List
{
public List<Int32?> STUDENT_ID_LIST {get;set;}

}
public partial class Params_Get_Mark_question_By_QUESTION_ID_List
{
public List<Int32?> QUESTION_ID_LIST {get;set;}

}
public partial class Params_Get_Mark_question_By_STUDENT_ID_List
{
public List<Int32?> STUDENT_ID_LIST {get;set;}

}
public partial class Params_Get_Article_By_TEACHER_ID_List
{
public List<Int32?> TEACHER_ID_LIST {get;set;}

}
public partial class Params_Get_Article_By_CATEGORY_ID_List
{
public List<Int32?> CATEGORY_ID_LIST {get;set;}

}
public partial class Params_Get_Answer_By_QUESTION_ID_List
{
public List<Int32?> QUESTION_ID_LIST {get;set;}

}
public partial class Params_Get_Answer_By_TEACHER_ID_List
{
public List<Int32?> TEACHER_ID_LIST {get;set;}

}
public partial class Params_Get_Student_By_USER_ID_List
{
public List<Int32?> USER_ID_LIST {get;set;}

}
public partial class Params_Get_Notification_By_USER_ID_List
{
public List<Int32?> USER_ID_LIST {get;set;}

}
public partial class Params_Get_Notification_By_QUESTION_ID_List
{
public List<Int32?> QUESTION_ID_LIST {get;set;}

}
public partial class Params_Get_Notification_By_ANSWER_ID_List
{
public List<Int32?> ANSWER_ID_LIST {get;set;}

}
public partial class Params_Get_Notification_By_ARTICLE_ID_List
{
public List<Int32?> ARTICLE_ID_LIST {get;set;}

}
public partial class Params_Get_Evaluation_By_STUDENT_ID_List
{
public List<Int32?> STUDENT_ID_LIST {get;set;}

}
public partial class Params_Get_Evaluation_By_ANSWER_ID_List
{
public List<Int32?> ANSWER_ID_LIST {get;set;}

}
public partial class Params_Get_Student_report_By_REPORTED_BY_STUDENT_ID_List
{
public List<Int32?> REPORTED_BY_STUDENT_ID_LIST {get;set;}

}
public partial class Params_Get_Student_report_By_REPORTED_STUDENT_ID_List
{
public List<Int32?> REPORTED_STUDENT_ID_LIST {get;set;}

}
public partial class Params_Get_Appreciate_By_ARTICLE_ID_List
{
public List<Int32?> ARTICLE_ID_LIST {get;set;}

}
public partial class Params_Get_Appreciate_By_STUDENT_ID_List
{
public List<Int32?> STUDENT_ID_LIST {get;set;}

}
public partial class Params_Get_Teacher_report_By_TEACHER_ID_List
{
public List<Int32?> TEACHER_ID_LIST {get;set;}

}
public partial class Params_Get_Teacher_report_By_STUDENT_ID_List
{
public List<Int32?> STUDENT_ID_LIST {get;set;}

}
public partial class Params_Get_Question_report_By_STUDENT_ID_List
{
public List<Int32?> STUDENT_ID_LIST {get;set;}

}
public partial class Params_Get_Question_report_By_TEACHER_ID_List
{
public List<Int32?> TEACHER_ID_LIST {get;set;}

}
public partial class Params_Get_Question_report_By_QUESTION_ID_List
{
public List<Int32?> QUESTION_ID_LIST {get;set;}

}
public partial class Params_Get_Answer_report_By_TEACHER_ID_List
{
public List<Int32?> TEACHER_ID_LIST {get;set;}

}
public partial class Params_Get_Answer_report_By_STUDENT_ID_List
{
public List<Int32?> STUDENT_ID_LIST {get;set;}

}
public partial class Params_Get_Answer_report_By_ANSWER_ID_List
{
public List<Int32?> ANSWER_ID_LIST {get;set;}

}
public partial class Params_Get_Teacher_rank_By_TEACHER_ID_List
{
public List<Int32?> TEACHER_ID_LIST {get;set;}

}
public partial class Params_Get_Teacher_By_USER_ID_List
{
public List<Int32?> USER_ID_LIST {get;set;}

}
public partial class Params_Get_Question_token_By_QUESTION_ID_List
{
public List<long?> QUESTION_ID_LIST {get;set;}

}
public partial class Params_Get_Teacher_category_By_TEACHER_ID_List
{
public List<Int32?> TEACHER_ID_LIST {get;set;}

}
public partial class Params_Get_Teacher_category_By_CATEGORY_ID_List
{
public List<Int32?> CATEGORY_ID_LIST {get;set;}

}
public partial class Params_Get_Favorite_teacher_By_TEACHER_ID_List
{
public List<Int32?> TEACHER_ID_LIST {get;set;}

}
public partial class Params_Get_Favorite_teacher_By_STUDENT_ID_List
{
public List<Int32?> STUDENT_ID_LIST {get;set;}

}
public partial class Params_Get_Teacher_favorite_By_TEACHER_ID_List
{
public List<Int32?> TEACHER_ID_LIST {get;set;}

}
public partial class Params_Get_Teacher_favorite_By_STUDENT_ID_List
{
public List<Int32?> STUDENT_ID_LIST {get;set;}

}
public partial class Params_Get_Favorite_category_By_Criteria
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Favorite_category_By_Where
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Category_By_Criteria
{

public Int32? OWNER_ID {get;set;}
public string NAME {get;set;}
public string DECRIPTION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Category_By_Where
{

public Int32? OWNER_ID {get;set;}
public string NAME {get;set;}
public string DECRIPTION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Owner_By_Criteria
{

public Int32? OWNER_ID {get;set;}
public string CODE {get;set;}
public string DESCRIPTION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Owner_By_Where
{

public Int32? OWNER_ID {get;set;}
public string CODE {get;set;}
public string DESCRIPTION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Owner_By_Criteria_V2
{

public Int32? OWNER_ID {get;set;}
public string CODE {get;set;}
public string MAINTENANCE_DUE_DATE {get;set;}
public string DESCRIPTION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Owner_By_Where_V2
{

public Int32? OWNER_ID {get;set;}
public string CODE {get;set;}
public string MAINTENANCE_DUE_DATE {get;set;}
public string DESCRIPTION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Question_By_Criteria
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Question_By_Where
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Report_article_By_Criteria
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Report_article_By_Where
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Mark_question_By_Criteria
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Mark_question_By_Where
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Article_By_Criteria
{

public Int32? OWNER_ID {get;set;}
public string TITLE {get;set;}
public string DESCRIPTION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Article_By_Where
{

public Int32? OWNER_ID {get;set;}
public string TITLE {get;set;}
public string DESCRIPTION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Answer_By_Criteria
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Answer_By_Where
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Student_By_Criteria
{

public Int32? OWNER_ID {get;set;}
public string FIRST_NAME {get;set;}
public string LAST_NAME {get;set;}
public string EMAIL {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Student_By_Where
{

public Int32? OWNER_ID {get;set;}
public string FIRST_NAME {get;set;}
public string LAST_NAME {get;set;}
public string EMAIL {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Notification_By_Criteria
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Notification_By_Where
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_User_By_Criteria
{

public Int32? OWNER_ID {get;set;}
public string USERNAME {get;set;}
public string PASSWORD {get;set;}
public string USER_TYPE_CODE {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_User_By_Where
{

public Int32? OWNER_ID {get;set;}
public string USERNAME {get;set;}
public string PASSWORD {get;set;}
public string USER_TYPE_CODE {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Evaluation_By_Criteria
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Evaluation_By_Where
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Student_report_By_Criteria
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Student_report_By_Where
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Appreciate_By_Criteria
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Appreciate_By_Where
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Teacher_report_By_Criteria
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Teacher_report_By_Where
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Question_report_By_Criteria
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Question_report_By_Where
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Answer_report_By_Criteria
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Answer_report_By_Where
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Teacher_rank_By_Criteria
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Teacher_rank_By_Where
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Teacher_By_Criteria
{

public Int32? OWNER_ID {get;set;}
public string FIRST_NAME {get;set;}
public string LAST_NAME {get;set;}
public string DESCRIPTION {get;set;}
public string EMAIL {get;set;}
public string MOBILE {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Teacher_By_Where
{

public Int32? OWNER_ID {get;set;}
public string FIRST_NAME {get;set;}
public string LAST_NAME {get;set;}
public string DESCRIPTION {get;set;}
public string EMAIL {get;set;}
public string MOBILE {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Question_token_By_Criteria
{

public Int32? OWNER_ID {get;set;}
public string PART {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Question_token_By_Where
{

public Int32? OWNER_ID {get;set;}
public string PART {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Teacher_category_By_Criteria
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Teacher_category_By_Where
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Favorite_teacher_By_Criteria
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Favorite_teacher_By_Where
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Teacher_favorite_By_Criteria
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Teacher_favorite_By_Where
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Favorite_category_By_Criteria_InList
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public List<Int32?> STUDENT_ID_LIST {get;set;}
public List<Int32?> CATEGORY_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Favorite_category_By_Criteria_InList_SP
{
public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public string STUDENT_ID_LIST {get;set;}
public string CATEGORY_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Favorite_category_By_Where_InList
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public List<Int32?> STUDENT_ID_LIST {get;set;}
public List<Int32?> CATEGORY_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Favorite_category_By_Where_InList_SP
{
public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public string STUDENT_ID_LIST {get;set;}
public string CATEGORY_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Question_By_Criteria_InList
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public List<Int32?> STUDENT_ID_LIST {get;set;}
public List<Int32?> CATEGORY_ID_LIST {get;set;}
public List<Int32?> TEACHER_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Question_By_Criteria_InList_SP
{
public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public string STUDENT_ID_LIST {get;set;}
public string CATEGORY_ID_LIST {get;set;}
public string TEACHER_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Question_By_Where_InList
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public List<Int32?> STUDENT_ID_LIST {get;set;}
public List<Int32?> CATEGORY_ID_LIST {get;set;}
public List<Int32?> TEACHER_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Question_By_Where_InList_SP
{
public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public string STUDENT_ID_LIST {get;set;}
public string CATEGORY_ID_LIST {get;set;}
public string TEACHER_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Report_article_By_Criteria_InList
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public List<Int32?> ARTICLE_ID_LIST {get;set;}
public List<Int32?> STUDENT_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Report_article_By_Criteria_InList_SP
{
public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public string ARTICLE_ID_LIST {get;set;}
public string STUDENT_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Report_article_By_Where_InList
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public List<Int32?> ARTICLE_ID_LIST {get;set;}
public List<Int32?> STUDENT_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Report_article_By_Where_InList_SP
{
public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public string ARTICLE_ID_LIST {get;set;}
public string STUDENT_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Mark_question_By_Criteria_InList
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public List<Int32?> QUESTION_ID_LIST {get;set;}
public List<Int32?> STUDENT_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Mark_question_By_Criteria_InList_SP
{
public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public string QUESTION_ID_LIST {get;set;}
public string STUDENT_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Mark_question_By_Where_InList
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public List<Int32?> QUESTION_ID_LIST {get;set;}
public List<Int32?> STUDENT_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Mark_question_By_Where_InList_SP
{
public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public string QUESTION_ID_LIST {get;set;}
public string STUDENT_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Article_By_Criteria_InList
{

public Int32? OWNER_ID {get;set;}
public string TITLE {get;set;}
public string DESCRIPTION {get;set;}
public List<Int32?> TEACHER_ID_LIST {get;set;}
public List<Int32?> CATEGORY_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Article_By_Criteria_InList_SP
{
public Int32? OWNER_ID {get;set;}
public string TITLE {get;set;}
public string DESCRIPTION {get;set;}
public string TEACHER_ID_LIST {get;set;}
public string CATEGORY_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Article_By_Where_InList
{

public Int32? OWNER_ID {get;set;}
public string TITLE {get;set;}
public string DESCRIPTION {get;set;}
public List<Int32?> TEACHER_ID_LIST {get;set;}
public List<Int32?> CATEGORY_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Article_By_Where_InList_SP
{
public Int32? OWNER_ID {get;set;}
public string TITLE {get;set;}
public string DESCRIPTION {get;set;}
public string TEACHER_ID_LIST {get;set;}
public string CATEGORY_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Answer_By_Criteria_InList
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public List<Int32?> QUESTION_ID_LIST {get;set;}
public List<Int32?> TEACHER_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Answer_By_Criteria_InList_SP
{
public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public string QUESTION_ID_LIST {get;set;}
public string TEACHER_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Answer_By_Where_InList
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public List<Int32?> QUESTION_ID_LIST {get;set;}
public List<Int32?> TEACHER_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Answer_By_Where_InList_SP
{
public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public string QUESTION_ID_LIST {get;set;}
public string TEACHER_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Notification_By_Criteria_InList
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public List<Int32?> QUESTION_ID_LIST {get;set;}
public List<Int32?> ANSWER_ID_LIST {get;set;}
public List<Int32?> ARTICLE_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Notification_By_Criteria_InList_SP
{
public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public string QUESTION_ID_LIST {get;set;}
public string ANSWER_ID_LIST {get;set;}
public string ARTICLE_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Notification_By_Where_InList
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public List<Int32?> QUESTION_ID_LIST {get;set;}
public List<Int32?> ANSWER_ID_LIST {get;set;}
public List<Int32?> ARTICLE_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Notification_By_Where_InList_SP
{
public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public string QUESTION_ID_LIST {get;set;}
public string ANSWER_ID_LIST {get;set;}
public string ARTICLE_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Evaluation_By_Criteria_InList
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public List<Int32?> STUDENT_ID_LIST {get;set;}
public List<Int32?> ANSWER_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Evaluation_By_Criteria_InList_SP
{
public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public string STUDENT_ID_LIST {get;set;}
public string ANSWER_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Evaluation_By_Where_InList
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public List<Int32?> STUDENT_ID_LIST {get;set;}
public List<Int32?> ANSWER_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Evaluation_By_Where_InList_SP
{
public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public string STUDENT_ID_LIST {get;set;}
public string ANSWER_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Appreciate_By_Criteria_InList
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public List<Int32?> ARTICLE_ID_LIST {get;set;}
public List<Int32?> STUDENT_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Appreciate_By_Criteria_InList_SP
{
public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public string ARTICLE_ID_LIST {get;set;}
public string STUDENT_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Appreciate_By_Where_InList
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public List<Int32?> ARTICLE_ID_LIST {get;set;}
public List<Int32?> STUDENT_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Appreciate_By_Where_InList_SP
{
public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public string ARTICLE_ID_LIST {get;set;}
public string STUDENT_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Teacher_report_By_Criteria_InList
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public List<Int32?> TEACHER_ID_LIST {get;set;}
public List<Int32?> STUDENT_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Teacher_report_By_Criteria_InList_SP
{
public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public string TEACHER_ID_LIST {get;set;}
public string STUDENT_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Teacher_report_By_Where_InList
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public List<Int32?> TEACHER_ID_LIST {get;set;}
public List<Int32?> STUDENT_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Teacher_report_By_Where_InList_SP
{
public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public string TEACHER_ID_LIST {get;set;}
public string STUDENT_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Question_report_By_Criteria_InList
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public List<Int32?> STUDENT_ID_LIST {get;set;}
public List<Int32?> TEACHER_ID_LIST {get;set;}
public List<Int32?> QUESTION_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Question_report_By_Criteria_InList_SP
{
public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public string STUDENT_ID_LIST {get;set;}
public string TEACHER_ID_LIST {get;set;}
public string QUESTION_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Question_report_By_Where_InList
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public List<Int32?> STUDENT_ID_LIST {get;set;}
public List<Int32?> TEACHER_ID_LIST {get;set;}
public List<Int32?> QUESTION_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Question_report_By_Where_InList_SP
{
public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public string STUDENT_ID_LIST {get;set;}
public string TEACHER_ID_LIST {get;set;}
public string QUESTION_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Answer_report_By_Criteria_InList
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public List<Int32?> TEACHER_ID_LIST {get;set;}
public List<Int32?> STUDENT_ID_LIST {get;set;}
public List<Int32?> ANSWER_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Answer_report_By_Criteria_InList_SP
{
public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public string TEACHER_ID_LIST {get;set;}
public string STUDENT_ID_LIST {get;set;}
public string ANSWER_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Answer_report_By_Where_InList
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public List<Int32?> TEACHER_ID_LIST {get;set;}
public List<Int32?> STUDENT_ID_LIST {get;set;}
public List<Int32?> ANSWER_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Answer_report_By_Where_InList_SP
{
public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public string TEACHER_ID_LIST {get;set;}
public string STUDENT_ID_LIST {get;set;}
public string ANSWER_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Teacher_rank_By_Criteria_InList
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public List<Int32?> TEACHER_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Teacher_rank_By_Criteria_InList_SP
{
public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public string TEACHER_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Teacher_rank_By_Where_InList
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public List<Int32?> TEACHER_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Teacher_rank_By_Where_InList_SP
{
public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public string TEACHER_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Teacher_category_By_Criteria_InList
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public List<Int32?> TEACHER_ID_LIST {get;set;}
public List<Int32?> CATEGORY_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Teacher_category_By_Criteria_InList_SP
{
public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public string TEACHER_ID_LIST {get;set;}
public string CATEGORY_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Teacher_category_By_Where_InList
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public List<Int32?> TEACHER_ID_LIST {get;set;}
public List<Int32?> CATEGORY_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Teacher_category_By_Where_InList_SP
{
public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public string TEACHER_ID_LIST {get;set;}
public string CATEGORY_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Favorite_teacher_By_Criteria_InList
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public List<Int32?> TEACHER_ID_LIST {get;set;}
public List<Int32?> STUDENT_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Favorite_teacher_By_Criteria_InList_SP
{
public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public string TEACHER_ID_LIST {get;set;}
public string STUDENT_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Favorite_teacher_By_Where_InList
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public List<Int32?> TEACHER_ID_LIST {get;set;}
public List<Int32?> STUDENT_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Favorite_teacher_By_Where_InList_SP
{
public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public string TEACHER_ID_LIST {get;set;}
public string STUDENT_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Teacher_favorite_By_Criteria_InList
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public List<Int32?> TEACHER_ID_LIST {get;set;}
public List<Int32?> STUDENT_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Teacher_favorite_By_Criteria_InList_SP
{
public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public string TEACHER_ID_LIST {get;set;}
public string STUDENT_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Teacher_favorite_By_Where_InList
{

public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public List<Int32?> TEACHER_ID_LIST {get;set;}
public List<Int32?> STUDENT_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
public partial class Params_Get_Teacher_favorite_By_Where_InList_SP
{
public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public string TEACHER_ID_LIST {get;set;}
public string STUDENT_ID_LIST {get;set;}
public long? START_ROW {get;set;}
public long? END_ROW {get;set;}
public long? TOTAL_COUNT {get;set;}
}
#region Params_Delete_Favorite_category
public partial class Params_Delete_Favorite_category
{
#region Properties
public Int32? FAVORITE_CATEGORY_ID {get;set;}
#endregion
}
#endregion
#region Params_Delete_Category
public partial class Params_Delete_Category
{
#region Properties
public Int32? CATEGORY_ID {get;set;}
#endregion
}
#endregion
#region Params_Delete_Owner
public partial class Params_Delete_Owner
{
#region Properties
public Int32? OWNER_ID {get;set;}
#endregion
}
#endregion
#region Params_Delete_Question
public partial class Params_Delete_Question
{
#region Properties
public Int32? QUESTION_ID {get;set;}
#endregion
}
#endregion
#region Params_Delete_Report_article
public partial class Params_Delete_Report_article
{
#region Properties
public Int32? REPORT_ARTICLE_ID {get;set;}
#endregion
}
#endregion
#region Params_Delete_Mark_question
public partial class Params_Delete_Mark_question
{
#region Properties
public Int32? MARK_QUESTION_ID {get;set;}
#endregion
}
#endregion
#region Params_Delete_Article
public partial class Params_Delete_Article
{
#region Properties
public Int32? ARTICLE_ID {get;set;}
#endregion
}
#endregion
#region Params_Delete_Answer
public partial class Params_Delete_Answer
{
#region Properties
public Int32? ANSWER_ID {get;set;}
#endregion
}
#endregion
#region Params_Delete_Student
public partial class Params_Delete_Student
{
#region Properties
public Int32? STUDENT_ID {get;set;}
#endregion
}
#endregion
#region Params_Delete_Notification
public partial class Params_Delete_Notification
{
#region Properties
public Int32? NOTIFICATION_ID {get;set;}
#endregion
}
#endregion
#region Params_Delete_User
public partial class Params_Delete_User
{
#region Properties
public long? USER_ID {get;set;}
#endregion
}
#endregion
#region Params_Delete_Evaluation
public partial class Params_Delete_Evaluation
{
#region Properties
public Int32? EVALUATION_ID {get;set;}
#endregion
}
#endregion
#region Params_Delete_Student_report
public partial class Params_Delete_Student_report
{
#region Properties
public Int32? STUDENT_REPORT_ID {get;set;}
#endregion
}
#endregion
#region Params_Delete_Appreciate
public partial class Params_Delete_Appreciate
{
#region Properties
public Int32? APPRECIATE_ID {get;set;}
#endregion
}
#endregion
#region Params_Delete_Teacher_report
public partial class Params_Delete_Teacher_report
{
#region Properties
public Int32? TEACHER_REPORT_ID {get;set;}
#endregion
}
#endregion
#region Params_Delete_Question_report
public partial class Params_Delete_Question_report
{
#region Properties
public Int32? QUESTION_REPORT_ID {get;set;}
#endregion
}
#endregion
#region Params_Delete_Answer_report
public partial class Params_Delete_Answer_report
{
#region Properties
public Int32? ANSWER_REPORT_ID {get;set;}
#endregion
}
#endregion
#region Params_Delete_Teacher_rank
public partial class Params_Delete_Teacher_rank
{
#region Properties
public Int32? TEACHER_RANK_ID {get;set;}
#endregion
}
#endregion
#region Params_Delete_Teacher
public partial class Params_Delete_Teacher
{
#region Properties
public Int32? TEACHER_ID {get;set;}
#endregion
}
#endregion
#region Params_Delete_Question_token
public partial class Params_Delete_Question_token
{
#region Properties
public long? QUESTION_TOKEN_ID {get;set;}
#endregion
}
#endregion
#region Params_Delete_Teacher_category
public partial class Params_Delete_Teacher_category
{
#region Properties
public Int32? TEACHER_CATEGORY_ID {get;set;}
#endregion
}
#endregion
#region Params_Delete_Favorite_teacher
public partial class Params_Delete_Favorite_teacher
{
#region Properties
public Int32? FAVORITE_TEACHER_ID {get;set;}
#endregion
}
#endregion
#region Params_Delete_Teacher_favorite
public partial class Params_Delete_Teacher_favorite
{
#region Properties
public Int32? TEACHER_FAVORITE_ID {get;set;}
#endregion
}
#endregion
public partial class Params_Delete_Favorite_category_By_STUDENT_ID
{
public Int32? STUDENT_ID {get;set;}
}
public partial class Params_Delete_Favorite_category_By_CATEGORY_ID
{
public Int32? CATEGORY_ID {get;set;}
}
public partial class Params_Delete_Favorite_category_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}
}
public partial class Params_Delete_Category_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}
}
public partial class Params_Delete_Question_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}
}
public partial class Params_Delete_Question_By_STUDENT_ID
{
public Int32? STUDENT_ID {get;set;}
}
public partial class Params_Delete_Question_By_CATEGORY_ID
{
public Int32? CATEGORY_ID {get;set;}
}
public partial class Params_Delete_Question_By_TEACHER_ID
{
public Int32? TEACHER_ID {get;set;}
}
public partial class Params_Delete_Report_article_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}
}
public partial class Params_Delete_Report_article_By_ARTICLE_ID
{
public Int32? ARTICLE_ID {get;set;}
}
public partial class Params_Delete_Report_article_By_STUDENT_ID
{
public Int32? STUDENT_ID {get;set;}
}
public partial class Params_Delete_Mark_question_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}
}
public partial class Params_Delete_Mark_question_By_QUESTION_ID
{
public Int32? QUESTION_ID {get;set;}
}
public partial class Params_Delete_Mark_question_By_STUDENT_ID
{
public Int32? STUDENT_ID {get;set;}
}
public partial class Params_Delete_Article_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}
}
public partial class Params_Delete_Article_By_TEACHER_ID
{
public Int32? TEACHER_ID {get;set;}
}
public partial class Params_Delete_Article_By_CATEGORY_ID
{
public Int32? CATEGORY_ID {get;set;}
}
public partial class Params_Delete_Answer_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}
}
public partial class Params_Delete_Answer_By_QUESTION_ID
{
public Int32? QUESTION_ID {get;set;}
}
public partial class Params_Delete_Answer_By_TEACHER_ID
{
public Int32? TEACHER_ID {get;set;}
}
public partial class Params_Delete_Student_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}
}
public partial class Params_Delete_Student_By_USER_ID
{
public Int32? USER_ID {get;set;}
}
public partial class Params_Delete_Notification_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}
}
public partial class Params_Delete_Notification_By_USER_ID
{
public Int32? USER_ID {get;set;}
}
public partial class Params_Delete_Notification_By_QUESTION_ID
{
public Int32? QUESTION_ID {get;set;}
}
public partial class Params_Delete_Notification_By_ANSWER_ID
{
public Int32? ANSWER_ID {get;set;}
}
public partial class Params_Delete_Notification_By_ARTICLE_ID
{
public Int32? ARTICLE_ID {get;set;}
}
public partial class Params_Delete_User_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}
}
public partial class Params_Delete_User_By_USERNAME
{
public string USERNAME {get;set;}
}
public partial class Params_Delete_Evaluation_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}
}
public partial class Params_Delete_Evaluation_By_STUDENT_ID
{
public Int32? STUDENT_ID {get;set;}
}
public partial class Params_Delete_Evaluation_By_ANSWER_ID
{
public Int32? ANSWER_ID {get;set;}
}
public partial class Params_Delete_Student_report_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}
}
public partial class Params_Delete_Student_report_By_REPORTED_BY_STUDENT_ID
{
public Int32? REPORTED_BY_STUDENT_ID {get;set;}
}
public partial class Params_Delete_Student_report_By_REPORTED_STUDENT_ID
{
public Int32? REPORTED_STUDENT_ID {get;set;}
}
public partial class Params_Delete_Appreciate_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}
}
public partial class Params_Delete_Appreciate_By_ARTICLE_ID
{
public Int32? ARTICLE_ID {get;set;}
}
public partial class Params_Delete_Appreciate_By_STUDENT_ID
{
public Int32? STUDENT_ID {get;set;}
}
public partial class Params_Delete_Appreciate_By_ARTICLE_ID_STUDENT_ID
{
public Int32? ARTICLE_ID {get;set;}
public Int32? STUDENT_ID {get;set;}
}
public partial class Params_Delete_Teacher_report_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}
}
public partial class Params_Delete_Teacher_report_By_TEACHER_ID
{
public Int32? TEACHER_ID {get;set;}
}
public partial class Params_Delete_Teacher_report_By_STUDENT_ID
{
public Int32? STUDENT_ID {get;set;}
}
public partial class Params_Delete_Question_report_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}
}
public partial class Params_Delete_Question_report_By_STUDENT_ID
{
public Int32? STUDENT_ID {get;set;}
}
public partial class Params_Delete_Question_report_By_TEACHER_ID
{
public Int32? TEACHER_ID {get;set;}
}
public partial class Params_Delete_Question_report_By_QUESTION_ID
{
public Int32? QUESTION_ID {get;set;}
}
public partial class Params_Delete_Answer_report_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}
}
public partial class Params_Delete_Answer_report_By_TEACHER_ID
{
public Int32? TEACHER_ID {get;set;}
}
public partial class Params_Delete_Answer_report_By_STUDENT_ID
{
public Int32? STUDENT_ID {get;set;}
}
public partial class Params_Delete_Answer_report_By_ANSWER_ID
{
public Int32? ANSWER_ID {get;set;}
}
public partial class Params_Delete_Teacher_rank_By_TEACHER_ID
{
public Int32? TEACHER_ID {get;set;}
}
public partial class Params_Delete_Teacher_rank_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}
}
public partial class Params_Delete_Teacher_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}
}
public partial class Params_Delete_Teacher_By_USER_ID
{
public Int32? USER_ID {get;set;}
}
public partial class Params_Delete_Question_token_By_PART
{
public string PART {get;set;}
}
public partial class Params_Delete_Question_token_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}
}
public partial class Params_Delete_Question_token_By_QUESTION_ID
{
public long? QUESTION_ID {get;set;}
}
public partial class Params_Delete_Teacher_category_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}
}
public partial class Params_Delete_Teacher_category_By_TEACHER_ID
{
public Int32? TEACHER_ID {get;set;}
}
public partial class Params_Delete_Teacher_category_By_CATEGORY_ID
{
public Int32? CATEGORY_ID {get;set;}
}
public partial class Params_Delete_Favorite_teacher_By_TEACHER_ID
{
public Int32? TEACHER_ID {get;set;}
}
public partial class Params_Delete_Favorite_teacher_By_STUDENT_ID
{
public Int32? STUDENT_ID {get;set;}
}
public partial class Params_Delete_Favorite_teacher_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}
}
public partial class Params_Delete_Teacher_favorite_By_OWNER_ID
{
public Int32? OWNER_ID {get;set;}
}
public partial class Params_Delete_Teacher_favorite_By_TEACHER_ID
{
public Int32? TEACHER_ID {get;set;}
}
public partial class Params_Delete_Teacher_favorite_By_STUDENT_ID
{
public Int32? STUDENT_ID {get;set;}
}
public partial class Favorite_category
{
public Int32? FAVORITE_CATEGORY_ID {get;set;}
public Int32? STUDENT_ID {get;set;}
public Int32? CATEGORY_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? ENTRY_USER_ID {get;set;}
public Int32? OWNER_ID {get;set;}
public string ENTRY_DATE {get;set;}
}
public partial class Category
{
public Int32? CATEGORY_ID {get;set;}
public string NAME {get;set;}
public string DECRIPTION {get;set;}
public long? ENTRY_USER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Int32? OWNER_ID {get;set;}
}
public partial class Owner
{
public Int32? OWNER_ID {get;set;}
public string CODE {get;set;}
public string MAINTENANCE_DUE_DATE {get;set;}
public string DESCRIPTION {get;set;}
public string ENTRY_DATE {get;set;}
}
public partial class Question
{
public Int32? QUESTION_ID {get;set;}
public Int32? STUDENT_ID {get;set;}
public Int32? CATEGORY_ID {get;set;}
public Int32? TEACHER_ID {get;set;}
public string DESCRIPTION {get;set;}
public bool? IS_ANSWERED {get;set;}
public bool? IS_ACTIVE {get;set;}
public Int32? REPORTS {get;set;}
public long? ENTRY_USER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Int32? OWNER_ID {get;set;}
}
public partial class Report_article
{
public Int32? REPORT_ARTICLE_ID {get;set;}
public Int32? ARTICLE_ID {get;set;}
public Int32? STUDENT_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? ENTRY_USER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Int32? OWNER_ID {get;set;}
}
public partial class Mark_question
{
public Int32? MARK_QUESTION_ID {get;set;}
public Int32? QUESTION_ID {get;set;}
public Int32? STUDENT_ID {get;set;}
public long? ENTRY_USER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
}
public partial class Article
{
public Int32? ARTICLE_ID {get;set;}
public Int32? TEACHER_ID {get;set;}
public Int32? CATEGORY_ID {get;set;}
public string TITLE {get;set;}
public string DESCRIPTION {get;set;}
public Int32? APPLAUDS {get;set;}
public Int32? REPORTS {get;set;}
public bool? IS_BLOCKED {get;set;}
public long? ENTRY_USER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Int32? OWNER_ID {get;set;}
}
public partial class Answer
{
public Int32? ANSWER_ID {get;set;}
public Int32? QUESTION_ID {get;set;}
public Int32? TEACHER_ID {get;set;}
public string DESCRIPTION {get;set;}
public decimal? SCORE {get;set;}
public Int32? REVIEWS {get;set;}
public Int32? REPORTS {get;set;}
public bool? IS_ACTIVE {get;set;}
public long? ENTRY_USER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Int32? OWNER_ID {get;set;}
}
public partial class Student
{
public Int32? STUDENT_ID {get;set;}
public Int32? USER_ID {get;set;}
public string FIRST_NAME {get;set;}
public string LAST_NAME {get;set;}
public string EMAIL {get;set;}
public bool? IS_BLOCKED {get;set;}
public Int32? PENDING_QUESTIONS {get;set;}
public long? ENTRY_USER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Int32? OWNER_ID {get;set;}
}
public partial class Notification
{
public Int32? NOTIFICATION_ID {get;set;}
public Int32? USER_ID {get;set;}
public string DESCRIPTION {get;set;}
public Int32? QUESTION_ID {get;set;}
public Int32? ANSWER_ID {get;set;}
public Int32? ARTICLE_ID {get;set;}
public long? ENTRY_USER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Int32? OWNER_ID {get;set;}
}
public partial class User
{
public long? USER_ID {get;set;}
public Int32? OWNER_ID {get;set;}
public string USERNAME {get;set;}
public string PASSWORD {get;set;}
public string USER_TYPE_CODE {get;set;}
public bool? IS_LOGGED_IN {get;set;}
public bool? IS_ACTIVE {get;set;}
public string ENTRY_DATE {get;set;}
}
public partial class Evaluation
{
public Int32? EVALUATION_ID {get;set;}
public Int32? STUDENT_ID {get;set;}
public Int32? ANSWER_ID {get;set;}
public decimal SCORE {get;set;}
public long? ENTRY_USER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
}
public partial class Student_report
{
public Int32? STUDENT_REPORT_ID {get;set;}
public Int32? REPORTED_BY_STUDENT_ID {get;set;}
public Int32? REPORTED_STUDENT_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? ENTRY_USER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Int32? OWNER_ID {get;set;}
}
public partial class Appreciate
{
public Int32? APPRECIATE_ID {get;set;}
public Int32? ARTICLE_ID {get;set;}
public Int32? STUDENT_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? ENTRY_USER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Int32? OWNER_ID {get;set;}
}
public partial class Teacher_report
{
public Int32? TEACHER_REPORT_ID {get;set;}
public Int32? TEACHER_ID {get;set;}
public Int32? STUDENT_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? ENTRY_USER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Int32? OWNER_ID {get;set;}
}
public partial class Question_report
{
public Int32? QUESTION_REPORT_ID {get;set;}
public Int32? STUDENT_ID {get;set;}
public Int32? TEACHER_ID {get;set;}
public Int32? QUESTION_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? ENTRY_USER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Int32? OWNER_ID {get;set;}
}
public partial class Answer_report
{
public Int32? ANSWER_REPORT_ID {get;set;}
public Int32? TEACHER_ID {get;set;}
public Int32? STUDENT_ID {get;set;}
public Int32? ANSWER_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? ENTRY_USER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Int32? OWNER_ID {get;set;}
}
public partial class Teacher_rank
{
public Int32? TEACHER_RANK_ID {get;set;}
public Int32? TEACHER_ID {get;set;}
public Int32? SCORE {get;set;}
public Int32? OVERALL_RANKING {get;set;}
public long? ENTRY_USER_ID {get;set;}
public Int32? OWNER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public string DESCRIPTION {get;set;}
}
public partial class Teacher
{
public Int32? TEACHER_ID {get;set;}
public Int32? USER_ID {get;set;}
public string FIRST_NAME {get;set;}
public string LAST_NAME {get;set;}
public decimal SCORE {get;set;}
public string DESCRIPTION {get;set;}
public bool? IS_BLOCKED {get;set;}
public string EMAIL {get;set;}
public string MOBILE {get;set;}
public long? ENTRY_USER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Int32? OWNER_ID {get;set;}
}
public partial class Question_token
{
public long? QUESTION_TOKEN_ID {get;set;}
public long? QUESTION_ID {get;set;}
public string PART {get;set;}
public long? ENTRY_USER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Int32? OWNER_ID {get;set;}
}
public partial class Teacher_category
{
public Int32? TEACHER_CATEGORY_ID {get;set;}
public Int32? TEACHER_ID {get;set;}
public Int32? CATEGORY_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? ENTRY_USER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Int32? OWNER_ID {get;set;}
}
public partial class Favorite_teacher
{
public Int32? FAVORITE_TEACHER_ID {get;set;}
public Int32? TEACHER_ID {get;set;}
public Int32? STUDENT_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? ENTRY_USER_ID {get;set;}
public Int32? OWNER_ID {get;set;}
public string ENTRY_DATE {get;set;}
}
public partial class Teacher_favorite
{
public Int32? TEACHER_FAVORITE_ID {get;set;}
public Int32? TEACHER_ID {get;set;}
public Int32? STUDENT_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? ENTRY_USER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Int32? OWNER_ID {get;set;}
}
#region Params_Edit_Favorite_category_List
public partial class Params_Edit_Favorite_category_List
{
#region Properties
public List<Favorite_category> My_List_To_Edit { get; set; }
public List<Favorite_category> My_List_To_Delete { get; set; }
#endregion
}
#endregion
#region Params_Edit_Category_List
public partial class Params_Edit_Category_List
{
#region Properties
public List<Category> My_List_To_Edit { get; set; }
public List<Category> My_List_To_Delete { get; set; }
#endregion
}
#endregion
#region Params_Edit_Owner_List
public partial class Params_Edit_Owner_List
{
#region Properties
public List<Owner> My_List_To_Edit { get; set; }
public List<Owner> My_List_To_Delete { get; set; }
#endregion
}
#endregion
#region Params_Edit_Question_List
public partial class Params_Edit_Question_List
{
#region Properties
public List<Question> My_List_To_Edit { get; set; }
public List<Question> My_List_To_Delete { get; set; }
#endregion
}
#endregion
#region Params_Edit_Report_article_List
public partial class Params_Edit_Report_article_List
{
#region Properties
public List<Report_article> My_List_To_Edit { get; set; }
public List<Report_article> My_List_To_Delete { get; set; }
#endregion
}
#endregion
#region Params_Edit_Mark_question_List
public partial class Params_Edit_Mark_question_List
{
#region Properties
public List<Mark_question> My_List_To_Edit { get; set; }
public List<Mark_question> My_List_To_Delete { get; set; }
#endregion
}
#endregion
#region Params_Edit_Article_List
public partial class Params_Edit_Article_List
{
#region Properties
public List<Article> My_List_To_Edit { get; set; }
public List<Article> My_List_To_Delete { get; set; }
#endregion
}
#endregion
#region Params_Edit_Answer_List
public partial class Params_Edit_Answer_List
{
#region Properties
public List<Answer> My_List_To_Edit { get; set; }
public List<Answer> My_List_To_Delete { get; set; }
#endregion
}
#endregion
#region Params_Edit_Student_List
public partial class Params_Edit_Student_List
{
#region Properties
public List<Student> My_List_To_Edit { get; set; }
public List<Student> My_List_To_Delete { get; set; }
#endregion
}
#endregion
#region Params_Edit_Notification_List
public partial class Params_Edit_Notification_List
{
#region Properties
public List<Notification> My_List_To_Edit { get; set; }
public List<Notification> My_List_To_Delete { get; set; }
#endregion
}
#endregion
#region Params_Edit_User_List
public partial class Params_Edit_User_List
{
#region Properties
public List<User> My_List_To_Edit { get; set; }
public List<User> My_List_To_Delete { get; set; }
#endregion
}
#endregion
#region Params_Edit_Evaluation_List
public partial class Params_Edit_Evaluation_List
{
#region Properties
public List<Evaluation> My_List_To_Edit { get; set; }
public List<Evaluation> My_List_To_Delete { get; set; }
#endregion
}
#endregion
#region Params_Edit_Student_report_List
public partial class Params_Edit_Student_report_List
{
#region Properties
public List<Student_report> My_List_To_Edit { get; set; }
public List<Student_report> My_List_To_Delete { get; set; }
#endregion
}
#endregion
#region Params_Edit_Appreciate_List
public partial class Params_Edit_Appreciate_List
{
#region Properties
public List<Appreciate> My_List_To_Edit { get; set; }
public List<Appreciate> My_List_To_Delete { get; set; }
#endregion
}
#endregion
#region Params_Edit_Teacher_report_List
public partial class Params_Edit_Teacher_report_List
{
#region Properties
public List<Teacher_report> My_List_To_Edit { get; set; }
public List<Teacher_report> My_List_To_Delete { get; set; }
#endregion
}
#endregion
#region Params_Edit_Question_report_List
public partial class Params_Edit_Question_report_List
{
#region Properties
public List<Question_report> My_List_To_Edit { get; set; }
public List<Question_report> My_List_To_Delete { get; set; }
#endregion
}
#endregion
#region Params_Edit_Answer_report_List
public partial class Params_Edit_Answer_report_List
{
#region Properties
public List<Answer_report> My_List_To_Edit { get; set; }
public List<Answer_report> My_List_To_Delete { get; set; }
#endregion
}
#endregion
#region Params_Edit_Teacher_rank_List
public partial class Params_Edit_Teacher_rank_List
{
#region Properties
public List<Teacher_rank> My_List_To_Edit { get; set; }
public List<Teacher_rank> My_List_To_Delete { get; set; }
#endregion
}
#endregion
#region Params_Edit_Teacher_List
public partial class Params_Edit_Teacher_List
{
#region Properties
public List<Teacher> My_List_To_Edit { get; set; }
public List<Teacher> My_List_To_Delete { get; set; }
#endregion
}
#endregion
#region Params_Edit_Question_token_List
public partial class Params_Edit_Question_token_List
{
#region Properties
public List<Question_token> My_List_To_Edit { get; set; }
public List<Question_token> My_List_To_Delete { get; set; }
#endregion
}
#endregion
#region Params_Edit_Teacher_category_List
public partial class Params_Edit_Teacher_category_List
{
#region Properties
public List<Teacher_category> My_List_To_Edit { get; set; }
public List<Teacher_category> My_List_To_Delete { get; set; }
#endregion
}
#endregion
#region Params_Edit_Favorite_teacher_List
public partial class Params_Edit_Favorite_teacher_List
{
#region Properties
public List<Favorite_teacher> My_List_To_Edit { get; set; }
public List<Favorite_teacher> My_List_To_Delete { get; set; }
#endregion
}
#endregion
#region Params_Edit_Teacher_favorite_List
public partial class Params_Edit_Teacher_favorite_List
{
#region Properties
public List<Teacher_favorite> My_List_To_Edit { get; set; }
public List<Teacher_favorite> My_List_To_Delete { get; set; }
#endregion
}
#endregion
}
