using System;
using System.Linq;
using System.Runtime.Serialization;
using System.Collections.Generic;
using System.Text;
using System.Configuration;
using System.IO;
using BLC;
namespace BLC
{
public partial class BLC
{

#region Enum_API_Method
public enum Enum_API_Method
{

}
#endregion

#region Prepare_BLCInitializer
public BLCInitializer Prepare_BLCInitializer(string i_Ticket, Enum_API_Method i_Enum_API_Method)
{
#region Declaration And Initialization Section.
BLCInitializer oBLCInitializer = new BLCInitializer();
BLC oBLC_Default = new BLC();
string str_CUSTOM_BLC_INIT = string.Empty;
#endregion
#region Body Section.
if (this.OnPreEvent_BLC_Init != null)
{
oBLCInitializer = this.OnPreEvent_BLC_Init(i_Ticket, i_Enum_API_Method);
return oBLCInitializer;
}
else
{
oBLCInitializer.UserID = Convert.ToInt64(oBLC_Default.ResolveTicket(i_Ticket)["USER_ID"]);
oBLCInitializer.OwnerID = Convert.ToInt32(oBLC_Default.ResolveTicket(i_Ticket)["OWNER_ID"]);
oBLCInitializer.ConnectionString = ConfigurationManager.AppSettings["CONN_STR"];
oBLCInitializer.Messages_FilePath = ConfigurationManager.AppSettings["BLC_MESSAGES"];
}
#endregion
#region Return Section.
return oBLCInitializer;
#endregion
}
#endregion

#region General Pre/Post events
public delegate void PreEvent_Handler_General(string i_MethodName);
public delegate void PostEvent_Handler_General(string i_MethodName);
public event PreEvent_Handler_General OnPreEvent_General;
public event PostEvent_Handler_General OnPostEvent_General;
#endregion
#region General Pre/Post BLC_Init
public delegate BLCInitializer PreEvent_Handler_BLC_Init(string i_Ticket, Enum_API_Method i_Enum_API_Method);
public delegate BLCInitializer PostEvent_Handler_BLC_Init(string i_Ticket, Enum_API_Method i_Enum_API_Method);
public event PreEvent_Handler_BLC_Init OnPreEvent_BLC_Init;
public event PostEvent_Handler_BLC_Init OnPostEvent_BLC_Init;
#endregion
public  delegate void PreEvent_Handler_Edit_Answer(Answer i_Answer,Enum_EditMode i_Enum_EditMode);
public  delegate void  PostEvent_Handler_Edit_Answer(Answer i_Answer,Enum_EditMode i_Enum_EditMode);
public event PreEvent_Handler_Edit_Answer OnPreEvent_Edit_Answer;
public event PostEvent_Handler_Edit_Answer OnPostEvent_Edit_Answer;
public  delegate void PreEvent_Handler_Edit_Answer_report(Answer_report i_Answer_report,Enum_EditMode i_Enum_EditMode);
public  delegate void  PostEvent_Handler_Edit_Answer_report(Answer_report i_Answer_report,Enum_EditMode i_Enum_EditMode);
public event PreEvent_Handler_Edit_Answer_report OnPreEvent_Edit_Answer_report;
public event PostEvent_Handler_Edit_Answer_report OnPostEvent_Edit_Answer_report;
public  delegate void PreEvent_Handler_Edit_Appreciate(Appreciate i_Appreciate,Enum_EditMode i_Enum_EditMode);
public  delegate void  PostEvent_Handler_Edit_Appreciate(Appreciate i_Appreciate,Enum_EditMode i_Enum_EditMode);
public event PreEvent_Handler_Edit_Appreciate OnPreEvent_Edit_Appreciate;
public event PostEvent_Handler_Edit_Appreciate OnPostEvent_Edit_Appreciate;
public  delegate void PreEvent_Handler_Edit_Article(Article i_Article,Enum_EditMode i_Enum_EditMode);
public  delegate void  PostEvent_Handler_Edit_Article(Article i_Article,Enum_EditMode i_Enum_EditMode);
public event PreEvent_Handler_Edit_Article OnPreEvent_Edit_Article;
public event PostEvent_Handler_Edit_Article OnPostEvent_Edit_Article;
public  delegate void PreEvent_Handler_Edit_Evaluation(Evaluation i_Evaluation,Enum_EditMode i_Enum_EditMode);
public  delegate void  PostEvent_Handler_Edit_Evaluation(Evaluation i_Evaluation,Enum_EditMode i_Enum_EditMode);
public event PreEvent_Handler_Edit_Evaluation OnPreEvent_Edit_Evaluation;
public event PostEvent_Handler_Edit_Evaluation OnPostEvent_Edit_Evaluation;
public  delegate void PreEvent_Handler_Edit_Question(Question i_Question,Enum_EditMode i_Enum_EditMode);
public  delegate void  PostEvent_Handler_Edit_Question(Question i_Question,Enum_EditMode i_Enum_EditMode);
public event PreEvent_Handler_Edit_Question OnPreEvent_Edit_Question;
public event PostEvent_Handler_Edit_Question OnPostEvent_Edit_Question;
public  delegate void PreEvent_Handler_Edit_Question_report(Question_report i_Question_report,Enum_EditMode i_Enum_EditMode);
public  delegate void  PostEvent_Handler_Edit_Question_report(Question_report i_Question_report,Enum_EditMode i_Enum_EditMode);
public event PreEvent_Handler_Edit_Question_report OnPreEvent_Edit_Question_report;
public event PostEvent_Handler_Edit_Question_report OnPostEvent_Edit_Question_report;
public  delegate void PreEvent_Handler_Edit_Report_article(Report_article i_Report_article,Enum_EditMode i_Enum_EditMode);
public  delegate void  PostEvent_Handler_Edit_Report_article(Report_article i_Report_article,Enum_EditMode i_Enum_EditMode);
public event PreEvent_Handler_Edit_Report_article OnPreEvent_Edit_Report_article;
public event PostEvent_Handler_Edit_Report_article OnPostEvent_Edit_Report_article;
public  delegate void PreEvent_Handler_Edit_Student(Student i_Student,Enum_EditMode i_Enum_EditMode);
public  delegate void  PostEvent_Handler_Edit_Student(Student i_Student,Enum_EditMode i_Enum_EditMode);
public event PreEvent_Handler_Edit_Student OnPreEvent_Edit_Student;
public event PostEvent_Handler_Edit_Student OnPostEvent_Edit_Student;
public  delegate void PreEvent_Handler_Edit_Student_report(Student_report i_Student_report,Enum_EditMode i_Enum_EditMode);
public  delegate void  PostEvent_Handler_Edit_Student_report(Student_report i_Student_report,Enum_EditMode i_Enum_EditMode);
public event PreEvent_Handler_Edit_Student_report OnPreEvent_Edit_Student_report;
public event PostEvent_Handler_Edit_Student_report OnPostEvent_Edit_Student_report;
public  delegate void PreEvent_Handler_Edit_Teacher(Teacher i_Teacher,Enum_EditMode i_Enum_EditMode);
public  delegate void  PostEvent_Handler_Edit_Teacher(Teacher i_Teacher,Enum_EditMode i_Enum_EditMode);
public event PreEvent_Handler_Edit_Teacher OnPreEvent_Edit_Teacher;
public event PostEvent_Handler_Edit_Teacher OnPostEvent_Edit_Teacher;
public  delegate void PreEvent_Handler_Edit_Teacher_report(Teacher_report i_Teacher_report,Enum_EditMode i_Enum_EditMode);
public  delegate void  PostEvent_Handler_Edit_Teacher_report(Teacher_report i_Teacher_report,Enum_EditMode i_Enum_EditMode);
public event PreEvent_Handler_Edit_Teacher_report OnPreEvent_Edit_Teacher_report;
public event PostEvent_Handler_Edit_Teacher_report OnPostEvent_Edit_Teacher_report;
public  delegate void PreEvent_Handler_Delete_Answer(Params_Delete_Answer i_Params_Delete_Answer);
public  delegate void  PostEvent_Handler_Delete_Answer(Params_Delete_Answer i_Params_Delete_Answer);
public event PreEvent_Handler_Delete_Answer OnPreEvent_Delete_Answer;
public event PostEvent_Handler_Delete_Answer OnPostEvent_Delete_Answer;
public  delegate void PreEvent_Handler_Delete_Question(Params_Delete_Question i_Params_Delete_Question);
public  delegate void  PostEvent_Handler_Delete_Question(Params_Delete_Question i_Params_Delete_Question);
public event PreEvent_Handler_Delete_Question OnPreEvent_Delete_Question;
public event PostEvent_Handler_Delete_Question OnPostEvent_Delete_Question;
public  delegate void PreEvent_Handler_Delete_Student(Params_Delete_Student i_Params_Delete_Student);
public  delegate void  PostEvent_Handler_Delete_Student(Params_Delete_Student i_Params_Delete_Student);
public event PreEvent_Handler_Delete_Student OnPreEvent_Delete_Student;
public event PostEvent_Handler_Delete_Student OnPostEvent_Delete_Student;
public  delegate void PreEvent_Handler_Delete_Teacher(Params_Delete_Teacher i_Params_Delete_Teacher);
public  delegate void  PostEvent_Handler_Delete_Teacher(Params_Delete_Teacher i_Params_Delete_Teacher);
public event PreEvent_Handler_Delete_Teacher OnPreEvent_Delete_Teacher;
public event PostEvent_Handler_Delete_Teacher OnPostEvent_Delete_Teacher;
public  delegate void PreEvent_Handler_Sign_in_Student(Params_Sign_in_Student i_Params_Sign_in_Student);
public  delegate void  PostEvent_Handler_Sign_in_Student(Params_Sign_in_Student i_Params_Sign_in_Student);
public event PreEvent_Handler_Sign_in_Student OnPreEvent_Sign_in_Student;
public event PostEvent_Handler_Sign_in_Student OnPostEvent_Sign_in_Student;
public  delegate void PreEvent_Handler_Sign_in_Teacher(Params_Sign_in_Teacher i_Params_Sign_in_Teacher);
public  delegate void  PostEvent_Handler_Sign_in_Teacher(Params_Sign_in_Teacher i_Params_Sign_in_Teacher);
public event PreEvent_Handler_Sign_in_Teacher OnPreEvent_Sign_in_Teacher;
public event PostEvent_Handler_Sign_in_Teacher OnPostEvent_Sign_in_Teacher;
#region Cach Dropper
public void Initialize_Cash_Dropper()
{
}
#endregion
}
}
