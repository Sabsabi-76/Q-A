using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;
using System.Configuration;
using DALC;
//using System.Data.Linq;
using System.Text.RegularExpressions;
using System.Transactions;
using System.Reflection;
using System.Diagnostics;
using System.Data.SqlClient;
using System.Threading;







namespace BLC
{
public partial class BLC
{
public Favorite_category Get_Favorite_category_By_FAVORITE_CATEGORY_ID_Adv(Params_Get_Favorite_category_By_FAVORITE_CATEGORY_ID i_Params_Get_Favorite_category_By_FAVORITE_CATEGORY_ID)
{
Tools.Tools oTools = new Tools.Tools();
Favorite_category oFavorite_category = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Favorite_category_By_FAVORITE_CATEGORY_ID_Adv");}
#region Body Section.
DALC.Favorite_category oDBEntry = _AppContext.Get_Favorite_category_By_FAVORITE_CATEGORY_ID_Adv(i_Params_Get_Favorite_category_By_FAVORITE_CATEGORY_ID.FAVORITE_CATEGORY_ID);
oFavorite_category = new Favorite_category();
oTools.CopyPropValues(oDBEntry, oFavorite_category);

oFavorite_category.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oFavorite_category.My_Student);

oFavorite_category.My_Category = new Category();
oTools.CopyPropValues(oDBEntry.My_Category, oFavorite_category.My_Category);

#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Favorite_category_By_FAVORITE_CATEGORY_ID_Adv");}
return oFavorite_category;
}
public Category Get_Category_By_CATEGORY_ID_Adv(Params_Get_Category_By_CATEGORY_ID i_Params_Get_Category_By_CATEGORY_ID)
{
Tools.Tools oTools = new Tools.Tools();
Category oCategory = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Category_By_CATEGORY_ID_Adv");}
#region Body Section.
DALC.Category oDBEntry = _AppContext.Get_Category_By_CATEGORY_ID_Adv(i_Params_Get_Category_By_CATEGORY_ID.CATEGORY_ID);
oCategory = new Category();
oTools.CopyPropValues(oDBEntry, oCategory);

#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Category_By_CATEGORY_ID_Adv");}
return oCategory;
}
public Question Get_Question_By_QUESTION_ID_Adv(Params_Get_Question_By_QUESTION_ID i_Params_Get_Question_By_QUESTION_ID)
{
Tools.Tools oTools = new Tools.Tools();
Question oQuestion = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Question_By_QUESTION_ID_Adv");}
#region Body Section.
DALC.Question oDBEntry = _AppContext.Get_Question_By_QUESTION_ID_Adv(i_Params_Get_Question_By_QUESTION_ID.QUESTION_ID);
oQuestion = new Question();
oTools.CopyPropValues(oDBEntry, oQuestion);

oQuestion.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oQuestion.My_Student);

oQuestion.My_Category = new Category();
oTools.CopyPropValues(oDBEntry.My_Category, oQuestion.My_Category);

oQuestion.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oQuestion.My_Teacher);

#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Question_By_QUESTION_ID_Adv");}
return oQuestion;
}
public Report_article Get_Report_article_By_REPORT_ARTICLE_ID_Adv(Params_Get_Report_article_By_REPORT_ARTICLE_ID i_Params_Get_Report_article_By_REPORT_ARTICLE_ID)
{
Tools.Tools oTools = new Tools.Tools();
Report_article oReport_article = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Report_article_By_REPORT_ARTICLE_ID_Adv");}
#region Body Section.
DALC.Report_article oDBEntry = _AppContext.Get_Report_article_By_REPORT_ARTICLE_ID_Adv(i_Params_Get_Report_article_By_REPORT_ARTICLE_ID.REPORT_ARTICLE_ID);
oReport_article = new Report_article();
oTools.CopyPropValues(oDBEntry, oReport_article);

oReport_article.My_Article = new Article();
oTools.CopyPropValues(oDBEntry.My_Article, oReport_article.My_Article);

oReport_article.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oReport_article.My_Student);

#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Report_article_By_REPORT_ARTICLE_ID_Adv");}
return oReport_article;
}
public Mark_question Get_Mark_question_By_MARK_QUESTION_ID_Adv(Params_Get_Mark_question_By_MARK_QUESTION_ID i_Params_Get_Mark_question_By_MARK_QUESTION_ID)
{
Tools.Tools oTools = new Tools.Tools();
Mark_question oMark_question = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Mark_question_By_MARK_QUESTION_ID_Adv");}
#region Body Section.
DALC.Mark_question oDBEntry = _AppContext.Get_Mark_question_By_MARK_QUESTION_ID_Adv(i_Params_Get_Mark_question_By_MARK_QUESTION_ID.MARK_QUESTION_ID);
oMark_question = new Mark_question();
oTools.CopyPropValues(oDBEntry, oMark_question);

oMark_question.My_Question = new Question();
oTools.CopyPropValues(oDBEntry.My_Question, oMark_question.My_Question);

oMark_question.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oMark_question.My_Student);

#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Mark_question_By_MARK_QUESTION_ID_Adv");}
return oMark_question;
}
public Article Get_Article_By_ARTICLE_ID_Adv(Params_Get_Article_By_ARTICLE_ID i_Params_Get_Article_By_ARTICLE_ID)
{
Tools.Tools oTools = new Tools.Tools();
Article oArticle = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Article_By_ARTICLE_ID_Adv");}
#region Body Section.
DALC.Article oDBEntry = _AppContext.Get_Article_By_ARTICLE_ID_Adv(i_Params_Get_Article_By_ARTICLE_ID.ARTICLE_ID);
oArticle = new Article();
oTools.CopyPropValues(oDBEntry, oArticle);

oArticle.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oArticle.My_Teacher);

oArticle.My_Category = new Category();
oTools.CopyPropValues(oDBEntry.My_Category, oArticle.My_Category);

#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Article_By_ARTICLE_ID_Adv");}
return oArticle;
}
public Answer Get_Answer_By_ANSWER_ID_Adv(Params_Get_Answer_By_ANSWER_ID i_Params_Get_Answer_By_ANSWER_ID)
{
Tools.Tools oTools = new Tools.Tools();
Answer oAnswer = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Answer_By_ANSWER_ID_Adv");}
#region Body Section.
DALC.Answer oDBEntry = _AppContext.Get_Answer_By_ANSWER_ID_Adv(i_Params_Get_Answer_By_ANSWER_ID.ANSWER_ID);
oAnswer = new Answer();
oTools.CopyPropValues(oDBEntry, oAnswer);

oAnswer.My_Question = new Question();
oTools.CopyPropValues(oDBEntry.My_Question, oAnswer.My_Question);

oAnswer.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oAnswer.My_Teacher);

#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Answer_By_ANSWER_ID_Adv");}
return oAnswer;
}
public Student Get_Student_By_STUDENT_ID_Adv(Params_Get_Student_By_STUDENT_ID i_Params_Get_Student_By_STUDENT_ID)
{
Tools.Tools oTools = new Tools.Tools();
Student oStudent = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Student_By_STUDENT_ID_Adv");}
#region Body Section.
DALC.Student oDBEntry = _AppContext.Get_Student_By_STUDENT_ID_Adv(i_Params_Get_Student_By_STUDENT_ID.STUDENT_ID);
oStudent = new Student();
oTools.CopyPropValues(oDBEntry, oStudent);

oStudent.My_User = new User();
oTools.CopyPropValues(oDBEntry.My_User, oStudent.My_User);

#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Student_By_STUDENT_ID_Adv");}
return oStudent;
}
public Notification Get_Notification_By_NOTIFICATION_ID_Adv(Params_Get_Notification_By_NOTIFICATION_ID i_Params_Get_Notification_By_NOTIFICATION_ID)
{
Tools.Tools oTools = new Tools.Tools();
Notification oNotification = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Notification_By_NOTIFICATION_ID_Adv");}
#region Body Section.
DALC.Notification oDBEntry = _AppContext.Get_Notification_By_NOTIFICATION_ID_Adv(i_Params_Get_Notification_By_NOTIFICATION_ID.NOTIFICATION_ID);
oNotification = new Notification();
oTools.CopyPropValues(oDBEntry, oNotification);

oNotification.My_User = new User();
oTools.CopyPropValues(oDBEntry.My_User, oNotification.My_User);

oNotification.My_Question = new Question();
oTools.CopyPropValues(oDBEntry.My_Question, oNotification.My_Question);

oNotification.My_Answer = new Answer();
oTools.CopyPropValues(oDBEntry.My_Answer, oNotification.My_Answer);

oNotification.My_Article = new Article();
oTools.CopyPropValues(oDBEntry.My_Article, oNotification.My_Article);

#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Notification_By_NOTIFICATION_ID_Adv");}
return oNotification;
}
public User Get_User_By_USER_ID_Adv(Params_Get_User_By_USER_ID i_Params_Get_User_By_USER_ID)
{
Tools.Tools oTools = new Tools.Tools();
User oUser = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_User_By_USER_ID_Adv");}
#region Body Section.
DALC.User oDBEntry = _AppContext.Get_User_By_USER_ID_Adv(i_Params_Get_User_By_USER_ID.USER_ID);
oUser = new User();
oTools.CopyPropValues(oDBEntry, oUser);

#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_User_By_USER_ID_Adv");}
return oUser;
}
public Evaluation Get_Evaluation_By_EVALUATION_ID_Adv(Params_Get_Evaluation_By_EVALUATION_ID i_Params_Get_Evaluation_By_EVALUATION_ID)
{
Tools.Tools oTools = new Tools.Tools();
Evaluation oEvaluation = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Evaluation_By_EVALUATION_ID_Adv");}
#region Body Section.
DALC.Evaluation oDBEntry = _AppContext.Get_Evaluation_By_EVALUATION_ID_Adv(i_Params_Get_Evaluation_By_EVALUATION_ID.EVALUATION_ID);
oEvaluation = new Evaluation();
oTools.CopyPropValues(oDBEntry, oEvaluation);

oEvaluation.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oEvaluation.My_Student);

oEvaluation.My_Answer = new Answer();
oTools.CopyPropValues(oDBEntry.My_Answer, oEvaluation.My_Answer);

#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Evaluation_By_EVALUATION_ID_Adv");}
return oEvaluation;
}
public Student_report Get_Student_report_By_STUDENT_REPORT_ID_Adv(Params_Get_Student_report_By_STUDENT_REPORT_ID i_Params_Get_Student_report_By_STUDENT_REPORT_ID)
{
Tools.Tools oTools = new Tools.Tools();
Student_report oStudent_report = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Student_report_By_STUDENT_REPORT_ID_Adv");}
#region Body Section.
DALC.Student_report oDBEntry = _AppContext.Get_Student_report_By_STUDENT_REPORT_ID_Adv(i_Params_Get_Student_report_By_STUDENT_REPORT_ID.STUDENT_REPORT_ID);
oStudent_report = new Student_report();
oTools.CopyPropValues(oDBEntry, oStudent_report);

oStudent_report.My_Reported_by_student = new Student();
oTools.CopyPropValues(oDBEntry.My_Reported_by_student, oStudent_report.My_Reported_by_student);

oStudent_report.My_Reported_student = new Student();
oTools.CopyPropValues(oDBEntry.My_Reported_student, oStudent_report.My_Reported_student);

#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Student_report_By_STUDENT_REPORT_ID_Adv");}
return oStudent_report;
}
public Appreciate Get_Appreciate_By_APPRECIATE_ID_Adv(Params_Get_Appreciate_By_APPRECIATE_ID i_Params_Get_Appreciate_By_APPRECIATE_ID)
{
Tools.Tools oTools = new Tools.Tools();
Appreciate oAppreciate = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Appreciate_By_APPRECIATE_ID_Adv");}
#region Body Section.
DALC.Appreciate oDBEntry = _AppContext.Get_Appreciate_By_APPRECIATE_ID_Adv(i_Params_Get_Appreciate_By_APPRECIATE_ID.APPRECIATE_ID);
oAppreciate = new Appreciate();
oTools.CopyPropValues(oDBEntry, oAppreciate);

oAppreciate.My_Article = new Article();
oTools.CopyPropValues(oDBEntry.My_Article, oAppreciate.My_Article);

oAppreciate.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oAppreciate.My_Student);

#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Appreciate_By_APPRECIATE_ID_Adv");}
return oAppreciate;
}
public Teacher_report Get_Teacher_report_By_TEACHER_REPORT_ID_Adv(Params_Get_Teacher_report_By_TEACHER_REPORT_ID i_Params_Get_Teacher_report_By_TEACHER_REPORT_ID)
{
Tools.Tools oTools = new Tools.Tools();
Teacher_report oTeacher_report = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_report_By_TEACHER_REPORT_ID_Adv");}
#region Body Section.
DALC.Teacher_report oDBEntry = _AppContext.Get_Teacher_report_By_TEACHER_REPORT_ID_Adv(i_Params_Get_Teacher_report_By_TEACHER_REPORT_ID.TEACHER_REPORT_ID);
oTeacher_report = new Teacher_report();
oTools.CopyPropValues(oDBEntry, oTeacher_report);

oTeacher_report.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oTeacher_report.My_Teacher);

oTeacher_report.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oTeacher_report.My_Student);

#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_report_By_TEACHER_REPORT_ID_Adv");}
return oTeacher_report;
}
public Question_report Get_Question_report_By_QUESTION_REPORT_ID_Adv(Params_Get_Question_report_By_QUESTION_REPORT_ID i_Params_Get_Question_report_By_QUESTION_REPORT_ID)
{
Tools.Tools oTools = new Tools.Tools();
Question_report oQuestion_report = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Question_report_By_QUESTION_REPORT_ID_Adv");}
#region Body Section.
DALC.Question_report oDBEntry = _AppContext.Get_Question_report_By_QUESTION_REPORT_ID_Adv(i_Params_Get_Question_report_By_QUESTION_REPORT_ID.QUESTION_REPORT_ID);
oQuestion_report = new Question_report();
oTools.CopyPropValues(oDBEntry, oQuestion_report);

oQuestion_report.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oQuestion_report.My_Student);

oQuestion_report.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oQuestion_report.My_Teacher);

oQuestion_report.My_Question = new Question();
oTools.CopyPropValues(oDBEntry.My_Question, oQuestion_report.My_Question);

#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Question_report_By_QUESTION_REPORT_ID_Adv");}
return oQuestion_report;
}
public Answer_report Get_Answer_report_By_ANSWER_REPORT_ID_Adv(Params_Get_Answer_report_By_ANSWER_REPORT_ID i_Params_Get_Answer_report_By_ANSWER_REPORT_ID)
{
Tools.Tools oTools = new Tools.Tools();
Answer_report oAnswer_report = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Answer_report_By_ANSWER_REPORT_ID_Adv");}
#region Body Section.
DALC.Answer_report oDBEntry = _AppContext.Get_Answer_report_By_ANSWER_REPORT_ID_Adv(i_Params_Get_Answer_report_By_ANSWER_REPORT_ID.ANSWER_REPORT_ID);
oAnswer_report = new Answer_report();
oTools.CopyPropValues(oDBEntry, oAnswer_report);

oAnswer_report.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oAnswer_report.My_Teacher);

oAnswer_report.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oAnswer_report.My_Student);

oAnswer_report.My_Answer = new Answer();
oTools.CopyPropValues(oDBEntry.My_Answer, oAnswer_report.My_Answer);

#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Answer_report_By_ANSWER_REPORT_ID_Adv");}
return oAnswer_report;
}
public Teacher_rank Get_Teacher_rank_By_TEACHER_RANK_ID_Adv(Params_Get_Teacher_rank_By_TEACHER_RANK_ID i_Params_Get_Teacher_rank_By_TEACHER_RANK_ID)
{
Tools.Tools oTools = new Tools.Tools();
Teacher_rank oTeacher_rank = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_rank_By_TEACHER_RANK_ID_Adv");}
#region Body Section.
DALC.Teacher_rank oDBEntry = _AppContext.Get_Teacher_rank_By_TEACHER_RANK_ID_Adv(i_Params_Get_Teacher_rank_By_TEACHER_RANK_ID.TEACHER_RANK_ID);
oTeacher_rank = new Teacher_rank();
oTools.CopyPropValues(oDBEntry, oTeacher_rank);

oTeacher_rank.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oTeacher_rank.My_Teacher);

#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_rank_By_TEACHER_RANK_ID_Adv");}
return oTeacher_rank;
}
public Teacher Get_Teacher_By_TEACHER_ID_Adv(Params_Get_Teacher_By_TEACHER_ID i_Params_Get_Teacher_By_TEACHER_ID)
{
Tools.Tools oTools = new Tools.Tools();
Teacher oTeacher = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_By_TEACHER_ID_Adv");}
#region Body Section.
DALC.Teacher oDBEntry = _AppContext.Get_Teacher_By_TEACHER_ID_Adv(i_Params_Get_Teacher_By_TEACHER_ID.TEACHER_ID);
oTeacher = new Teacher();
oTools.CopyPropValues(oDBEntry, oTeacher);

oTeacher.My_User = new User();
oTools.CopyPropValues(oDBEntry.My_User, oTeacher.My_User);

#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_By_TEACHER_ID_Adv");}
return oTeacher;
}
public Question_token Get_Question_token_By_QUESTION_TOKEN_ID_Adv(Params_Get_Question_token_By_QUESTION_TOKEN_ID i_Params_Get_Question_token_By_QUESTION_TOKEN_ID)
{
Tools.Tools oTools = new Tools.Tools();
Question_token oQuestion_token = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Question_token_By_QUESTION_TOKEN_ID_Adv");}
#region Body Section.
DALC.Question_token oDBEntry = _AppContext.Get_Question_token_By_QUESTION_TOKEN_ID_Adv(i_Params_Get_Question_token_By_QUESTION_TOKEN_ID.QUESTION_TOKEN_ID);
oQuestion_token = new Question_token();
oTools.CopyPropValues(oDBEntry, oQuestion_token);

oQuestion_token.My_Question = new Question();
oTools.CopyPropValues(oDBEntry.My_Question, oQuestion_token.My_Question);

#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Question_token_By_QUESTION_TOKEN_ID_Adv");}
return oQuestion_token;
}
public Teacher_category Get_Teacher_category_By_TEACHER_CATEGORY_ID_Adv(Params_Get_Teacher_category_By_TEACHER_CATEGORY_ID i_Params_Get_Teacher_category_By_TEACHER_CATEGORY_ID)
{
Tools.Tools oTools = new Tools.Tools();
Teacher_category oTeacher_category = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_category_By_TEACHER_CATEGORY_ID_Adv");}
#region Body Section.
DALC.Teacher_category oDBEntry = _AppContext.Get_Teacher_category_By_TEACHER_CATEGORY_ID_Adv(i_Params_Get_Teacher_category_By_TEACHER_CATEGORY_ID.TEACHER_CATEGORY_ID);
oTeacher_category = new Teacher_category();
oTools.CopyPropValues(oDBEntry, oTeacher_category);

oTeacher_category.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oTeacher_category.My_Teacher);

oTeacher_category.My_Category = new Category();
oTools.CopyPropValues(oDBEntry.My_Category, oTeacher_category.My_Category);

#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_category_By_TEACHER_CATEGORY_ID_Adv");}
return oTeacher_category;
}
public Favorite_teacher Get_Favorite_teacher_By_FAVORITE_TEACHER_ID_Adv(Params_Get_Favorite_teacher_By_FAVORITE_TEACHER_ID i_Params_Get_Favorite_teacher_By_FAVORITE_TEACHER_ID)
{
Tools.Tools oTools = new Tools.Tools();
Favorite_teacher oFavorite_teacher = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Favorite_teacher_By_FAVORITE_TEACHER_ID_Adv");}
#region Body Section.
DALC.Favorite_teacher oDBEntry = _AppContext.Get_Favorite_teacher_By_FAVORITE_TEACHER_ID_Adv(i_Params_Get_Favorite_teacher_By_FAVORITE_TEACHER_ID.FAVORITE_TEACHER_ID);
oFavorite_teacher = new Favorite_teacher();
oTools.CopyPropValues(oDBEntry, oFavorite_teacher);

oFavorite_teacher.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oFavorite_teacher.My_Teacher);

oFavorite_teacher.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oFavorite_teacher.My_Student);

#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Favorite_teacher_By_FAVORITE_TEACHER_ID_Adv");}
return oFavorite_teacher;
}
public Teacher_favorite Get_Teacher_favorite_By_TEACHER_FAVORITE_ID_Adv(Params_Get_Teacher_favorite_By_TEACHER_FAVORITE_ID i_Params_Get_Teacher_favorite_By_TEACHER_FAVORITE_ID)
{
Tools.Tools oTools = new Tools.Tools();
Teacher_favorite oTeacher_favorite = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_favorite_By_TEACHER_FAVORITE_ID_Adv");}
#region Body Section.
DALC.Teacher_favorite oDBEntry = _AppContext.Get_Teacher_favorite_By_TEACHER_FAVORITE_ID_Adv(i_Params_Get_Teacher_favorite_By_TEACHER_FAVORITE_ID.TEACHER_FAVORITE_ID);
oTeacher_favorite = new Teacher_favorite();
oTools.CopyPropValues(oDBEntry, oTeacher_favorite);

oTeacher_favorite.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oTeacher_favorite.My_Teacher);

oTeacher_favorite.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oTeacher_favorite.My_Student);

#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_favorite_By_TEACHER_FAVORITE_ID_Adv");}
return oTeacher_favorite;
}
public List<Favorite_category> Get_Favorite_category_By_FAVORITE_CATEGORY_ID_List_Adv(Params_Get_Favorite_category_By_FAVORITE_CATEGORY_ID_List i_Params_Get_Favorite_category_By_FAVORITE_CATEGORY_ID_List)
{
Favorite_category oFavorite_category = null;
List<Favorite_category> oList = new List<Favorite_category>();
Params_Get_Favorite_category_By_FAVORITE_CATEGORY_ID_List_SP oParams_Get_Favorite_category_By_FAVORITE_CATEGORY_ID_List_SP = new Params_Get_Favorite_category_By_FAVORITE_CATEGORY_ID_List_SP();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Favorite_category_By_FAVORITE_CATEGORY_ID_List_Adv");}
#region Body Section.
List<DALC.Favorite_category> oList_DBEntries = _AppContext.Get_Favorite_category_By_FAVORITE_CATEGORY_ID_List_Adv(i_Params_Get_Favorite_category_By_FAVORITE_CATEGORY_ID_List.FAVORITE_CATEGORY_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oFavorite_category = new Favorite_category();
oTools.CopyPropValues(oDBEntry, oFavorite_category);

oFavorite_category.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oFavorite_category.My_Student);

oFavorite_category.My_Category = new Category();
oTools.CopyPropValues(oDBEntry.My_Category, oFavorite_category.My_Category);

oList.Add(oFavorite_category);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Favorite_category_By_FAVORITE_CATEGORY_ID_List_Adv");}
return oList;
}
public List<Category> Get_Category_By_CATEGORY_ID_List_Adv(Params_Get_Category_By_CATEGORY_ID_List i_Params_Get_Category_By_CATEGORY_ID_List)
{
Category oCategory = null;
List<Category> oList = new List<Category>();
Params_Get_Category_By_CATEGORY_ID_List_SP oParams_Get_Category_By_CATEGORY_ID_List_SP = new Params_Get_Category_By_CATEGORY_ID_List_SP();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Category_By_CATEGORY_ID_List_Adv");}
#region Body Section.
List<DALC.Category> oList_DBEntries = _AppContext.Get_Category_By_CATEGORY_ID_List_Adv(i_Params_Get_Category_By_CATEGORY_ID_List.CATEGORY_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCategory = new Category();
oTools.CopyPropValues(oDBEntry, oCategory);

oList.Add(oCategory);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Category_By_CATEGORY_ID_List_Adv");}
return oList;
}
public List<Question> Get_Question_By_QUESTION_ID_List_Adv(Params_Get_Question_By_QUESTION_ID_List i_Params_Get_Question_By_QUESTION_ID_List)
{
Question oQuestion = null;
List<Question> oList = new List<Question>();
Params_Get_Question_By_QUESTION_ID_List_SP oParams_Get_Question_By_QUESTION_ID_List_SP = new Params_Get_Question_By_QUESTION_ID_List_SP();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Question_By_QUESTION_ID_List_Adv");}
#region Body Section.
List<DALC.Question> oList_DBEntries = _AppContext.Get_Question_By_QUESTION_ID_List_Adv(i_Params_Get_Question_By_QUESTION_ID_List.QUESTION_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oQuestion = new Question();
oTools.CopyPropValues(oDBEntry, oQuestion);

oQuestion.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oQuestion.My_Student);

oQuestion.My_Category = new Category();
oTools.CopyPropValues(oDBEntry.My_Category, oQuestion.My_Category);

oQuestion.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oQuestion.My_Teacher);

oList.Add(oQuestion);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Question_By_QUESTION_ID_List_Adv");}
return oList;
}
public List<Report_article> Get_Report_article_By_REPORT_ARTICLE_ID_List_Adv(Params_Get_Report_article_By_REPORT_ARTICLE_ID_List i_Params_Get_Report_article_By_REPORT_ARTICLE_ID_List)
{
Report_article oReport_article = null;
List<Report_article> oList = new List<Report_article>();
Params_Get_Report_article_By_REPORT_ARTICLE_ID_List_SP oParams_Get_Report_article_By_REPORT_ARTICLE_ID_List_SP = new Params_Get_Report_article_By_REPORT_ARTICLE_ID_List_SP();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Report_article_By_REPORT_ARTICLE_ID_List_Adv");}
#region Body Section.
List<DALC.Report_article> oList_DBEntries = _AppContext.Get_Report_article_By_REPORT_ARTICLE_ID_List_Adv(i_Params_Get_Report_article_By_REPORT_ARTICLE_ID_List.REPORT_ARTICLE_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oReport_article = new Report_article();
oTools.CopyPropValues(oDBEntry, oReport_article);

oReport_article.My_Article = new Article();
oTools.CopyPropValues(oDBEntry.My_Article, oReport_article.My_Article);

oReport_article.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oReport_article.My_Student);

oList.Add(oReport_article);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Report_article_By_REPORT_ARTICLE_ID_List_Adv");}
return oList;
}
public List<Mark_question> Get_Mark_question_By_MARK_QUESTION_ID_List_Adv(Params_Get_Mark_question_By_MARK_QUESTION_ID_List i_Params_Get_Mark_question_By_MARK_QUESTION_ID_List)
{
Mark_question oMark_question = null;
List<Mark_question> oList = new List<Mark_question>();
Params_Get_Mark_question_By_MARK_QUESTION_ID_List_SP oParams_Get_Mark_question_By_MARK_QUESTION_ID_List_SP = new Params_Get_Mark_question_By_MARK_QUESTION_ID_List_SP();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Mark_question_By_MARK_QUESTION_ID_List_Adv");}
#region Body Section.
List<DALC.Mark_question> oList_DBEntries = _AppContext.Get_Mark_question_By_MARK_QUESTION_ID_List_Adv(i_Params_Get_Mark_question_By_MARK_QUESTION_ID_List.MARK_QUESTION_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oMark_question = new Mark_question();
oTools.CopyPropValues(oDBEntry, oMark_question);

oMark_question.My_Question = new Question();
oTools.CopyPropValues(oDBEntry.My_Question, oMark_question.My_Question);

oMark_question.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oMark_question.My_Student);

oList.Add(oMark_question);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Mark_question_By_MARK_QUESTION_ID_List_Adv");}
return oList;
}
public List<Article> Get_Article_By_ARTICLE_ID_List_Adv(Params_Get_Article_By_ARTICLE_ID_List i_Params_Get_Article_By_ARTICLE_ID_List)
{
Article oArticle = null;
List<Article> oList = new List<Article>();
Params_Get_Article_By_ARTICLE_ID_List_SP oParams_Get_Article_By_ARTICLE_ID_List_SP = new Params_Get_Article_By_ARTICLE_ID_List_SP();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Article_By_ARTICLE_ID_List_Adv");}
#region Body Section.
List<DALC.Article> oList_DBEntries = _AppContext.Get_Article_By_ARTICLE_ID_List_Adv(i_Params_Get_Article_By_ARTICLE_ID_List.ARTICLE_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oArticle = new Article();
oTools.CopyPropValues(oDBEntry, oArticle);

oArticle.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oArticle.My_Teacher);

oArticle.My_Category = new Category();
oTools.CopyPropValues(oDBEntry.My_Category, oArticle.My_Category);

oList.Add(oArticle);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Article_By_ARTICLE_ID_List_Adv");}
return oList;
}
public List<Answer> Get_Answer_By_ANSWER_ID_List_Adv(Params_Get_Answer_By_ANSWER_ID_List i_Params_Get_Answer_By_ANSWER_ID_List)
{
Answer oAnswer = null;
List<Answer> oList = new List<Answer>();
Params_Get_Answer_By_ANSWER_ID_List_SP oParams_Get_Answer_By_ANSWER_ID_List_SP = new Params_Get_Answer_By_ANSWER_ID_List_SP();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Answer_By_ANSWER_ID_List_Adv");}
#region Body Section.
List<DALC.Answer> oList_DBEntries = _AppContext.Get_Answer_By_ANSWER_ID_List_Adv(i_Params_Get_Answer_By_ANSWER_ID_List.ANSWER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oAnswer = new Answer();
oTools.CopyPropValues(oDBEntry, oAnswer);

oAnswer.My_Question = new Question();
oTools.CopyPropValues(oDBEntry.My_Question, oAnswer.My_Question);

oAnswer.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oAnswer.My_Teacher);

oList.Add(oAnswer);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Answer_By_ANSWER_ID_List_Adv");}
return oList;
}
public List<Student> Get_Student_By_STUDENT_ID_List_Adv(Params_Get_Student_By_STUDENT_ID_List i_Params_Get_Student_By_STUDENT_ID_List)
{
Student oStudent = null;
List<Student> oList = new List<Student>();
Params_Get_Student_By_STUDENT_ID_List_SP oParams_Get_Student_By_STUDENT_ID_List_SP = new Params_Get_Student_By_STUDENT_ID_List_SP();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Student_By_STUDENT_ID_List_Adv");}
#region Body Section.
List<DALC.Student> oList_DBEntries = _AppContext.Get_Student_By_STUDENT_ID_List_Adv(i_Params_Get_Student_By_STUDENT_ID_List.STUDENT_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oStudent = new Student();
oTools.CopyPropValues(oDBEntry, oStudent);

oStudent.My_User = new User();
oTools.CopyPropValues(oDBEntry.My_User, oStudent.My_User);

oList.Add(oStudent);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Student_By_STUDENT_ID_List_Adv");}
return oList;
}
public List<Notification> Get_Notification_By_NOTIFICATION_ID_List_Adv(Params_Get_Notification_By_NOTIFICATION_ID_List i_Params_Get_Notification_By_NOTIFICATION_ID_List)
{
Notification oNotification = null;
List<Notification> oList = new List<Notification>();
Params_Get_Notification_By_NOTIFICATION_ID_List_SP oParams_Get_Notification_By_NOTIFICATION_ID_List_SP = new Params_Get_Notification_By_NOTIFICATION_ID_List_SP();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Notification_By_NOTIFICATION_ID_List_Adv");}
#region Body Section.
List<DALC.Notification> oList_DBEntries = _AppContext.Get_Notification_By_NOTIFICATION_ID_List_Adv(i_Params_Get_Notification_By_NOTIFICATION_ID_List.NOTIFICATION_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oNotification = new Notification();
oTools.CopyPropValues(oDBEntry, oNotification);

oNotification.My_User = new User();
oTools.CopyPropValues(oDBEntry.My_User, oNotification.My_User);

oNotification.My_Question = new Question();
oTools.CopyPropValues(oDBEntry.My_Question, oNotification.My_Question);

oNotification.My_Answer = new Answer();
oTools.CopyPropValues(oDBEntry.My_Answer, oNotification.My_Answer);

oNotification.My_Article = new Article();
oTools.CopyPropValues(oDBEntry.My_Article, oNotification.My_Article);

oList.Add(oNotification);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Notification_By_NOTIFICATION_ID_List_Adv");}
return oList;
}
public List<User> Get_User_By_USER_ID_List_Adv(Params_Get_User_By_USER_ID_List i_Params_Get_User_By_USER_ID_List)
{
User oUser = null;
List<User> oList = new List<User>();
Params_Get_User_By_USER_ID_List_SP oParams_Get_User_By_USER_ID_List_SP = new Params_Get_User_By_USER_ID_List_SP();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_User_By_USER_ID_List_Adv");}
#region Body Section.
List<DALC.User> oList_DBEntries = _AppContext.Get_User_By_USER_ID_List_Adv(i_Params_Get_User_By_USER_ID_List.USER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oUser = new User();
oTools.CopyPropValues(oDBEntry, oUser);

oList.Add(oUser);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_User_By_USER_ID_List_Adv");}
return oList;
}
public List<Evaluation> Get_Evaluation_By_EVALUATION_ID_List_Adv(Params_Get_Evaluation_By_EVALUATION_ID_List i_Params_Get_Evaluation_By_EVALUATION_ID_List)
{
Evaluation oEvaluation = null;
List<Evaluation> oList = new List<Evaluation>();
Params_Get_Evaluation_By_EVALUATION_ID_List_SP oParams_Get_Evaluation_By_EVALUATION_ID_List_SP = new Params_Get_Evaluation_By_EVALUATION_ID_List_SP();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Evaluation_By_EVALUATION_ID_List_Adv");}
#region Body Section.
List<DALC.Evaluation> oList_DBEntries = _AppContext.Get_Evaluation_By_EVALUATION_ID_List_Adv(i_Params_Get_Evaluation_By_EVALUATION_ID_List.EVALUATION_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oEvaluation = new Evaluation();
oTools.CopyPropValues(oDBEntry, oEvaluation);

oEvaluation.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oEvaluation.My_Student);

oEvaluation.My_Answer = new Answer();
oTools.CopyPropValues(oDBEntry.My_Answer, oEvaluation.My_Answer);

oList.Add(oEvaluation);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Evaluation_By_EVALUATION_ID_List_Adv");}
return oList;
}
public List<Student_report> Get_Student_report_By_STUDENT_REPORT_ID_List_Adv(Params_Get_Student_report_By_STUDENT_REPORT_ID_List i_Params_Get_Student_report_By_STUDENT_REPORT_ID_List)
{
Student_report oStudent_report = null;
List<Student_report> oList = new List<Student_report>();
Params_Get_Student_report_By_STUDENT_REPORT_ID_List_SP oParams_Get_Student_report_By_STUDENT_REPORT_ID_List_SP = new Params_Get_Student_report_By_STUDENT_REPORT_ID_List_SP();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Student_report_By_STUDENT_REPORT_ID_List_Adv");}
#region Body Section.
List<DALC.Student_report> oList_DBEntries = _AppContext.Get_Student_report_By_STUDENT_REPORT_ID_List_Adv(i_Params_Get_Student_report_By_STUDENT_REPORT_ID_List.STUDENT_REPORT_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oStudent_report = new Student_report();
oTools.CopyPropValues(oDBEntry, oStudent_report);

oStudent_report.My_Reported_by_student = new Student();
oTools.CopyPropValues(oDBEntry.My_Reported_by_student, oStudent_report.My_Reported_by_student);

oStudent_report.My_Reported_student = new Student();
oTools.CopyPropValues(oDBEntry.My_Reported_student, oStudent_report.My_Reported_student);

oList.Add(oStudent_report);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Student_report_By_STUDENT_REPORT_ID_List_Adv");}
return oList;
}
public List<Appreciate> Get_Appreciate_By_APPRECIATE_ID_List_Adv(Params_Get_Appreciate_By_APPRECIATE_ID_List i_Params_Get_Appreciate_By_APPRECIATE_ID_List)
{
Appreciate oAppreciate = null;
List<Appreciate> oList = new List<Appreciate>();
Params_Get_Appreciate_By_APPRECIATE_ID_List_SP oParams_Get_Appreciate_By_APPRECIATE_ID_List_SP = new Params_Get_Appreciate_By_APPRECIATE_ID_List_SP();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Appreciate_By_APPRECIATE_ID_List_Adv");}
#region Body Section.
List<DALC.Appreciate> oList_DBEntries = _AppContext.Get_Appreciate_By_APPRECIATE_ID_List_Adv(i_Params_Get_Appreciate_By_APPRECIATE_ID_List.APPRECIATE_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oAppreciate = new Appreciate();
oTools.CopyPropValues(oDBEntry, oAppreciate);

oAppreciate.My_Article = new Article();
oTools.CopyPropValues(oDBEntry.My_Article, oAppreciate.My_Article);

oAppreciate.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oAppreciate.My_Student);

oList.Add(oAppreciate);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Appreciate_By_APPRECIATE_ID_List_Adv");}
return oList;
}
public List<Teacher_report> Get_Teacher_report_By_TEACHER_REPORT_ID_List_Adv(Params_Get_Teacher_report_By_TEACHER_REPORT_ID_List i_Params_Get_Teacher_report_By_TEACHER_REPORT_ID_List)
{
Teacher_report oTeacher_report = null;
List<Teacher_report> oList = new List<Teacher_report>();
Params_Get_Teacher_report_By_TEACHER_REPORT_ID_List_SP oParams_Get_Teacher_report_By_TEACHER_REPORT_ID_List_SP = new Params_Get_Teacher_report_By_TEACHER_REPORT_ID_List_SP();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_report_By_TEACHER_REPORT_ID_List_Adv");}
#region Body Section.
List<DALC.Teacher_report> oList_DBEntries = _AppContext.Get_Teacher_report_By_TEACHER_REPORT_ID_List_Adv(i_Params_Get_Teacher_report_By_TEACHER_REPORT_ID_List.TEACHER_REPORT_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_report = new Teacher_report();
oTools.CopyPropValues(oDBEntry, oTeacher_report);

oTeacher_report.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oTeacher_report.My_Teacher);

oTeacher_report.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oTeacher_report.My_Student);

oList.Add(oTeacher_report);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_report_By_TEACHER_REPORT_ID_List_Adv");}
return oList;
}
public List<Question_report> Get_Question_report_By_QUESTION_REPORT_ID_List_Adv(Params_Get_Question_report_By_QUESTION_REPORT_ID_List i_Params_Get_Question_report_By_QUESTION_REPORT_ID_List)
{
Question_report oQuestion_report = null;
List<Question_report> oList = new List<Question_report>();
Params_Get_Question_report_By_QUESTION_REPORT_ID_List_SP oParams_Get_Question_report_By_QUESTION_REPORT_ID_List_SP = new Params_Get_Question_report_By_QUESTION_REPORT_ID_List_SP();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Question_report_By_QUESTION_REPORT_ID_List_Adv");}
#region Body Section.
List<DALC.Question_report> oList_DBEntries = _AppContext.Get_Question_report_By_QUESTION_REPORT_ID_List_Adv(i_Params_Get_Question_report_By_QUESTION_REPORT_ID_List.QUESTION_REPORT_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oQuestion_report = new Question_report();
oTools.CopyPropValues(oDBEntry, oQuestion_report);

oQuestion_report.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oQuestion_report.My_Student);

oQuestion_report.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oQuestion_report.My_Teacher);

oQuestion_report.My_Question = new Question();
oTools.CopyPropValues(oDBEntry.My_Question, oQuestion_report.My_Question);

oList.Add(oQuestion_report);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Question_report_By_QUESTION_REPORT_ID_List_Adv");}
return oList;
}
public List<Answer_report> Get_Answer_report_By_ANSWER_REPORT_ID_List_Adv(Params_Get_Answer_report_By_ANSWER_REPORT_ID_List i_Params_Get_Answer_report_By_ANSWER_REPORT_ID_List)
{
Answer_report oAnswer_report = null;
List<Answer_report> oList = new List<Answer_report>();
Params_Get_Answer_report_By_ANSWER_REPORT_ID_List_SP oParams_Get_Answer_report_By_ANSWER_REPORT_ID_List_SP = new Params_Get_Answer_report_By_ANSWER_REPORT_ID_List_SP();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Answer_report_By_ANSWER_REPORT_ID_List_Adv");}
#region Body Section.
List<DALC.Answer_report> oList_DBEntries = _AppContext.Get_Answer_report_By_ANSWER_REPORT_ID_List_Adv(i_Params_Get_Answer_report_By_ANSWER_REPORT_ID_List.ANSWER_REPORT_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oAnswer_report = new Answer_report();
oTools.CopyPropValues(oDBEntry, oAnswer_report);

oAnswer_report.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oAnswer_report.My_Teacher);

oAnswer_report.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oAnswer_report.My_Student);

oAnswer_report.My_Answer = new Answer();
oTools.CopyPropValues(oDBEntry.My_Answer, oAnswer_report.My_Answer);

oList.Add(oAnswer_report);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Answer_report_By_ANSWER_REPORT_ID_List_Adv");}
return oList;
}
public List<Teacher_rank> Get_Teacher_rank_By_TEACHER_RANK_ID_List_Adv(Params_Get_Teacher_rank_By_TEACHER_RANK_ID_List i_Params_Get_Teacher_rank_By_TEACHER_RANK_ID_List)
{
Teacher_rank oTeacher_rank = null;
List<Teacher_rank> oList = new List<Teacher_rank>();
Params_Get_Teacher_rank_By_TEACHER_RANK_ID_List_SP oParams_Get_Teacher_rank_By_TEACHER_RANK_ID_List_SP = new Params_Get_Teacher_rank_By_TEACHER_RANK_ID_List_SP();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_rank_By_TEACHER_RANK_ID_List_Adv");}
#region Body Section.
List<DALC.Teacher_rank> oList_DBEntries = _AppContext.Get_Teacher_rank_By_TEACHER_RANK_ID_List_Adv(i_Params_Get_Teacher_rank_By_TEACHER_RANK_ID_List.TEACHER_RANK_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_rank = new Teacher_rank();
oTools.CopyPropValues(oDBEntry, oTeacher_rank);

oTeacher_rank.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oTeacher_rank.My_Teacher);

oList.Add(oTeacher_rank);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_rank_By_TEACHER_RANK_ID_List_Adv");}
return oList;
}
public List<Teacher> Get_Teacher_By_TEACHER_ID_List_Adv(Params_Get_Teacher_By_TEACHER_ID_List i_Params_Get_Teacher_By_TEACHER_ID_List)
{
Teacher oTeacher = null;
List<Teacher> oList = new List<Teacher>();
Params_Get_Teacher_By_TEACHER_ID_List_SP oParams_Get_Teacher_By_TEACHER_ID_List_SP = new Params_Get_Teacher_By_TEACHER_ID_List_SP();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_By_TEACHER_ID_List_Adv");}
#region Body Section.
List<DALC.Teacher> oList_DBEntries = _AppContext.Get_Teacher_By_TEACHER_ID_List_Adv(i_Params_Get_Teacher_By_TEACHER_ID_List.TEACHER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher = new Teacher();
oTools.CopyPropValues(oDBEntry, oTeacher);

oTeacher.My_User = new User();
oTools.CopyPropValues(oDBEntry.My_User, oTeacher.My_User);

oList.Add(oTeacher);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_By_TEACHER_ID_List_Adv");}
return oList;
}
public List<Question_token> Get_Question_token_By_QUESTION_TOKEN_ID_List_Adv(Params_Get_Question_token_By_QUESTION_TOKEN_ID_List i_Params_Get_Question_token_By_QUESTION_TOKEN_ID_List)
{
Question_token oQuestion_token = null;
List<Question_token> oList = new List<Question_token>();
Params_Get_Question_token_By_QUESTION_TOKEN_ID_List_SP oParams_Get_Question_token_By_QUESTION_TOKEN_ID_List_SP = new Params_Get_Question_token_By_QUESTION_TOKEN_ID_List_SP();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Question_token_By_QUESTION_TOKEN_ID_List_Adv");}
#region Body Section.
List<DALC.Question_token> oList_DBEntries = _AppContext.Get_Question_token_By_QUESTION_TOKEN_ID_List_Adv(i_Params_Get_Question_token_By_QUESTION_TOKEN_ID_List.QUESTION_TOKEN_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oQuestion_token = new Question_token();
oTools.CopyPropValues(oDBEntry, oQuestion_token);

oQuestion_token.My_Question = new Question();
oTools.CopyPropValues(oDBEntry.My_Question, oQuestion_token.My_Question);

oList.Add(oQuestion_token);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Question_token_By_QUESTION_TOKEN_ID_List_Adv");}
return oList;
}
public List<Teacher_category> Get_Teacher_category_By_TEACHER_CATEGORY_ID_List_Adv(Params_Get_Teacher_category_By_TEACHER_CATEGORY_ID_List i_Params_Get_Teacher_category_By_TEACHER_CATEGORY_ID_List)
{
Teacher_category oTeacher_category = null;
List<Teacher_category> oList = new List<Teacher_category>();
Params_Get_Teacher_category_By_TEACHER_CATEGORY_ID_List_SP oParams_Get_Teacher_category_By_TEACHER_CATEGORY_ID_List_SP = new Params_Get_Teacher_category_By_TEACHER_CATEGORY_ID_List_SP();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_category_By_TEACHER_CATEGORY_ID_List_Adv");}
#region Body Section.
List<DALC.Teacher_category> oList_DBEntries = _AppContext.Get_Teacher_category_By_TEACHER_CATEGORY_ID_List_Adv(i_Params_Get_Teacher_category_By_TEACHER_CATEGORY_ID_List.TEACHER_CATEGORY_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_category = new Teacher_category();
oTools.CopyPropValues(oDBEntry, oTeacher_category);

oTeacher_category.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oTeacher_category.My_Teacher);

oTeacher_category.My_Category = new Category();
oTools.CopyPropValues(oDBEntry.My_Category, oTeacher_category.My_Category);

oList.Add(oTeacher_category);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_category_By_TEACHER_CATEGORY_ID_List_Adv");}
return oList;
}
public List<Favorite_teacher> Get_Favorite_teacher_By_FAVORITE_TEACHER_ID_List_Adv(Params_Get_Favorite_teacher_By_FAVORITE_TEACHER_ID_List i_Params_Get_Favorite_teacher_By_FAVORITE_TEACHER_ID_List)
{
Favorite_teacher oFavorite_teacher = null;
List<Favorite_teacher> oList = new List<Favorite_teacher>();
Params_Get_Favorite_teacher_By_FAVORITE_TEACHER_ID_List_SP oParams_Get_Favorite_teacher_By_FAVORITE_TEACHER_ID_List_SP = new Params_Get_Favorite_teacher_By_FAVORITE_TEACHER_ID_List_SP();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Favorite_teacher_By_FAVORITE_TEACHER_ID_List_Adv");}
#region Body Section.
List<DALC.Favorite_teacher> oList_DBEntries = _AppContext.Get_Favorite_teacher_By_FAVORITE_TEACHER_ID_List_Adv(i_Params_Get_Favorite_teacher_By_FAVORITE_TEACHER_ID_List.FAVORITE_TEACHER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oFavorite_teacher = new Favorite_teacher();
oTools.CopyPropValues(oDBEntry, oFavorite_teacher);

oFavorite_teacher.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oFavorite_teacher.My_Teacher);

oFavorite_teacher.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oFavorite_teacher.My_Student);

oList.Add(oFavorite_teacher);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Favorite_teacher_By_FAVORITE_TEACHER_ID_List_Adv");}
return oList;
}
public List<Teacher_favorite> Get_Teacher_favorite_By_TEACHER_FAVORITE_ID_List_Adv(Params_Get_Teacher_favorite_By_TEACHER_FAVORITE_ID_List i_Params_Get_Teacher_favorite_By_TEACHER_FAVORITE_ID_List)
{
Teacher_favorite oTeacher_favorite = null;
List<Teacher_favorite> oList = new List<Teacher_favorite>();
Params_Get_Teacher_favorite_By_TEACHER_FAVORITE_ID_List_SP oParams_Get_Teacher_favorite_By_TEACHER_FAVORITE_ID_List_SP = new Params_Get_Teacher_favorite_By_TEACHER_FAVORITE_ID_List_SP();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_favorite_By_TEACHER_FAVORITE_ID_List_Adv");}
#region Body Section.
List<DALC.Teacher_favorite> oList_DBEntries = _AppContext.Get_Teacher_favorite_By_TEACHER_FAVORITE_ID_List_Adv(i_Params_Get_Teacher_favorite_By_TEACHER_FAVORITE_ID_List.TEACHER_FAVORITE_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_favorite = new Teacher_favorite();
oTools.CopyPropValues(oDBEntry, oTeacher_favorite);

oTeacher_favorite.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oTeacher_favorite.My_Teacher);

oTeacher_favorite.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oTeacher_favorite.My_Student);

oList.Add(oTeacher_favorite);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_favorite_By_TEACHER_FAVORITE_ID_List_Adv");}
return oList;
}
public List<Favorite_category> Get_Favorite_category_By_STUDENT_ID_Adv(Params_Get_Favorite_category_By_STUDENT_ID i_Params_Get_Favorite_category_By_STUDENT_ID)
{
List<Favorite_category> oList = new List<Favorite_category>();
Favorite_category oFavorite_category = new Favorite_category();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Favorite_category_By_STUDENT_ID_Adv");}
#region Body Section.
List<DALC.Favorite_category> oList_DBEntries = _AppContext.Get_Favorite_category_By_STUDENT_ID_Adv(i_Params_Get_Favorite_category_By_STUDENT_ID.STUDENT_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oFavorite_category = new Favorite_category();
oTools.CopyPropValues(oDBEntry, oFavorite_category);

oFavorite_category.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oFavorite_category.My_Student);

oFavorite_category.My_Category = new Category();
oTools.CopyPropValues(oDBEntry.My_Category, oFavorite_category.My_Category);

oList.Add(oFavorite_category);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Favorite_category_By_STUDENT_ID_Adv");}
return oList;
}
public List<Favorite_category> Get_Favorite_category_By_CATEGORY_ID_Adv(Params_Get_Favorite_category_By_CATEGORY_ID i_Params_Get_Favorite_category_By_CATEGORY_ID)
{
List<Favorite_category> oList = new List<Favorite_category>();
Favorite_category oFavorite_category = new Favorite_category();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Favorite_category_By_CATEGORY_ID_Adv");}
#region Body Section.
List<DALC.Favorite_category> oList_DBEntries = _AppContext.Get_Favorite_category_By_CATEGORY_ID_Adv(i_Params_Get_Favorite_category_By_CATEGORY_ID.CATEGORY_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oFavorite_category = new Favorite_category();
oTools.CopyPropValues(oDBEntry, oFavorite_category);

oFavorite_category.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oFavorite_category.My_Student);

oFavorite_category.My_Category = new Category();
oTools.CopyPropValues(oDBEntry.My_Category, oFavorite_category.My_Category);

oList.Add(oFavorite_category);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Favorite_category_By_CATEGORY_ID_Adv");}
return oList;
}
public List<Favorite_category> Get_Favorite_category_By_OWNER_ID_Adv(Params_Get_Favorite_category_By_OWNER_ID i_Params_Get_Favorite_category_By_OWNER_ID)
{
List<Favorite_category> oList = new List<Favorite_category>();
Favorite_category oFavorite_category = new Favorite_category();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Favorite_category_By_OWNER_ID_Adv");}
#region Body Section.
List<DALC.Favorite_category> oList_DBEntries = _AppContext.Get_Favorite_category_By_OWNER_ID_Adv(i_Params_Get_Favorite_category_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oFavorite_category = new Favorite_category();
oTools.CopyPropValues(oDBEntry, oFavorite_category);

oFavorite_category.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oFavorite_category.My_Student);

oFavorite_category.My_Category = new Category();
oTools.CopyPropValues(oDBEntry.My_Category, oFavorite_category.My_Category);

oList.Add(oFavorite_category);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Favorite_category_By_OWNER_ID_Adv");}
return oList;
}
public List<Category> Get_Category_By_OWNER_ID_Adv(Params_Get_Category_By_OWNER_ID i_Params_Get_Category_By_OWNER_ID)
{
List<Category> oList = new List<Category>();
Category oCategory = new Category();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Category_By_OWNER_ID_Adv");}
#region Body Section.
List<DALC.Category> oList_DBEntries = _AppContext.Get_Category_By_OWNER_ID_Adv(i_Params_Get_Category_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCategory = new Category();
oTools.CopyPropValues(oDBEntry, oCategory);

oList.Add(oCategory);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Category_By_OWNER_ID_Adv");}
return oList;
}
public List<Question> Get_Question_By_OWNER_ID_Adv(Params_Get_Question_By_OWNER_ID i_Params_Get_Question_By_OWNER_ID)
{
List<Question> oList = new List<Question>();
Question oQuestion = new Question();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Question_By_OWNER_ID_Adv");}
#region Body Section.
List<DALC.Question> oList_DBEntries = _AppContext.Get_Question_By_OWNER_ID_Adv(i_Params_Get_Question_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oQuestion = new Question();
oTools.CopyPropValues(oDBEntry, oQuestion);

oQuestion.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oQuestion.My_Student);

oQuestion.My_Category = new Category();
oTools.CopyPropValues(oDBEntry.My_Category, oQuestion.My_Category);

oQuestion.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oQuestion.My_Teacher);

oList.Add(oQuestion);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Question_By_OWNER_ID_Adv");}
return oList;
}
public List<Question> Get_Question_By_STUDENT_ID_Adv(Params_Get_Question_By_STUDENT_ID i_Params_Get_Question_By_STUDENT_ID)
{
List<Question> oList = new List<Question>();
Question oQuestion = new Question();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Question_By_STUDENT_ID_Adv");}
#region Body Section.
List<DALC.Question> oList_DBEntries = _AppContext.Get_Question_By_STUDENT_ID_Adv(i_Params_Get_Question_By_STUDENT_ID.STUDENT_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oQuestion = new Question();
oTools.CopyPropValues(oDBEntry, oQuestion);

oQuestion.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oQuestion.My_Student);

oQuestion.My_Category = new Category();
oTools.CopyPropValues(oDBEntry.My_Category, oQuestion.My_Category);

oQuestion.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oQuestion.My_Teacher);

oList.Add(oQuestion);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Question_By_STUDENT_ID_Adv");}
return oList;
}
public List<Question> Get_Question_By_CATEGORY_ID_Adv(Params_Get_Question_By_CATEGORY_ID i_Params_Get_Question_By_CATEGORY_ID)
{
List<Question> oList = new List<Question>();
Question oQuestion = new Question();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Question_By_CATEGORY_ID_Adv");}
#region Body Section.
List<DALC.Question> oList_DBEntries = _AppContext.Get_Question_By_CATEGORY_ID_Adv(i_Params_Get_Question_By_CATEGORY_ID.CATEGORY_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oQuestion = new Question();
oTools.CopyPropValues(oDBEntry, oQuestion);

oQuestion.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oQuestion.My_Student);

oQuestion.My_Category = new Category();
oTools.CopyPropValues(oDBEntry.My_Category, oQuestion.My_Category);

oQuestion.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oQuestion.My_Teacher);

oList.Add(oQuestion);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Question_By_CATEGORY_ID_Adv");}
return oList;
}
public List<Question> Get_Question_By_TEACHER_ID_Adv(Params_Get_Question_By_TEACHER_ID i_Params_Get_Question_By_TEACHER_ID)
{
List<Question> oList = new List<Question>();
Question oQuestion = new Question();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Question_By_TEACHER_ID_Adv");}
#region Body Section.
List<DALC.Question> oList_DBEntries = _AppContext.Get_Question_By_TEACHER_ID_Adv(i_Params_Get_Question_By_TEACHER_ID.TEACHER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oQuestion = new Question();
oTools.CopyPropValues(oDBEntry, oQuestion);

oQuestion.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oQuestion.My_Student);

oQuestion.My_Category = new Category();
oTools.CopyPropValues(oDBEntry.My_Category, oQuestion.My_Category);

oQuestion.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oQuestion.My_Teacher);

oList.Add(oQuestion);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Question_By_TEACHER_ID_Adv");}
return oList;
}
public List<Report_article> Get_Report_article_By_OWNER_ID_Adv(Params_Get_Report_article_By_OWNER_ID i_Params_Get_Report_article_By_OWNER_ID)
{
List<Report_article> oList = new List<Report_article>();
Report_article oReport_article = new Report_article();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Report_article_By_OWNER_ID_Adv");}
#region Body Section.
List<DALC.Report_article> oList_DBEntries = _AppContext.Get_Report_article_By_OWNER_ID_Adv(i_Params_Get_Report_article_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oReport_article = new Report_article();
oTools.CopyPropValues(oDBEntry, oReport_article);

oReport_article.My_Article = new Article();
oTools.CopyPropValues(oDBEntry.My_Article, oReport_article.My_Article);

oReport_article.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oReport_article.My_Student);

oList.Add(oReport_article);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Report_article_By_OWNER_ID_Adv");}
return oList;
}
public List<Report_article> Get_Report_article_By_ARTICLE_ID_Adv(Params_Get_Report_article_By_ARTICLE_ID i_Params_Get_Report_article_By_ARTICLE_ID)
{
List<Report_article> oList = new List<Report_article>();
Report_article oReport_article = new Report_article();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Report_article_By_ARTICLE_ID_Adv");}
#region Body Section.
List<DALC.Report_article> oList_DBEntries = _AppContext.Get_Report_article_By_ARTICLE_ID_Adv(i_Params_Get_Report_article_By_ARTICLE_ID.ARTICLE_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oReport_article = new Report_article();
oTools.CopyPropValues(oDBEntry, oReport_article);

oReport_article.My_Article = new Article();
oTools.CopyPropValues(oDBEntry.My_Article, oReport_article.My_Article);

oReport_article.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oReport_article.My_Student);

oList.Add(oReport_article);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Report_article_By_ARTICLE_ID_Adv");}
return oList;
}
public List<Report_article> Get_Report_article_By_STUDENT_ID_Adv(Params_Get_Report_article_By_STUDENT_ID i_Params_Get_Report_article_By_STUDENT_ID)
{
List<Report_article> oList = new List<Report_article>();
Report_article oReport_article = new Report_article();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Report_article_By_STUDENT_ID_Adv");}
#region Body Section.
List<DALC.Report_article> oList_DBEntries = _AppContext.Get_Report_article_By_STUDENT_ID_Adv(i_Params_Get_Report_article_By_STUDENT_ID.STUDENT_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oReport_article = new Report_article();
oTools.CopyPropValues(oDBEntry, oReport_article);

oReport_article.My_Article = new Article();
oTools.CopyPropValues(oDBEntry.My_Article, oReport_article.My_Article);

oReport_article.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oReport_article.My_Student);

oList.Add(oReport_article);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Report_article_By_STUDENT_ID_Adv");}
return oList;
}
public List<Mark_question> Get_Mark_question_By_OWNER_ID_Adv(Params_Get_Mark_question_By_OWNER_ID i_Params_Get_Mark_question_By_OWNER_ID)
{
List<Mark_question> oList = new List<Mark_question>();
Mark_question oMark_question = new Mark_question();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Mark_question_By_OWNER_ID_Adv");}
#region Body Section.
List<DALC.Mark_question> oList_DBEntries = _AppContext.Get_Mark_question_By_OWNER_ID_Adv(i_Params_Get_Mark_question_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oMark_question = new Mark_question();
oTools.CopyPropValues(oDBEntry, oMark_question);

oMark_question.My_Question = new Question();
oTools.CopyPropValues(oDBEntry.My_Question, oMark_question.My_Question);

oMark_question.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oMark_question.My_Student);

oList.Add(oMark_question);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Mark_question_By_OWNER_ID_Adv");}
return oList;
}
public List<Mark_question> Get_Mark_question_By_QUESTION_ID_Adv(Params_Get_Mark_question_By_QUESTION_ID i_Params_Get_Mark_question_By_QUESTION_ID)
{
List<Mark_question> oList = new List<Mark_question>();
Mark_question oMark_question = new Mark_question();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Mark_question_By_QUESTION_ID_Adv");}
#region Body Section.
List<DALC.Mark_question> oList_DBEntries = _AppContext.Get_Mark_question_By_QUESTION_ID_Adv(i_Params_Get_Mark_question_By_QUESTION_ID.QUESTION_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oMark_question = new Mark_question();
oTools.CopyPropValues(oDBEntry, oMark_question);

oMark_question.My_Question = new Question();
oTools.CopyPropValues(oDBEntry.My_Question, oMark_question.My_Question);

oMark_question.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oMark_question.My_Student);

oList.Add(oMark_question);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Mark_question_By_QUESTION_ID_Adv");}
return oList;
}
public List<Mark_question> Get_Mark_question_By_STUDENT_ID_Adv(Params_Get_Mark_question_By_STUDENT_ID i_Params_Get_Mark_question_By_STUDENT_ID)
{
List<Mark_question> oList = new List<Mark_question>();
Mark_question oMark_question = new Mark_question();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Mark_question_By_STUDENT_ID_Adv");}
#region Body Section.
List<DALC.Mark_question> oList_DBEntries = _AppContext.Get_Mark_question_By_STUDENT_ID_Adv(i_Params_Get_Mark_question_By_STUDENT_ID.STUDENT_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oMark_question = new Mark_question();
oTools.CopyPropValues(oDBEntry, oMark_question);

oMark_question.My_Question = new Question();
oTools.CopyPropValues(oDBEntry.My_Question, oMark_question.My_Question);

oMark_question.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oMark_question.My_Student);

oList.Add(oMark_question);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Mark_question_By_STUDENT_ID_Adv");}
return oList;
}
public List<Article> Get_Article_By_OWNER_ID_Adv(Params_Get_Article_By_OWNER_ID i_Params_Get_Article_By_OWNER_ID)
{
List<Article> oList = new List<Article>();
Article oArticle = new Article();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Article_By_OWNER_ID_Adv");}
#region Body Section.
List<DALC.Article> oList_DBEntries = _AppContext.Get_Article_By_OWNER_ID_Adv(i_Params_Get_Article_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oArticle = new Article();
oTools.CopyPropValues(oDBEntry, oArticle);

oArticle.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oArticle.My_Teacher);

oArticle.My_Category = new Category();
oTools.CopyPropValues(oDBEntry.My_Category, oArticle.My_Category);

oList.Add(oArticle);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Article_By_OWNER_ID_Adv");}
return oList;
}
public List<Article> Get_Article_By_TEACHER_ID_Adv(Params_Get_Article_By_TEACHER_ID i_Params_Get_Article_By_TEACHER_ID)
{
List<Article> oList = new List<Article>();
Article oArticle = new Article();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Article_By_TEACHER_ID_Adv");}
#region Body Section.
List<DALC.Article> oList_DBEntries = _AppContext.Get_Article_By_TEACHER_ID_Adv(i_Params_Get_Article_By_TEACHER_ID.TEACHER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oArticle = new Article();
oTools.CopyPropValues(oDBEntry, oArticle);

oArticle.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oArticle.My_Teacher);

oArticle.My_Category = new Category();
oTools.CopyPropValues(oDBEntry.My_Category, oArticle.My_Category);

oList.Add(oArticle);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Article_By_TEACHER_ID_Adv");}
return oList;
}
public List<Article> Get_Article_By_CATEGORY_ID_Adv(Params_Get_Article_By_CATEGORY_ID i_Params_Get_Article_By_CATEGORY_ID)
{
List<Article> oList = new List<Article>();
Article oArticle = new Article();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Article_By_CATEGORY_ID_Adv");}
#region Body Section.
List<DALC.Article> oList_DBEntries = _AppContext.Get_Article_By_CATEGORY_ID_Adv(i_Params_Get_Article_By_CATEGORY_ID.CATEGORY_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oArticle = new Article();
oTools.CopyPropValues(oDBEntry, oArticle);

oArticle.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oArticle.My_Teacher);

oArticle.My_Category = new Category();
oTools.CopyPropValues(oDBEntry.My_Category, oArticle.My_Category);

oList.Add(oArticle);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Article_By_CATEGORY_ID_Adv");}
return oList;
}
public List<Answer> Get_Answer_By_OWNER_ID_Adv(Params_Get_Answer_By_OWNER_ID i_Params_Get_Answer_By_OWNER_ID)
{
List<Answer> oList = new List<Answer>();
Answer oAnswer = new Answer();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Answer_By_OWNER_ID_Adv");}
#region Body Section.
List<DALC.Answer> oList_DBEntries = _AppContext.Get_Answer_By_OWNER_ID_Adv(i_Params_Get_Answer_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oAnswer = new Answer();
oTools.CopyPropValues(oDBEntry, oAnswer);

oAnswer.My_Question = new Question();
oTools.CopyPropValues(oDBEntry.My_Question, oAnswer.My_Question);

oAnswer.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oAnswer.My_Teacher);

oList.Add(oAnswer);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Answer_By_OWNER_ID_Adv");}
return oList;
}
public List<Answer> Get_Answer_By_QUESTION_ID_Adv(Params_Get_Answer_By_QUESTION_ID i_Params_Get_Answer_By_QUESTION_ID)
{
List<Answer> oList = new List<Answer>();
Answer oAnswer = new Answer();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Answer_By_QUESTION_ID_Adv");}
#region Body Section.
List<DALC.Answer> oList_DBEntries = _AppContext.Get_Answer_By_QUESTION_ID_Adv(i_Params_Get_Answer_By_QUESTION_ID.QUESTION_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oAnswer = new Answer();
oTools.CopyPropValues(oDBEntry, oAnswer);

oAnswer.My_Question = new Question();
oTools.CopyPropValues(oDBEntry.My_Question, oAnswer.My_Question);

oAnswer.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oAnswer.My_Teacher);

oList.Add(oAnswer);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Answer_By_QUESTION_ID_Adv");}
return oList;
}
public List<Answer> Get_Answer_By_TEACHER_ID_Adv(Params_Get_Answer_By_TEACHER_ID i_Params_Get_Answer_By_TEACHER_ID)
{
List<Answer> oList = new List<Answer>();
Answer oAnswer = new Answer();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Answer_By_TEACHER_ID_Adv");}
#region Body Section.
List<DALC.Answer> oList_DBEntries = _AppContext.Get_Answer_By_TEACHER_ID_Adv(i_Params_Get_Answer_By_TEACHER_ID.TEACHER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oAnswer = new Answer();
oTools.CopyPropValues(oDBEntry, oAnswer);

oAnswer.My_Question = new Question();
oTools.CopyPropValues(oDBEntry.My_Question, oAnswer.My_Question);

oAnswer.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oAnswer.My_Teacher);

oList.Add(oAnswer);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Answer_By_TEACHER_ID_Adv");}
return oList;
}
public List<Student> Get_Student_By_OWNER_ID_Adv(Params_Get_Student_By_OWNER_ID i_Params_Get_Student_By_OWNER_ID)
{
List<Student> oList = new List<Student>();
Student oStudent = new Student();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Student_By_OWNER_ID_Adv");}
#region Body Section.
List<DALC.Student> oList_DBEntries = _AppContext.Get_Student_By_OWNER_ID_Adv(i_Params_Get_Student_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oStudent = new Student();
oTools.CopyPropValues(oDBEntry, oStudent);

oStudent.My_User = new User();
oTools.CopyPropValues(oDBEntry.My_User, oStudent.My_User);

oList.Add(oStudent);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Student_By_OWNER_ID_Adv");}
return oList;
}
public List<Student> Get_Student_By_USER_ID_Adv(Params_Get_Student_By_USER_ID i_Params_Get_Student_By_USER_ID)
{
List<Student> oList = new List<Student>();
Student oStudent = new Student();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Student_By_USER_ID_Adv");}
#region Body Section.
List<DALC.Student> oList_DBEntries = _AppContext.Get_Student_By_USER_ID_Adv(i_Params_Get_Student_By_USER_ID.USER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oStudent = new Student();
oTools.CopyPropValues(oDBEntry, oStudent);

oStudent.My_User = new User();
oTools.CopyPropValues(oDBEntry.My_User, oStudent.My_User);

oList.Add(oStudent);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Student_By_USER_ID_Adv");}
return oList;
}
public List<Notification> Get_Notification_By_OWNER_ID_Adv(Params_Get_Notification_By_OWNER_ID i_Params_Get_Notification_By_OWNER_ID)
{
List<Notification> oList = new List<Notification>();
Notification oNotification = new Notification();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Notification_By_OWNER_ID_Adv");}
#region Body Section.
List<DALC.Notification> oList_DBEntries = _AppContext.Get_Notification_By_OWNER_ID_Adv(i_Params_Get_Notification_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oNotification = new Notification();
oTools.CopyPropValues(oDBEntry, oNotification);

oNotification.My_User = new User();
oTools.CopyPropValues(oDBEntry.My_User, oNotification.My_User);

oNotification.My_Question = new Question();
oTools.CopyPropValues(oDBEntry.My_Question, oNotification.My_Question);

oNotification.My_Answer = new Answer();
oTools.CopyPropValues(oDBEntry.My_Answer, oNotification.My_Answer);

oNotification.My_Article = new Article();
oTools.CopyPropValues(oDBEntry.My_Article, oNotification.My_Article);

oList.Add(oNotification);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Notification_By_OWNER_ID_Adv");}
return oList;
}
public List<Notification> Get_Notification_By_USER_ID_Adv(Params_Get_Notification_By_USER_ID i_Params_Get_Notification_By_USER_ID)
{
List<Notification> oList = new List<Notification>();
Notification oNotification = new Notification();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Notification_By_USER_ID_Adv");}
#region Body Section.
List<DALC.Notification> oList_DBEntries = _AppContext.Get_Notification_By_USER_ID_Adv(i_Params_Get_Notification_By_USER_ID.USER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oNotification = new Notification();
oTools.CopyPropValues(oDBEntry, oNotification);

oNotification.My_User = new User();
oTools.CopyPropValues(oDBEntry.My_User, oNotification.My_User);

oNotification.My_Question = new Question();
oTools.CopyPropValues(oDBEntry.My_Question, oNotification.My_Question);

oNotification.My_Answer = new Answer();
oTools.CopyPropValues(oDBEntry.My_Answer, oNotification.My_Answer);

oNotification.My_Article = new Article();
oTools.CopyPropValues(oDBEntry.My_Article, oNotification.My_Article);

oList.Add(oNotification);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Notification_By_USER_ID_Adv");}
return oList;
}
public List<Notification> Get_Notification_By_QUESTION_ID_Adv(Params_Get_Notification_By_QUESTION_ID i_Params_Get_Notification_By_QUESTION_ID)
{
List<Notification> oList = new List<Notification>();
Notification oNotification = new Notification();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Notification_By_QUESTION_ID_Adv");}
#region Body Section.
List<DALC.Notification> oList_DBEntries = _AppContext.Get_Notification_By_QUESTION_ID_Adv(i_Params_Get_Notification_By_QUESTION_ID.QUESTION_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oNotification = new Notification();
oTools.CopyPropValues(oDBEntry, oNotification);

oNotification.My_User = new User();
oTools.CopyPropValues(oDBEntry.My_User, oNotification.My_User);

oNotification.My_Question = new Question();
oTools.CopyPropValues(oDBEntry.My_Question, oNotification.My_Question);

oNotification.My_Answer = new Answer();
oTools.CopyPropValues(oDBEntry.My_Answer, oNotification.My_Answer);

oNotification.My_Article = new Article();
oTools.CopyPropValues(oDBEntry.My_Article, oNotification.My_Article);

oList.Add(oNotification);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Notification_By_QUESTION_ID_Adv");}
return oList;
}
public List<Notification> Get_Notification_By_ANSWER_ID_Adv(Params_Get_Notification_By_ANSWER_ID i_Params_Get_Notification_By_ANSWER_ID)
{
List<Notification> oList = new List<Notification>();
Notification oNotification = new Notification();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Notification_By_ANSWER_ID_Adv");}
#region Body Section.
List<DALC.Notification> oList_DBEntries = _AppContext.Get_Notification_By_ANSWER_ID_Adv(i_Params_Get_Notification_By_ANSWER_ID.ANSWER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oNotification = new Notification();
oTools.CopyPropValues(oDBEntry, oNotification);

oNotification.My_User = new User();
oTools.CopyPropValues(oDBEntry.My_User, oNotification.My_User);

oNotification.My_Question = new Question();
oTools.CopyPropValues(oDBEntry.My_Question, oNotification.My_Question);

oNotification.My_Answer = new Answer();
oTools.CopyPropValues(oDBEntry.My_Answer, oNotification.My_Answer);

oNotification.My_Article = new Article();
oTools.CopyPropValues(oDBEntry.My_Article, oNotification.My_Article);

oList.Add(oNotification);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Notification_By_ANSWER_ID_Adv");}
return oList;
}
public List<Notification> Get_Notification_By_ARTICLE_ID_Adv(Params_Get_Notification_By_ARTICLE_ID i_Params_Get_Notification_By_ARTICLE_ID)
{
List<Notification> oList = new List<Notification>();
Notification oNotification = new Notification();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Notification_By_ARTICLE_ID_Adv");}
#region Body Section.
List<DALC.Notification> oList_DBEntries = _AppContext.Get_Notification_By_ARTICLE_ID_Adv(i_Params_Get_Notification_By_ARTICLE_ID.ARTICLE_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oNotification = new Notification();
oTools.CopyPropValues(oDBEntry, oNotification);

oNotification.My_User = new User();
oTools.CopyPropValues(oDBEntry.My_User, oNotification.My_User);

oNotification.My_Question = new Question();
oTools.CopyPropValues(oDBEntry.My_Question, oNotification.My_Question);

oNotification.My_Answer = new Answer();
oTools.CopyPropValues(oDBEntry.My_Answer, oNotification.My_Answer);

oNotification.My_Article = new Article();
oTools.CopyPropValues(oDBEntry.My_Article, oNotification.My_Article);

oList.Add(oNotification);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Notification_By_ARTICLE_ID_Adv");}
return oList;
}
public List<User> Get_User_By_OWNER_ID_Adv(Params_Get_User_By_OWNER_ID i_Params_Get_User_By_OWNER_ID)
{
List<User> oList = new List<User>();
User oUser = new User();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_User_By_OWNER_ID_Adv");}
#region Body Section.
List<DALC.User> oList_DBEntries = _AppContext.Get_User_By_OWNER_ID_Adv(i_Params_Get_User_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oUser = new User();
oTools.CopyPropValues(oDBEntry, oUser);

oList.Add(oUser);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_User_By_OWNER_ID_Adv");}
return oList;
}
public List<User> Get_User_By_USERNAME_Adv(Params_Get_User_By_USERNAME i_Params_Get_User_By_USERNAME)
{
List<User> oList = new List<User>();
User oUser = new User();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_User_By_USERNAME_Adv");}
#region Body Section.
List<DALC.User> oList_DBEntries = _AppContext.Get_User_By_USERNAME_Adv(i_Params_Get_User_By_USERNAME.USERNAME);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oUser = new User();
oTools.CopyPropValues(oDBEntry, oUser);

oList.Add(oUser);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_User_By_USERNAME_Adv");}
return oList;
}
public List<Evaluation> Get_Evaluation_By_OWNER_ID_Adv(Params_Get_Evaluation_By_OWNER_ID i_Params_Get_Evaluation_By_OWNER_ID)
{
List<Evaluation> oList = new List<Evaluation>();
Evaluation oEvaluation = new Evaluation();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Evaluation_By_OWNER_ID_Adv");}
#region Body Section.
List<DALC.Evaluation> oList_DBEntries = _AppContext.Get_Evaluation_By_OWNER_ID_Adv(i_Params_Get_Evaluation_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oEvaluation = new Evaluation();
oTools.CopyPropValues(oDBEntry, oEvaluation);

oEvaluation.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oEvaluation.My_Student);

oEvaluation.My_Answer = new Answer();
oTools.CopyPropValues(oDBEntry.My_Answer, oEvaluation.My_Answer);

oList.Add(oEvaluation);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Evaluation_By_OWNER_ID_Adv");}
return oList;
}
public List<Evaluation> Get_Evaluation_By_STUDENT_ID_Adv(Params_Get_Evaluation_By_STUDENT_ID i_Params_Get_Evaluation_By_STUDENT_ID)
{
List<Evaluation> oList = new List<Evaluation>();
Evaluation oEvaluation = new Evaluation();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Evaluation_By_STUDENT_ID_Adv");}
#region Body Section.
List<DALC.Evaluation> oList_DBEntries = _AppContext.Get_Evaluation_By_STUDENT_ID_Adv(i_Params_Get_Evaluation_By_STUDENT_ID.STUDENT_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oEvaluation = new Evaluation();
oTools.CopyPropValues(oDBEntry, oEvaluation);

oEvaluation.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oEvaluation.My_Student);

oEvaluation.My_Answer = new Answer();
oTools.CopyPropValues(oDBEntry.My_Answer, oEvaluation.My_Answer);

oList.Add(oEvaluation);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Evaluation_By_STUDENT_ID_Adv");}
return oList;
}
public List<Evaluation> Get_Evaluation_By_ANSWER_ID_Adv(Params_Get_Evaluation_By_ANSWER_ID i_Params_Get_Evaluation_By_ANSWER_ID)
{
List<Evaluation> oList = new List<Evaluation>();
Evaluation oEvaluation = new Evaluation();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Evaluation_By_ANSWER_ID_Adv");}
#region Body Section.
List<DALC.Evaluation> oList_DBEntries = _AppContext.Get_Evaluation_By_ANSWER_ID_Adv(i_Params_Get_Evaluation_By_ANSWER_ID.ANSWER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oEvaluation = new Evaluation();
oTools.CopyPropValues(oDBEntry, oEvaluation);

oEvaluation.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oEvaluation.My_Student);

oEvaluation.My_Answer = new Answer();
oTools.CopyPropValues(oDBEntry.My_Answer, oEvaluation.My_Answer);

oList.Add(oEvaluation);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Evaluation_By_ANSWER_ID_Adv");}
return oList;
}
public List<Student_report> Get_Student_report_By_OWNER_ID_Adv(Params_Get_Student_report_By_OWNER_ID i_Params_Get_Student_report_By_OWNER_ID)
{
List<Student_report> oList = new List<Student_report>();
Student_report oStudent_report = new Student_report();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Student_report_By_OWNER_ID_Adv");}
#region Body Section.
List<DALC.Student_report> oList_DBEntries = _AppContext.Get_Student_report_By_OWNER_ID_Adv(i_Params_Get_Student_report_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oStudent_report = new Student_report();
oTools.CopyPropValues(oDBEntry, oStudent_report);

oStudent_report.My_Reported_by_student = new Student();
oTools.CopyPropValues(oDBEntry.My_Reported_by_student, oStudent_report.My_Reported_by_student);

oStudent_report.My_Reported_student = new Student();
oTools.CopyPropValues(oDBEntry.My_Reported_student, oStudent_report.My_Reported_student);

oList.Add(oStudent_report);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Student_report_By_OWNER_ID_Adv");}
return oList;
}
public List<Student_report> Get_Student_report_By_REPORTED_BY_STUDENT_ID_Adv(Params_Get_Student_report_By_REPORTED_BY_STUDENT_ID i_Params_Get_Student_report_By_REPORTED_BY_STUDENT_ID)
{
List<Student_report> oList = new List<Student_report>();
Student_report oStudent_report = new Student_report();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Student_report_By_REPORTED_BY_STUDENT_ID_Adv");}
#region Body Section.
List<DALC.Student_report> oList_DBEntries = _AppContext.Get_Student_report_By_REPORTED_BY_STUDENT_ID_Adv(i_Params_Get_Student_report_By_REPORTED_BY_STUDENT_ID.REPORTED_BY_STUDENT_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oStudent_report = new Student_report();
oTools.CopyPropValues(oDBEntry, oStudent_report);

oStudent_report.My_Reported_by_student = new Student();
oTools.CopyPropValues(oDBEntry.My_Reported_by_student, oStudent_report.My_Reported_by_student);

oStudent_report.My_Reported_student = new Student();
oTools.CopyPropValues(oDBEntry.My_Reported_student, oStudent_report.My_Reported_student);

oList.Add(oStudent_report);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Student_report_By_REPORTED_BY_STUDENT_ID_Adv");}
return oList;
}
public List<Student_report> Get_Student_report_By_REPORTED_STUDENT_ID_Adv(Params_Get_Student_report_By_REPORTED_STUDENT_ID i_Params_Get_Student_report_By_REPORTED_STUDENT_ID)
{
List<Student_report> oList = new List<Student_report>();
Student_report oStudent_report = new Student_report();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Student_report_By_REPORTED_STUDENT_ID_Adv");}
#region Body Section.
List<DALC.Student_report> oList_DBEntries = _AppContext.Get_Student_report_By_REPORTED_STUDENT_ID_Adv(i_Params_Get_Student_report_By_REPORTED_STUDENT_ID.REPORTED_STUDENT_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oStudent_report = new Student_report();
oTools.CopyPropValues(oDBEntry, oStudent_report);

oStudent_report.My_Reported_by_student = new Student();
oTools.CopyPropValues(oDBEntry.My_Reported_by_student, oStudent_report.My_Reported_by_student);

oStudent_report.My_Reported_student = new Student();
oTools.CopyPropValues(oDBEntry.My_Reported_student, oStudent_report.My_Reported_student);

oList.Add(oStudent_report);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Student_report_By_REPORTED_STUDENT_ID_Adv");}
return oList;
}
public List<Appreciate> Get_Appreciate_By_OWNER_ID_Adv(Params_Get_Appreciate_By_OWNER_ID i_Params_Get_Appreciate_By_OWNER_ID)
{
List<Appreciate> oList = new List<Appreciate>();
Appreciate oAppreciate = new Appreciate();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Appreciate_By_OWNER_ID_Adv");}
#region Body Section.
List<DALC.Appreciate> oList_DBEntries = _AppContext.Get_Appreciate_By_OWNER_ID_Adv(i_Params_Get_Appreciate_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oAppreciate = new Appreciate();
oTools.CopyPropValues(oDBEntry, oAppreciate);

oAppreciate.My_Article = new Article();
oTools.CopyPropValues(oDBEntry.My_Article, oAppreciate.My_Article);

oAppreciate.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oAppreciate.My_Student);

oList.Add(oAppreciate);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Appreciate_By_OWNER_ID_Adv");}
return oList;
}
public List<Appreciate> Get_Appreciate_By_ARTICLE_ID_Adv(Params_Get_Appreciate_By_ARTICLE_ID i_Params_Get_Appreciate_By_ARTICLE_ID)
{
List<Appreciate> oList = new List<Appreciate>();
Appreciate oAppreciate = new Appreciate();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Appreciate_By_ARTICLE_ID_Adv");}
#region Body Section.
List<DALC.Appreciate> oList_DBEntries = _AppContext.Get_Appreciate_By_ARTICLE_ID_Adv(i_Params_Get_Appreciate_By_ARTICLE_ID.ARTICLE_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oAppreciate = new Appreciate();
oTools.CopyPropValues(oDBEntry, oAppreciate);

oAppreciate.My_Article = new Article();
oTools.CopyPropValues(oDBEntry.My_Article, oAppreciate.My_Article);

oAppreciate.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oAppreciate.My_Student);

oList.Add(oAppreciate);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Appreciate_By_ARTICLE_ID_Adv");}
return oList;
}
public List<Appreciate> Get_Appreciate_By_STUDENT_ID_Adv(Params_Get_Appreciate_By_STUDENT_ID i_Params_Get_Appreciate_By_STUDENT_ID)
{
List<Appreciate> oList = new List<Appreciate>();
Appreciate oAppreciate = new Appreciate();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Appreciate_By_STUDENT_ID_Adv");}
#region Body Section.
List<DALC.Appreciate> oList_DBEntries = _AppContext.Get_Appreciate_By_STUDENT_ID_Adv(i_Params_Get_Appreciate_By_STUDENT_ID.STUDENT_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oAppreciate = new Appreciate();
oTools.CopyPropValues(oDBEntry, oAppreciate);

oAppreciate.My_Article = new Article();
oTools.CopyPropValues(oDBEntry.My_Article, oAppreciate.My_Article);

oAppreciate.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oAppreciate.My_Student);

oList.Add(oAppreciate);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Appreciate_By_STUDENT_ID_Adv");}
return oList;
}
public List<Appreciate> Get_Appreciate_By_ARTICLE_ID_STUDENT_ID_Adv(Params_Get_Appreciate_By_ARTICLE_ID_STUDENT_ID i_Params_Get_Appreciate_By_ARTICLE_ID_STUDENT_ID)
{
List<Appreciate> oList = new List<Appreciate>();
Appreciate oAppreciate = new Appreciate();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Appreciate_By_ARTICLE_ID_STUDENT_ID_Adv");}
#region Body Section.
List<DALC.Appreciate> oList_DBEntries = _AppContext.Get_Appreciate_By_ARTICLE_ID_STUDENT_ID_Adv(i_Params_Get_Appreciate_By_ARTICLE_ID_STUDENT_ID.ARTICLE_ID,i_Params_Get_Appreciate_By_ARTICLE_ID_STUDENT_ID.STUDENT_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oAppreciate = new Appreciate();
oTools.CopyPropValues(oDBEntry, oAppreciate);

oAppreciate.My_Article = new Article();
oTools.CopyPropValues(oDBEntry.My_Article, oAppreciate.My_Article);

oAppreciate.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oAppreciate.My_Student);

oList.Add(oAppreciate);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Appreciate_By_ARTICLE_ID_STUDENT_ID_Adv");}
return oList;
}
public List<Teacher_report> Get_Teacher_report_By_OWNER_ID_Adv(Params_Get_Teacher_report_By_OWNER_ID i_Params_Get_Teacher_report_By_OWNER_ID)
{
List<Teacher_report> oList = new List<Teacher_report>();
Teacher_report oTeacher_report = new Teacher_report();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_report_By_OWNER_ID_Adv");}
#region Body Section.
List<DALC.Teacher_report> oList_DBEntries = _AppContext.Get_Teacher_report_By_OWNER_ID_Adv(i_Params_Get_Teacher_report_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_report = new Teacher_report();
oTools.CopyPropValues(oDBEntry, oTeacher_report);

oTeacher_report.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oTeacher_report.My_Teacher);

oTeacher_report.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oTeacher_report.My_Student);

oList.Add(oTeacher_report);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_report_By_OWNER_ID_Adv");}
return oList;
}
public List<Teacher_report> Get_Teacher_report_By_TEACHER_ID_Adv(Params_Get_Teacher_report_By_TEACHER_ID i_Params_Get_Teacher_report_By_TEACHER_ID)
{
List<Teacher_report> oList = new List<Teacher_report>();
Teacher_report oTeacher_report = new Teacher_report();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_report_By_TEACHER_ID_Adv");}
#region Body Section.
List<DALC.Teacher_report> oList_DBEntries = _AppContext.Get_Teacher_report_By_TEACHER_ID_Adv(i_Params_Get_Teacher_report_By_TEACHER_ID.TEACHER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_report = new Teacher_report();
oTools.CopyPropValues(oDBEntry, oTeacher_report);

oTeacher_report.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oTeacher_report.My_Teacher);

oTeacher_report.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oTeacher_report.My_Student);

oList.Add(oTeacher_report);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_report_By_TEACHER_ID_Adv");}
return oList;
}
public List<Teacher_report> Get_Teacher_report_By_STUDENT_ID_Adv(Params_Get_Teacher_report_By_STUDENT_ID i_Params_Get_Teacher_report_By_STUDENT_ID)
{
List<Teacher_report> oList = new List<Teacher_report>();
Teacher_report oTeacher_report = new Teacher_report();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_report_By_STUDENT_ID_Adv");}
#region Body Section.
List<DALC.Teacher_report> oList_DBEntries = _AppContext.Get_Teacher_report_By_STUDENT_ID_Adv(i_Params_Get_Teacher_report_By_STUDENT_ID.STUDENT_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_report = new Teacher_report();
oTools.CopyPropValues(oDBEntry, oTeacher_report);

oTeacher_report.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oTeacher_report.My_Teacher);

oTeacher_report.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oTeacher_report.My_Student);

oList.Add(oTeacher_report);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_report_By_STUDENT_ID_Adv");}
return oList;
}
public List<Question_report> Get_Question_report_By_OWNER_ID_Adv(Params_Get_Question_report_By_OWNER_ID i_Params_Get_Question_report_By_OWNER_ID)
{
List<Question_report> oList = new List<Question_report>();
Question_report oQuestion_report = new Question_report();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Question_report_By_OWNER_ID_Adv");}
#region Body Section.
List<DALC.Question_report> oList_DBEntries = _AppContext.Get_Question_report_By_OWNER_ID_Adv(i_Params_Get_Question_report_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oQuestion_report = new Question_report();
oTools.CopyPropValues(oDBEntry, oQuestion_report);

oQuestion_report.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oQuestion_report.My_Student);

oQuestion_report.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oQuestion_report.My_Teacher);

oQuestion_report.My_Question = new Question();
oTools.CopyPropValues(oDBEntry.My_Question, oQuestion_report.My_Question);

oList.Add(oQuestion_report);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Question_report_By_OWNER_ID_Adv");}
return oList;
}
public List<Question_report> Get_Question_report_By_STUDENT_ID_Adv(Params_Get_Question_report_By_STUDENT_ID i_Params_Get_Question_report_By_STUDENT_ID)
{
List<Question_report> oList = new List<Question_report>();
Question_report oQuestion_report = new Question_report();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Question_report_By_STUDENT_ID_Adv");}
#region Body Section.
List<DALC.Question_report> oList_DBEntries = _AppContext.Get_Question_report_By_STUDENT_ID_Adv(i_Params_Get_Question_report_By_STUDENT_ID.STUDENT_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oQuestion_report = new Question_report();
oTools.CopyPropValues(oDBEntry, oQuestion_report);

oQuestion_report.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oQuestion_report.My_Student);

oQuestion_report.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oQuestion_report.My_Teacher);

oQuestion_report.My_Question = new Question();
oTools.CopyPropValues(oDBEntry.My_Question, oQuestion_report.My_Question);

oList.Add(oQuestion_report);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Question_report_By_STUDENT_ID_Adv");}
return oList;
}
public List<Question_report> Get_Question_report_By_TEACHER_ID_Adv(Params_Get_Question_report_By_TEACHER_ID i_Params_Get_Question_report_By_TEACHER_ID)
{
List<Question_report> oList = new List<Question_report>();
Question_report oQuestion_report = new Question_report();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Question_report_By_TEACHER_ID_Adv");}
#region Body Section.
List<DALC.Question_report> oList_DBEntries = _AppContext.Get_Question_report_By_TEACHER_ID_Adv(i_Params_Get_Question_report_By_TEACHER_ID.TEACHER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oQuestion_report = new Question_report();
oTools.CopyPropValues(oDBEntry, oQuestion_report);

oQuestion_report.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oQuestion_report.My_Student);

oQuestion_report.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oQuestion_report.My_Teacher);

oQuestion_report.My_Question = new Question();
oTools.CopyPropValues(oDBEntry.My_Question, oQuestion_report.My_Question);

oList.Add(oQuestion_report);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Question_report_By_TEACHER_ID_Adv");}
return oList;
}
public List<Question_report> Get_Question_report_By_QUESTION_ID_Adv(Params_Get_Question_report_By_QUESTION_ID i_Params_Get_Question_report_By_QUESTION_ID)
{
List<Question_report> oList = new List<Question_report>();
Question_report oQuestion_report = new Question_report();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Question_report_By_QUESTION_ID_Adv");}
#region Body Section.
List<DALC.Question_report> oList_DBEntries = _AppContext.Get_Question_report_By_QUESTION_ID_Adv(i_Params_Get_Question_report_By_QUESTION_ID.QUESTION_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oQuestion_report = new Question_report();
oTools.CopyPropValues(oDBEntry, oQuestion_report);

oQuestion_report.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oQuestion_report.My_Student);

oQuestion_report.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oQuestion_report.My_Teacher);

oQuestion_report.My_Question = new Question();
oTools.CopyPropValues(oDBEntry.My_Question, oQuestion_report.My_Question);

oList.Add(oQuestion_report);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Question_report_By_QUESTION_ID_Adv");}
return oList;
}
public List<Answer_report> Get_Answer_report_By_OWNER_ID_Adv(Params_Get_Answer_report_By_OWNER_ID i_Params_Get_Answer_report_By_OWNER_ID)
{
List<Answer_report> oList = new List<Answer_report>();
Answer_report oAnswer_report = new Answer_report();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Answer_report_By_OWNER_ID_Adv");}
#region Body Section.
List<DALC.Answer_report> oList_DBEntries = _AppContext.Get_Answer_report_By_OWNER_ID_Adv(i_Params_Get_Answer_report_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oAnswer_report = new Answer_report();
oTools.CopyPropValues(oDBEntry, oAnswer_report);

oAnswer_report.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oAnswer_report.My_Teacher);

oAnswer_report.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oAnswer_report.My_Student);

oAnswer_report.My_Answer = new Answer();
oTools.CopyPropValues(oDBEntry.My_Answer, oAnswer_report.My_Answer);

oList.Add(oAnswer_report);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Answer_report_By_OWNER_ID_Adv");}
return oList;
}
public List<Answer_report> Get_Answer_report_By_TEACHER_ID_Adv(Params_Get_Answer_report_By_TEACHER_ID i_Params_Get_Answer_report_By_TEACHER_ID)
{
List<Answer_report> oList = new List<Answer_report>();
Answer_report oAnswer_report = new Answer_report();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Answer_report_By_TEACHER_ID_Adv");}
#region Body Section.
List<DALC.Answer_report> oList_DBEntries = _AppContext.Get_Answer_report_By_TEACHER_ID_Adv(i_Params_Get_Answer_report_By_TEACHER_ID.TEACHER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oAnswer_report = new Answer_report();
oTools.CopyPropValues(oDBEntry, oAnswer_report);

oAnswer_report.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oAnswer_report.My_Teacher);

oAnswer_report.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oAnswer_report.My_Student);

oAnswer_report.My_Answer = new Answer();
oTools.CopyPropValues(oDBEntry.My_Answer, oAnswer_report.My_Answer);

oList.Add(oAnswer_report);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Answer_report_By_TEACHER_ID_Adv");}
return oList;
}
public List<Answer_report> Get_Answer_report_By_STUDENT_ID_Adv(Params_Get_Answer_report_By_STUDENT_ID i_Params_Get_Answer_report_By_STUDENT_ID)
{
List<Answer_report> oList = new List<Answer_report>();
Answer_report oAnswer_report = new Answer_report();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Answer_report_By_STUDENT_ID_Adv");}
#region Body Section.
List<DALC.Answer_report> oList_DBEntries = _AppContext.Get_Answer_report_By_STUDENT_ID_Adv(i_Params_Get_Answer_report_By_STUDENT_ID.STUDENT_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oAnswer_report = new Answer_report();
oTools.CopyPropValues(oDBEntry, oAnswer_report);

oAnswer_report.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oAnswer_report.My_Teacher);

oAnswer_report.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oAnswer_report.My_Student);

oAnswer_report.My_Answer = new Answer();
oTools.CopyPropValues(oDBEntry.My_Answer, oAnswer_report.My_Answer);

oList.Add(oAnswer_report);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Answer_report_By_STUDENT_ID_Adv");}
return oList;
}
public List<Answer_report> Get_Answer_report_By_ANSWER_ID_Adv(Params_Get_Answer_report_By_ANSWER_ID i_Params_Get_Answer_report_By_ANSWER_ID)
{
List<Answer_report> oList = new List<Answer_report>();
Answer_report oAnswer_report = new Answer_report();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Answer_report_By_ANSWER_ID_Adv");}
#region Body Section.
List<DALC.Answer_report> oList_DBEntries = _AppContext.Get_Answer_report_By_ANSWER_ID_Adv(i_Params_Get_Answer_report_By_ANSWER_ID.ANSWER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oAnswer_report = new Answer_report();
oTools.CopyPropValues(oDBEntry, oAnswer_report);

oAnswer_report.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oAnswer_report.My_Teacher);

oAnswer_report.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oAnswer_report.My_Student);

oAnswer_report.My_Answer = new Answer();
oTools.CopyPropValues(oDBEntry.My_Answer, oAnswer_report.My_Answer);

oList.Add(oAnswer_report);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Answer_report_By_ANSWER_ID_Adv");}
return oList;
}
public List<Teacher_rank> Get_Teacher_rank_By_TEACHER_ID_Adv(Params_Get_Teacher_rank_By_TEACHER_ID i_Params_Get_Teacher_rank_By_TEACHER_ID)
{
List<Teacher_rank> oList = new List<Teacher_rank>();
Teacher_rank oTeacher_rank = new Teacher_rank();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_rank_By_TEACHER_ID_Adv");}
#region Body Section.
List<DALC.Teacher_rank> oList_DBEntries = _AppContext.Get_Teacher_rank_By_TEACHER_ID_Adv(i_Params_Get_Teacher_rank_By_TEACHER_ID.TEACHER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_rank = new Teacher_rank();
oTools.CopyPropValues(oDBEntry, oTeacher_rank);

oTeacher_rank.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oTeacher_rank.My_Teacher);

oList.Add(oTeacher_rank);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_rank_By_TEACHER_ID_Adv");}
return oList;
}
public List<Teacher_rank> Get_Teacher_rank_By_OWNER_ID_Adv(Params_Get_Teacher_rank_By_OWNER_ID i_Params_Get_Teacher_rank_By_OWNER_ID)
{
List<Teacher_rank> oList = new List<Teacher_rank>();
Teacher_rank oTeacher_rank = new Teacher_rank();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_rank_By_OWNER_ID_Adv");}
#region Body Section.
List<DALC.Teacher_rank> oList_DBEntries = _AppContext.Get_Teacher_rank_By_OWNER_ID_Adv(i_Params_Get_Teacher_rank_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_rank = new Teacher_rank();
oTools.CopyPropValues(oDBEntry, oTeacher_rank);

oTeacher_rank.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oTeacher_rank.My_Teacher);

oList.Add(oTeacher_rank);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_rank_By_OWNER_ID_Adv");}
return oList;
}
public List<Teacher> Get_Teacher_By_OWNER_ID_Adv(Params_Get_Teacher_By_OWNER_ID i_Params_Get_Teacher_By_OWNER_ID)
{
List<Teacher> oList = new List<Teacher>();
Teacher oTeacher = new Teacher();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_By_OWNER_ID_Adv");}
#region Body Section.
List<DALC.Teacher> oList_DBEntries = _AppContext.Get_Teacher_By_OWNER_ID_Adv(i_Params_Get_Teacher_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher = new Teacher();
oTools.CopyPropValues(oDBEntry, oTeacher);

oTeacher.My_User = new User();
oTools.CopyPropValues(oDBEntry.My_User, oTeacher.My_User);

oList.Add(oTeacher);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_By_OWNER_ID_Adv");}
return oList;
}
public List<Teacher> Get_Teacher_By_USER_ID_Adv(Params_Get_Teacher_By_USER_ID i_Params_Get_Teacher_By_USER_ID)
{
List<Teacher> oList = new List<Teacher>();
Teacher oTeacher = new Teacher();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_By_USER_ID_Adv");}
#region Body Section.
List<DALC.Teacher> oList_DBEntries = _AppContext.Get_Teacher_By_USER_ID_Adv(i_Params_Get_Teacher_By_USER_ID.USER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher = new Teacher();
oTools.CopyPropValues(oDBEntry, oTeacher);

oTeacher.My_User = new User();
oTools.CopyPropValues(oDBEntry.My_User, oTeacher.My_User);

oList.Add(oTeacher);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_By_USER_ID_Adv");}
return oList;
}
public List<Question_token> Get_Question_token_By_PART_Adv(Params_Get_Question_token_By_PART i_Params_Get_Question_token_By_PART)
{
List<Question_token> oList = new List<Question_token>();
Question_token oQuestion_token = new Question_token();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Question_token_By_PART_Adv");}
#region Body Section.
List<DALC.Question_token> oList_DBEntries = _AppContext.Get_Question_token_By_PART_Adv(i_Params_Get_Question_token_By_PART.PART);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oQuestion_token = new Question_token();
oTools.CopyPropValues(oDBEntry, oQuestion_token);

oQuestion_token.My_Question = new Question();
oTools.CopyPropValues(oDBEntry.My_Question, oQuestion_token.My_Question);

oList.Add(oQuestion_token);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Question_token_By_PART_Adv");}
return oList;
}
public List<Question_token> Get_Question_token_By_OWNER_ID_Adv(Params_Get_Question_token_By_OWNER_ID i_Params_Get_Question_token_By_OWNER_ID)
{
List<Question_token> oList = new List<Question_token>();
Question_token oQuestion_token = new Question_token();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Question_token_By_OWNER_ID_Adv");}
#region Body Section.
List<DALC.Question_token> oList_DBEntries = _AppContext.Get_Question_token_By_OWNER_ID_Adv(i_Params_Get_Question_token_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oQuestion_token = new Question_token();
oTools.CopyPropValues(oDBEntry, oQuestion_token);

oQuestion_token.My_Question = new Question();
oTools.CopyPropValues(oDBEntry.My_Question, oQuestion_token.My_Question);

oList.Add(oQuestion_token);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Question_token_By_OWNER_ID_Adv");}
return oList;
}
public List<Question_token> Get_Question_token_By_QUESTION_ID_Adv(Params_Get_Question_token_By_QUESTION_ID i_Params_Get_Question_token_By_QUESTION_ID)
{
List<Question_token> oList = new List<Question_token>();
Question_token oQuestion_token = new Question_token();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Question_token_By_QUESTION_ID_Adv");}
#region Body Section.
List<DALC.Question_token> oList_DBEntries = _AppContext.Get_Question_token_By_QUESTION_ID_Adv(i_Params_Get_Question_token_By_QUESTION_ID.QUESTION_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oQuestion_token = new Question_token();
oTools.CopyPropValues(oDBEntry, oQuestion_token);

oQuestion_token.My_Question = new Question();
oTools.CopyPropValues(oDBEntry.My_Question, oQuestion_token.My_Question);

oList.Add(oQuestion_token);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Question_token_By_QUESTION_ID_Adv");}
return oList;
}
public List<Teacher_category> Get_Teacher_category_By_OWNER_ID_Adv(Params_Get_Teacher_category_By_OWNER_ID i_Params_Get_Teacher_category_By_OWNER_ID)
{
List<Teacher_category> oList = new List<Teacher_category>();
Teacher_category oTeacher_category = new Teacher_category();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_category_By_OWNER_ID_Adv");}
#region Body Section.
List<DALC.Teacher_category> oList_DBEntries = _AppContext.Get_Teacher_category_By_OWNER_ID_Adv(i_Params_Get_Teacher_category_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_category = new Teacher_category();
oTools.CopyPropValues(oDBEntry, oTeacher_category);

oTeacher_category.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oTeacher_category.My_Teacher);

oTeacher_category.My_Category = new Category();
oTools.CopyPropValues(oDBEntry.My_Category, oTeacher_category.My_Category);

oList.Add(oTeacher_category);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_category_By_OWNER_ID_Adv");}
return oList;
}
public List<Teacher_category> Get_Teacher_category_By_TEACHER_ID_Adv(Params_Get_Teacher_category_By_TEACHER_ID i_Params_Get_Teacher_category_By_TEACHER_ID)
{
List<Teacher_category> oList = new List<Teacher_category>();
Teacher_category oTeacher_category = new Teacher_category();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_category_By_TEACHER_ID_Adv");}
#region Body Section.
List<DALC.Teacher_category> oList_DBEntries = _AppContext.Get_Teacher_category_By_TEACHER_ID_Adv(i_Params_Get_Teacher_category_By_TEACHER_ID.TEACHER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_category = new Teacher_category();
oTools.CopyPropValues(oDBEntry, oTeacher_category);

oTeacher_category.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oTeacher_category.My_Teacher);

oTeacher_category.My_Category = new Category();
oTools.CopyPropValues(oDBEntry.My_Category, oTeacher_category.My_Category);

oList.Add(oTeacher_category);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_category_By_TEACHER_ID_Adv");}
return oList;
}
public List<Teacher_category> Get_Teacher_category_By_CATEGORY_ID_Adv(Params_Get_Teacher_category_By_CATEGORY_ID i_Params_Get_Teacher_category_By_CATEGORY_ID)
{
List<Teacher_category> oList = new List<Teacher_category>();
Teacher_category oTeacher_category = new Teacher_category();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_category_By_CATEGORY_ID_Adv");}
#region Body Section.
List<DALC.Teacher_category> oList_DBEntries = _AppContext.Get_Teacher_category_By_CATEGORY_ID_Adv(i_Params_Get_Teacher_category_By_CATEGORY_ID.CATEGORY_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_category = new Teacher_category();
oTools.CopyPropValues(oDBEntry, oTeacher_category);

oTeacher_category.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oTeacher_category.My_Teacher);

oTeacher_category.My_Category = new Category();
oTools.CopyPropValues(oDBEntry.My_Category, oTeacher_category.My_Category);

oList.Add(oTeacher_category);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_category_By_CATEGORY_ID_Adv");}
return oList;
}
public List<Favorite_teacher> Get_Favorite_teacher_By_TEACHER_ID_Adv(Params_Get_Favorite_teacher_By_TEACHER_ID i_Params_Get_Favorite_teacher_By_TEACHER_ID)
{
List<Favorite_teacher> oList = new List<Favorite_teacher>();
Favorite_teacher oFavorite_teacher = new Favorite_teacher();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Favorite_teacher_By_TEACHER_ID_Adv");}
#region Body Section.
List<DALC.Favorite_teacher> oList_DBEntries = _AppContext.Get_Favorite_teacher_By_TEACHER_ID_Adv(i_Params_Get_Favorite_teacher_By_TEACHER_ID.TEACHER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oFavorite_teacher = new Favorite_teacher();
oTools.CopyPropValues(oDBEntry, oFavorite_teacher);

oFavorite_teacher.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oFavorite_teacher.My_Teacher);

oFavorite_teacher.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oFavorite_teacher.My_Student);

oList.Add(oFavorite_teacher);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Favorite_teacher_By_TEACHER_ID_Adv");}
return oList;
}
public List<Favorite_teacher> Get_Favorite_teacher_By_STUDENT_ID_Adv(Params_Get_Favorite_teacher_By_STUDENT_ID i_Params_Get_Favorite_teacher_By_STUDENT_ID)
{
List<Favorite_teacher> oList = new List<Favorite_teacher>();
Favorite_teacher oFavorite_teacher = new Favorite_teacher();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Favorite_teacher_By_STUDENT_ID_Adv");}
#region Body Section.
List<DALC.Favorite_teacher> oList_DBEntries = _AppContext.Get_Favorite_teacher_By_STUDENT_ID_Adv(i_Params_Get_Favorite_teacher_By_STUDENT_ID.STUDENT_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oFavorite_teacher = new Favorite_teacher();
oTools.CopyPropValues(oDBEntry, oFavorite_teacher);

oFavorite_teacher.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oFavorite_teacher.My_Teacher);

oFavorite_teacher.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oFavorite_teacher.My_Student);

oList.Add(oFavorite_teacher);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Favorite_teacher_By_STUDENT_ID_Adv");}
return oList;
}
public List<Favorite_teacher> Get_Favorite_teacher_By_OWNER_ID_Adv(Params_Get_Favorite_teacher_By_OWNER_ID i_Params_Get_Favorite_teacher_By_OWNER_ID)
{
List<Favorite_teacher> oList = new List<Favorite_teacher>();
Favorite_teacher oFavorite_teacher = new Favorite_teacher();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Favorite_teacher_By_OWNER_ID_Adv");}
#region Body Section.
List<DALC.Favorite_teacher> oList_DBEntries = _AppContext.Get_Favorite_teacher_By_OWNER_ID_Adv(i_Params_Get_Favorite_teacher_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oFavorite_teacher = new Favorite_teacher();
oTools.CopyPropValues(oDBEntry, oFavorite_teacher);

oFavorite_teacher.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oFavorite_teacher.My_Teacher);

oFavorite_teacher.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oFavorite_teacher.My_Student);

oList.Add(oFavorite_teacher);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Favorite_teacher_By_OWNER_ID_Adv");}
return oList;
}
public List<Teacher_favorite> Get_Teacher_favorite_By_OWNER_ID_Adv(Params_Get_Teacher_favorite_By_OWNER_ID i_Params_Get_Teacher_favorite_By_OWNER_ID)
{
List<Teacher_favorite> oList = new List<Teacher_favorite>();
Teacher_favorite oTeacher_favorite = new Teacher_favorite();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_favorite_By_OWNER_ID_Adv");}
#region Body Section.
List<DALC.Teacher_favorite> oList_DBEntries = _AppContext.Get_Teacher_favorite_By_OWNER_ID_Adv(i_Params_Get_Teacher_favorite_By_OWNER_ID.OWNER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_favorite = new Teacher_favorite();
oTools.CopyPropValues(oDBEntry, oTeacher_favorite);

oTeacher_favorite.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oTeacher_favorite.My_Teacher);

oTeacher_favorite.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oTeacher_favorite.My_Student);

oList.Add(oTeacher_favorite);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_favorite_By_OWNER_ID_Adv");}
return oList;
}
public List<Teacher_favorite> Get_Teacher_favorite_By_TEACHER_ID_Adv(Params_Get_Teacher_favorite_By_TEACHER_ID i_Params_Get_Teacher_favorite_By_TEACHER_ID)
{
List<Teacher_favorite> oList = new List<Teacher_favorite>();
Teacher_favorite oTeacher_favorite = new Teacher_favorite();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_favorite_By_TEACHER_ID_Adv");}
#region Body Section.
List<DALC.Teacher_favorite> oList_DBEntries = _AppContext.Get_Teacher_favorite_By_TEACHER_ID_Adv(i_Params_Get_Teacher_favorite_By_TEACHER_ID.TEACHER_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_favorite = new Teacher_favorite();
oTools.CopyPropValues(oDBEntry, oTeacher_favorite);

oTeacher_favorite.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oTeacher_favorite.My_Teacher);

oTeacher_favorite.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oTeacher_favorite.My_Student);

oList.Add(oTeacher_favorite);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_favorite_By_TEACHER_ID_Adv");}
return oList;
}
public List<Teacher_favorite> Get_Teacher_favorite_By_STUDENT_ID_Adv(Params_Get_Teacher_favorite_By_STUDENT_ID i_Params_Get_Teacher_favorite_By_STUDENT_ID)
{
List<Teacher_favorite> oList = new List<Teacher_favorite>();
Teacher_favorite oTeacher_favorite = new Teacher_favorite();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_favorite_By_STUDENT_ID_Adv");}
#region Body Section.
List<DALC.Teacher_favorite> oList_DBEntries = _AppContext.Get_Teacher_favorite_By_STUDENT_ID_Adv(i_Params_Get_Teacher_favorite_By_STUDENT_ID.STUDENT_ID);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_favorite = new Teacher_favorite();
oTools.CopyPropValues(oDBEntry, oTeacher_favorite);

oTeacher_favorite.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oTeacher_favorite.My_Teacher);

oTeacher_favorite.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oTeacher_favorite.My_Student);

oList.Add(oTeacher_favorite);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_favorite_By_STUDENT_ID_Adv");}
return oList;
}
public List<Favorite_category> Get_Favorite_category_By_STUDENT_ID_List_Adv(Params_Get_Favorite_category_By_STUDENT_ID_List i_Params_Get_Favorite_category_By_STUDENT_ID_List)
{
List<Favorite_category> oList = new List<Favorite_category>();
Favorite_category oFavorite_category = new Favorite_category();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Favorite_category_By_STUDENT_ID_List_Adv");}
#region Body Section.
List<DALC.Favorite_category> oList_DBEntries = _AppContext.Get_Favorite_category_By_STUDENT_ID_List_Adv(i_Params_Get_Favorite_category_By_STUDENT_ID_List.STUDENT_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oFavorite_category = new Favorite_category();
oTools.CopyPropValues(oDBEntry, oFavorite_category);

oFavorite_category.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oFavorite_category.My_Student);

oFavorite_category.My_Category = new Category();
oTools.CopyPropValues(oDBEntry.My_Category, oFavorite_category.My_Category);

oList.Add(oFavorite_category);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Favorite_category_By_STUDENT_ID_List_Adv");}
return oList;
}
public List<Favorite_category> Get_Favorite_category_By_CATEGORY_ID_List_Adv(Params_Get_Favorite_category_By_CATEGORY_ID_List i_Params_Get_Favorite_category_By_CATEGORY_ID_List)
{
List<Favorite_category> oList = new List<Favorite_category>();
Favorite_category oFavorite_category = new Favorite_category();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Favorite_category_By_CATEGORY_ID_List_Adv");}
#region Body Section.
List<DALC.Favorite_category> oList_DBEntries = _AppContext.Get_Favorite_category_By_CATEGORY_ID_List_Adv(i_Params_Get_Favorite_category_By_CATEGORY_ID_List.CATEGORY_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oFavorite_category = new Favorite_category();
oTools.CopyPropValues(oDBEntry, oFavorite_category);

oFavorite_category.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oFavorite_category.My_Student);

oFavorite_category.My_Category = new Category();
oTools.CopyPropValues(oDBEntry.My_Category, oFavorite_category.My_Category);

oList.Add(oFavorite_category);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Favorite_category_By_CATEGORY_ID_List_Adv");}
return oList;
}
public List<Question> Get_Question_By_STUDENT_ID_List_Adv(Params_Get_Question_By_STUDENT_ID_List i_Params_Get_Question_By_STUDENT_ID_List)
{
List<Question> oList = new List<Question>();
Question oQuestion = new Question();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Question_By_STUDENT_ID_List_Adv");}
#region Body Section.
List<DALC.Question> oList_DBEntries = _AppContext.Get_Question_By_STUDENT_ID_List_Adv(i_Params_Get_Question_By_STUDENT_ID_List.STUDENT_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oQuestion = new Question();
oTools.CopyPropValues(oDBEntry, oQuestion);

oQuestion.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oQuestion.My_Student);

oQuestion.My_Category = new Category();
oTools.CopyPropValues(oDBEntry.My_Category, oQuestion.My_Category);

oQuestion.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oQuestion.My_Teacher);

oList.Add(oQuestion);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Question_By_STUDENT_ID_List_Adv");}
return oList;
}
public List<Question> Get_Question_By_CATEGORY_ID_List_Adv(Params_Get_Question_By_CATEGORY_ID_List i_Params_Get_Question_By_CATEGORY_ID_List)
{
List<Question> oList = new List<Question>();
Question oQuestion = new Question();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Question_By_CATEGORY_ID_List_Adv");}
#region Body Section.
List<DALC.Question> oList_DBEntries = _AppContext.Get_Question_By_CATEGORY_ID_List_Adv(i_Params_Get_Question_By_CATEGORY_ID_List.CATEGORY_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oQuestion = new Question();
oTools.CopyPropValues(oDBEntry, oQuestion);

oQuestion.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oQuestion.My_Student);

oQuestion.My_Category = new Category();
oTools.CopyPropValues(oDBEntry.My_Category, oQuestion.My_Category);

oQuestion.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oQuestion.My_Teacher);

oList.Add(oQuestion);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Question_By_CATEGORY_ID_List_Adv");}
return oList;
}
public List<Question> Get_Question_By_TEACHER_ID_List_Adv(Params_Get_Question_By_TEACHER_ID_List i_Params_Get_Question_By_TEACHER_ID_List)
{
List<Question> oList = new List<Question>();
Question oQuestion = new Question();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Question_By_TEACHER_ID_List_Adv");}
#region Body Section.
List<DALC.Question> oList_DBEntries = _AppContext.Get_Question_By_TEACHER_ID_List_Adv(i_Params_Get_Question_By_TEACHER_ID_List.TEACHER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oQuestion = new Question();
oTools.CopyPropValues(oDBEntry, oQuestion);

oQuestion.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oQuestion.My_Student);

oQuestion.My_Category = new Category();
oTools.CopyPropValues(oDBEntry.My_Category, oQuestion.My_Category);

oQuestion.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oQuestion.My_Teacher);

oList.Add(oQuestion);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Question_By_TEACHER_ID_List_Adv");}
return oList;
}
public List<Report_article> Get_Report_article_By_ARTICLE_ID_List_Adv(Params_Get_Report_article_By_ARTICLE_ID_List i_Params_Get_Report_article_By_ARTICLE_ID_List)
{
List<Report_article> oList = new List<Report_article>();
Report_article oReport_article = new Report_article();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Report_article_By_ARTICLE_ID_List_Adv");}
#region Body Section.
List<DALC.Report_article> oList_DBEntries = _AppContext.Get_Report_article_By_ARTICLE_ID_List_Adv(i_Params_Get_Report_article_By_ARTICLE_ID_List.ARTICLE_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oReport_article = new Report_article();
oTools.CopyPropValues(oDBEntry, oReport_article);

oReport_article.My_Article = new Article();
oTools.CopyPropValues(oDBEntry.My_Article, oReport_article.My_Article);

oReport_article.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oReport_article.My_Student);

oList.Add(oReport_article);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Report_article_By_ARTICLE_ID_List_Adv");}
return oList;
}
public List<Report_article> Get_Report_article_By_STUDENT_ID_List_Adv(Params_Get_Report_article_By_STUDENT_ID_List i_Params_Get_Report_article_By_STUDENT_ID_List)
{
List<Report_article> oList = new List<Report_article>();
Report_article oReport_article = new Report_article();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Report_article_By_STUDENT_ID_List_Adv");}
#region Body Section.
List<DALC.Report_article> oList_DBEntries = _AppContext.Get_Report_article_By_STUDENT_ID_List_Adv(i_Params_Get_Report_article_By_STUDENT_ID_List.STUDENT_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oReport_article = new Report_article();
oTools.CopyPropValues(oDBEntry, oReport_article);

oReport_article.My_Article = new Article();
oTools.CopyPropValues(oDBEntry.My_Article, oReport_article.My_Article);

oReport_article.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oReport_article.My_Student);

oList.Add(oReport_article);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Report_article_By_STUDENT_ID_List_Adv");}
return oList;
}
public List<Mark_question> Get_Mark_question_By_QUESTION_ID_List_Adv(Params_Get_Mark_question_By_QUESTION_ID_List i_Params_Get_Mark_question_By_QUESTION_ID_List)
{
List<Mark_question> oList = new List<Mark_question>();
Mark_question oMark_question = new Mark_question();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Mark_question_By_QUESTION_ID_List_Adv");}
#region Body Section.
List<DALC.Mark_question> oList_DBEntries = _AppContext.Get_Mark_question_By_QUESTION_ID_List_Adv(i_Params_Get_Mark_question_By_QUESTION_ID_List.QUESTION_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oMark_question = new Mark_question();
oTools.CopyPropValues(oDBEntry, oMark_question);

oMark_question.My_Question = new Question();
oTools.CopyPropValues(oDBEntry.My_Question, oMark_question.My_Question);

oMark_question.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oMark_question.My_Student);

oList.Add(oMark_question);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Mark_question_By_QUESTION_ID_List_Adv");}
return oList;
}
public List<Mark_question> Get_Mark_question_By_STUDENT_ID_List_Adv(Params_Get_Mark_question_By_STUDENT_ID_List i_Params_Get_Mark_question_By_STUDENT_ID_List)
{
List<Mark_question> oList = new List<Mark_question>();
Mark_question oMark_question = new Mark_question();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Mark_question_By_STUDENT_ID_List_Adv");}
#region Body Section.
List<DALC.Mark_question> oList_DBEntries = _AppContext.Get_Mark_question_By_STUDENT_ID_List_Adv(i_Params_Get_Mark_question_By_STUDENT_ID_List.STUDENT_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oMark_question = new Mark_question();
oTools.CopyPropValues(oDBEntry, oMark_question);

oMark_question.My_Question = new Question();
oTools.CopyPropValues(oDBEntry.My_Question, oMark_question.My_Question);

oMark_question.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oMark_question.My_Student);

oList.Add(oMark_question);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Mark_question_By_STUDENT_ID_List_Adv");}
return oList;
}
public List<Article> Get_Article_By_TEACHER_ID_List_Adv(Params_Get_Article_By_TEACHER_ID_List i_Params_Get_Article_By_TEACHER_ID_List)
{
List<Article> oList = new List<Article>();
Article oArticle = new Article();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Article_By_TEACHER_ID_List_Adv");}
#region Body Section.
List<DALC.Article> oList_DBEntries = _AppContext.Get_Article_By_TEACHER_ID_List_Adv(i_Params_Get_Article_By_TEACHER_ID_List.TEACHER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oArticle = new Article();
oTools.CopyPropValues(oDBEntry, oArticle);

oArticle.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oArticle.My_Teacher);

oArticle.My_Category = new Category();
oTools.CopyPropValues(oDBEntry.My_Category, oArticle.My_Category);

oList.Add(oArticle);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Article_By_TEACHER_ID_List_Adv");}
return oList;
}
public List<Article> Get_Article_By_CATEGORY_ID_List_Adv(Params_Get_Article_By_CATEGORY_ID_List i_Params_Get_Article_By_CATEGORY_ID_List)
{
List<Article> oList = new List<Article>();
Article oArticle = new Article();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Article_By_CATEGORY_ID_List_Adv");}
#region Body Section.
List<DALC.Article> oList_DBEntries = _AppContext.Get_Article_By_CATEGORY_ID_List_Adv(i_Params_Get_Article_By_CATEGORY_ID_List.CATEGORY_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oArticle = new Article();
oTools.CopyPropValues(oDBEntry, oArticle);

oArticle.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oArticle.My_Teacher);

oArticle.My_Category = new Category();
oTools.CopyPropValues(oDBEntry.My_Category, oArticle.My_Category);

oList.Add(oArticle);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Article_By_CATEGORY_ID_List_Adv");}
return oList;
}
public List<Answer> Get_Answer_By_QUESTION_ID_List_Adv(Params_Get_Answer_By_QUESTION_ID_List i_Params_Get_Answer_By_QUESTION_ID_List)
{
List<Answer> oList = new List<Answer>();
Answer oAnswer = new Answer();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Answer_By_QUESTION_ID_List_Adv");}
#region Body Section.
List<DALC.Answer> oList_DBEntries = _AppContext.Get_Answer_By_QUESTION_ID_List_Adv(i_Params_Get_Answer_By_QUESTION_ID_List.QUESTION_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oAnswer = new Answer();
oTools.CopyPropValues(oDBEntry, oAnswer);

oAnswer.My_Question = new Question();
oTools.CopyPropValues(oDBEntry.My_Question, oAnswer.My_Question);

oAnswer.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oAnswer.My_Teacher);

oList.Add(oAnswer);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Answer_By_QUESTION_ID_List_Adv");}
return oList;
}
public List<Answer> Get_Answer_By_TEACHER_ID_List_Adv(Params_Get_Answer_By_TEACHER_ID_List i_Params_Get_Answer_By_TEACHER_ID_List)
{
List<Answer> oList = new List<Answer>();
Answer oAnswer = new Answer();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Answer_By_TEACHER_ID_List_Adv");}
#region Body Section.
List<DALC.Answer> oList_DBEntries = _AppContext.Get_Answer_By_TEACHER_ID_List_Adv(i_Params_Get_Answer_By_TEACHER_ID_List.TEACHER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oAnswer = new Answer();
oTools.CopyPropValues(oDBEntry, oAnswer);

oAnswer.My_Question = new Question();
oTools.CopyPropValues(oDBEntry.My_Question, oAnswer.My_Question);

oAnswer.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oAnswer.My_Teacher);

oList.Add(oAnswer);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Answer_By_TEACHER_ID_List_Adv");}
return oList;
}
public List<Student> Get_Student_By_USER_ID_List_Adv(Params_Get_Student_By_USER_ID_List i_Params_Get_Student_By_USER_ID_List)
{
List<Student> oList = new List<Student>();
Student oStudent = new Student();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Student_By_USER_ID_List_Adv");}
#region Body Section.
List<DALC.Student> oList_DBEntries = _AppContext.Get_Student_By_USER_ID_List_Adv(i_Params_Get_Student_By_USER_ID_List.USER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oStudent = new Student();
oTools.CopyPropValues(oDBEntry, oStudent);

oStudent.My_User = new User();
oTools.CopyPropValues(oDBEntry.My_User, oStudent.My_User);

oList.Add(oStudent);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Student_By_USER_ID_List_Adv");}
return oList;
}
public List<Notification> Get_Notification_By_USER_ID_List_Adv(Params_Get_Notification_By_USER_ID_List i_Params_Get_Notification_By_USER_ID_List)
{
List<Notification> oList = new List<Notification>();
Notification oNotification = new Notification();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Notification_By_USER_ID_List_Adv");}
#region Body Section.
List<DALC.Notification> oList_DBEntries = _AppContext.Get_Notification_By_USER_ID_List_Adv(i_Params_Get_Notification_By_USER_ID_List.USER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oNotification = new Notification();
oTools.CopyPropValues(oDBEntry, oNotification);

oNotification.My_User = new User();
oTools.CopyPropValues(oDBEntry.My_User, oNotification.My_User);

oNotification.My_Question = new Question();
oTools.CopyPropValues(oDBEntry.My_Question, oNotification.My_Question);

oNotification.My_Answer = new Answer();
oTools.CopyPropValues(oDBEntry.My_Answer, oNotification.My_Answer);

oNotification.My_Article = new Article();
oTools.CopyPropValues(oDBEntry.My_Article, oNotification.My_Article);

oList.Add(oNotification);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Notification_By_USER_ID_List_Adv");}
return oList;
}
public List<Notification> Get_Notification_By_QUESTION_ID_List_Adv(Params_Get_Notification_By_QUESTION_ID_List i_Params_Get_Notification_By_QUESTION_ID_List)
{
List<Notification> oList = new List<Notification>();
Notification oNotification = new Notification();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Notification_By_QUESTION_ID_List_Adv");}
#region Body Section.
List<DALC.Notification> oList_DBEntries = _AppContext.Get_Notification_By_QUESTION_ID_List_Adv(i_Params_Get_Notification_By_QUESTION_ID_List.QUESTION_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oNotification = new Notification();
oTools.CopyPropValues(oDBEntry, oNotification);

oNotification.My_User = new User();
oTools.CopyPropValues(oDBEntry.My_User, oNotification.My_User);

oNotification.My_Question = new Question();
oTools.CopyPropValues(oDBEntry.My_Question, oNotification.My_Question);

oNotification.My_Answer = new Answer();
oTools.CopyPropValues(oDBEntry.My_Answer, oNotification.My_Answer);

oNotification.My_Article = new Article();
oTools.CopyPropValues(oDBEntry.My_Article, oNotification.My_Article);

oList.Add(oNotification);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Notification_By_QUESTION_ID_List_Adv");}
return oList;
}
public List<Notification> Get_Notification_By_ANSWER_ID_List_Adv(Params_Get_Notification_By_ANSWER_ID_List i_Params_Get_Notification_By_ANSWER_ID_List)
{
List<Notification> oList = new List<Notification>();
Notification oNotification = new Notification();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Notification_By_ANSWER_ID_List_Adv");}
#region Body Section.
List<DALC.Notification> oList_DBEntries = _AppContext.Get_Notification_By_ANSWER_ID_List_Adv(i_Params_Get_Notification_By_ANSWER_ID_List.ANSWER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oNotification = new Notification();
oTools.CopyPropValues(oDBEntry, oNotification);

oNotification.My_User = new User();
oTools.CopyPropValues(oDBEntry.My_User, oNotification.My_User);

oNotification.My_Question = new Question();
oTools.CopyPropValues(oDBEntry.My_Question, oNotification.My_Question);

oNotification.My_Answer = new Answer();
oTools.CopyPropValues(oDBEntry.My_Answer, oNotification.My_Answer);

oNotification.My_Article = new Article();
oTools.CopyPropValues(oDBEntry.My_Article, oNotification.My_Article);

oList.Add(oNotification);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Notification_By_ANSWER_ID_List_Adv");}
return oList;
}
public List<Notification> Get_Notification_By_ARTICLE_ID_List_Adv(Params_Get_Notification_By_ARTICLE_ID_List i_Params_Get_Notification_By_ARTICLE_ID_List)
{
List<Notification> oList = new List<Notification>();
Notification oNotification = new Notification();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Notification_By_ARTICLE_ID_List_Adv");}
#region Body Section.
List<DALC.Notification> oList_DBEntries = _AppContext.Get_Notification_By_ARTICLE_ID_List_Adv(i_Params_Get_Notification_By_ARTICLE_ID_List.ARTICLE_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oNotification = new Notification();
oTools.CopyPropValues(oDBEntry, oNotification);

oNotification.My_User = new User();
oTools.CopyPropValues(oDBEntry.My_User, oNotification.My_User);

oNotification.My_Question = new Question();
oTools.CopyPropValues(oDBEntry.My_Question, oNotification.My_Question);

oNotification.My_Answer = new Answer();
oTools.CopyPropValues(oDBEntry.My_Answer, oNotification.My_Answer);

oNotification.My_Article = new Article();
oTools.CopyPropValues(oDBEntry.My_Article, oNotification.My_Article);

oList.Add(oNotification);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Notification_By_ARTICLE_ID_List_Adv");}
return oList;
}
public List<Evaluation> Get_Evaluation_By_STUDENT_ID_List_Adv(Params_Get_Evaluation_By_STUDENT_ID_List i_Params_Get_Evaluation_By_STUDENT_ID_List)
{
List<Evaluation> oList = new List<Evaluation>();
Evaluation oEvaluation = new Evaluation();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Evaluation_By_STUDENT_ID_List_Adv");}
#region Body Section.
List<DALC.Evaluation> oList_DBEntries = _AppContext.Get_Evaluation_By_STUDENT_ID_List_Adv(i_Params_Get_Evaluation_By_STUDENT_ID_List.STUDENT_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oEvaluation = new Evaluation();
oTools.CopyPropValues(oDBEntry, oEvaluation);

oEvaluation.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oEvaluation.My_Student);

oEvaluation.My_Answer = new Answer();
oTools.CopyPropValues(oDBEntry.My_Answer, oEvaluation.My_Answer);

oList.Add(oEvaluation);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Evaluation_By_STUDENT_ID_List_Adv");}
return oList;
}
public List<Evaluation> Get_Evaluation_By_ANSWER_ID_List_Adv(Params_Get_Evaluation_By_ANSWER_ID_List i_Params_Get_Evaluation_By_ANSWER_ID_List)
{
List<Evaluation> oList = new List<Evaluation>();
Evaluation oEvaluation = new Evaluation();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Evaluation_By_ANSWER_ID_List_Adv");}
#region Body Section.
List<DALC.Evaluation> oList_DBEntries = _AppContext.Get_Evaluation_By_ANSWER_ID_List_Adv(i_Params_Get_Evaluation_By_ANSWER_ID_List.ANSWER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oEvaluation = new Evaluation();
oTools.CopyPropValues(oDBEntry, oEvaluation);

oEvaluation.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oEvaluation.My_Student);

oEvaluation.My_Answer = new Answer();
oTools.CopyPropValues(oDBEntry.My_Answer, oEvaluation.My_Answer);

oList.Add(oEvaluation);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Evaluation_By_ANSWER_ID_List_Adv");}
return oList;
}
public List<Student_report> Get_Student_report_By_REPORTED_BY_STUDENT_ID_List_Adv(Params_Get_Student_report_By_REPORTED_BY_STUDENT_ID_List i_Params_Get_Student_report_By_REPORTED_BY_STUDENT_ID_List)
{
List<Student_report> oList = new List<Student_report>();
Student_report oStudent_report = new Student_report();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Student_report_By_REPORTED_BY_STUDENT_ID_List_Adv");}
#region Body Section.
List<DALC.Student_report> oList_DBEntries = _AppContext.Get_Student_report_By_REPORTED_BY_STUDENT_ID_List_Adv(i_Params_Get_Student_report_By_REPORTED_BY_STUDENT_ID_List.REPORTED_BY_STUDENT_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oStudent_report = new Student_report();
oTools.CopyPropValues(oDBEntry, oStudent_report);

oStudent_report.My_Reported_by_student = new Student();
oTools.CopyPropValues(oDBEntry.My_Reported_by_student, oStudent_report.My_Reported_by_student);

oStudent_report.My_Reported_student = new Student();
oTools.CopyPropValues(oDBEntry.My_Reported_student, oStudent_report.My_Reported_student);

oList.Add(oStudent_report);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Student_report_By_REPORTED_BY_STUDENT_ID_List_Adv");}
return oList;
}
public List<Student_report> Get_Student_report_By_REPORTED_STUDENT_ID_List_Adv(Params_Get_Student_report_By_REPORTED_STUDENT_ID_List i_Params_Get_Student_report_By_REPORTED_STUDENT_ID_List)
{
List<Student_report> oList = new List<Student_report>();
Student_report oStudent_report = new Student_report();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Student_report_By_REPORTED_STUDENT_ID_List_Adv");}
#region Body Section.
List<DALC.Student_report> oList_DBEntries = _AppContext.Get_Student_report_By_REPORTED_STUDENT_ID_List_Adv(i_Params_Get_Student_report_By_REPORTED_STUDENT_ID_List.REPORTED_STUDENT_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oStudent_report = new Student_report();
oTools.CopyPropValues(oDBEntry, oStudent_report);

oStudent_report.My_Reported_by_student = new Student();
oTools.CopyPropValues(oDBEntry.My_Reported_by_student, oStudent_report.My_Reported_by_student);

oStudent_report.My_Reported_student = new Student();
oTools.CopyPropValues(oDBEntry.My_Reported_student, oStudent_report.My_Reported_student);

oList.Add(oStudent_report);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Student_report_By_REPORTED_STUDENT_ID_List_Adv");}
return oList;
}
public List<Appreciate> Get_Appreciate_By_ARTICLE_ID_List_Adv(Params_Get_Appreciate_By_ARTICLE_ID_List i_Params_Get_Appreciate_By_ARTICLE_ID_List)
{
List<Appreciate> oList = new List<Appreciate>();
Appreciate oAppreciate = new Appreciate();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Appreciate_By_ARTICLE_ID_List_Adv");}
#region Body Section.
List<DALC.Appreciate> oList_DBEntries = _AppContext.Get_Appreciate_By_ARTICLE_ID_List_Adv(i_Params_Get_Appreciate_By_ARTICLE_ID_List.ARTICLE_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oAppreciate = new Appreciate();
oTools.CopyPropValues(oDBEntry, oAppreciate);

oAppreciate.My_Article = new Article();
oTools.CopyPropValues(oDBEntry.My_Article, oAppreciate.My_Article);

oAppreciate.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oAppreciate.My_Student);

oList.Add(oAppreciate);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Appreciate_By_ARTICLE_ID_List_Adv");}
return oList;
}
public List<Appreciate> Get_Appreciate_By_STUDENT_ID_List_Adv(Params_Get_Appreciate_By_STUDENT_ID_List i_Params_Get_Appreciate_By_STUDENT_ID_List)
{
List<Appreciate> oList = new List<Appreciate>();
Appreciate oAppreciate = new Appreciate();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Appreciate_By_STUDENT_ID_List_Adv");}
#region Body Section.
List<DALC.Appreciate> oList_DBEntries = _AppContext.Get_Appreciate_By_STUDENT_ID_List_Adv(i_Params_Get_Appreciate_By_STUDENT_ID_List.STUDENT_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oAppreciate = new Appreciate();
oTools.CopyPropValues(oDBEntry, oAppreciate);

oAppreciate.My_Article = new Article();
oTools.CopyPropValues(oDBEntry.My_Article, oAppreciate.My_Article);

oAppreciate.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oAppreciate.My_Student);

oList.Add(oAppreciate);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Appreciate_By_STUDENT_ID_List_Adv");}
return oList;
}
public List<Teacher_report> Get_Teacher_report_By_TEACHER_ID_List_Adv(Params_Get_Teacher_report_By_TEACHER_ID_List i_Params_Get_Teacher_report_By_TEACHER_ID_List)
{
List<Teacher_report> oList = new List<Teacher_report>();
Teacher_report oTeacher_report = new Teacher_report();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_report_By_TEACHER_ID_List_Adv");}
#region Body Section.
List<DALC.Teacher_report> oList_DBEntries = _AppContext.Get_Teacher_report_By_TEACHER_ID_List_Adv(i_Params_Get_Teacher_report_By_TEACHER_ID_List.TEACHER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_report = new Teacher_report();
oTools.CopyPropValues(oDBEntry, oTeacher_report);

oTeacher_report.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oTeacher_report.My_Teacher);

oTeacher_report.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oTeacher_report.My_Student);

oList.Add(oTeacher_report);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_report_By_TEACHER_ID_List_Adv");}
return oList;
}
public List<Teacher_report> Get_Teacher_report_By_STUDENT_ID_List_Adv(Params_Get_Teacher_report_By_STUDENT_ID_List i_Params_Get_Teacher_report_By_STUDENT_ID_List)
{
List<Teacher_report> oList = new List<Teacher_report>();
Teacher_report oTeacher_report = new Teacher_report();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_report_By_STUDENT_ID_List_Adv");}
#region Body Section.
List<DALC.Teacher_report> oList_DBEntries = _AppContext.Get_Teacher_report_By_STUDENT_ID_List_Adv(i_Params_Get_Teacher_report_By_STUDENT_ID_List.STUDENT_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_report = new Teacher_report();
oTools.CopyPropValues(oDBEntry, oTeacher_report);

oTeacher_report.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oTeacher_report.My_Teacher);

oTeacher_report.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oTeacher_report.My_Student);

oList.Add(oTeacher_report);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_report_By_STUDENT_ID_List_Adv");}
return oList;
}
public List<Question_report> Get_Question_report_By_STUDENT_ID_List_Adv(Params_Get_Question_report_By_STUDENT_ID_List i_Params_Get_Question_report_By_STUDENT_ID_List)
{
List<Question_report> oList = new List<Question_report>();
Question_report oQuestion_report = new Question_report();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Question_report_By_STUDENT_ID_List_Adv");}
#region Body Section.
List<DALC.Question_report> oList_DBEntries = _AppContext.Get_Question_report_By_STUDENT_ID_List_Adv(i_Params_Get_Question_report_By_STUDENT_ID_List.STUDENT_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oQuestion_report = new Question_report();
oTools.CopyPropValues(oDBEntry, oQuestion_report);

oQuestion_report.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oQuestion_report.My_Student);

oQuestion_report.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oQuestion_report.My_Teacher);

oQuestion_report.My_Question = new Question();
oTools.CopyPropValues(oDBEntry.My_Question, oQuestion_report.My_Question);

oList.Add(oQuestion_report);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Question_report_By_STUDENT_ID_List_Adv");}
return oList;
}
public List<Question_report> Get_Question_report_By_TEACHER_ID_List_Adv(Params_Get_Question_report_By_TEACHER_ID_List i_Params_Get_Question_report_By_TEACHER_ID_List)
{
List<Question_report> oList = new List<Question_report>();
Question_report oQuestion_report = new Question_report();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Question_report_By_TEACHER_ID_List_Adv");}
#region Body Section.
List<DALC.Question_report> oList_DBEntries = _AppContext.Get_Question_report_By_TEACHER_ID_List_Adv(i_Params_Get_Question_report_By_TEACHER_ID_List.TEACHER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oQuestion_report = new Question_report();
oTools.CopyPropValues(oDBEntry, oQuestion_report);

oQuestion_report.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oQuestion_report.My_Student);

oQuestion_report.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oQuestion_report.My_Teacher);

oQuestion_report.My_Question = new Question();
oTools.CopyPropValues(oDBEntry.My_Question, oQuestion_report.My_Question);

oList.Add(oQuestion_report);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Question_report_By_TEACHER_ID_List_Adv");}
return oList;
}
public List<Question_report> Get_Question_report_By_QUESTION_ID_List_Adv(Params_Get_Question_report_By_QUESTION_ID_List i_Params_Get_Question_report_By_QUESTION_ID_List)
{
List<Question_report> oList = new List<Question_report>();
Question_report oQuestion_report = new Question_report();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Question_report_By_QUESTION_ID_List_Adv");}
#region Body Section.
List<DALC.Question_report> oList_DBEntries = _AppContext.Get_Question_report_By_QUESTION_ID_List_Adv(i_Params_Get_Question_report_By_QUESTION_ID_List.QUESTION_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oQuestion_report = new Question_report();
oTools.CopyPropValues(oDBEntry, oQuestion_report);

oQuestion_report.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oQuestion_report.My_Student);

oQuestion_report.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oQuestion_report.My_Teacher);

oQuestion_report.My_Question = new Question();
oTools.CopyPropValues(oDBEntry.My_Question, oQuestion_report.My_Question);

oList.Add(oQuestion_report);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Question_report_By_QUESTION_ID_List_Adv");}
return oList;
}
public List<Answer_report> Get_Answer_report_By_TEACHER_ID_List_Adv(Params_Get_Answer_report_By_TEACHER_ID_List i_Params_Get_Answer_report_By_TEACHER_ID_List)
{
List<Answer_report> oList = new List<Answer_report>();
Answer_report oAnswer_report = new Answer_report();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Answer_report_By_TEACHER_ID_List_Adv");}
#region Body Section.
List<DALC.Answer_report> oList_DBEntries = _AppContext.Get_Answer_report_By_TEACHER_ID_List_Adv(i_Params_Get_Answer_report_By_TEACHER_ID_List.TEACHER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oAnswer_report = new Answer_report();
oTools.CopyPropValues(oDBEntry, oAnswer_report);

oAnswer_report.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oAnswer_report.My_Teacher);

oAnswer_report.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oAnswer_report.My_Student);

oAnswer_report.My_Answer = new Answer();
oTools.CopyPropValues(oDBEntry.My_Answer, oAnswer_report.My_Answer);

oList.Add(oAnswer_report);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Answer_report_By_TEACHER_ID_List_Adv");}
return oList;
}
public List<Answer_report> Get_Answer_report_By_STUDENT_ID_List_Adv(Params_Get_Answer_report_By_STUDENT_ID_List i_Params_Get_Answer_report_By_STUDENT_ID_List)
{
List<Answer_report> oList = new List<Answer_report>();
Answer_report oAnswer_report = new Answer_report();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Answer_report_By_STUDENT_ID_List_Adv");}
#region Body Section.
List<DALC.Answer_report> oList_DBEntries = _AppContext.Get_Answer_report_By_STUDENT_ID_List_Adv(i_Params_Get_Answer_report_By_STUDENT_ID_List.STUDENT_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oAnswer_report = new Answer_report();
oTools.CopyPropValues(oDBEntry, oAnswer_report);

oAnswer_report.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oAnswer_report.My_Teacher);

oAnswer_report.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oAnswer_report.My_Student);

oAnswer_report.My_Answer = new Answer();
oTools.CopyPropValues(oDBEntry.My_Answer, oAnswer_report.My_Answer);

oList.Add(oAnswer_report);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Answer_report_By_STUDENT_ID_List_Adv");}
return oList;
}
public List<Answer_report> Get_Answer_report_By_ANSWER_ID_List_Adv(Params_Get_Answer_report_By_ANSWER_ID_List i_Params_Get_Answer_report_By_ANSWER_ID_List)
{
List<Answer_report> oList = new List<Answer_report>();
Answer_report oAnswer_report = new Answer_report();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Answer_report_By_ANSWER_ID_List_Adv");}
#region Body Section.
List<DALC.Answer_report> oList_DBEntries = _AppContext.Get_Answer_report_By_ANSWER_ID_List_Adv(i_Params_Get_Answer_report_By_ANSWER_ID_List.ANSWER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oAnswer_report = new Answer_report();
oTools.CopyPropValues(oDBEntry, oAnswer_report);

oAnswer_report.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oAnswer_report.My_Teacher);

oAnswer_report.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oAnswer_report.My_Student);

oAnswer_report.My_Answer = new Answer();
oTools.CopyPropValues(oDBEntry.My_Answer, oAnswer_report.My_Answer);

oList.Add(oAnswer_report);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Answer_report_By_ANSWER_ID_List_Adv");}
return oList;
}
public List<Teacher_rank> Get_Teacher_rank_By_TEACHER_ID_List_Adv(Params_Get_Teacher_rank_By_TEACHER_ID_List i_Params_Get_Teacher_rank_By_TEACHER_ID_List)
{
List<Teacher_rank> oList = new List<Teacher_rank>();
Teacher_rank oTeacher_rank = new Teacher_rank();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_rank_By_TEACHER_ID_List_Adv");}
#region Body Section.
List<DALC.Teacher_rank> oList_DBEntries = _AppContext.Get_Teacher_rank_By_TEACHER_ID_List_Adv(i_Params_Get_Teacher_rank_By_TEACHER_ID_List.TEACHER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_rank = new Teacher_rank();
oTools.CopyPropValues(oDBEntry, oTeacher_rank);

oTeacher_rank.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oTeacher_rank.My_Teacher);

oList.Add(oTeacher_rank);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_rank_By_TEACHER_ID_List_Adv");}
return oList;
}
public List<Teacher> Get_Teacher_By_USER_ID_List_Adv(Params_Get_Teacher_By_USER_ID_List i_Params_Get_Teacher_By_USER_ID_List)
{
List<Teacher> oList = new List<Teacher>();
Teacher oTeacher = new Teacher();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_By_USER_ID_List_Adv");}
#region Body Section.
List<DALC.Teacher> oList_DBEntries = _AppContext.Get_Teacher_By_USER_ID_List_Adv(i_Params_Get_Teacher_By_USER_ID_List.USER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher = new Teacher();
oTools.CopyPropValues(oDBEntry, oTeacher);

oTeacher.My_User = new User();
oTools.CopyPropValues(oDBEntry.My_User, oTeacher.My_User);

oList.Add(oTeacher);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_By_USER_ID_List_Adv");}
return oList;
}
public List<Question_token> Get_Question_token_By_QUESTION_ID_List_Adv(Params_Get_Question_token_By_QUESTION_ID_List i_Params_Get_Question_token_By_QUESTION_ID_List)
{
List<Question_token> oList = new List<Question_token>();
Question_token oQuestion_token = new Question_token();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Question_token_By_QUESTION_ID_List_Adv");}
#region Body Section.
List<DALC.Question_token> oList_DBEntries = _AppContext.Get_Question_token_By_QUESTION_ID_List_Adv(i_Params_Get_Question_token_By_QUESTION_ID_List.QUESTION_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oQuestion_token = new Question_token();
oTools.CopyPropValues(oDBEntry, oQuestion_token);

oQuestion_token.My_Question = new Question();
oTools.CopyPropValues(oDBEntry.My_Question, oQuestion_token.My_Question);

oList.Add(oQuestion_token);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Question_token_By_QUESTION_ID_List_Adv");}
return oList;
}
public List<Teacher_category> Get_Teacher_category_By_TEACHER_ID_List_Adv(Params_Get_Teacher_category_By_TEACHER_ID_List i_Params_Get_Teacher_category_By_TEACHER_ID_List)
{
List<Teacher_category> oList = new List<Teacher_category>();
Teacher_category oTeacher_category = new Teacher_category();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_category_By_TEACHER_ID_List_Adv");}
#region Body Section.
List<DALC.Teacher_category> oList_DBEntries = _AppContext.Get_Teacher_category_By_TEACHER_ID_List_Adv(i_Params_Get_Teacher_category_By_TEACHER_ID_List.TEACHER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_category = new Teacher_category();
oTools.CopyPropValues(oDBEntry, oTeacher_category);

oTeacher_category.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oTeacher_category.My_Teacher);

oTeacher_category.My_Category = new Category();
oTools.CopyPropValues(oDBEntry.My_Category, oTeacher_category.My_Category);

oList.Add(oTeacher_category);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_category_By_TEACHER_ID_List_Adv");}
return oList;
}
public List<Teacher_category> Get_Teacher_category_By_CATEGORY_ID_List_Adv(Params_Get_Teacher_category_By_CATEGORY_ID_List i_Params_Get_Teacher_category_By_CATEGORY_ID_List)
{
List<Teacher_category> oList = new List<Teacher_category>();
Teacher_category oTeacher_category = new Teacher_category();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_category_By_CATEGORY_ID_List_Adv");}
#region Body Section.
List<DALC.Teacher_category> oList_DBEntries = _AppContext.Get_Teacher_category_By_CATEGORY_ID_List_Adv(i_Params_Get_Teacher_category_By_CATEGORY_ID_List.CATEGORY_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_category = new Teacher_category();
oTools.CopyPropValues(oDBEntry, oTeacher_category);

oTeacher_category.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oTeacher_category.My_Teacher);

oTeacher_category.My_Category = new Category();
oTools.CopyPropValues(oDBEntry.My_Category, oTeacher_category.My_Category);

oList.Add(oTeacher_category);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_category_By_CATEGORY_ID_List_Adv");}
return oList;
}
public List<Favorite_teacher> Get_Favorite_teacher_By_TEACHER_ID_List_Adv(Params_Get_Favorite_teacher_By_TEACHER_ID_List i_Params_Get_Favorite_teacher_By_TEACHER_ID_List)
{
List<Favorite_teacher> oList = new List<Favorite_teacher>();
Favorite_teacher oFavorite_teacher = new Favorite_teacher();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Favorite_teacher_By_TEACHER_ID_List_Adv");}
#region Body Section.
List<DALC.Favorite_teacher> oList_DBEntries = _AppContext.Get_Favorite_teacher_By_TEACHER_ID_List_Adv(i_Params_Get_Favorite_teacher_By_TEACHER_ID_List.TEACHER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oFavorite_teacher = new Favorite_teacher();
oTools.CopyPropValues(oDBEntry, oFavorite_teacher);

oFavorite_teacher.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oFavorite_teacher.My_Teacher);

oFavorite_teacher.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oFavorite_teacher.My_Student);

oList.Add(oFavorite_teacher);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Favorite_teacher_By_TEACHER_ID_List_Adv");}
return oList;
}
public List<Favorite_teacher> Get_Favorite_teacher_By_STUDENT_ID_List_Adv(Params_Get_Favorite_teacher_By_STUDENT_ID_List i_Params_Get_Favorite_teacher_By_STUDENT_ID_List)
{
List<Favorite_teacher> oList = new List<Favorite_teacher>();
Favorite_teacher oFavorite_teacher = new Favorite_teacher();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Favorite_teacher_By_STUDENT_ID_List_Adv");}
#region Body Section.
List<DALC.Favorite_teacher> oList_DBEntries = _AppContext.Get_Favorite_teacher_By_STUDENT_ID_List_Adv(i_Params_Get_Favorite_teacher_By_STUDENT_ID_List.STUDENT_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oFavorite_teacher = new Favorite_teacher();
oTools.CopyPropValues(oDBEntry, oFavorite_teacher);

oFavorite_teacher.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oFavorite_teacher.My_Teacher);

oFavorite_teacher.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oFavorite_teacher.My_Student);

oList.Add(oFavorite_teacher);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Favorite_teacher_By_STUDENT_ID_List_Adv");}
return oList;
}
public List<Teacher_favorite> Get_Teacher_favorite_By_TEACHER_ID_List_Adv(Params_Get_Teacher_favorite_By_TEACHER_ID_List i_Params_Get_Teacher_favorite_By_TEACHER_ID_List)
{
List<Teacher_favorite> oList = new List<Teacher_favorite>();
Teacher_favorite oTeacher_favorite = new Teacher_favorite();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_favorite_By_TEACHER_ID_List_Adv");}
#region Body Section.
List<DALC.Teacher_favorite> oList_DBEntries = _AppContext.Get_Teacher_favorite_By_TEACHER_ID_List_Adv(i_Params_Get_Teacher_favorite_By_TEACHER_ID_List.TEACHER_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_favorite = new Teacher_favorite();
oTools.CopyPropValues(oDBEntry, oTeacher_favorite);

oTeacher_favorite.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oTeacher_favorite.My_Teacher);

oTeacher_favorite.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oTeacher_favorite.My_Student);

oList.Add(oTeacher_favorite);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_favorite_By_TEACHER_ID_List_Adv");}
return oList;
}
public List<Teacher_favorite> Get_Teacher_favorite_By_STUDENT_ID_List_Adv(Params_Get_Teacher_favorite_By_STUDENT_ID_List i_Params_Get_Teacher_favorite_By_STUDENT_ID_List)
{
List<Teacher_favorite> oList = new List<Teacher_favorite>();
Teacher_favorite oTeacher_favorite = new Teacher_favorite();
Tools.Tools oTools = new Tools.Tools();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_favorite_By_STUDENT_ID_List_Adv");}
#region Body Section.
List<DALC.Teacher_favorite> oList_DBEntries = _AppContext.Get_Teacher_favorite_By_STUDENT_ID_List_Adv(i_Params_Get_Teacher_favorite_By_STUDENT_ID_List.STUDENT_ID_LIST);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_favorite = new Teacher_favorite();
oTools.CopyPropValues(oDBEntry, oTeacher_favorite);

oTeacher_favorite.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oTeacher_favorite.My_Teacher);

oTeacher_favorite.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oTeacher_favorite.My_Student);

oList.Add(oTeacher_favorite);
}
}
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_favorite_By_STUDENT_ID_List_Adv");}
return oList;
}
public List<Favorite_category> Get_Favorite_category_By_Criteria_Adv(Params_Get_Favorite_category_By_Criteria i_Params_Get_Favorite_category_By_Criteria)
{
List<Favorite_category> oList = new List<Favorite_category>();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0;
Favorite_category oFavorite_category = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Favorite_category_By_Criteria_Adv");}
#region Body Section.
if ((i_Params_Get_Favorite_category_By_Criteria.OWNER_ID == null) || (i_Params_Get_Favorite_category_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Favorite_category_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Favorite_category_By_Criteria.START_ROW == null) { i_Params_Get_Favorite_category_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Favorite_category_By_Criteria.END_ROW == null) || (i_Params_Get_Favorite_category_By_Criteria.END_ROW == 0)) { i_Params_Get_Favorite_category_By_Criteria.END_ROW = 1000000; }
List<DALC.Favorite_category> oList_DBEntries = _AppContext.Get_Favorite_category_By_Criteria_Adv(i_Params_Get_Favorite_category_By_Criteria.DESCRIPTION,i_Params_Get_Favorite_category_By_Criteria.OWNER_ID,i_Params_Get_Favorite_category_By_Criteria.START_ROW,i_Params_Get_Favorite_category_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oFavorite_category = new Favorite_category();
oTools.CopyPropValues(oDBEntry, oFavorite_category);

oFavorite_category.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oFavorite_category.My_Student);

oFavorite_category.My_Category = new Category();
oTools.CopyPropValues(oDBEntry.My_Category, oFavorite_category.My_Category);

oList.Add(oFavorite_category);
}
}
i_Params_Get_Favorite_category_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Favorite_category_By_Criteria_Adv");}
return oList;
}
public List<Favorite_category> Get_Favorite_category_By_Where_Adv(Params_Get_Favorite_category_By_Where i_Params_Get_Favorite_category_By_Where)
{
List<Favorite_category> oList = new List<Favorite_category>();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0;
Favorite_category oFavorite_category = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Favorite_category_By_Where_Adv");}
#region Body Section.
if ((i_Params_Get_Favorite_category_By_Where.OWNER_ID == null) || (i_Params_Get_Favorite_category_By_Where.OWNER_ID == 0)) { i_Params_Get_Favorite_category_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Favorite_category_By_Where.START_ROW == null) { i_Params_Get_Favorite_category_By_Where.START_ROW = 0; }
if ((i_Params_Get_Favorite_category_By_Where.END_ROW == null) || (i_Params_Get_Favorite_category_By_Where.END_ROW == 0)) { i_Params_Get_Favorite_category_By_Where.END_ROW = 1000000; }
List<DALC.Favorite_category> oList_DBEntries = _AppContext.Get_Favorite_category_By_Where_Adv(i_Params_Get_Favorite_category_By_Where.DESCRIPTION,i_Params_Get_Favorite_category_By_Where.OWNER_ID,i_Params_Get_Favorite_category_By_Where.START_ROW,i_Params_Get_Favorite_category_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oFavorite_category = new Favorite_category();
oTools.CopyPropValues(oDBEntry, oFavorite_category);

oFavorite_category.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oFavorite_category.My_Student);

oFavorite_category.My_Category = new Category();
oTools.CopyPropValues(oDBEntry.My_Category, oFavorite_category.My_Category);

oList.Add(oFavorite_category);
}
}
i_Params_Get_Favorite_category_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Favorite_category_By_Where_Adv");}
return oList;
}
public List<Category> Get_Category_By_Criteria_Adv(Params_Get_Category_By_Criteria i_Params_Get_Category_By_Criteria)
{
List<Category> oList = new List<Category>();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0;
Category oCategory = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Category_By_Criteria_Adv");}
#region Body Section.
if ((i_Params_Get_Category_By_Criteria.OWNER_ID == null) || (i_Params_Get_Category_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Category_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Category_By_Criteria.START_ROW == null) { i_Params_Get_Category_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Category_By_Criteria.END_ROW == null) || (i_Params_Get_Category_By_Criteria.END_ROW == 0)) { i_Params_Get_Category_By_Criteria.END_ROW = 1000000; }
List<DALC.Category> oList_DBEntries = _AppContext.Get_Category_By_Criteria_Adv(i_Params_Get_Category_By_Criteria.NAME,i_Params_Get_Category_By_Criteria.DECRIPTION,i_Params_Get_Category_By_Criteria.OWNER_ID,i_Params_Get_Category_By_Criteria.START_ROW,i_Params_Get_Category_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCategory = new Category();
oTools.CopyPropValues(oDBEntry, oCategory);

oList.Add(oCategory);
}
}
i_Params_Get_Category_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Category_By_Criteria_Adv");}
return oList;
}
public List<Category> Get_Category_By_Where_Adv(Params_Get_Category_By_Where i_Params_Get_Category_By_Where)
{
List<Category> oList = new List<Category>();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0;
Category oCategory = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Category_By_Where_Adv");}
#region Body Section.
if ((i_Params_Get_Category_By_Where.OWNER_ID == null) || (i_Params_Get_Category_By_Where.OWNER_ID == 0)) { i_Params_Get_Category_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Category_By_Where.START_ROW == null) { i_Params_Get_Category_By_Where.START_ROW = 0; }
if ((i_Params_Get_Category_By_Where.END_ROW == null) || (i_Params_Get_Category_By_Where.END_ROW == 0)) { i_Params_Get_Category_By_Where.END_ROW = 1000000; }
List<DALC.Category> oList_DBEntries = _AppContext.Get_Category_By_Where_Adv(i_Params_Get_Category_By_Where.NAME,i_Params_Get_Category_By_Where.DECRIPTION,i_Params_Get_Category_By_Where.OWNER_ID,i_Params_Get_Category_By_Where.START_ROW,i_Params_Get_Category_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oCategory = new Category();
oTools.CopyPropValues(oDBEntry, oCategory);

oList.Add(oCategory);
}
}
i_Params_Get_Category_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Category_By_Where_Adv");}
return oList;
}
public List<Question> Get_Question_By_Criteria_Adv(Params_Get_Question_By_Criteria i_Params_Get_Question_By_Criteria)
{
List<Question> oList = new List<Question>();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0;
Question oQuestion = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Question_By_Criteria_Adv");}
#region Body Section.
if ((i_Params_Get_Question_By_Criteria.OWNER_ID == null) || (i_Params_Get_Question_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Question_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Question_By_Criteria.START_ROW == null) { i_Params_Get_Question_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Question_By_Criteria.END_ROW == null) || (i_Params_Get_Question_By_Criteria.END_ROW == 0)) { i_Params_Get_Question_By_Criteria.END_ROW = 1000000; }
List<DALC.Question> oList_DBEntries = _AppContext.Get_Question_By_Criteria_Adv(i_Params_Get_Question_By_Criteria.DESCRIPTION,i_Params_Get_Question_By_Criteria.OWNER_ID,i_Params_Get_Question_By_Criteria.START_ROW,i_Params_Get_Question_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oQuestion = new Question();
oTools.CopyPropValues(oDBEntry, oQuestion);

oQuestion.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oQuestion.My_Student);

oQuestion.My_Category = new Category();
oTools.CopyPropValues(oDBEntry.My_Category, oQuestion.My_Category);

oQuestion.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oQuestion.My_Teacher);

oList.Add(oQuestion);
}
}
i_Params_Get_Question_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Question_By_Criteria_Adv");}
return oList;
}
public List<Question> Get_Question_By_Where_Adv(Params_Get_Question_By_Where i_Params_Get_Question_By_Where)
{
List<Question> oList = new List<Question>();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0;
Question oQuestion = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Question_By_Where_Adv");}
#region Body Section.
if ((i_Params_Get_Question_By_Where.OWNER_ID == null) || (i_Params_Get_Question_By_Where.OWNER_ID == 0)) { i_Params_Get_Question_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Question_By_Where.START_ROW == null) { i_Params_Get_Question_By_Where.START_ROW = 0; }
if ((i_Params_Get_Question_By_Where.END_ROW == null) || (i_Params_Get_Question_By_Where.END_ROW == 0)) { i_Params_Get_Question_By_Where.END_ROW = 1000000; }
List<DALC.Question> oList_DBEntries = _AppContext.Get_Question_By_Where_Adv(i_Params_Get_Question_By_Where.DESCRIPTION,i_Params_Get_Question_By_Where.OWNER_ID,i_Params_Get_Question_By_Where.START_ROW,i_Params_Get_Question_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oQuestion = new Question();
oTools.CopyPropValues(oDBEntry, oQuestion);

oQuestion.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oQuestion.My_Student);

oQuestion.My_Category = new Category();
oTools.CopyPropValues(oDBEntry.My_Category, oQuestion.My_Category);

oQuestion.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oQuestion.My_Teacher);

oList.Add(oQuestion);
}
}
i_Params_Get_Question_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Question_By_Where_Adv");}
return oList;
}
public List<Report_article> Get_Report_article_By_Criteria_Adv(Params_Get_Report_article_By_Criteria i_Params_Get_Report_article_By_Criteria)
{
List<Report_article> oList = new List<Report_article>();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0;
Report_article oReport_article = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Report_article_By_Criteria_Adv");}
#region Body Section.
if ((i_Params_Get_Report_article_By_Criteria.OWNER_ID == null) || (i_Params_Get_Report_article_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Report_article_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Report_article_By_Criteria.START_ROW == null) { i_Params_Get_Report_article_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Report_article_By_Criteria.END_ROW == null) || (i_Params_Get_Report_article_By_Criteria.END_ROW == 0)) { i_Params_Get_Report_article_By_Criteria.END_ROW = 1000000; }
List<DALC.Report_article> oList_DBEntries = _AppContext.Get_Report_article_By_Criteria_Adv(i_Params_Get_Report_article_By_Criteria.DESCRIPTION,i_Params_Get_Report_article_By_Criteria.OWNER_ID,i_Params_Get_Report_article_By_Criteria.START_ROW,i_Params_Get_Report_article_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oReport_article = new Report_article();
oTools.CopyPropValues(oDBEntry, oReport_article);

oReport_article.My_Article = new Article();
oTools.CopyPropValues(oDBEntry.My_Article, oReport_article.My_Article);

oReport_article.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oReport_article.My_Student);

oList.Add(oReport_article);
}
}
i_Params_Get_Report_article_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Report_article_By_Criteria_Adv");}
return oList;
}
public List<Report_article> Get_Report_article_By_Where_Adv(Params_Get_Report_article_By_Where i_Params_Get_Report_article_By_Where)
{
List<Report_article> oList = new List<Report_article>();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0;
Report_article oReport_article = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Report_article_By_Where_Adv");}
#region Body Section.
if ((i_Params_Get_Report_article_By_Where.OWNER_ID == null) || (i_Params_Get_Report_article_By_Where.OWNER_ID == 0)) { i_Params_Get_Report_article_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Report_article_By_Where.START_ROW == null) { i_Params_Get_Report_article_By_Where.START_ROW = 0; }
if ((i_Params_Get_Report_article_By_Where.END_ROW == null) || (i_Params_Get_Report_article_By_Where.END_ROW == 0)) { i_Params_Get_Report_article_By_Where.END_ROW = 1000000; }
List<DALC.Report_article> oList_DBEntries = _AppContext.Get_Report_article_By_Where_Adv(i_Params_Get_Report_article_By_Where.DESCRIPTION,i_Params_Get_Report_article_By_Where.OWNER_ID,i_Params_Get_Report_article_By_Where.START_ROW,i_Params_Get_Report_article_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oReport_article = new Report_article();
oTools.CopyPropValues(oDBEntry, oReport_article);

oReport_article.My_Article = new Article();
oTools.CopyPropValues(oDBEntry.My_Article, oReport_article.My_Article);

oReport_article.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oReport_article.My_Student);

oList.Add(oReport_article);
}
}
i_Params_Get_Report_article_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Report_article_By_Where_Adv");}
return oList;
}
public List<Mark_question> Get_Mark_question_By_Criteria_Adv(Params_Get_Mark_question_By_Criteria i_Params_Get_Mark_question_By_Criteria)
{
List<Mark_question> oList = new List<Mark_question>();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0;
Mark_question oMark_question = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Mark_question_By_Criteria_Adv");}
#region Body Section.
if ((i_Params_Get_Mark_question_By_Criteria.OWNER_ID == null) || (i_Params_Get_Mark_question_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Mark_question_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Mark_question_By_Criteria.START_ROW == null) { i_Params_Get_Mark_question_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Mark_question_By_Criteria.END_ROW == null) || (i_Params_Get_Mark_question_By_Criteria.END_ROW == 0)) { i_Params_Get_Mark_question_By_Criteria.END_ROW = 1000000; }
List<DALC.Mark_question> oList_DBEntries = _AppContext.Get_Mark_question_By_Criteria_Adv(i_Params_Get_Mark_question_By_Criteria.DESCRIPTION,i_Params_Get_Mark_question_By_Criteria.OWNER_ID,i_Params_Get_Mark_question_By_Criteria.START_ROW,i_Params_Get_Mark_question_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oMark_question = new Mark_question();
oTools.CopyPropValues(oDBEntry, oMark_question);

oMark_question.My_Question = new Question();
oTools.CopyPropValues(oDBEntry.My_Question, oMark_question.My_Question);

oMark_question.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oMark_question.My_Student);

oList.Add(oMark_question);
}
}
i_Params_Get_Mark_question_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Mark_question_By_Criteria_Adv");}
return oList;
}
public List<Mark_question> Get_Mark_question_By_Where_Adv(Params_Get_Mark_question_By_Where i_Params_Get_Mark_question_By_Where)
{
List<Mark_question> oList = new List<Mark_question>();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0;
Mark_question oMark_question = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Mark_question_By_Where_Adv");}
#region Body Section.
if ((i_Params_Get_Mark_question_By_Where.OWNER_ID == null) || (i_Params_Get_Mark_question_By_Where.OWNER_ID == 0)) { i_Params_Get_Mark_question_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Mark_question_By_Where.START_ROW == null) { i_Params_Get_Mark_question_By_Where.START_ROW = 0; }
if ((i_Params_Get_Mark_question_By_Where.END_ROW == null) || (i_Params_Get_Mark_question_By_Where.END_ROW == 0)) { i_Params_Get_Mark_question_By_Where.END_ROW = 1000000; }
List<DALC.Mark_question> oList_DBEntries = _AppContext.Get_Mark_question_By_Where_Adv(i_Params_Get_Mark_question_By_Where.DESCRIPTION,i_Params_Get_Mark_question_By_Where.OWNER_ID,i_Params_Get_Mark_question_By_Where.START_ROW,i_Params_Get_Mark_question_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oMark_question = new Mark_question();
oTools.CopyPropValues(oDBEntry, oMark_question);

oMark_question.My_Question = new Question();
oTools.CopyPropValues(oDBEntry.My_Question, oMark_question.My_Question);

oMark_question.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oMark_question.My_Student);

oList.Add(oMark_question);
}
}
i_Params_Get_Mark_question_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Mark_question_By_Where_Adv");}
return oList;
}
public List<Article> Get_Article_By_Criteria_Adv(Params_Get_Article_By_Criteria i_Params_Get_Article_By_Criteria)
{
List<Article> oList = new List<Article>();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0;
Article oArticle = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Article_By_Criteria_Adv");}
#region Body Section.
if ((i_Params_Get_Article_By_Criteria.OWNER_ID == null) || (i_Params_Get_Article_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Article_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Article_By_Criteria.START_ROW == null) { i_Params_Get_Article_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Article_By_Criteria.END_ROW == null) || (i_Params_Get_Article_By_Criteria.END_ROW == 0)) { i_Params_Get_Article_By_Criteria.END_ROW = 1000000; }
List<DALC.Article> oList_DBEntries = _AppContext.Get_Article_By_Criteria_Adv(i_Params_Get_Article_By_Criteria.TITLE,i_Params_Get_Article_By_Criteria.DESCRIPTION,i_Params_Get_Article_By_Criteria.OWNER_ID,i_Params_Get_Article_By_Criteria.START_ROW,i_Params_Get_Article_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oArticle = new Article();
oTools.CopyPropValues(oDBEntry, oArticle);

oArticle.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oArticle.My_Teacher);

oArticle.My_Category = new Category();
oTools.CopyPropValues(oDBEntry.My_Category, oArticle.My_Category);

oList.Add(oArticle);
}
}
i_Params_Get_Article_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Article_By_Criteria_Adv");}
return oList;
}
public List<Article> Get_Article_By_Where_Adv(Params_Get_Article_By_Where i_Params_Get_Article_By_Where)
{
List<Article> oList = new List<Article>();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0;
Article oArticle = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Article_By_Where_Adv");}
#region Body Section.
if ((i_Params_Get_Article_By_Where.OWNER_ID == null) || (i_Params_Get_Article_By_Where.OWNER_ID == 0)) { i_Params_Get_Article_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Article_By_Where.START_ROW == null) { i_Params_Get_Article_By_Where.START_ROW = 0; }
if ((i_Params_Get_Article_By_Where.END_ROW == null) || (i_Params_Get_Article_By_Where.END_ROW == 0)) { i_Params_Get_Article_By_Where.END_ROW = 1000000; }
List<DALC.Article> oList_DBEntries = _AppContext.Get_Article_By_Where_Adv(i_Params_Get_Article_By_Where.TITLE,i_Params_Get_Article_By_Where.DESCRIPTION,i_Params_Get_Article_By_Where.OWNER_ID,i_Params_Get_Article_By_Where.START_ROW,i_Params_Get_Article_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oArticle = new Article();
oTools.CopyPropValues(oDBEntry, oArticle);

oArticle.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oArticle.My_Teacher);

oArticle.My_Category = new Category();
oTools.CopyPropValues(oDBEntry.My_Category, oArticle.My_Category);

oList.Add(oArticle);
}
}
i_Params_Get_Article_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Article_By_Where_Adv");}
return oList;
}
public List<Answer> Get_Answer_By_Criteria_Adv(Params_Get_Answer_By_Criteria i_Params_Get_Answer_By_Criteria)
{
List<Answer> oList = new List<Answer>();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0;
Answer oAnswer = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Answer_By_Criteria_Adv");}
#region Body Section.
if ((i_Params_Get_Answer_By_Criteria.OWNER_ID == null) || (i_Params_Get_Answer_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Answer_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Answer_By_Criteria.START_ROW == null) { i_Params_Get_Answer_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Answer_By_Criteria.END_ROW == null) || (i_Params_Get_Answer_By_Criteria.END_ROW == 0)) { i_Params_Get_Answer_By_Criteria.END_ROW = 1000000; }
List<DALC.Answer> oList_DBEntries = _AppContext.Get_Answer_By_Criteria_Adv(i_Params_Get_Answer_By_Criteria.DESCRIPTION,i_Params_Get_Answer_By_Criteria.OWNER_ID,i_Params_Get_Answer_By_Criteria.START_ROW,i_Params_Get_Answer_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oAnswer = new Answer();
oTools.CopyPropValues(oDBEntry, oAnswer);

oAnswer.My_Question = new Question();
oTools.CopyPropValues(oDBEntry.My_Question, oAnswer.My_Question);

oAnswer.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oAnswer.My_Teacher);

oList.Add(oAnswer);
}
}
i_Params_Get_Answer_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Answer_By_Criteria_Adv");}
return oList;
}
public List<Answer> Get_Answer_By_Where_Adv(Params_Get_Answer_By_Where i_Params_Get_Answer_By_Where)
{
List<Answer> oList = new List<Answer>();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0;
Answer oAnswer = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Answer_By_Where_Adv");}
#region Body Section.
if ((i_Params_Get_Answer_By_Where.OWNER_ID == null) || (i_Params_Get_Answer_By_Where.OWNER_ID == 0)) { i_Params_Get_Answer_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Answer_By_Where.START_ROW == null) { i_Params_Get_Answer_By_Where.START_ROW = 0; }
if ((i_Params_Get_Answer_By_Where.END_ROW == null) || (i_Params_Get_Answer_By_Where.END_ROW == 0)) { i_Params_Get_Answer_By_Where.END_ROW = 1000000; }
List<DALC.Answer> oList_DBEntries = _AppContext.Get_Answer_By_Where_Adv(i_Params_Get_Answer_By_Where.DESCRIPTION,i_Params_Get_Answer_By_Where.OWNER_ID,i_Params_Get_Answer_By_Where.START_ROW,i_Params_Get_Answer_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oAnswer = new Answer();
oTools.CopyPropValues(oDBEntry, oAnswer);

oAnswer.My_Question = new Question();
oTools.CopyPropValues(oDBEntry.My_Question, oAnswer.My_Question);

oAnswer.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oAnswer.My_Teacher);

oList.Add(oAnswer);
}
}
i_Params_Get_Answer_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Answer_By_Where_Adv");}
return oList;
}
public List<Student> Get_Student_By_Criteria_Adv(Params_Get_Student_By_Criteria i_Params_Get_Student_By_Criteria)
{
List<Student> oList = new List<Student>();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0;
Student oStudent = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Student_By_Criteria_Adv");}
#region Body Section.
if ((i_Params_Get_Student_By_Criteria.OWNER_ID == null) || (i_Params_Get_Student_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Student_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Student_By_Criteria.START_ROW == null) { i_Params_Get_Student_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Student_By_Criteria.END_ROW == null) || (i_Params_Get_Student_By_Criteria.END_ROW == 0)) { i_Params_Get_Student_By_Criteria.END_ROW = 1000000; }
List<DALC.Student> oList_DBEntries = _AppContext.Get_Student_By_Criteria_Adv(i_Params_Get_Student_By_Criteria.FIRST_NAME,i_Params_Get_Student_By_Criteria.LAST_NAME,i_Params_Get_Student_By_Criteria.EMAIL,i_Params_Get_Student_By_Criteria.OWNER_ID,i_Params_Get_Student_By_Criteria.START_ROW,i_Params_Get_Student_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oStudent = new Student();
oTools.CopyPropValues(oDBEntry, oStudent);

oStudent.My_User = new User();
oTools.CopyPropValues(oDBEntry.My_User, oStudent.My_User);

oList.Add(oStudent);
}
}
i_Params_Get_Student_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Student_By_Criteria_Adv");}
return oList;
}
public List<Student> Get_Student_By_Where_Adv(Params_Get_Student_By_Where i_Params_Get_Student_By_Where)
{
List<Student> oList = new List<Student>();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0;
Student oStudent = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Student_By_Where_Adv");}
#region Body Section.
if ((i_Params_Get_Student_By_Where.OWNER_ID == null) || (i_Params_Get_Student_By_Where.OWNER_ID == 0)) { i_Params_Get_Student_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Student_By_Where.START_ROW == null) { i_Params_Get_Student_By_Where.START_ROW = 0; }
if ((i_Params_Get_Student_By_Where.END_ROW == null) || (i_Params_Get_Student_By_Where.END_ROW == 0)) { i_Params_Get_Student_By_Where.END_ROW = 1000000; }
List<DALC.Student> oList_DBEntries = _AppContext.Get_Student_By_Where_Adv(i_Params_Get_Student_By_Where.FIRST_NAME,i_Params_Get_Student_By_Where.LAST_NAME,i_Params_Get_Student_By_Where.EMAIL,i_Params_Get_Student_By_Where.OWNER_ID,i_Params_Get_Student_By_Where.START_ROW,i_Params_Get_Student_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oStudent = new Student();
oTools.CopyPropValues(oDBEntry, oStudent);

oStudent.My_User = new User();
oTools.CopyPropValues(oDBEntry.My_User, oStudent.My_User);

oList.Add(oStudent);
}
}
i_Params_Get_Student_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Student_By_Where_Adv");}
return oList;
}
public List<Notification> Get_Notification_By_Criteria_Adv(Params_Get_Notification_By_Criteria i_Params_Get_Notification_By_Criteria)
{
List<Notification> oList = new List<Notification>();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0;
Notification oNotification = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Notification_By_Criteria_Adv");}
#region Body Section.
if ((i_Params_Get_Notification_By_Criteria.OWNER_ID == null) || (i_Params_Get_Notification_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Notification_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Notification_By_Criteria.START_ROW == null) { i_Params_Get_Notification_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Notification_By_Criteria.END_ROW == null) || (i_Params_Get_Notification_By_Criteria.END_ROW == 0)) { i_Params_Get_Notification_By_Criteria.END_ROW = 1000000; }
List<DALC.Notification> oList_DBEntries = _AppContext.Get_Notification_By_Criteria_Adv(i_Params_Get_Notification_By_Criteria.DESCRIPTION,i_Params_Get_Notification_By_Criteria.OWNER_ID,i_Params_Get_Notification_By_Criteria.START_ROW,i_Params_Get_Notification_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oNotification = new Notification();
oTools.CopyPropValues(oDBEntry, oNotification);

oNotification.My_User = new User();
oTools.CopyPropValues(oDBEntry.My_User, oNotification.My_User);

oNotification.My_Question = new Question();
oTools.CopyPropValues(oDBEntry.My_Question, oNotification.My_Question);

oNotification.My_Answer = new Answer();
oTools.CopyPropValues(oDBEntry.My_Answer, oNotification.My_Answer);

oNotification.My_Article = new Article();
oTools.CopyPropValues(oDBEntry.My_Article, oNotification.My_Article);

oList.Add(oNotification);
}
}
i_Params_Get_Notification_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Notification_By_Criteria_Adv");}
return oList;
}
public List<Notification> Get_Notification_By_Where_Adv(Params_Get_Notification_By_Where i_Params_Get_Notification_By_Where)
{
List<Notification> oList = new List<Notification>();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0;
Notification oNotification = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Notification_By_Where_Adv");}
#region Body Section.
if ((i_Params_Get_Notification_By_Where.OWNER_ID == null) || (i_Params_Get_Notification_By_Where.OWNER_ID == 0)) { i_Params_Get_Notification_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Notification_By_Where.START_ROW == null) { i_Params_Get_Notification_By_Where.START_ROW = 0; }
if ((i_Params_Get_Notification_By_Where.END_ROW == null) || (i_Params_Get_Notification_By_Where.END_ROW == 0)) { i_Params_Get_Notification_By_Where.END_ROW = 1000000; }
List<DALC.Notification> oList_DBEntries = _AppContext.Get_Notification_By_Where_Adv(i_Params_Get_Notification_By_Where.DESCRIPTION,i_Params_Get_Notification_By_Where.OWNER_ID,i_Params_Get_Notification_By_Where.START_ROW,i_Params_Get_Notification_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oNotification = new Notification();
oTools.CopyPropValues(oDBEntry, oNotification);

oNotification.My_User = new User();
oTools.CopyPropValues(oDBEntry.My_User, oNotification.My_User);

oNotification.My_Question = new Question();
oTools.CopyPropValues(oDBEntry.My_Question, oNotification.My_Question);

oNotification.My_Answer = new Answer();
oTools.CopyPropValues(oDBEntry.My_Answer, oNotification.My_Answer);

oNotification.My_Article = new Article();
oTools.CopyPropValues(oDBEntry.My_Article, oNotification.My_Article);

oList.Add(oNotification);
}
}
i_Params_Get_Notification_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Notification_By_Where_Adv");}
return oList;
}
public List<User> Get_User_By_Criteria_Adv(Params_Get_User_By_Criteria i_Params_Get_User_By_Criteria)
{
List<User> oList = new List<User>();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0;
User oUser = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_User_By_Criteria_Adv");}
#region Body Section.
if ((i_Params_Get_User_By_Criteria.OWNER_ID == null) || (i_Params_Get_User_By_Criteria.OWNER_ID == 0)) { i_Params_Get_User_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_User_By_Criteria.START_ROW == null) { i_Params_Get_User_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_User_By_Criteria.END_ROW == null) || (i_Params_Get_User_By_Criteria.END_ROW == 0)) { i_Params_Get_User_By_Criteria.END_ROW = 1000000; }
List<DALC.User> oList_DBEntries = _AppContext.Get_User_By_Criteria_Adv(i_Params_Get_User_By_Criteria.USERNAME,i_Params_Get_User_By_Criteria.PASSWORD,i_Params_Get_User_By_Criteria.USER_TYPE_CODE,i_Params_Get_User_By_Criteria.OWNER_ID,i_Params_Get_User_By_Criteria.START_ROW,i_Params_Get_User_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oUser = new User();
oTools.CopyPropValues(oDBEntry, oUser);

oList.Add(oUser);
}
}
i_Params_Get_User_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_User_By_Criteria_Adv");}
return oList;
}
public List<User> Get_User_By_Where_Adv(Params_Get_User_By_Where i_Params_Get_User_By_Where)
{
List<User> oList = new List<User>();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0;
User oUser = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_User_By_Where_Adv");}
#region Body Section.
if ((i_Params_Get_User_By_Where.OWNER_ID == null) || (i_Params_Get_User_By_Where.OWNER_ID == 0)) { i_Params_Get_User_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_User_By_Where.START_ROW == null) { i_Params_Get_User_By_Where.START_ROW = 0; }
if ((i_Params_Get_User_By_Where.END_ROW == null) || (i_Params_Get_User_By_Where.END_ROW == 0)) { i_Params_Get_User_By_Where.END_ROW = 1000000; }
List<DALC.User> oList_DBEntries = _AppContext.Get_User_By_Where_Adv(i_Params_Get_User_By_Where.USERNAME,i_Params_Get_User_By_Where.PASSWORD,i_Params_Get_User_By_Where.USER_TYPE_CODE,i_Params_Get_User_By_Where.OWNER_ID,i_Params_Get_User_By_Where.START_ROW,i_Params_Get_User_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oUser = new User();
oTools.CopyPropValues(oDBEntry, oUser);

oList.Add(oUser);
}
}
i_Params_Get_User_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_User_By_Where_Adv");}
return oList;
}
public List<Evaluation> Get_Evaluation_By_Criteria_Adv(Params_Get_Evaluation_By_Criteria i_Params_Get_Evaluation_By_Criteria)
{
List<Evaluation> oList = new List<Evaluation>();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0;
Evaluation oEvaluation = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Evaluation_By_Criteria_Adv");}
#region Body Section.
if ((i_Params_Get_Evaluation_By_Criteria.OWNER_ID == null) || (i_Params_Get_Evaluation_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Evaluation_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Evaluation_By_Criteria.START_ROW == null) { i_Params_Get_Evaluation_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Evaluation_By_Criteria.END_ROW == null) || (i_Params_Get_Evaluation_By_Criteria.END_ROW == 0)) { i_Params_Get_Evaluation_By_Criteria.END_ROW = 1000000; }
List<DALC.Evaluation> oList_DBEntries = _AppContext.Get_Evaluation_By_Criteria_Adv(i_Params_Get_Evaluation_By_Criteria.DESCRIPTION,i_Params_Get_Evaluation_By_Criteria.OWNER_ID,i_Params_Get_Evaluation_By_Criteria.START_ROW,i_Params_Get_Evaluation_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oEvaluation = new Evaluation();
oTools.CopyPropValues(oDBEntry, oEvaluation);

oEvaluation.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oEvaluation.My_Student);

oEvaluation.My_Answer = new Answer();
oTools.CopyPropValues(oDBEntry.My_Answer, oEvaluation.My_Answer);

oList.Add(oEvaluation);
}
}
i_Params_Get_Evaluation_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Evaluation_By_Criteria_Adv");}
return oList;
}
public List<Evaluation> Get_Evaluation_By_Where_Adv(Params_Get_Evaluation_By_Where i_Params_Get_Evaluation_By_Where)
{
List<Evaluation> oList = new List<Evaluation>();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0;
Evaluation oEvaluation = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Evaluation_By_Where_Adv");}
#region Body Section.
if ((i_Params_Get_Evaluation_By_Where.OWNER_ID == null) || (i_Params_Get_Evaluation_By_Where.OWNER_ID == 0)) { i_Params_Get_Evaluation_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Evaluation_By_Where.START_ROW == null) { i_Params_Get_Evaluation_By_Where.START_ROW = 0; }
if ((i_Params_Get_Evaluation_By_Where.END_ROW == null) || (i_Params_Get_Evaluation_By_Where.END_ROW == 0)) { i_Params_Get_Evaluation_By_Where.END_ROW = 1000000; }
List<DALC.Evaluation> oList_DBEntries = _AppContext.Get_Evaluation_By_Where_Adv(i_Params_Get_Evaluation_By_Where.DESCRIPTION,i_Params_Get_Evaluation_By_Where.OWNER_ID,i_Params_Get_Evaluation_By_Where.START_ROW,i_Params_Get_Evaluation_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oEvaluation = new Evaluation();
oTools.CopyPropValues(oDBEntry, oEvaluation);

oEvaluation.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oEvaluation.My_Student);

oEvaluation.My_Answer = new Answer();
oTools.CopyPropValues(oDBEntry.My_Answer, oEvaluation.My_Answer);

oList.Add(oEvaluation);
}
}
i_Params_Get_Evaluation_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Evaluation_By_Where_Adv");}
return oList;
}
public List<Student_report> Get_Student_report_By_Criteria_Adv(Params_Get_Student_report_By_Criteria i_Params_Get_Student_report_By_Criteria)
{
List<Student_report> oList = new List<Student_report>();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0;
Student_report oStudent_report = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Student_report_By_Criteria_Adv");}
#region Body Section.
if ((i_Params_Get_Student_report_By_Criteria.OWNER_ID == null) || (i_Params_Get_Student_report_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Student_report_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Student_report_By_Criteria.START_ROW == null) { i_Params_Get_Student_report_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Student_report_By_Criteria.END_ROW == null) || (i_Params_Get_Student_report_By_Criteria.END_ROW == 0)) { i_Params_Get_Student_report_By_Criteria.END_ROW = 1000000; }
List<DALC.Student_report> oList_DBEntries = _AppContext.Get_Student_report_By_Criteria_Adv(i_Params_Get_Student_report_By_Criteria.DESCRIPTION,i_Params_Get_Student_report_By_Criteria.OWNER_ID,i_Params_Get_Student_report_By_Criteria.START_ROW,i_Params_Get_Student_report_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oStudent_report = new Student_report();
oTools.CopyPropValues(oDBEntry, oStudent_report);

oStudent_report.My_Reported_by_student = new Student();
oTools.CopyPropValues(oDBEntry.My_Reported_by_student, oStudent_report.My_Reported_by_student);

oStudent_report.My_Reported_student = new Student();
oTools.CopyPropValues(oDBEntry.My_Reported_student, oStudent_report.My_Reported_student);

oList.Add(oStudent_report);
}
}
i_Params_Get_Student_report_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Student_report_By_Criteria_Adv");}
return oList;
}
public List<Student_report> Get_Student_report_By_Where_Adv(Params_Get_Student_report_By_Where i_Params_Get_Student_report_By_Where)
{
List<Student_report> oList = new List<Student_report>();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0;
Student_report oStudent_report = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Student_report_By_Where_Adv");}
#region Body Section.
if ((i_Params_Get_Student_report_By_Where.OWNER_ID == null) || (i_Params_Get_Student_report_By_Where.OWNER_ID == 0)) { i_Params_Get_Student_report_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Student_report_By_Where.START_ROW == null) { i_Params_Get_Student_report_By_Where.START_ROW = 0; }
if ((i_Params_Get_Student_report_By_Where.END_ROW == null) || (i_Params_Get_Student_report_By_Where.END_ROW == 0)) { i_Params_Get_Student_report_By_Where.END_ROW = 1000000; }
List<DALC.Student_report> oList_DBEntries = _AppContext.Get_Student_report_By_Where_Adv(i_Params_Get_Student_report_By_Where.DESCRIPTION,i_Params_Get_Student_report_By_Where.OWNER_ID,i_Params_Get_Student_report_By_Where.START_ROW,i_Params_Get_Student_report_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oStudent_report = new Student_report();
oTools.CopyPropValues(oDBEntry, oStudent_report);

oStudent_report.My_Reported_by_student = new Student();
oTools.CopyPropValues(oDBEntry.My_Reported_by_student, oStudent_report.My_Reported_by_student);

oStudent_report.My_Reported_student = new Student();
oTools.CopyPropValues(oDBEntry.My_Reported_student, oStudent_report.My_Reported_student);

oList.Add(oStudent_report);
}
}
i_Params_Get_Student_report_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Student_report_By_Where_Adv");}
return oList;
}
public List<Appreciate> Get_Appreciate_By_Criteria_Adv(Params_Get_Appreciate_By_Criteria i_Params_Get_Appreciate_By_Criteria)
{
List<Appreciate> oList = new List<Appreciate>();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0;
Appreciate oAppreciate = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Appreciate_By_Criteria_Adv");}
#region Body Section.
if ((i_Params_Get_Appreciate_By_Criteria.OWNER_ID == null) || (i_Params_Get_Appreciate_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Appreciate_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Appreciate_By_Criteria.START_ROW == null) { i_Params_Get_Appreciate_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Appreciate_By_Criteria.END_ROW == null) || (i_Params_Get_Appreciate_By_Criteria.END_ROW == 0)) { i_Params_Get_Appreciate_By_Criteria.END_ROW = 1000000; }
List<DALC.Appreciate> oList_DBEntries = _AppContext.Get_Appreciate_By_Criteria_Adv(i_Params_Get_Appreciate_By_Criteria.DESCRIPTION,i_Params_Get_Appreciate_By_Criteria.OWNER_ID,i_Params_Get_Appreciate_By_Criteria.START_ROW,i_Params_Get_Appreciate_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oAppreciate = new Appreciate();
oTools.CopyPropValues(oDBEntry, oAppreciate);

oAppreciate.My_Article = new Article();
oTools.CopyPropValues(oDBEntry.My_Article, oAppreciate.My_Article);

oAppreciate.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oAppreciate.My_Student);

oList.Add(oAppreciate);
}
}
i_Params_Get_Appreciate_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Appreciate_By_Criteria_Adv");}
return oList;
}
public List<Appreciate> Get_Appreciate_By_Where_Adv(Params_Get_Appreciate_By_Where i_Params_Get_Appreciate_By_Where)
{
List<Appreciate> oList = new List<Appreciate>();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0;
Appreciate oAppreciate = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Appreciate_By_Where_Adv");}
#region Body Section.
if ((i_Params_Get_Appreciate_By_Where.OWNER_ID == null) || (i_Params_Get_Appreciate_By_Where.OWNER_ID == 0)) { i_Params_Get_Appreciate_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Appreciate_By_Where.START_ROW == null) { i_Params_Get_Appreciate_By_Where.START_ROW = 0; }
if ((i_Params_Get_Appreciate_By_Where.END_ROW == null) || (i_Params_Get_Appreciate_By_Where.END_ROW == 0)) { i_Params_Get_Appreciate_By_Where.END_ROW = 1000000; }
List<DALC.Appreciate> oList_DBEntries = _AppContext.Get_Appreciate_By_Where_Adv(i_Params_Get_Appreciate_By_Where.DESCRIPTION,i_Params_Get_Appreciate_By_Where.OWNER_ID,i_Params_Get_Appreciate_By_Where.START_ROW,i_Params_Get_Appreciate_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oAppreciate = new Appreciate();
oTools.CopyPropValues(oDBEntry, oAppreciate);

oAppreciate.My_Article = new Article();
oTools.CopyPropValues(oDBEntry.My_Article, oAppreciate.My_Article);

oAppreciate.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oAppreciate.My_Student);

oList.Add(oAppreciate);
}
}
i_Params_Get_Appreciate_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Appreciate_By_Where_Adv");}
return oList;
}
public List<Teacher_report> Get_Teacher_report_By_Criteria_Adv(Params_Get_Teacher_report_By_Criteria i_Params_Get_Teacher_report_By_Criteria)
{
List<Teacher_report> oList = new List<Teacher_report>();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0;
Teacher_report oTeacher_report = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_report_By_Criteria_Adv");}
#region Body Section.
if ((i_Params_Get_Teacher_report_By_Criteria.OWNER_ID == null) || (i_Params_Get_Teacher_report_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Teacher_report_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Teacher_report_By_Criteria.START_ROW == null) { i_Params_Get_Teacher_report_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Teacher_report_By_Criteria.END_ROW == null) || (i_Params_Get_Teacher_report_By_Criteria.END_ROW == 0)) { i_Params_Get_Teacher_report_By_Criteria.END_ROW = 1000000; }
List<DALC.Teacher_report> oList_DBEntries = _AppContext.Get_Teacher_report_By_Criteria_Adv(i_Params_Get_Teacher_report_By_Criteria.DESCRIPTION,i_Params_Get_Teacher_report_By_Criteria.OWNER_ID,i_Params_Get_Teacher_report_By_Criteria.START_ROW,i_Params_Get_Teacher_report_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_report = new Teacher_report();
oTools.CopyPropValues(oDBEntry, oTeacher_report);

oTeacher_report.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oTeacher_report.My_Teacher);

oTeacher_report.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oTeacher_report.My_Student);

oList.Add(oTeacher_report);
}
}
i_Params_Get_Teacher_report_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_report_By_Criteria_Adv");}
return oList;
}
public List<Teacher_report> Get_Teacher_report_By_Where_Adv(Params_Get_Teacher_report_By_Where i_Params_Get_Teacher_report_By_Where)
{
List<Teacher_report> oList = new List<Teacher_report>();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0;
Teacher_report oTeacher_report = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_report_By_Where_Adv");}
#region Body Section.
if ((i_Params_Get_Teacher_report_By_Where.OWNER_ID == null) || (i_Params_Get_Teacher_report_By_Where.OWNER_ID == 0)) { i_Params_Get_Teacher_report_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Teacher_report_By_Where.START_ROW == null) { i_Params_Get_Teacher_report_By_Where.START_ROW = 0; }
if ((i_Params_Get_Teacher_report_By_Where.END_ROW == null) || (i_Params_Get_Teacher_report_By_Where.END_ROW == 0)) { i_Params_Get_Teacher_report_By_Where.END_ROW = 1000000; }
List<DALC.Teacher_report> oList_DBEntries = _AppContext.Get_Teacher_report_By_Where_Adv(i_Params_Get_Teacher_report_By_Where.DESCRIPTION,i_Params_Get_Teacher_report_By_Where.OWNER_ID,i_Params_Get_Teacher_report_By_Where.START_ROW,i_Params_Get_Teacher_report_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_report = new Teacher_report();
oTools.CopyPropValues(oDBEntry, oTeacher_report);

oTeacher_report.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oTeacher_report.My_Teacher);

oTeacher_report.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oTeacher_report.My_Student);

oList.Add(oTeacher_report);
}
}
i_Params_Get_Teacher_report_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_report_By_Where_Adv");}
return oList;
}
public List<Question_report> Get_Question_report_By_Criteria_Adv(Params_Get_Question_report_By_Criteria i_Params_Get_Question_report_By_Criteria)
{
List<Question_report> oList = new List<Question_report>();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0;
Question_report oQuestion_report = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Question_report_By_Criteria_Adv");}
#region Body Section.
if ((i_Params_Get_Question_report_By_Criteria.OWNER_ID == null) || (i_Params_Get_Question_report_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Question_report_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Question_report_By_Criteria.START_ROW == null) { i_Params_Get_Question_report_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Question_report_By_Criteria.END_ROW == null) || (i_Params_Get_Question_report_By_Criteria.END_ROW == 0)) { i_Params_Get_Question_report_By_Criteria.END_ROW = 1000000; }
List<DALC.Question_report> oList_DBEntries = _AppContext.Get_Question_report_By_Criteria_Adv(i_Params_Get_Question_report_By_Criteria.DESCRIPTION,i_Params_Get_Question_report_By_Criteria.OWNER_ID,i_Params_Get_Question_report_By_Criteria.START_ROW,i_Params_Get_Question_report_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oQuestion_report = new Question_report();
oTools.CopyPropValues(oDBEntry, oQuestion_report);

oQuestion_report.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oQuestion_report.My_Student);

oQuestion_report.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oQuestion_report.My_Teacher);

oQuestion_report.My_Question = new Question();
oTools.CopyPropValues(oDBEntry.My_Question, oQuestion_report.My_Question);

oList.Add(oQuestion_report);
}
}
i_Params_Get_Question_report_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Question_report_By_Criteria_Adv");}
return oList;
}
public List<Question_report> Get_Question_report_By_Where_Adv(Params_Get_Question_report_By_Where i_Params_Get_Question_report_By_Where)
{
List<Question_report> oList = new List<Question_report>();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0;
Question_report oQuestion_report = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Question_report_By_Where_Adv");}
#region Body Section.
if ((i_Params_Get_Question_report_By_Where.OWNER_ID == null) || (i_Params_Get_Question_report_By_Where.OWNER_ID == 0)) { i_Params_Get_Question_report_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Question_report_By_Where.START_ROW == null) { i_Params_Get_Question_report_By_Where.START_ROW = 0; }
if ((i_Params_Get_Question_report_By_Where.END_ROW == null) || (i_Params_Get_Question_report_By_Where.END_ROW == 0)) { i_Params_Get_Question_report_By_Where.END_ROW = 1000000; }
List<DALC.Question_report> oList_DBEntries = _AppContext.Get_Question_report_By_Where_Adv(i_Params_Get_Question_report_By_Where.DESCRIPTION,i_Params_Get_Question_report_By_Where.OWNER_ID,i_Params_Get_Question_report_By_Where.START_ROW,i_Params_Get_Question_report_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oQuestion_report = new Question_report();
oTools.CopyPropValues(oDBEntry, oQuestion_report);

oQuestion_report.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oQuestion_report.My_Student);

oQuestion_report.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oQuestion_report.My_Teacher);

oQuestion_report.My_Question = new Question();
oTools.CopyPropValues(oDBEntry.My_Question, oQuestion_report.My_Question);

oList.Add(oQuestion_report);
}
}
i_Params_Get_Question_report_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Question_report_By_Where_Adv");}
return oList;
}
public List<Answer_report> Get_Answer_report_By_Criteria_Adv(Params_Get_Answer_report_By_Criteria i_Params_Get_Answer_report_By_Criteria)
{
List<Answer_report> oList = new List<Answer_report>();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0;
Answer_report oAnswer_report = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Answer_report_By_Criteria_Adv");}
#region Body Section.
if ((i_Params_Get_Answer_report_By_Criteria.OWNER_ID == null) || (i_Params_Get_Answer_report_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Answer_report_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Answer_report_By_Criteria.START_ROW == null) { i_Params_Get_Answer_report_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Answer_report_By_Criteria.END_ROW == null) || (i_Params_Get_Answer_report_By_Criteria.END_ROW == 0)) { i_Params_Get_Answer_report_By_Criteria.END_ROW = 1000000; }
List<DALC.Answer_report> oList_DBEntries = _AppContext.Get_Answer_report_By_Criteria_Adv(i_Params_Get_Answer_report_By_Criteria.DESCRIPTION,i_Params_Get_Answer_report_By_Criteria.OWNER_ID,i_Params_Get_Answer_report_By_Criteria.START_ROW,i_Params_Get_Answer_report_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oAnswer_report = new Answer_report();
oTools.CopyPropValues(oDBEntry, oAnswer_report);

oAnswer_report.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oAnswer_report.My_Teacher);

oAnswer_report.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oAnswer_report.My_Student);

oAnswer_report.My_Answer = new Answer();
oTools.CopyPropValues(oDBEntry.My_Answer, oAnswer_report.My_Answer);

oList.Add(oAnswer_report);
}
}
i_Params_Get_Answer_report_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Answer_report_By_Criteria_Adv");}
return oList;
}
public List<Answer_report> Get_Answer_report_By_Where_Adv(Params_Get_Answer_report_By_Where i_Params_Get_Answer_report_By_Where)
{
List<Answer_report> oList = new List<Answer_report>();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0;
Answer_report oAnswer_report = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Answer_report_By_Where_Adv");}
#region Body Section.
if ((i_Params_Get_Answer_report_By_Where.OWNER_ID == null) || (i_Params_Get_Answer_report_By_Where.OWNER_ID == 0)) { i_Params_Get_Answer_report_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Answer_report_By_Where.START_ROW == null) { i_Params_Get_Answer_report_By_Where.START_ROW = 0; }
if ((i_Params_Get_Answer_report_By_Where.END_ROW == null) || (i_Params_Get_Answer_report_By_Where.END_ROW == 0)) { i_Params_Get_Answer_report_By_Where.END_ROW = 1000000; }
List<DALC.Answer_report> oList_DBEntries = _AppContext.Get_Answer_report_By_Where_Adv(i_Params_Get_Answer_report_By_Where.DESCRIPTION,i_Params_Get_Answer_report_By_Where.OWNER_ID,i_Params_Get_Answer_report_By_Where.START_ROW,i_Params_Get_Answer_report_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oAnswer_report = new Answer_report();
oTools.CopyPropValues(oDBEntry, oAnswer_report);

oAnswer_report.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oAnswer_report.My_Teacher);

oAnswer_report.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oAnswer_report.My_Student);

oAnswer_report.My_Answer = new Answer();
oTools.CopyPropValues(oDBEntry.My_Answer, oAnswer_report.My_Answer);

oList.Add(oAnswer_report);
}
}
i_Params_Get_Answer_report_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Answer_report_By_Where_Adv");}
return oList;
}
public List<Teacher_rank> Get_Teacher_rank_By_Criteria_Adv(Params_Get_Teacher_rank_By_Criteria i_Params_Get_Teacher_rank_By_Criteria)
{
List<Teacher_rank> oList = new List<Teacher_rank>();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0;
Teacher_rank oTeacher_rank = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_rank_By_Criteria_Adv");}
#region Body Section.
if ((i_Params_Get_Teacher_rank_By_Criteria.OWNER_ID == null) || (i_Params_Get_Teacher_rank_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Teacher_rank_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Teacher_rank_By_Criteria.START_ROW == null) { i_Params_Get_Teacher_rank_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Teacher_rank_By_Criteria.END_ROW == null) || (i_Params_Get_Teacher_rank_By_Criteria.END_ROW == 0)) { i_Params_Get_Teacher_rank_By_Criteria.END_ROW = 1000000; }
List<DALC.Teacher_rank> oList_DBEntries = _AppContext.Get_Teacher_rank_By_Criteria_Adv(i_Params_Get_Teacher_rank_By_Criteria.DESCRIPTION,i_Params_Get_Teacher_rank_By_Criteria.OWNER_ID,i_Params_Get_Teacher_rank_By_Criteria.START_ROW,i_Params_Get_Teacher_rank_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_rank = new Teacher_rank();
oTools.CopyPropValues(oDBEntry, oTeacher_rank);

oTeacher_rank.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oTeacher_rank.My_Teacher);

oList.Add(oTeacher_rank);
}
}
i_Params_Get_Teacher_rank_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_rank_By_Criteria_Adv");}
return oList;
}
public List<Teacher_rank> Get_Teacher_rank_By_Where_Adv(Params_Get_Teacher_rank_By_Where i_Params_Get_Teacher_rank_By_Where)
{
List<Teacher_rank> oList = new List<Teacher_rank>();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0;
Teacher_rank oTeacher_rank = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_rank_By_Where_Adv");}
#region Body Section.
if ((i_Params_Get_Teacher_rank_By_Where.OWNER_ID == null) || (i_Params_Get_Teacher_rank_By_Where.OWNER_ID == 0)) { i_Params_Get_Teacher_rank_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Teacher_rank_By_Where.START_ROW == null) { i_Params_Get_Teacher_rank_By_Where.START_ROW = 0; }
if ((i_Params_Get_Teacher_rank_By_Where.END_ROW == null) || (i_Params_Get_Teacher_rank_By_Where.END_ROW == 0)) { i_Params_Get_Teacher_rank_By_Where.END_ROW = 1000000; }
List<DALC.Teacher_rank> oList_DBEntries = _AppContext.Get_Teacher_rank_By_Where_Adv(i_Params_Get_Teacher_rank_By_Where.DESCRIPTION,i_Params_Get_Teacher_rank_By_Where.OWNER_ID,i_Params_Get_Teacher_rank_By_Where.START_ROW,i_Params_Get_Teacher_rank_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_rank = new Teacher_rank();
oTools.CopyPropValues(oDBEntry, oTeacher_rank);

oTeacher_rank.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oTeacher_rank.My_Teacher);

oList.Add(oTeacher_rank);
}
}
i_Params_Get_Teacher_rank_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_rank_By_Where_Adv");}
return oList;
}
public List<Teacher> Get_Teacher_By_Criteria_Adv(Params_Get_Teacher_By_Criteria i_Params_Get_Teacher_By_Criteria)
{
List<Teacher> oList = new List<Teacher>();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0;
Teacher oTeacher = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_By_Criteria_Adv");}
#region Body Section.
if ((i_Params_Get_Teacher_By_Criteria.OWNER_ID == null) || (i_Params_Get_Teacher_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Teacher_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Teacher_By_Criteria.START_ROW == null) { i_Params_Get_Teacher_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Teacher_By_Criteria.END_ROW == null) || (i_Params_Get_Teacher_By_Criteria.END_ROW == 0)) { i_Params_Get_Teacher_By_Criteria.END_ROW = 1000000; }
List<DALC.Teacher> oList_DBEntries = _AppContext.Get_Teacher_By_Criteria_Adv(i_Params_Get_Teacher_By_Criteria.FIRST_NAME,i_Params_Get_Teacher_By_Criteria.LAST_NAME,i_Params_Get_Teacher_By_Criteria.DESCRIPTION,i_Params_Get_Teacher_By_Criteria.EMAIL,i_Params_Get_Teacher_By_Criteria.MOBILE,i_Params_Get_Teacher_By_Criteria.OWNER_ID,i_Params_Get_Teacher_By_Criteria.START_ROW,i_Params_Get_Teacher_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher = new Teacher();
oTools.CopyPropValues(oDBEntry, oTeacher);

oTeacher.My_User = new User();
oTools.CopyPropValues(oDBEntry.My_User, oTeacher.My_User);

oList.Add(oTeacher);
}
}
i_Params_Get_Teacher_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_By_Criteria_Adv");}
return oList;
}
public List<Teacher> Get_Teacher_By_Where_Adv(Params_Get_Teacher_By_Where i_Params_Get_Teacher_By_Where)
{
List<Teacher> oList = new List<Teacher>();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0;
Teacher oTeacher = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_By_Where_Adv");}
#region Body Section.
if ((i_Params_Get_Teacher_By_Where.OWNER_ID == null) || (i_Params_Get_Teacher_By_Where.OWNER_ID == 0)) { i_Params_Get_Teacher_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Teacher_By_Where.START_ROW == null) { i_Params_Get_Teacher_By_Where.START_ROW = 0; }
if ((i_Params_Get_Teacher_By_Where.END_ROW == null) || (i_Params_Get_Teacher_By_Where.END_ROW == 0)) { i_Params_Get_Teacher_By_Where.END_ROW = 1000000; }
List<DALC.Teacher> oList_DBEntries = _AppContext.Get_Teacher_By_Where_Adv(i_Params_Get_Teacher_By_Where.FIRST_NAME,i_Params_Get_Teacher_By_Where.LAST_NAME,i_Params_Get_Teacher_By_Where.DESCRIPTION,i_Params_Get_Teacher_By_Where.EMAIL,i_Params_Get_Teacher_By_Where.MOBILE,i_Params_Get_Teacher_By_Where.OWNER_ID,i_Params_Get_Teacher_By_Where.START_ROW,i_Params_Get_Teacher_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher = new Teacher();
oTools.CopyPropValues(oDBEntry, oTeacher);

oTeacher.My_User = new User();
oTools.CopyPropValues(oDBEntry.My_User, oTeacher.My_User);

oList.Add(oTeacher);
}
}
i_Params_Get_Teacher_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_By_Where_Adv");}
return oList;
}
public List<Question_token> Get_Question_token_By_Criteria_Adv(Params_Get_Question_token_By_Criteria i_Params_Get_Question_token_By_Criteria)
{
List<Question_token> oList = new List<Question_token>();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0;
Question_token oQuestion_token = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Question_token_By_Criteria_Adv");}
#region Body Section.
if ((i_Params_Get_Question_token_By_Criteria.OWNER_ID == null) || (i_Params_Get_Question_token_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Question_token_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Question_token_By_Criteria.START_ROW == null) { i_Params_Get_Question_token_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Question_token_By_Criteria.END_ROW == null) || (i_Params_Get_Question_token_By_Criteria.END_ROW == 0)) { i_Params_Get_Question_token_By_Criteria.END_ROW = 1000000; }
List<DALC.Question_token> oList_DBEntries = _AppContext.Get_Question_token_By_Criteria_Adv(i_Params_Get_Question_token_By_Criteria.PART,i_Params_Get_Question_token_By_Criteria.OWNER_ID,i_Params_Get_Question_token_By_Criteria.START_ROW,i_Params_Get_Question_token_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oQuestion_token = new Question_token();
oTools.CopyPropValues(oDBEntry, oQuestion_token);

oQuestion_token.My_Question = new Question();
oTools.CopyPropValues(oDBEntry.My_Question, oQuestion_token.My_Question);

oList.Add(oQuestion_token);
}
}
i_Params_Get_Question_token_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Question_token_By_Criteria_Adv");}
return oList;
}
public List<Question_token> Get_Question_token_By_Where_Adv(Params_Get_Question_token_By_Where i_Params_Get_Question_token_By_Where)
{
List<Question_token> oList = new List<Question_token>();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0;
Question_token oQuestion_token = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Question_token_By_Where_Adv");}
#region Body Section.
if ((i_Params_Get_Question_token_By_Where.OWNER_ID == null) || (i_Params_Get_Question_token_By_Where.OWNER_ID == 0)) { i_Params_Get_Question_token_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Question_token_By_Where.START_ROW == null) { i_Params_Get_Question_token_By_Where.START_ROW = 0; }
if ((i_Params_Get_Question_token_By_Where.END_ROW == null) || (i_Params_Get_Question_token_By_Where.END_ROW == 0)) { i_Params_Get_Question_token_By_Where.END_ROW = 1000000; }
List<DALC.Question_token> oList_DBEntries = _AppContext.Get_Question_token_By_Where_Adv(i_Params_Get_Question_token_By_Where.PART,i_Params_Get_Question_token_By_Where.OWNER_ID,i_Params_Get_Question_token_By_Where.START_ROW,i_Params_Get_Question_token_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oQuestion_token = new Question_token();
oTools.CopyPropValues(oDBEntry, oQuestion_token);

oQuestion_token.My_Question = new Question();
oTools.CopyPropValues(oDBEntry.My_Question, oQuestion_token.My_Question);

oList.Add(oQuestion_token);
}
}
i_Params_Get_Question_token_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Question_token_By_Where_Adv");}
return oList;
}
public List<Teacher_category> Get_Teacher_category_By_Criteria_Adv(Params_Get_Teacher_category_By_Criteria i_Params_Get_Teacher_category_By_Criteria)
{
List<Teacher_category> oList = new List<Teacher_category>();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0;
Teacher_category oTeacher_category = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_category_By_Criteria_Adv");}
#region Body Section.
if ((i_Params_Get_Teacher_category_By_Criteria.OWNER_ID == null) || (i_Params_Get_Teacher_category_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Teacher_category_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Teacher_category_By_Criteria.START_ROW == null) { i_Params_Get_Teacher_category_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Teacher_category_By_Criteria.END_ROW == null) || (i_Params_Get_Teacher_category_By_Criteria.END_ROW == 0)) { i_Params_Get_Teacher_category_By_Criteria.END_ROW = 1000000; }
List<DALC.Teacher_category> oList_DBEntries = _AppContext.Get_Teacher_category_By_Criteria_Adv(i_Params_Get_Teacher_category_By_Criteria.DESCRIPTION,i_Params_Get_Teacher_category_By_Criteria.OWNER_ID,i_Params_Get_Teacher_category_By_Criteria.START_ROW,i_Params_Get_Teacher_category_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_category = new Teacher_category();
oTools.CopyPropValues(oDBEntry, oTeacher_category);

oTeacher_category.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oTeacher_category.My_Teacher);

oTeacher_category.My_Category = new Category();
oTools.CopyPropValues(oDBEntry.My_Category, oTeacher_category.My_Category);

oList.Add(oTeacher_category);
}
}
i_Params_Get_Teacher_category_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_category_By_Criteria_Adv");}
return oList;
}
public List<Teacher_category> Get_Teacher_category_By_Where_Adv(Params_Get_Teacher_category_By_Where i_Params_Get_Teacher_category_By_Where)
{
List<Teacher_category> oList = new List<Teacher_category>();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0;
Teacher_category oTeacher_category = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_category_By_Where_Adv");}
#region Body Section.
if ((i_Params_Get_Teacher_category_By_Where.OWNER_ID == null) || (i_Params_Get_Teacher_category_By_Where.OWNER_ID == 0)) { i_Params_Get_Teacher_category_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Teacher_category_By_Where.START_ROW == null) { i_Params_Get_Teacher_category_By_Where.START_ROW = 0; }
if ((i_Params_Get_Teacher_category_By_Where.END_ROW == null) || (i_Params_Get_Teacher_category_By_Where.END_ROW == 0)) { i_Params_Get_Teacher_category_By_Where.END_ROW = 1000000; }
List<DALC.Teacher_category> oList_DBEntries = _AppContext.Get_Teacher_category_By_Where_Adv(i_Params_Get_Teacher_category_By_Where.DESCRIPTION,i_Params_Get_Teacher_category_By_Where.OWNER_ID,i_Params_Get_Teacher_category_By_Where.START_ROW,i_Params_Get_Teacher_category_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_category = new Teacher_category();
oTools.CopyPropValues(oDBEntry, oTeacher_category);

oTeacher_category.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oTeacher_category.My_Teacher);

oTeacher_category.My_Category = new Category();
oTools.CopyPropValues(oDBEntry.My_Category, oTeacher_category.My_Category);

oList.Add(oTeacher_category);
}
}
i_Params_Get_Teacher_category_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_category_By_Where_Adv");}
return oList;
}
public List<Favorite_teacher> Get_Favorite_teacher_By_Criteria_Adv(Params_Get_Favorite_teacher_By_Criteria i_Params_Get_Favorite_teacher_By_Criteria)
{
List<Favorite_teacher> oList = new List<Favorite_teacher>();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0;
Favorite_teacher oFavorite_teacher = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Favorite_teacher_By_Criteria_Adv");}
#region Body Section.
if ((i_Params_Get_Favorite_teacher_By_Criteria.OWNER_ID == null) || (i_Params_Get_Favorite_teacher_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Favorite_teacher_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Favorite_teacher_By_Criteria.START_ROW == null) { i_Params_Get_Favorite_teacher_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Favorite_teacher_By_Criteria.END_ROW == null) || (i_Params_Get_Favorite_teacher_By_Criteria.END_ROW == 0)) { i_Params_Get_Favorite_teacher_By_Criteria.END_ROW = 1000000; }
List<DALC.Favorite_teacher> oList_DBEntries = _AppContext.Get_Favorite_teacher_By_Criteria_Adv(i_Params_Get_Favorite_teacher_By_Criteria.DESCRIPTION,i_Params_Get_Favorite_teacher_By_Criteria.OWNER_ID,i_Params_Get_Favorite_teacher_By_Criteria.START_ROW,i_Params_Get_Favorite_teacher_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oFavorite_teacher = new Favorite_teacher();
oTools.CopyPropValues(oDBEntry, oFavorite_teacher);

oFavorite_teacher.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oFavorite_teacher.My_Teacher);

oFavorite_teacher.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oFavorite_teacher.My_Student);

oList.Add(oFavorite_teacher);
}
}
i_Params_Get_Favorite_teacher_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Favorite_teacher_By_Criteria_Adv");}
return oList;
}
public List<Favorite_teacher> Get_Favorite_teacher_By_Where_Adv(Params_Get_Favorite_teacher_By_Where i_Params_Get_Favorite_teacher_By_Where)
{
List<Favorite_teacher> oList = new List<Favorite_teacher>();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0;
Favorite_teacher oFavorite_teacher = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Favorite_teacher_By_Where_Adv");}
#region Body Section.
if ((i_Params_Get_Favorite_teacher_By_Where.OWNER_ID == null) || (i_Params_Get_Favorite_teacher_By_Where.OWNER_ID == 0)) { i_Params_Get_Favorite_teacher_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Favorite_teacher_By_Where.START_ROW == null) { i_Params_Get_Favorite_teacher_By_Where.START_ROW = 0; }
if ((i_Params_Get_Favorite_teacher_By_Where.END_ROW == null) || (i_Params_Get_Favorite_teacher_By_Where.END_ROW == 0)) { i_Params_Get_Favorite_teacher_By_Where.END_ROW = 1000000; }
List<DALC.Favorite_teacher> oList_DBEntries = _AppContext.Get_Favorite_teacher_By_Where_Adv(i_Params_Get_Favorite_teacher_By_Where.DESCRIPTION,i_Params_Get_Favorite_teacher_By_Where.OWNER_ID,i_Params_Get_Favorite_teacher_By_Where.START_ROW,i_Params_Get_Favorite_teacher_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oFavorite_teacher = new Favorite_teacher();
oTools.CopyPropValues(oDBEntry, oFavorite_teacher);

oFavorite_teacher.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oFavorite_teacher.My_Teacher);

oFavorite_teacher.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oFavorite_teacher.My_Student);

oList.Add(oFavorite_teacher);
}
}
i_Params_Get_Favorite_teacher_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Favorite_teacher_By_Where_Adv");}
return oList;
}
public List<Teacher_favorite> Get_Teacher_favorite_By_Criteria_Adv(Params_Get_Teacher_favorite_By_Criteria i_Params_Get_Teacher_favorite_By_Criteria)
{
List<Teacher_favorite> oList = new List<Teacher_favorite>();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0;
Teacher_favorite oTeacher_favorite = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_favorite_By_Criteria_Adv");}
#region Body Section.
if ((i_Params_Get_Teacher_favorite_By_Criteria.OWNER_ID == null) || (i_Params_Get_Teacher_favorite_By_Criteria.OWNER_ID == 0)) { i_Params_Get_Teacher_favorite_By_Criteria.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Teacher_favorite_By_Criteria.START_ROW == null) { i_Params_Get_Teacher_favorite_By_Criteria.START_ROW = 0; }
if ((i_Params_Get_Teacher_favorite_By_Criteria.END_ROW == null) || (i_Params_Get_Teacher_favorite_By_Criteria.END_ROW == 0)) { i_Params_Get_Teacher_favorite_By_Criteria.END_ROW = 1000000; }
List<DALC.Teacher_favorite> oList_DBEntries = _AppContext.Get_Teacher_favorite_By_Criteria_Adv(i_Params_Get_Teacher_favorite_By_Criteria.DESCRIPTION,i_Params_Get_Teacher_favorite_By_Criteria.OWNER_ID,i_Params_Get_Teacher_favorite_By_Criteria.START_ROW,i_Params_Get_Teacher_favorite_By_Criteria.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_favorite = new Teacher_favorite();
oTools.CopyPropValues(oDBEntry, oTeacher_favorite);

oTeacher_favorite.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oTeacher_favorite.My_Teacher);

oTeacher_favorite.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oTeacher_favorite.My_Student);

oList.Add(oTeacher_favorite);
}
}
i_Params_Get_Teacher_favorite_By_Criteria.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_favorite_By_Criteria_Adv");}
return oList;
}
public List<Teacher_favorite> Get_Teacher_favorite_By_Where_Adv(Params_Get_Teacher_favorite_By_Where i_Params_Get_Teacher_favorite_By_Where)
{
List<Teacher_favorite> oList = new List<Teacher_favorite>();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0;
Teacher_favorite oTeacher_favorite = null;
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_favorite_By_Where_Adv");}
#region Body Section.
if ((i_Params_Get_Teacher_favorite_By_Where.OWNER_ID == null) || (i_Params_Get_Teacher_favorite_By_Where.OWNER_ID == 0)) { i_Params_Get_Teacher_favorite_By_Where.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Teacher_favorite_By_Where.START_ROW == null) { i_Params_Get_Teacher_favorite_By_Where.START_ROW = 0; }
if ((i_Params_Get_Teacher_favorite_By_Where.END_ROW == null) || (i_Params_Get_Teacher_favorite_By_Where.END_ROW == 0)) { i_Params_Get_Teacher_favorite_By_Where.END_ROW = 1000000; }
List<DALC.Teacher_favorite> oList_DBEntries = _AppContext.Get_Teacher_favorite_By_Where_Adv(i_Params_Get_Teacher_favorite_By_Where.DESCRIPTION,i_Params_Get_Teacher_favorite_By_Where.OWNER_ID,i_Params_Get_Teacher_favorite_By_Where.START_ROW,i_Params_Get_Teacher_favorite_By_Where.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_favorite = new Teacher_favorite();
oTools.CopyPropValues(oDBEntry, oTeacher_favorite);

oTeacher_favorite.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oTeacher_favorite.My_Teacher);

oTeacher_favorite.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oTeacher_favorite.My_Student);

oList.Add(oTeacher_favorite);
}
}
i_Params_Get_Teacher_favorite_By_Where.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_favorite_By_Where_Adv");}
return oList;
}
public List<Favorite_category> Get_Favorite_category_By_Criteria_InList_Adv(Params_Get_Favorite_category_By_Criteria_InList i_Params_Get_Favorite_category_By_Criteria_InList)
{
List<Favorite_category> oList = new List<Favorite_category>();
Favorite_category oFavorite_category = new Favorite_category();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0; 
Params_Get_Favorite_category_By_Criteria_InList_SP oParams_Get_Favorite_category_By_Criteria_InList_SP = new Params_Get_Favorite_category_By_Criteria_InList_SP();
Params_Get_Student_By_STUDENT_ID oParams_Get_Student_By_STUDENT_ID = new Params_Get_Student_By_STUDENT_ID();
Params_Get_Category_By_CATEGORY_ID oParams_Get_Category_By_CATEGORY_ID = new Params_Get_Category_By_CATEGORY_ID();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Favorite_category_By_Criteria_InList_Adv");}
#region Body Section.
if ((i_Params_Get_Favorite_category_By_Criteria_InList.OWNER_ID == null) || (i_Params_Get_Favorite_category_By_Criteria_InList.OWNER_ID == 0)) { i_Params_Get_Favorite_category_By_Criteria_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Favorite_category_By_Criteria_InList.START_ROW == null) { i_Params_Get_Favorite_category_By_Criteria_InList.START_ROW = 0; }
if ((i_Params_Get_Favorite_category_By_Criteria_InList.END_ROW == null) || (i_Params_Get_Favorite_category_By_Criteria_InList.END_ROW == 0)) { i_Params_Get_Favorite_category_By_Criteria_InList.END_ROW = 1000000; }
oParams_Get_Favorite_category_By_Criteria_InList_SP.OWNER_ID = i_Params_Get_Favorite_category_By_Criteria_InList.OWNER_ID;
oParams_Get_Favorite_category_By_Criteria_InList_SP.DESCRIPTION = i_Params_Get_Favorite_category_By_Criteria_InList.DESCRIPTION;
if ( i_Params_Get_Favorite_category_By_Criteria_InList.STUDENT_ID_LIST == null)
{
i_Params_Get_Favorite_category_By_Criteria_InList.STUDENT_ID_LIST = new List<Int32?>();
}
oParams_Get_Favorite_category_By_Criteria_InList_SP.STUDENT_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Favorite_category_By_Criteria_InList.STUDENT_ID_LIST);
if ( i_Params_Get_Favorite_category_By_Criteria_InList.CATEGORY_ID_LIST == null)
{
i_Params_Get_Favorite_category_By_Criteria_InList.CATEGORY_ID_LIST = new List<Int32?>();
}
oParams_Get_Favorite_category_By_Criteria_InList_SP.CATEGORY_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Favorite_category_By_Criteria_InList.CATEGORY_ID_LIST);
oParams_Get_Favorite_category_By_Criteria_InList_SP.START_ROW = i_Params_Get_Favorite_category_By_Criteria_InList.START_ROW;
oParams_Get_Favorite_category_By_Criteria_InList_SP.END_ROW = i_Params_Get_Favorite_category_By_Criteria_InList.END_ROW;
oParams_Get_Favorite_category_By_Criteria_InList_SP.TOTAL_COUNT = i_Params_Get_Favorite_category_By_Criteria_InList.TOTAL_COUNT;
List<DALC.Favorite_category> oList_DBEntries = _AppContext.Get_Favorite_category_By_Criteria_InList(i_Params_Get_Favorite_category_By_Criteria_InList.DESCRIPTION,i_Params_Get_Favorite_category_By_Criteria_InList.STUDENT_ID_LIST,i_Params_Get_Favorite_category_By_Criteria_InList.CATEGORY_ID_LIST,i_Params_Get_Favorite_category_By_Criteria_InList.OWNER_ID,i_Params_Get_Favorite_category_By_Criteria_InList.START_ROW,i_Params_Get_Favorite_category_By_Criteria_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oFavorite_category = new Favorite_category();
oTools.CopyPropValues(oDBEntry, oFavorite_category);

oFavorite_category.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oFavorite_category.My_Student);

oFavorite_category.My_Category = new Category();
oTools.CopyPropValues(oDBEntry.My_Category, oFavorite_category.My_Category);

oList.Add(oFavorite_category);
}
}
i_Params_Get_Favorite_category_By_Criteria_InList.TOTAL_COUNT = oParams_Get_Favorite_category_By_Criteria_InList_SP.TOTAL_COUNT;
i_Params_Get_Favorite_category_By_Criteria_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Favorite_category_By_Criteria_InList_Adv");}
return oList;
}
public List<Favorite_category> Get_Favorite_category_By_Where_InList_Adv(Params_Get_Favorite_category_By_Where_InList i_Params_Get_Favorite_category_By_Where_InList)
{
List<Favorite_category> oList = new List<Favorite_category>();
Favorite_category oFavorite_category = new Favorite_category();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0; 
Params_Get_Favorite_category_By_Where_InList_SP oParams_Get_Favorite_category_By_Where_InList_SP = new Params_Get_Favorite_category_By_Where_InList_SP();
Params_Get_Student_By_STUDENT_ID oParams_Get_Student_By_STUDENT_ID = new Params_Get_Student_By_STUDENT_ID();
Params_Get_Category_By_CATEGORY_ID oParams_Get_Category_By_CATEGORY_ID = new Params_Get_Category_By_CATEGORY_ID();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Favorite_category_By_Where_InList_Adv");}
#region Body Section.
if ((i_Params_Get_Favorite_category_By_Where_InList.OWNER_ID == null) || (i_Params_Get_Favorite_category_By_Where_InList.OWNER_ID == 0)) { i_Params_Get_Favorite_category_By_Where_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Favorite_category_By_Where_InList.START_ROW == null) { i_Params_Get_Favorite_category_By_Where_InList.START_ROW = 0; }
if ((i_Params_Get_Favorite_category_By_Where_InList.END_ROW == null) || (i_Params_Get_Favorite_category_By_Where_InList.END_ROW == 0)) { i_Params_Get_Favorite_category_By_Where_InList.END_ROW = 1000000; }
oParams_Get_Favorite_category_By_Where_InList_SP.OWNER_ID = i_Params_Get_Favorite_category_By_Where_InList.OWNER_ID;
oParams_Get_Favorite_category_By_Where_InList_SP.DESCRIPTION = i_Params_Get_Favorite_category_By_Where_InList.DESCRIPTION;
if ( i_Params_Get_Favorite_category_By_Where_InList.STUDENT_ID_LIST == null)
{
i_Params_Get_Favorite_category_By_Where_InList.STUDENT_ID_LIST = new List<Int32?>();
}
oParams_Get_Favorite_category_By_Where_InList_SP.STUDENT_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Favorite_category_By_Where_InList.STUDENT_ID_LIST);
if ( i_Params_Get_Favorite_category_By_Where_InList.CATEGORY_ID_LIST == null)
{
i_Params_Get_Favorite_category_By_Where_InList.CATEGORY_ID_LIST = new List<Int32?>();
}
oParams_Get_Favorite_category_By_Where_InList_SP.CATEGORY_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Favorite_category_By_Where_InList.CATEGORY_ID_LIST);
oParams_Get_Favorite_category_By_Where_InList_SP.START_ROW = i_Params_Get_Favorite_category_By_Where_InList.START_ROW;
oParams_Get_Favorite_category_By_Where_InList_SP.END_ROW = i_Params_Get_Favorite_category_By_Where_InList.END_ROW;
oParams_Get_Favorite_category_By_Where_InList_SP.TOTAL_COUNT = i_Params_Get_Favorite_category_By_Where_InList.TOTAL_COUNT;
List<DALC.Favorite_category> oList_DBEntries = _AppContext.Get_Favorite_category_By_Where_InList(i_Params_Get_Favorite_category_By_Where_InList.DESCRIPTION,i_Params_Get_Favorite_category_By_Where_InList.STUDENT_ID_LIST,i_Params_Get_Favorite_category_By_Where_InList.CATEGORY_ID_LIST,i_Params_Get_Favorite_category_By_Where_InList.OWNER_ID,i_Params_Get_Favorite_category_By_Where_InList.START_ROW,i_Params_Get_Favorite_category_By_Where_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oFavorite_category = new Favorite_category();
oTools.CopyPropValues(oDBEntry, oFavorite_category);

oFavorite_category.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oFavorite_category.My_Student);

oFavorite_category.My_Category = new Category();
oTools.CopyPropValues(oDBEntry.My_Category, oFavorite_category.My_Category);

oList.Add(oFavorite_category);
}
}
i_Params_Get_Favorite_category_By_Where_InList.TOTAL_COUNT = oParams_Get_Favorite_category_By_Where_InList_SP.TOTAL_COUNT;
i_Params_Get_Favorite_category_By_Where_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Favorite_category_By_Where_InList_Adv");}
return oList;
}
public List<Question> Get_Question_By_Criteria_InList_Adv(Params_Get_Question_By_Criteria_InList i_Params_Get_Question_By_Criteria_InList)
{
List<Question> oList = new List<Question>();
Question oQuestion = new Question();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0; 
Params_Get_Question_By_Criteria_InList_SP oParams_Get_Question_By_Criteria_InList_SP = new Params_Get_Question_By_Criteria_InList_SP();
Params_Get_Student_By_STUDENT_ID oParams_Get_Student_By_STUDENT_ID = new Params_Get_Student_By_STUDENT_ID();
Params_Get_Category_By_CATEGORY_ID oParams_Get_Category_By_CATEGORY_ID = new Params_Get_Category_By_CATEGORY_ID();
Params_Get_Teacher_By_TEACHER_ID oParams_Get_Teacher_By_TEACHER_ID = new Params_Get_Teacher_By_TEACHER_ID();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Question_By_Criteria_InList_Adv");}
#region Body Section.
if ((i_Params_Get_Question_By_Criteria_InList.OWNER_ID == null) || (i_Params_Get_Question_By_Criteria_InList.OWNER_ID == 0)) { i_Params_Get_Question_By_Criteria_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Question_By_Criteria_InList.START_ROW == null) { i_Params_Get_Question_By_Criteria_InList.START_ROW = 0; }
if ((i_Params_Get_Question_By_Criteria_InList.END_ROW == null) || (i_Params_Get_Question_By_Criteria_InList.END_ROW == 0)) { i_Params_Get_Question_By_Criteria_InList.END_ROW = 1000000; }
oParams_Get_Question_By_Criteria_InList_SP.OWNER_ID = i_Params_Get_Question_By_Criteria_InList.OWNER_ID;
oParams_Get_Question_By_Criteria_InList_SP.DESCRIPTION = i_Params_Get_Question_By_Criteria_InList.DESCRIPTION;
if ( i_Params_Get_Question_By_Criteria_InList.STUDENT_ID_LIST == null)
{
i_Params_Get_Question_By_Criteria_InList.STUDENT_ID_LIST = new List<Int32?>();
}
oParams_Get_Question_By_Criteria_InList_SP.STUDENT_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Question_By_Criteria_InList.STUDENT_ID_LIST);
if ( i_Params_Get_Question_By_Criteria_InList.CATEGORY_ID_LIST == null)
{
i_Params_Get_Question_By_Criteria_InList.CATEGORY_ID_LIST = new List<Int32?>();
}
oParams_Get_Question_By_Criteria_InList_SP.CATEGORY_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Question_By_Criteria_InList.CATEGORY_ID_LIST);
if ( i_Params_Get_Question_By_Criteria_InList.TEACHER_ID_LIST == null)
{
i_Params_Get_Question_By_Criteria_InList.TEACHER_ID_LIST = new List<Int32?>();
}
oParams_Get_Question_By_Criteria_InList_SP.TEACHER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Question_By_Criteria_InList.TEACHER_ID_LIST);
oParams_Get_Question_By_Criteria_InList_SP.START_ROW = i_Params_Get_Question_By_Criteria_InList.START_ROW;
oParams_Get_Question_By_Criteria_InList_SP.END_ROW = i_Params_Get_Question_By_Criteria_InList.END_ROW;
oParams_Get_Question_By_Criteria_InList_SP.TOTAL_COUNT = i_Params_Get_Question_By_Criteria_InList.TOTAL_COUNT;
List<DALC.Question> oList_DBEntries = _AppContext.Get_Question_By_Criteria_InList(i_Params_Get_Question_By_Criteria_InList.DESCRIPTION,i_Params_Get_Question_By_Criteria_InList.STUDENT_ID_LIST,i_Params_Get_Question_By_Criteria_InList.CATEGORY_ID_LIST,i_Params_Get_Question_By_Criteria_InList.TEACHER_ID_LIST,i_Params_Get_Question_By_Criteria_InList.OWNER_ID,i_Params_Get_Question_By_Criteria_InList.START_ROW,i_Params_Get_Question_By_Criteria_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oQuestion = new Question();
oTools.CopyPropValues(oDBEntry, oQuestion);

oQuestion.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oQuestion.My_Student);

oQuestion.My_Category = new Category();
oTools.CopyPropValues(oDBEntry.My_Category, oQuestion.My_Category);

oQuestion.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oQuestion.My_Teacher);

oList.Add(oQuestion);
}
}
i_Params_Get_Question_By_Criteria_InList.TOTAL_COUNT = oParams_Get_Question_By_Criteria_InList_SP.TOTAL_COUNT;
i_Params_Get_Question_By_Criteria_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Question_By_Criteria_InList_Adv");}
return oList;
}
public List<Question> Get_Question_By_Where_InList_Adv(Params_Get_Question_By_Where_InList i_Params_Get_Question_By_Where_InList)
{
List<Question> oList = new List<Question>();
Question oQuestion = new Question();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0; 
Params_Get_Question_By_Where_InList_SP oParams_Get_Question_By_Where_InList_SP = new Params_Get_Question_By_Where_InList_SP();
Params_Get_Student_By_STUDENT_ID oParams_Get_Student_By_STUDENT_ID = new Params_Get_Student_By_STUDENT_ID();
Params_Get_Category_By_CATEGORY_ID oParams_Get_Category_By_CATEGORY_ID = new Params_Get_Category_By_CATEGORY_ID();
Params_Get_Teacher_By_TEACHER_ID oParams_Get_Teacher_By_TEACHER_ID = new Params_Get_Teacher_By_TEACHER_ID();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Question_By_Where_InList_Adv");}
#region Body Section.
if ((i_Params_Get_Question_By_Where_InList.OWNER_ID == null) || (i_Params_Get_Question_By_Where_InList.OWNER_ID == 0)) { i_Params_Get_Question_By_Where_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Question_By_Where_InList.START_ROW == null) { i_Params_Get_Question_By_Where_InList.START_ROW = 0; }
if ((i_Params_Get_Question_By_Where_InList.END_ROW == null) || (i_Params_Get_Question_By_Where_InList.END_ROW == 0)) { i_Params_Get_Question_By_Where_InList.END_ROW = 1000000; }
oParams_Get_Question_By_Where_InList_SP.OWNER_ID = i_Params_Get_Question_By_Where_InList.OWNER_ID;
oParams_Get_Question_By_Where_InList_SP.DESCRIPTION = i_Params_Get_Question_By_Where_InList.DESCRIPTION;
if ( i_Params_Get_Question_By_Where_InList.STUDENT_ID_LIST == null)
{
i_Params_Get_Question_By_Where_InList.STUDENT_ID_LIST = new List<Int32?>();
}
oParams_Get_Question_By_Where_InList_SP.STUDENT_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Question_By_Where_InList.STUDENT_ID_LIST);
if ( i_Params_Get_Question_By_Where_InList.CATEGORY_ID_LIST == null)
{
i_Params_Get_Question_By_Where_InList.CATEGORY_ID_LIST = new List<Int32?>();
}
oParams_Get_Question_By_Where_InList_SP.CATEGORY_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Question_By_Where_InList.CATEGORY_ID_LIST);
if ( i_Params_Get_Question_By_Where_InList.TEACHER_ID_LIST == null)
{
i_Params_Get_Question_By_Where_InList.TEACHER_ID_LIST = new List<Int32?>();
}
oParams_Get_Question_By_Where_InList_SP.TEACHER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Question_By_Where_InList.TEACHER_ID_LIST);
oParams_Get_Question_By_Where_InList_SP.START_ROW = i_Params_Get_Question_By_Where_InList.START_ROW;
oParams_Get_Question_By_Where_InList_SP.END_ROW = i_Params_Get_Question_By_Where_InList.END_ROW;
oParams_Get_Question_By_Where_InList_SP.TOTAL_COUNT = i_Params_Get_Question_By_Where_InList.TOTAL_COUNT;
List<DALC.Question> oList_DBEntries = _AppContext.Get_Question_By_Where_InList(i_Params_Get_Question_By_Where_InList.DESCRIPTION,i_Params_Get_Question_By_Where_InList.STUDENT_ID_LIST,i_Params_Get_Question_By_Where_InList.CATEGORY_ID_LIST,i_Params_Get_Question_By_Where_InList.TEACHER_ID_LIST,i_Params_Get_Question_By_Where_InList.OWNER_ID,i_Params_Get_Question_By_Where_InList.START_ROW,i_Params_Get_Question_By_Where_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oQuestion = new Question();
oTools.CopyPropValues(oDBEntry, oQuestion);

oQuestion.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oQuestion.My_Student);

oQuestion.My_Category = new Category();
oTools.CopyPropValues(oDBEntry.My_Category, oQuestion.My_Category);

oQuestion.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oQuestion.My_Teacher);

oList.Add(oQuestion);
}
}
i_Params_Get_Question_By_Where_InList.TOTAL_COUNT = oParams_Get_Question_By_Where_InList_SP.TOTAL_COUNT;
i_Params_Get_Question_By_Where_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Question_By_Where_InList_Adv");}
return oList;
}
public List<Report_article> Get_Report_article_By_Criteria_InList_Adv(Params_Get_Report_article_By_Criteria_InList i_Params_Get_Report_article_By_Criteria_InList)
{
List<Report_article> oList = new List<Report_article>();
Report_article oReport_article = new Report_article();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0; 
Params_Get_Report_article_By_Criteria_InList_SP oParams_Get_Report_article_By_Criteria_InList_SP = new Params_Get_Report_article_By_Criteria_InList_SP();
Params_Get_Article_By_ARTICLE_ID oParams_Get_Article_By_ARTICLE_ID = new Params_Get_Article_By_ARTICLE_ID();
Params_Get_Student_By_STUDENT_ID oParams_Get_Student_By_STUDENT_ID = new Params_Get_Student_By_STUDENT_ID();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Report_article_By_Criteria_InList_Adv");}
#region Body Section.
if ((i_Params_Get_Report_article_By_Criteria_InList.OWNER_ID == null) || (i_Params_Get_Report_article_By_Criteria_InList.OWNER_ID == 0)) { i_Params_Get_Report_article_By_Criteria_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Report_article_By_Criteria_InList.START_ROW == null) { i_Params_Get_Report_article_By_Criteria_InList.START_ROW = 0; }
if ((i_Params_Get_Report_article_By_Criteria_InList.END_ROW == null) || (i_Params_Get_Report_article_By_Criteria_InList.END_ROW == 0)) { i_Params_Get_Report_article_By_Criteria_InList.END_ROW = 1000000; }
oParams_Get_Report_article_By_Criteria_InList_SP.OWNER_ID = i_Params_Get_Report_article_By_Criteria_InList.OWNER_ID;
oParams_Get_Report_article_By_Criteria_InList_SP.DESCRIPTION = i_Params_Get_Report_article_By_Criteria_InList.DESCRIPTION;
if ( i_Params_Get_Report_article_By_Criteria_InList.ARTICLE_ID_LIST == null)
{
i_Params_Get_Report_article_By_Criteria_InList.ARTICLE_ID_LIST = new List<Int32?>();
}
oParams_Get_Report_article_By_Criteria_InList_SP.ARTICLE_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Report_article_By_Criteria_InList.ARTICLE_ID_LIST);
if ( i_Params_Get_Report_article_By_Criteria_InList.STUDENT_ID_LIST == null)
{
i_Params_Get_Report_article_By_Criteria_InList.STUDENT_ID_LIST = new List<Int32?>();
}
oParams_Get_Report_article_By_Criteria_InList_SP.STUDENT_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Report_article_By_Criteria_InList.STUDENT_ID_LIST);
oParams_Get_Report_article_By_Criteria_InList_SP.START_ROW = i_Params_Get_Report_article_By_Criteria_InList.START_ROW;
oParams_Get_Report_article_By_Criteria_InList_SP.END_ROW = i_Params_Get_Report_article_By_Criteria_InList.END_ROW;
oParams_Get_Report_article_By_Criteria_InList_SP.TOTAL_COUNT = i_Params_Get_Report_article_By_Criteria_InList.TOTAL_COUNT;
List<DALC.Report_article> oList_DBEntries = _AppContext.Get_Report_article_By_Criteria_InList(i_Params_Get_Report_article_By_Criteria_InList.DESCRIPTION,i_Params_Get_Report_article_By_Criteria_InList.ARTICLE_ID_LIST,i_Params_Get_Report_article_By_Criteria_InList.STUDENT_ID_LIST,i_Params_Get_Report_article_By_Criteria_InList.OWNER_ID,i_Params_Get_Report_article_By_Criteria_InList.START_ROW,i_Params_Get_Report_article_By_Criteria_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oReport_article = new Report_article();
oTools.CopyPropValues(oDBEntry, oReport_article);

oReport_article.My_Article = new Article();
oTools.CopyPropValues(oDBEntry.My_Article, oReport_article.My_Article);

oReport_article.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oReport_article.My_Student);

oList.Add(oReport_article);
}
}
i_Params_Get_Report_article_By_Criteria_InList.TOTAL_COUNT = oParams_Get_Report_article_By_Criteria_InList_SP.TOTAL_COUNT;
i_Params_Get_Report_article_By_Criteria_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Report_article_By_Criteria_InList_Adv");}
return oList;
}
public List<Report_article> Get_Report_article_By_Where_InList_Adv(Params_Get_Report_article_By_Where_InList i_Params_Get_Report_article_By_Where_InList)
{
List<Report_article> oList = new List<Report_article>();
Report_article oReport_article = new Report_article();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0; 
Params_Get_Report_article_By_Where_InList_SP oParams_Get_Report_article_By_Where_InList_SP = new Params_Get_Report_article_By_Where_InList_SP();
Params_Get_Article_By_ARTICLE_ID oParams_Get_Article_By_ARTICLE_ID = new Params_Get_Article_By_ARTICLE_ID();
Params_Get_Student_By_STUDENT_ID oParams_Get_Student_By_STUDENT_ID = new Params_Get_Student_By_STUDENT_ID();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Report_article_By_Where_InList_Adv");}
#region Body Section.
if ((i_Params_Get_Report_article_By_Where_InList.OWNER_ID == null) || (i_Params_Get_Report_article_By_Where_InList.OWNER_ID == 0)) { i_Params_Get_Report_article_By_Where_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Report_article_By_Where_InList.START_ROW == null) { i_Params_Get_Report_article_By_Where_InList.START_ROW = 0; }
if ((i_Params_Get_Report_article_By_Where_InList.END_ROW == null) || (i_Params_Get_Report_article_By_Where_InList.END_ROW == 0)) { i_Params_Get_Report_article_By_Where_InList.END_ROW = 1000000; }
oParams_Get_Report_article_By_Where_InList_SP.OWNER_ID = i_Params_Get_Report_article_By_Where_InList.OWNER_ID;
oParams_Get_Report_article_By_Where_InList_SP.DESCRIPTION = i_Params_Get_Report_article_By_Where_InList.DESCRIPTION;
if ( i_Params_Get_Report_article_By_Where_InList.ARTICLE_ID_LIST == null)
{
i_Params_Get_Report_article_By_Where_InList.ARTICLE_ID_LIST = new List<Int32?>();
}
oParams_Get_Report_article_By_Where_InList_SP.ARTICLE_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Report_article_By_Where_InList.ARTICLE_ID_LIST);
if ( i_Params_Get_Report_article_By_Where_InList.STUDENT_ID_LIST == null)
{
i_Params_Get_Report_article_By_Where_InList.STUDENT_ID_LIST = new List<Int32?>();
}
oParams_Get_Report_article_By_Where_InList_SP.STUDENT_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Report_article_By_Where_InList.STUDENT_ID_LIST);
oParams_Get_Report_article_By_Where_InList_SP.START_ROW = i_Params_Get_Report_article_By_Where_InList.START_ROW;
oParams_Get_Report_article_By_Where_InList_SP.END_ROW = i_Params_Get_Report_article_By_Where_InList.END_ROW;
oParams_Get_Report_article_By_Where_InList_SP.TOTAL_COUNT = i_Params_Get_Report_article_By_Where_InList.TOTAL_COUNT;
List<DALC.Report_article> oList_DBEntries = _AppContext.Get_Report_article_By_Where_InList(i_Params_Get_Report_article_By_Where_InList.DESCRIPTION,i_Params_Get_Report_article_By_Where_InList.ARTICLE_ID_LIST,i_Params_Get_Report_article_By_Where_InList.STUDENT_ID_LIST,i_Params_Get_Report_article_By_Where_InList.OWNER_ID,i_Params_Get_Report_article_By_Where_InList.START_ROW,i_Params_Get_Report_article_By_Where_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oReport_article = new Report_article();
oTools.CopyPropValues(oDBEntry, oReport_article);

oReport_article.My_Article = new Article();
oTools.CopyPropValues(oDBEntry.My_Article, oReport_article.My_Article);

oReport_article.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oReport_article.My_Student);

oList.Add(oReport_article);
}
}
i_Params_Get_Report_article_By_Where_InList.TOTAL_COUNT = oParams_Get_Report_article_By_Where_InList_SP.TOTAL_COUNT;
i_Params_Get_Report_article_By_Where_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Report_article_By_Where_InList_Adv");}
return oList;
}
public List<Mark_question> Get_Mark_question_By_Criteria_InList_Adv(Params_Get_Mark_question_By_Criteria_InList i_Params_Get_Mark_question_By_Criteria_InList)
{
List<Mark_question> oList = new List<Mark_question>();
Mark_question oMark_question = new Mark_question();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0; 
Params_Get_Mark_question_By_Criteria_InList_SP oParams_Get_Mark_question_By_Criteria_InList_SP = new Params_Get_Mark_question_By_Criteria_InList_SP();
Params_Get_Question_By_QUESTION_ID oParams_Get_Question_By_QUESTION_ID = new Params_Get_Question_By_QUESTION_ID();
Params_Get_Student_By_STUDENT_ID oParams_Get_Student_By_STUDENT_ID = new Params_Get_Student_By_STUDENT_ID();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Mark_question_By_Criteria_InList_Adv");}
#region Body Section.
if ((i_Params_Get_Mark_question_By_Criteria_InList.OWNER_ID == null) || (i_Params_Get_Mark_question_By_Criteria_InList.OWNER_ID == 0)) { i_Params_Get_Mark_question_By_Criteria_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Mark_question_By_Criteria_InList.START_ROW == null) { i_Params_Get_Mark_question_By_Criteria_InList.START_ROW = 0; }
if ((i_Params_Get_Mark_question_By_Criteria_InList.END_ROW == null) || (i_Params_Get_Mark_question_By_Criteria_InList.END_ROW == 0)) { i_Params_Get_Mark_question_By_Criteria_InList.END_ROW = 1000000; }
oParams_Get_Mark_question_By_Criteria_InList_SP.OWNER_ID = i_Params_Get_Mark_question_By_Criteria_InList.OWNER_ID;
oParams_Get_Mark_question_By_Criteria_InList_SP.DESCRIPTION = i_Params_Get_Mark_question_By_Criteria_InList.DESCRIPTION;
if ( i_Params_Get_Mark_question_By_Criteria_InList.QUESTION_ID_LIST == null)
{
i_Params_Get_Mark_question_By_Criteria_InList.QUESTION_ID_LIST = new List<Int32?>();
}
oParams_Get_Mark_question_By_Criteria_InList_SP.QUESTION_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Mark_question_By_Criteria_InList.QUESTION_ID_LIST);
if ( i_Params_Get_Mark_question_By_Criteria_InList.STUDENT_ID_LIST == null)
{
i_Params_Get_Mark_question_By_Criteria_InList.STUDENT_ID_LIST = new List<Int32?>();
}
oParams_Get_Mark_question_By_Criteria_InList_SP.STUDENT_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Mark_question_By_Criteria_InList.STUDENT_ID_LIST);
oParams_Get_Mark_question_By_Criteria_InList_SP.START_ROW = i_Params_Get_Mark_question_By_Criteria_InList.START_ROW;
oParams_Get_Mark_question_By_Criteria_InList_SP.END_ROW = i_Params_Get_Mark_question_By_Criteria_InList.END_ROW;
oParams_Get_Mark_question_By_Criteria_InList_SP.TOTAL_COUNT = i_Params_Get_Mark_question_By_Criteria_InList.TOTAL_COUNT;
List<DALC.Mark_question> oList_DBEntries = _AppContext.Get_Mark_question_By_Criteria_InList(i_Params_Get_Mark_question_By_Criteria_InList.DESCRIPTION,i_Params_Get_Mark_question_By_Criteria_InList.QUESTION_ID_LIST,i_Params_Get_Mark_question_By_Criteria_InList.STUDENT_ID_LIST,i_Params_Get_Mark_question_By_Criteria_InList.OWNER_ID,i_Params_Get_Mark_question_By_Criteria_InList.START_ROW,i_Params_Get_Mark_question_By_Criteria_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oMark_question = new Mark_question();
oTools.CopyPropValues(oDBEntry, oMark_question);

oMark_question.My_Question = new Question();
oTools.CopyPropValues(oDBEntry.My_Question, oMark_question.My_Question);

oMark_question.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oMark_question.My_Student);

oList.Add(oMark_question);
}
}
i_Params_Get_Mark_question_By_Criteria_InList.TOTAL_COUNT = oParams_Get_Mark_question_By_Criteria_InList_SP.TOTAL_COUNT;
i_Params_Get_Mark_question_By_Criteria_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Mark_question_By_Criteria_InList_Adv");}
return oList;
}
public List<Mark_question> Get_Mark_question_By_Where_InList_Adv(Params_Get_Mark_question_By_Where_InList i_Params_Get_Mark_question_By_Where_InList)
{
List<Mark_question> oList = new List<Mark_question>();
Mark_question oMark_question = new Mark_question();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0; 
Params_Get_Mark_question_By_Where_InList_SP oParams_Get_Mark_question_By_Where_InList_SP = new Params_Get_Mark_question_By_Where_InList_SP();
Params_Get_Question_By_QUESTION_ID oParams_Get_Question_By_QUESTION_ID = new Params_Get_Question_By_QUESTION_ID();
Params_Get_Student_By_STUDENT_ID oParams_Get_Student_By_STUDENT_ID = new Params_Get_Student_By_STUDENT_ID();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Mark_question_By_Where_InList_Adv");}
#region Body Section.
if ((i_Params_Get_Mark_question_By_Where_InList.OWNER_ID == null) || (i_Params_Get_Mark_question_By_Where_InList.OWNER_ID == 0)) { i_Params_Get_Mark_question_By_Where_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Mark_question_By_Where_InList.START_ROW == null) { i_Params_Get_Mark_question_By_Where_InList.START_ROW = 0; }
if ((i_Params_Get_Mark_question_By_Where_InList.END_ROW == null) || (i_Params_Get_Mark_question_By_Where_InList.END_ROW == 0)) { i_Params_Get_Mark_question_By_Where_InList.END_ROW = 1000000; }
oParams_Get_Mark_question_By_Where_InList_SP.OWNER_ID = i_Params_Get_Mark_question_By_Where_InList.OWNER_ID;
oParams_Get_Mark_question_By_Where_InList_SP.DESCRIPTION = i_Params_Get_Mark_question_By_Where_InList.DESCRIPTION;
if ( i_Params_Get_Mark_question_By_Where_InList.QUESTION_ID_LIST == null)
{
i_Params_Get_Mark_question_By_Where_InList.QUESTION_ID_LIST = new List<Int32?>();
}
oParams_Get_Mark_question_By_Where_InList_SP.QUESTION_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Mark_question_By_Where_InList.QUESTION_ID_LIST);
if ( i_Params_Get_Mark_question_By_Where_InList.STUDENT_ID_LIST == null)
{
i_Params_Get_Mark_question_By_Where_InList.STUDENT_ID_LIST = new List<Int32?>();
}
oParams_Get_Mark_question_By_Where_InList_SP.STUDENT_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Mark_question_By_Where_InList.STUDENT_ID_LIST);
oParams_Get_Mark_question_By_Where_InList_SP.START_ROW = i_Params_Get_Mark_question_By_Where_InList.START_ROW;
oParams_Get_Mark_question_By_Where_InList_SP.END_ROW = i_Params_Get_Mark_question_By_Where_InList.END_ROW;
oParams_Get_Mark_question_By_Where_InList_SP.TOTAL_COUNT = i_Params_Get_Mark_question_By_Where_InList.TOTAL_COUNT;
List<DALC.Mark_question> oList_DBEntries = _AppContext.Get_Mark_question_By_Where_InList(i_Params_Get_Mark_question_By_Where_InList.DESCRIPTION,i_Params_Get_Mark_question_By_Where_InList.QUESTION_ID_LIST,i_Params_Get_Mark_question_By_Where_InList.STUDENT_ID_LIST,i_Params_Get_Mark_question_By_Where_InList.OWNER_ID,i_Params_Get_Mark_question_By_Where_InList.START_ROW,i_Params_Get_Mark_question_By_Where_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oMark_question = new Mark_question();
oTools.CopyPropValues(oDBEntry, oMark_question);

oMark_question.My_Question = new Question();
oTools.CopyPropValues(oDBEntry.My_Question, oMark_question.My_Question);

oMark_question.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oMark_question.My_Student);

oList.Add(oMark_question);
}
}
i_Params_Get_Mark_question_By_Where_InList.TOTAL_COUNT = oParams_Get_Mark_question_By_Where_InList_SP.TOTAL_COUNT;
i_Params_Get_Mark_question_By_Where_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Mark_question_By_Where_InList_Adv");}
return oList;
}
public List<Article> Get_Article_By_Criteria_InList_Adv(Params_Get_Article_By_Criteria_InList i_Params_Get_Article_By_Criteria_InList)
{
List<Article> oList = new List<Article>();
Article oArticle = new Article();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0; 
Params_Get_Article_By_Criteria_InList_SP oParams_Get_Article_By_Criteria_InList_SP = new Params_Get_Article_By_Criteria_InList_SP();
Params_Get_Teacher_By_TEACHER_ID oParams_Get_Teacher_By_TEACHER_ID = new Params_Get_Teacher_By_TEACHER_ID();
Params_Get_Category_By_CATEGORY_ID oParams_Get_Category_By_CATEGORY_ID = new Params_Get_Category_By_CATEGORY_ID();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Article_By_Criteria_InList_Adv");}
#region Body Section.
if ((i_Params_Get_Article_By_Criteria_InList.OWNER_ID == null) || (i_Params_Get_Article_By_Criteria_InList.OWNER_ID == 0)) { i_Params_Get_Article_By_Criteria_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Article_By_Criteria_InList.START_ROW == null) { i_Params_Get_Article_By_Criteria_InList.START_ROW = 0; }
if ((i_Params_Get_Article_By_Criteria_InList.END_ROW == null) || (i_Params_Get_Article_By_Criteria_InList.END_ROW == 0)) { i_Params_Get_Article_By_Criteria_InList.END_ROW = 1000000; }
oParams_Get_Article_By_Criteria_InList_SP.OWNER_ID = i_Params_Get_Article_By_Criteria_InList.OWNER_ID;
oParams_Get_Article_By_Criteria_InList_SP.TITLE = i_Params_Get_Article_By_Criteria_InList.TITLE;
oParams_Get_Article_By_Criteria_InList_SP.DESCRIPTION = i_Params_Get_Article_By_Criteria_InList.DESCRIPTION;
if ( i_Params_Get_Article_By_Criteria_InList.TEACHER_ID_LIST == null)
{
i_Params_Get_Article_By_Criteria_InList.TEACHER_ID_LIST = new List<Int32?>();
}
oParams_Get_Article_By_Criteria_InList_SP.TEACHER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Article_By_Criteria_InList.TEACHER_ID_LIST);
if ( i_Params_Get_Article_By_Criteria_InList.CATEGORY_ID_LIST == null)
{
i_Params_Get_Article_By_Criteria_InList.CATEGORY_ID_LIST = new List<Int32?>();
}
oParams_Get_Article_By_Criteria_InList_SP.CATEGORY_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Article_By_Criteria_InList.CATEGORY_ID_LIST);
oParams_Get_Article_By_Criteria_InList_SP.START_ROW = i_Params_Get_Article_By_Criteria_InList.START_ROW;
oParams_Get_Article_By_Criteria_InList_SP.END_ROW = i_Params_Get_Article_By_Criteria_InList.END_ROW;
oParams_Get_Article_By_Criteria_InList_SP.TOTAL_COUNT = i_Params_Get_Article_By_Criteria_InList.TOTAL_COUNT;
List<DALC.Article> oList_DBEntries = _AppContext.Get_Article_By_Criteria_InList(i_Params_Get_Article_By_Criteria_InList.TITLE,i_Params_Get_Article_By_Criteria_InList.DESCRIPTION,i_Params_Get_Article_By_Criteria_InList.TEACHER_ID_LIST,i_Params_Get_Article_By_Criteria_InList.CATEGORY_ID_LIST,i_Params_Get_Article_By_Criteria_InList.OWNER_ID,i_Params_Get_Article_By_Criteria_InList.START_ROW,i_Params_Get_Article_By_Criteria_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oArticle = new Article();
oTools.CopyPropValues(oDBEntry, oArticle);

oArticle.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oArticle.My_Teacher);

oArticle.My_Category = new Category();
oTools.CopyPropValues(oDBEntry.My_Category, oArticle.My_Category);

oList.Add(oArticle);
}
}
i_Params_Get_Article_By_Criteria_InList.TOTAL_COUNT = oParams_Get_Article_By_Criteria_InList_SP.TOTAL_COUNT;
i_Params_Get_Article_By_Criteria_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Article_By_Criteria_InList_Adv");}
return oList;
}
public List<Article> Get_Article_By_Where_InList_Adv(Params_Get_Article_By_Where_InList i_Params_Get_Article_By_Where_InList)
{
List<Article> oList = new List<Article>();
Article oArticle = new Article();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0; 
Params_Get_Article_By_Where_InList_SP oParams_Get_Article_By_Where_InList_SP = new Params_Get_Article_By_Where_InList_SP();
Params_Get_Teacher_By_TEACHER_ID oParams_Get_Teacher_By_TEACHER_ID = new Params_Get_Teacher_By_TEACHER_ID();
Params_Get_Category_By_CATEGORY_ID oParams_Get_Category_By_CATEGORY_ID = new Params_Get_Category_By_CATEGORY_ID();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Article_By_Where_InList_Adv");}
#region Body Section.
if ((i_Params_Get_Article_By_Where_InList.OWNER_ID == null) || (i_Params_Get_Article_By_Where_InList.OWNER_ID == 0)) { i_Params_Get_Article_By_Where_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Article_By_Where_InList.START_ROW == null) { i_Params_Get_Article_By_Where_InList.START_ROW = 0; }
if ((i_Params_Get_Article_By_Where_InList.END_ROW == null) || (i_Params_Get_Article_By_Where_InList.END_ROW == 0)) { i_Params_Get_Article_By_Where_InList.END_ROW = 1000000; }
oParams_Get_Article_By_Where_InList_SP.OWNER_ID = i_Params_Get_Article_By_Where_InList.OWNER_ID;
oParams_Get_Article_By_Where_InList_SP.TITLE = i_Params_Get_Article_By_Where_InList.TITLE;
oParams_Get_Article_By_Where_InList_SP.DESCRIPTION = i_Params_Get_Article_By_Where_InList.DESCRIPTION;
if ( i_Params_Get_Article_By_Where_InList.TEACHER_ID_LIST == null)
{
i_Params_Get_Article_By_Where_InList.TEACHER_ID_LIST = new List<Int32?>();
}
oParams_Get_Article_By_Where_InList_SP.TEACHER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Article_By_Where_InList.TEACHER_ID_LIST);
if ( i_Params_Get_Article_By_Where_InList.CATEGORY_ID_LIST == null)
{
i_Params_Get_Article_By_Where_InList.CATEGORY_ID_LIST = new List<Int32?>();
}
oParams_Get_Article_By_Where_InList_SP.CATEGORY_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Article_By_Where_InList.CATEGORY_ID_LIST);
oParams_Get_Article_By_Where_InList_SP.START_ROW = i_Params_Get_Article_By_Where_InList.START_ROW;
oParams_Get_Article_By_Where_InList_SP.END_ROW = i_Params_Get_Article_By_Where_InList.END_ROW;
oParams_Get_Article_By_Where_InList_SP.TOTAL_COUNT = i_Params_Get_Article_By_Where_InList.TOTAL_COUNT;
List<DALC.Article> oList_DBEntries = _AppContext.Get_Article_By_Where_InList(i_Params_Get_Article_By_Where_InList.TITLE,i_Params_Get_Article_By_Where_InList.DESCRIPTION,i_Params_Get_Article_By_Where_InList.TEACHER_ID_LIST,i_Params_Get_Article_By_Where_InList.CATEGORY_ID_LIST,i_Params_Get_Article_By_Where_InList.OWNER_ID,i_Params_Get_Article_By_Where_InList.START_ROW,i_Params_Get_Article_By_Where_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oArticle = new Article();
oTools.CopyPropValues(oDBEntry, oArticle);

oArticle.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oArticle.My_Teacher);

oArticle.My_Category = new Category();
oTools.CopyPropValues(oDBEntry.My_Category, oArticle.My_Category);

oList.Add(oArticle);
}
}
i_Params_Get_Article_By_Where_InList.TOTAL_COUNT = oParams_Get_Article_By_Where_InList_SP.TOTAL_COUNT;
i_Params_Get_Article_By_Where_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Article_By_Where_InList_Adv");}
return oList;
}
public List<Answer> Get_Answer_By_Criteria_InList_Adv(Params_Get_Answer_By_Criteria_InList i_Params_Get_Answer_By_Criteria_InList)
{
List<Answer> oList = new List<Answer>();
Answer oAnswer = new Answer();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0; 
Params_Get_Answer_By_Criteria_InList_SP oParams_Get_Answer_By_Criteria_InList_SP = new Params_Get_Answer_By_Criteria_InList_SP();
Params_Get_Question_By_QUESTION_ID oParams_Get_Question_By_QUESTION_ID = new Params_Get_Question_By_QUESTION_ID();
Params_Get_Teacher_By_TEACHER_ID oParams_Get_Teacher_By_TEACHER_ID = new Params_Get_Teacher_By_TEACHER_ID();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Answer_By_Criteria_InList_Adv");}
#region Body Section.
if ((i_Params_Get_Answer_By_Criteria_InList.OWNER_ID == null) || (i_Params_Get_Answer_By_Criteria_InList.OWNER_ID == 0)) { i_Params_Get_Answer_By_Criteria_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Answer_By_Criteria_InList.START_ROW == null) { i_Params_Get_Answer_By_Criteria_InList.START_ROW = 0; }
if ((i_Params_Get_Answer_By_Criteria_InList.END_ROW == null) || (i_Params_Get_Answer_By_Criteria_InList.END_ROW == 0)) { i_Params_Get_Answer_By_Criteria_InList.END_ROW = 1000000; }
oParams_Get_Answer_By_Criteria_InList_SP.OWNER_ID = i_Params_Get_Answer_By_Criteria_InList.OWNER_ID;
oParams_Get_Answer_By_Criteria_InList_SP.DESCRIPTION = i_Params_Get_Answer_By_Criteria_InList.DESCRIPTION;
if ( i_Params_Get_Answer_By_Criteria_InList.QUESTION_ID_LIST == null)
{
i_Params_Get_Answer_By_Criteria_InList.QUESTION_ID_LIST = new List<Int32?>();
}
oParams_Get_Answer_By_Criteria_InList_SP.QUESTION_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Answer_By_Criteria_InList.QUESTION_ID_LIST);
if ( i_Params_Get_Answer_By_Criteria_InList.TEACHER_ID_LIST == null)
{
i_Params_Get_Answer_By_Criteria_InList.TEACHER_ID_LIST = new List<Int32?>();
}
oParams_Get_Answer_By_Criteria_InList_SP.TEACHER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Answer_By_Criteria_InList.TEACHER_ID_LIST);
oParams_Get_Answer_By_Criteria_InList_SP.START_ROW = i_Params_Get_Answer_By_Criteria_InList.START_ROW;
oParams_Get_Answer_By_Criteria_InList_SP.END_ROW = i_Params_Get_Answer_By_Criteria_InList.END_ROW;
oParams_Get_Answer_By_Criteria_InList_SP.TOTAL_COUNT = i_Params_Get_Answer_By_Criteria_InList.TOTAL_COUNT;
List<DALC.Answer> oList_DBEntries = _AppContext.Get_Answer_By_Criteria_InList(i_Params_Get_Answer_By_Criteria_InList.DESCRIPTION,i_Params_Get_Answer_By_Criteria_InList.QUESTION_ID_LIST,i_Params_Get_Answer_By_Criteria_InList.TEACHER_ID_LIST,i_Params_Get_Answer_By_Criteria_InList.OWNER_ID,i_Params_Get_Answer_By_Criteria_InList.START_ROW,i_Params_Get_Answer_By_Criteria_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oAnswer = new Answer();
oTools.CopyPropValues(oDBEntry, oAnswer);

oAnswer.My_Question = new Question();
oTools.CopyPropValues(oDBEntry.My_Question, oAnswer.My_Question);

oAnswer.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oAnswer.My_Teacher);

oList.Add(oAnswer);
}
}
i_Params_Get_Answer_By_Criteria_InList.TOTAL_COUNT = oParams_Get_Answer_By_Criteria_InList_SP.TOTAL_COUNT;
i_Params_Get_Answer_By_Criteria_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Answer_By_Criteria_InList_Adv");}
return oList;
}
public List<Answer> Get_Answer_By_Where_InList_Adv(Params_Get_Answer_By_Where_InList i_Params_Get_Answer_By_Where_InList)
{
List<Answer> oList = new List<Answer>();
Answer oAnswer = new Answer();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0; 
Params_Get_Answer_By_Where_InList_SP oParams_Get_Answer_By_Where_InList_SP = new Params_Get_Answer_By_Where_InList_SP();
Params_Get_Question_By_QUESTION_ID oParams_Get_Question_By_QUESTION_ID = new Params_Get_Question_By_QUESTION_ID();
Params_Get_Teacher_By_TEACHER_ID oParams_Get_Teacher_By_TEACHER_ID = new Params_Get_Teacher_By_TEACHER_ID();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Answer_By_Where_InList_Adv");}
#region Body Section.
if ((i_Params_Get_Answer_By_Where_InList.OWNER_ID == null) || (i_Params_Get_Answer_By_Where_InList.OWNER_ID == 0)) { i_Params_Get_Answer_By_Where_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Answer_By_Where_InList.START_ROW == null) { i_Params_Get_Answer_By_Where_InList.START_ROW = 0; }
if ((i_Params_Get_Answer_By_Where_InList.END_ROW == null) || (i_Params_Get_Answer_By_Where_InList.END_ROW == 0)) { i_Params_Get_Answer_By_Where_InList.END_ROW = 1000000; }
oParams_Get_Answer_By_Where_InList_SP.OWNER_ID = i_Params_Get_Answer_By_Where_InList.OWNER_ID;
oParams_Get_Answer_By_Where_InList_SP.DESCRIPTION = i_Params_Get_Answer_By_Where_InList.DESCRIPTION;
if ( i_Params_Get_Answer_By_Where_InList.QUESTION_ID_LIST == null)
{
i_Params_Get_Answer_By_Where_InList.QUESTION_ID_LIST = new List<Int32?>();
}
oParams_Get_Answer_By_Where_InList_SP.QUESTION_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Answer_By_Where_InList.QUESTION_ID_LIST);
if ( i_Params_Get_Answer_By_Where_InList.TEACHER_ID_LIST == null)
{
i_Params_Get_Answer_By_Where_InList.TEACHER_ID_LIST = new List<Int32?>();
}
oParams_Get_Answer_By_Where_InList_SP.TEACHER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Answer_By_Where_InList.TEACHER_ID_LIST);
oParams_Get_Answer_By_Where_InList_SP.START_ROW = i_Params_Get_Answer_By_Where_InList.START_ROW;
oParams_Get_Answer_By_Where_InList_SP.END_ROW = i_Params_Get_Answer_By_Where_InList.END_ROW;
oParams_Get_Answer_By_Where_InList_SP.TOTAL_COUNT = i_Params_Get_Answer_By_Where_InList.TOTAL_COUNT;
List<DALC.Answer> oList_DBEntries = _AppContext.Get_Answer_By_Where_InList(i_Params_Get_Answer_By_Where_InList.DESCRIPTION,i_Params_Get_Answer_By_Where_InList.QUESTION_ID_LIST,i_Params_Get_Answer_By_Where_InList.TEACHER_ID_LIST,i_Params_Get_Answer_By_Where_InList.OWNER_ID,i_Params_Get_Answer_By_Where_InList.START_ROW,i_Params_Get_Answer_By_Where_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oAnswer = new Answer();
oTools.CopyPropValues(oDBEntry, oAnswer);

oAnswer.My_Question = new Question();
oTools.CopyPropValues(oDBEntry.My_Question, oAnswer.My_Question);

oAnswer.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oAnswer.My_Teacher);

oList.Add(oAnswer);
}
}
i_Params_Get_Answer_By_Where_InList.TOTAL_COUNT = oParams_Get_Answer_By_Where_InList_SP.TOTAL_COUNT;
i_Params_Get_Answer_By_Where_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Answer_By_Where_InList_Adv");}
return oList;
}
public List<Notification> Get_Notification_By_Criteria_InList_Adv(Params_Get_Notification_By_Criteria_InList i_Params_Get_Notification_By_Criteria_InList)
{
List<Notification> oList = new List<Notification>();
Notification oNotification = new Notification();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0; 
Params_Get_Notification_By_Criteria_InList_SP oParams_Get_Notification_By_Criteria_InList_SP = new Params_Get_Notification_By_Criteria_InList_SP();
Params_Get_User_By_USER_ID oParams_Get_User_By_USER_ID = new Params_Get_User_By_USER_ID();
Params_Get_Question_By_QUESTION_ID oParams_Get_Question_By_QUESTION_ID = new Params_Get_Question_By_QUESTION_ID();
Params_Get_Answer_By_ANSWER_ID oParams_Get_Answer_By_ANSWER_ID = new Params_Get_Answer_By_ANSWER_ID();
Params_Get_Article_By_ARTICLE_ID oParams_Get_Article_By_ARTICLE_ID = new Params_Get_Article_By_ARTICLE_ID();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Notification_By_Criteria_InList_Adv");}
#region Body Section.
if ((i_Params_Get_Notification_By_Criteria_InList.OWNER_ID == null) || (i_Params_Get_Notification_By_Criteria_InList.OWNER_ID == 0)) { i_Params_Get_Notification_By_Criteria_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Notification_By_Criteria_InList.START_ROW == null) { i_Params_Get_Notification_By_Criteria_InList.START_ROW = 0; }
if ((i_Params_Get_Notification_By_Criteria_InList.END_ROW == null) || (i_Params_Get_Notification_By_Criteria_InList.END_ROW == 0)) { i_Params_Get_Notification_By_Criteria_InList.END_ROW = 1000000; }
oParams_Get_Notification_By_Criteria_InList_SP.OWNER_ID = i_Params_Get_Notification_By_Criteria_InList.OWNER_ID;
oParams_Get_Notification_By_Criteria_InList_SP.DESCRIPTION = i_Params_Get_Notification_By_Criteria_InList.DESCRIPTION;
if ( i_Params_Get_Notification_By_Criteria_InList.QUESTION_ID_LIST == null)
{
i_Params_Get_Notification_By_Criteria_InList.QUESTION_ID_LIST = new List<Int32?>();
}
oParams_Get_Notification_By_Criteria_InList_SP.QUESTION_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Notification_By_Criteria_InList.QUESTION_ID_LIST);
if ( i_Params_Get_Notification_By_Criteria_InList.ANSWER_ID_LIST == null)
{
i_Params_Get_Notification_By_Criteria_InList.ANSWER_ID_LIST = new List<Int32?>();
}
oParams_Get_Notification_By_Criteria_InList_SP.ANSWER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Notification_By_Criteria_InList.ANSWER_ID_LIST);
if ( i_Params_Get_Notification_By_Criteria_InList.ARTICLE_ID_LIST == null)
{
i_Params_Get_Notification_By_Criteria_InList.ARTICLE_ID_LIST = new List<Int32?>();
}
oParams_Get_Notification_By_Criteria_InList_SP.ARTICLE_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Notification_By_Criteria_InList.ARTICLE_ID_LIST);
oParams_Get_Notification_By_Criteria_InList_SP.START_ROW = i_Params_Get_Notification_By_Criteria_InList.START_ROW;
oParams_Get_Notification_By_Criteria_InList_SP.END_ROW = i_Params_Get_Notification_By_Criteria_InList.END_ROW;
oParams_Get_Notification_By_Criteria_InList_SP.TOTAL_COUNT = i_Params_Get_Notification_By_Criteria_InList.TOTAL_COUNT;
List<DALC.Notification> oList_DBEntries = _AppContext.Get_Notification_By_Criteria_InList(i_Params_Get_Notification_By_Criteria_InList.DESCRIPTION,i_Params_Get_Notification_By_Criteria_InList.QUESTION_ID_LIST,i_Params_Get_Notification_By_Criteria_InList.ANSWER_ID_LIST,i_Params_Get_Notification_By_Criteria_InList.ARTICLE_ID_LIST,i_Params_Get_Notification_By_Criteria_InList.OWNER_ID,i_Params_Get_Notification_By_Criteria_InList.START_ROW,i_Params_Get_Notification_By_Criteria_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oNotification = new Notification();
oTools.CopyPropValues(oDBEntry, oNotification);

oNotification.My_User = new User();
oTools.CopyPropValues(oDBEntry.My_User, oNotification.My_User);

oNotification.My_Question = new Question();
oTools.CopyPropValues(oDBEntry.My_Question, oNotification.My_Question);

oNotification.My_Answer = new Answer();
oTools.CopyPropValues(oDBEntry.My_Answer, oNotification.My_Answer);

oNotification.My_Article = new Article();
oTools.CopyPropValues(oDBEntry.My_Article, oNotification.My_Article);

oList.Add(oNotification);
}
}
i_Params_Get_Notification_By_Criteria_InList.TOTAL_COUNT = oParams_Get_Notification_By_Criteria_InList_SP.TOTAL_COUNT;
i_Params_Get_Notification_By_Criteria_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Notification_By_Criteria_InList_Adv");}
return oList;
}
public List<Notification> Get_Notification_By_Where_InList_Adv(Params_Get_Notification_By_Where_InList i_Params_Get_Notification_By_Where_InList)
{
List<Notification> oList = new List<Notification>();
Notification oNotification = new Notification();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0; 
Params_Get_Notification_By_Where_InList_SP oParams_Get_Notification_By_Where_InList_SP = new Params_Get_Notification_By_Where_InList_SP();
Params_Get_User_By_USER_ID oParams_Get_User_By_USER_ID = new Params_Get_User_By_USER_ID();
Params_Get_Question_By_QUESTION_ID oParams_Get_Question_By_QUESTION_ID = new Params_Get_Question_By_QUESTION_ID();
Params_Get_Answer_By_ANSWER_ID oParams_Get_Answer_By_ANSWER_ID = new Params_Get_Answer_By_ANSWER_ID();
Params_Get_Article_By_ARTICLE_ID oParams_Get_Article_By_ARTICLE_ID = new Params_Get_Article_By_ARTICLE_ID();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Notification_By_Where_InList_Adv");}
#region Body Section.
if ((i_Params_Get_Notification_By_Where_InList.OWNER_ID == null) || (i_Params_Get_Notification_By_Where_InList.OWNER_ID == 0)) { i_Params_Get_Notification_By_Where_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Notification_By_Where_InList.START_ROW == null) { i_Params_Get_Notification_By_Where_InList.START_ROW = 0; }
if ((i_Params_Get_Notification_By_Where_InList.END_ROW == null) || (i_Params_Get_Notification_By_Where_InList.END_ROW == 0)) { i_Params_Get_Notification_By_Where_InList.END_ROW = 1000000; }
oParams_Get_Notification_By_Where_InList_SP.OWNER_ID = i_Params_Get_Notification_By_Where_InList.OWNER_ID;
oParams_Get_Notification_By_Where_InList_SP.DESCRIPTION = i_Params_Get_Notification_By_Where_InList.DESCRIPTION;
if ( i_Params_Get_Notification_By_Where_InList.QUESTION_ID_LIST == null)
{
i_Params_Get_Notification_By_Where_InList.QUESTION_ID_LIST = new List<Int32?>();
}
oParams_Get_Notification_By_Where_InList_SP.QUESTION_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Notification_By_Where_InList.QUESTION_ID_LIST);
if ( i_Params_Get_Notification_By_Where_InList.ANSWER_ID_LIST == null)
{
i_Params_Get_Notification_By_Where_InList.ANSWER_ID_LIST = new List<Int32?>();
}
oParams_Get_Notification_By_Where_InList_SP.ANSWER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Notification_By_Where_InList.ANSWER_ID_LIST);
if ( i_Params_Get_Notification_By_Where_InList.ARTICLE_ID_LIST == null)
{
i_Params_Get_Notification_By_Where_InList.ARTICLE_ID_LIST = new List<Int32?>();
}
oParams_Get_Notification_By_Where_InList_SP.ARTICLE_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Notification_By_Where_InList.ARTICLE_ID_LIST);
oParams_Get_Notification_By_Where_InList_SP.START_ROW = i_Params_Get_Notification_By_Where_InList.START_ROW;
oParams_Get_Notification_By_Where_InList_SP.END_ROW = i_Params_Get_Notification_By_Where_InList.END_ROW;
oParams_Get_Notification_By_Where_InList_SP.TOTAL_COUNT = i_Params_Get_Notification_By_Where_InList.TOTAL_COUNT;
List<DALC.Notification> oList_DBEntries = _AppContext.Get_Notification_By_Where_InList(i_Params_Get_Notification_By_Where_InList.DESCRIPTION,i_Params_Get_Notification_By_Where_InList.QUESTION_ID_LIST,i_Params_Get_Notification_By_Where_InList.ANSWER_ID_LIST,i_Params_Get_Notification_By_Where_InList.ARTICLE_ID_LIST,i_Params_Get_Notification_By_Where_InList.OWNER_ID,i_Params_Get_Notification_By_Where_InList.START_ROW,i_Params_Get_Notification_By_Where_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oNotification = new Notification();
oTools.CopyPropValues(oDBEntry, oNotification);

oNotification.My_User = new User();
oTools.CopyPropValues(oDBEntry.My_User, oNotification.My_User);

oNotification.My_Question = new Question();
oTools.CopyPropValues(oDBEntry.My_Question, oNotification.My_Question);

oNotification.My_Answer = new Answer();
oTools.CopyPropValues(oDBEntry.My_Answer, oNotification.My_Answer);

oNotification.My_Article = new Article();
oTools.CopyPropValues(oDBEntry.My_Article, oNotification.My_Article);

oList.Add(oNotification);
}
}
i_Params_Get_Notification_By_Where_InList.TOTAL_COUNT = oParams_Get_Notification_By_Where_InList_SP.TOTAL_COUNT;
i_Params_Get_Notification_By_Where_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Notification_By_Where_InList_Adv");}
return oList;
}
public List<Evaluation> Get_Evaluation_By_Criteria_InList_Adv(Params_Get_Evaluation_By_Criteria_InList i_Params_Get_Evaluation_By_Criteria_InList)
{
List<Evaluation> oList = new List<Evaluation>();
Evaluation oEvaluation = new Evaluation();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0; 
Params_Get_Evaluation_By_Criteria_InList_SP oParams_Get_Evaluation_By_Criteria_InList_SP = new Params_Get_Evaluation_By_Criteria_InList_SP();
Params_Get_Student_By_STUDENT_ID oParams_Get_Student_By_STUDENT_ID = new Params_Get_Student_By_STUDENT_ID();
Params_Get_Answer_By_ANSWER_ID oParams_Get_Answer_By_ANSWER_ID = new Params_Get_Answer_By_ANSWER_ID();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Evaluation_By_Criteria_InList_Adv");}
#region Body Section.
if ((i_Params_Get_Evaluation_By_Criteria_InList.OWNER_ID == null) || (i_Params_Get_Evaluation_By_Criteria_InList.OWNER_ID == 0)) { i_Params_Get_Evaluation_By_Criteria_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Evaluation_By_Criteria_InList.START_ROW == null) { i_Params_Get_Evaluation_By_Criteria_InList.START_ROW = 0; }
if ((i_Params_Get_Evaluation_By_Criteria_InList.END_ROW == null) || (i_Params_Get_Evaluation_By_Criteria_InList.END_ROW == 0)) { i_Params_Get_Evaluation_By_Criteria_InList.END_ROW = 1000000; }
oParams_Get_Evaluation_By_Criteria_InList_SP.OWNER_ID = i_Params_Get_Evaluation_By_Criteria_InList.OWNER_ID;
oParams_Get_Evaluation_By_Criteria_InList_SP.DESCRIPTION = i_Params_Get_Evaluation_By_Criteria_InList.DESCRIPTION;
if ( i_Params_Get_Evaluation_By_Criteria_InList.STUDENT_ID_LIST == null)
{
i_Params_Get_Evaluation_By_Criteria_InList.STUDENT_ID_LIST = new List<Int32?>();
}
oParams_Get_Evaluation_By_Criteria_InList_SP.STUDENT_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Evaluation_By_Criteria_InList.STUDENT_ID_LIST);
if ( i_Params_Get_Evaluation_By_Criteria_InList.ANSWER_ID_LIST == null)
{
i_Params_Get_Evaluation_By_Criteria_InList.ANSWER_ID_LIST = new List<Int32?>();
}
oParams_Get_Evaluation_By_Criteria_InList_SP.ANSWER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Evaluation_By_Criteria_InList.ANSWER_ID_LIST);
oParams_Get_Evaluation_By_Criteria_InList_SP.START_ROW = i_Params_Get_Evaluation_By_Criteria_InList.START_ROW;
oParams_Get_Evaluation_By_Criteria_InList_SP.END_ROW = i_Params_Get_Evaluation_By_Criteria_InList.END_ROW;
oParams_Get_Evaluation_By_Criteria_InList_SP.TOTAL_COUNT = i_Params_Get_Evaluation_By_Criteria_InList.TOTAL_COUNT;
List<DALC.Evaluation> oList_DBEntries = _AppContext.Get_Evaluation_By_Criteria_InList(i_Params_Get_Evaluation_By_Criteria_InList.DESCRIPTION,i_Params_Get_Evaluation_By_Criteria_InList.STUDENT_ID_LIST,i_Params_Get_Evaluation_By_Criteria_InList.ANSWER_ID_LIST,i_Params_Get_Evaluation_By_Criteria_InList.OWNER_ID,i_Params_Get_Evaluation_By_Criteria_InList.START_ROW,i_Params_Get_Evaluation_By_Criteria_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oEvaluation = new Evaluation();
oTools.CopyPropValues(oDBEntry, oEvaluation);

oEvaluation.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oEvaluation.My_Student);

oEvaluation.My_Answer = new Answer();
oTools.CopyPropValues(oDBEntry.My_Answer, oEvaluation.My_Answer);

oList.Add(oEvaluation);
}
}
i_Params_Get_Evaluation_By_Criteria_InList.TOTAL_COUNT = oParams_Get_Evaluation_By_Criteria_InList_SP.TOTAL_COUNT;
i_Params_Get_Evaluation_By_Criteria_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Evaluation_By_Criteria_InList_Adv");}
return oList;
}
public List<Evaluation> Get_Evaluation_By_Where_InList_Adv(Params_Get_Evaluation_By_Where_InList i_Params_Get_Evaluation_By_Where_InList)
{
List<Evaluation> oList = new List<Evaluation>();
Evaluation oEvaluation = new Evaluation();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0; 
Params_Get_Evaluation_By_Where_InList_SP oParams_Get_Evaluation_By_Where_InList_SP = new Params_Get_Evaluation_By_Where_InList_SP();
Params_Get_Student_By_STUDENT_ID oParams_Get_Student_By_STUDENT_ID = new Params_Get_Student_By_STUDENT_ID();
Params_Get_Answer_By_ANSWER_ID oParams_Get_Answer_By_ANSWER_ID = new Params_Get_Answer_By_ANSWER_ID();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Evaluation_By_Where_InList_Adv");}
#region Body Section.
if ((i_Params_Get_Evaluation_By_Where_InList.OWNER_ID == null) || (i_Params_Get_Evaluation_By_Where_InList.OWNER_ID == 0)) { i_Params_Get_Evaluation_By_Where_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Evaluation_By_Where_InList.START_ROW == null) { i_Params_Get_Evaluation_By_Where_InList.START_ROW = 0; }
if ((i_Params_Get_Evaluation_By_Where_InList.END_ROW == null) || (i_Params_Get_Evaluation_By_Where_InList.END_ROW == 0)) { i_Params_Get_Evaluation_By_Where_InList.END_ROW = 1000000; }
oParams_Get_Evaluation_By_Where_InList_SP.OWNER_ID = i_Params_Get_Evaluation_By_Where_InList.OWNER_ID;
oParams_Get_Evaluation_By_Where_InList_SP.DESCRIPTION = i_Params_Get_Evaluation_By_Where_InList.DESCRIPTION;
if ( i_Params_Get_Evaluation_By_Where_InList.STUDENT_ID_LIST == null)
{
i_Params_Get_Evaluation_By_Where_InList.STUDENT_ID_LIST = new List<Int32?>();
}
oParams_Get_Evaluation_By_Where_InList_SP.STUDENT_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Evaluation_By_Where_InList.STUDENT_ID_LIST);
if ( i_Params_Get_Evaluation_By_Where_InList.ANSWER_ID_LIST == null)
{
i_Params_Get_Evaluation_By_Where_InList.ANSWER_ID_LIST = new List<Int32?>();
}
oParams_Get_Evaluation_By_Where_InList_SP.ANSWER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Evaluation_By_Where_InList.ANSWER_ID_LIST);
oParams_Get_Evaluation_By_Where_InList_SP.START_ROW = i_Params_Get_Evaluation_By_Where_InList.START_ROW;
oParams_Get_Evaluation_By_Where_InList_SP.END_ROW = i_Params_Get_Evaluation_By_Where_InList.END_ROW;
oParams_Get_Evaluation_By_Where_InList_SP.TOTAL_COUNT = i_Params_Get_Evaluation_By_Where_InList.TOTAL_COUNT;
List<DALC.Evaluation> oList_DBEntries = _AppContext.Get_Evaluation_By_Where_InList(i_Params_Get_Evaluation_By_Where_InList.DESCRIPTION,i_Params_Get_Evaluation_By_Where_InList.STUDENT_ID_LIST,i_Params_Get_Evaluation_By_Where_InList.ANSWER_ID_LIST,i_Params_Get_Evaluation_By_Where_InList.OWNER_ID,i_Params_Get_Evaluation_By_Where_InList.START_ROW,i_Params_Get_Evaluation_By_Where_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oEvaluation = new Evaluation();
oTools.CopyPropValues(oDBEntry, oEvaluation);

oEvaluation.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oEvaluation.My_Student);

oEvaluation.My_Answer = new Answer();
oTools.CopyPropValues(oDBEntry.My_Answer, oEvaluation.My_Answer);

oList.Add(oEvaluation);
}
}
i_Params_Get_Evaluation_By_Where_InList.TOTAL_COUNT = oParams_Get_Evaluation_By_Where_InList_SP.TOTAL_COUNT;
i_Params_Get_Evaluation_By_Where_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Evaluation_By_Where_InList_Adv");}
return oList;
}
public List<Appreciate> Get_Appreciate_By_Criteria_InList_Adv(Params_Get_Appreciate_By_Criteria_InList i_Params_Get_Appreciate_By_Criteria_InList)
{
List<Appreciate> oList = new List<Appreciate>();
Appreciate oAppreciate = new Appreciate();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0; 
Params_Get_Appreciate_By_Criteria_InList_SP oParams_Get_Appreciate_By_Criteria_InList_SP = new Params_Get_Appreciate_By_Criteria_InList_SP();
Params_Get_Article_By_ARTICLE_ID oParams_Get_Article_By_ARTICLE_ID = new Params_Get_Article_By_ARTICLE_ID();
Params_Get_Student_By_STUDENT_ID oParams_Get_Student_By_STUDENT_ID = new Params_Get_Student_By_STUDENT_ID();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Appreciate_By_Criteria_InList_Adv");}
#region Body Section.
if ((i_Params_Get_Appreciate_By_Criteria_InList.OWNER_ID == null) || (i_Params_Get_Appreciate_By_Criteria_InList.OWNER_ID == 0)) { i_Params_Get_Appreciate_By_Criteria_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Appreciate_By_Criteria_InList.START_ROW == null) { i_Params_Get_Appreciate_By_Criteria_InList.START_ROW = 0; }
if ((i_Params_Get_Appreciate_By_Criteria_InList.END_ROW == null) || (i_Params_Get_Appreciate_By_Criteria_InList.END_ROW == 0)) { i_Params_Get_Appreciate_By_Criteria_InList.END_ROW = 1000000; }
oParams_Get_Appreciate_By_Criteria_InList_SP.OWNER_ID = i_Params_Get_Appreciate_By_Criteria_InList.OWNER_ID;
oParams_Get_Appreciate_By_Criteria_InList_SP.DESCRIPTION = i_Params_Get_Appreciate_By_Criteria_InList.DESCRIPTION;
if ( i_Params_Get_Appreciate_By_Criteria_InList.ARTICLE_ID_LIST == null)
{
i_Params_Get_Appreciate_By_Criteria_InList.ARTICLE_ID_LIST = new List<Int32?>();
}
oParams_Get_Appreciate_By_Criteria_InList_SP.ARTICLE_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Appreciate_By_Criteria_InList.ARTICLE_ID_LIST);
if ( i_Params_Get_Appreciate_By_Criteria_InList.STUDENT_ID_LIST == null)
{
i_Params_Get_Appreciate_By_Criteria_InList.STUDENT_ID_LIST = new List<Int32?>();
}
oParams_Get_Appreciate_By_Criteria_InList_SP.STUDENT_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Appreciate_By_Criteria_InList.STUDENT_ID_LIST);
oParams_Get_Appreciate_By_Criteria_InList_SP.START_ROW = i_Params_Get_Appreciate_By_Criteria_InList.START_ROW;
oParams_Get_Appreciate_By_Criteria_InList_SP.END_ROW = i_Params_Get_Appreciate_By_Criteria_InList.END_ROW;
oParams_Get_Appreciate_By_Criteria_InList_SP.TOTAL_COUNT = i_Params_Get_Appreciate_By_Criteria_InList.TOTAL_COUNT;
List<DALC.Appreciate> oList_DBEntries = _AppContext.Get_Appreciate_By_Criteria_InList(i_Params_Get_Appreciate_By_Criteria_InList.DESCRIPTION,i_Params_Get_Appreciate_By_Criteria_InList.ARTICLE_ID_LIST,i_Params_Get_Appreciate_By_Criteria_InList.STUDENT_ID_LIST,i_Params_Get_Appreciate_By_Criteria_InList.OWNER_ID,i_Params_Get_Appreciate_By_Criteria_InList.START_ROW,i_Params_Get_Appreciate_By_Criteria_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oAppreciate = new Appreciate();
oTools.CopyPropValues(oDBEntry, oAppreciate);

oAppreciate.My_Article = new Article();
oTools.CopyPropValues(oDBEntry.My_Article, oAppreciate.My_Article);

oAppreciate.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oAppreciate.My_Student);

oList.Add(oAppreciate);
}
}
i_Params_Get_Appreciate_By_Criteria_InList.TOTAL_COUNT = oParams_Get_Appreciate_By_Criteria_InList_SP.TOTAL_COUNT;
i_Params_Get_Appreciate_By_Criteria_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Appreciate_By_Criteria_InList_Adv");}
return oList;
}
public List<Appreciate> Get_Appreciate_By_Where_InList_Adv(Params_Get_Appreciate_By_Where_InList i_Params_Get_Appreciate_By_Where_InList)
{
List<Appreciate> oList = new List<Appreciate>();
Appreciate oAppreciate = new Appreciate();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0; 
Params_Get_Appreciate_By_Where_InList_SP oParams_Get_Appreciate_By_Where_InList_SP = new Params_Get_Appreciate_By_Where_InList_SP();
Params_Get_Article_By_ARTICLE_ID oParams_Get_Article_By_ARTICLE_ID = new Params_Get_Article_By_ARTICLE_ID();
Params_Get_Student_By_STUDENT_ID oParams_Get_Student_By_STUDENT_ID = new Params_Get_Student_By_STUDENT_ID();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Appreciate_By_Where_InList_Adv");}
#region Body Section.
if ((i_Params_Get_Appreciate_By_Where_InList.OWNER_ID == null) || (i_Params_Get_Appreciate_By_Where_InList.OWNER_ID == 0)) { i_Params_Get_Appreciate_By_Where_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Appreciate_By_Where_InList.START_ROW == null) { i_Params_Get_Appreciate_By_Where_InList.START_ROW = 0; }
if ((i_Params_Get_Appreciate_By_Where_InList.END_ROW == null) || (i_Params_Get_Appreciate_By_Where_InList.END_ROW == 0)) { i_Params_Get_Appreciate_By_Where_InList.END_ROW = 1000000; }
oParams_Get_Appreciate_By_Where_InList_SP.OWNER_ID = i_Params_Get_Appreciate_By_Where_InList.OWNER_ID;
oParams_Get_Appreciate_By_Where_InList_SP.DESCRIPTION = i_Params_Get_Appreciate_By_Where_InList.DESCRIPTION;
if ( i_Params_Get_Appreciate_By_Where_InList.ARTICLE_ID_LIST == null)
{
i_Params_Get_Appreciate_By_Where_InList.ARTICLE_ID_LIST = new List<Int32?>();
}
oParams_Get_Appreciate_By_Where_InList_SP.ARTICLE_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Appreciate_By_Where_InList.ARTICLE_ID_LIST);
if ( i_Params_Get_Appreciate_By_Where_InList.STUDENT_ID_LIST == null)
{
i_Params_Get_Appreciate_By_Where_InList.STUDENT_ID_LIST = new List<Int32?>();
}
oParams_Get_Appreciate_By_Where_InList_SP.STUDENT_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Appreciate_By_Where_InList.STUDENT_ID_LIST);
oParams_Get_Appreciate_By_Where_InList_SP.START_ROW = i_Params_Get_Appreciate_By_Where_InList.START_ROW;
oParams_Get_Appreciate_By_Where_InList_SP.END_ROW = i_Params_Get_Appreciate_By_Where_InList.END_ROW;
oParams_Get_Appreciate_By_Where_InList_SP.TOTAL_COUNT = i_Params_Get_Appreciate_By_Where_InList.TOTAL_COUNT;
List<DALC.Appreciate> oList_DBEntries = _AppContext.Get_Appreciate_By_Where_InList(i_Params_Get_Appreciate_By_Where_InList.DESCRIPTION,i_Params_Get_Appreciate_By_Where_InList.ARTICLE_ID_LIST,i_Params_Get_Appreciate_By_Where_InList.STUDENT_ID_LIST,i_Params_Get_Appreciate_By_Where_InList.OWNER_ID,i_Params_Get_Appreciate_By_Where_InList.START_ROW,i_Params_Get_Appreciate_By_Where_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oAppreciate = new Appreciate();
oTools.CopyPropValues(oDBEntry, oAppreciate);

oAppreciate.My_Article = new Article();
oTools.CopyPropValues(oDBEntry.My_Article, oAppreciate.My_Article);

oAppreciate.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oAppreciate.My_Student);

oList.Add(oAppreciate);
}
}
i_Params_Get_Appreciate_By_Where_InList.TOTAL_COUNT = oParams_Get_Appreciate_By_Where_InList_SP.TOTAL_COUNT;
i_Params_Get_Appreciate_By_Where_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Appreciate_By_Where_InList_Adv");}
return oList;
}
public List<Teacher_report> Get_Teacher_report_By_Criteria_InList_Adv(Params_Get_Teacher_report_By_Criteria_InList i_Params_Get_Teacher_report_By_Criteria_InList)
{
List<Teacher_report> oList = new List<Teacher_report>();
Teacher_report oTeacher_report = new Teacher_report();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0; 
Params_Get_Teacher_report_By_Criteria_InList_SP oParams_Get_Teacher_report_By_Criteria_InList_SP = new Params_Get_Teacher_report_By_Criteria_InList_SP();
Params_Get_Teacher_By_TEACHER_ID oParams_Get_Teacher_By_TEACHER_ID = new Params_Get_Teacher_By_TEACHER_ID();
Params_Get_Student_By_STUDENT_ID oParams_Get_Student_By_STUDENT_ID = new Params_Get_Student_By_STUDENT_ID();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_report_By_Criteria_InList_Adv");}
#region Body Section.
if ((i_Params_Get_Teacher_report_By_Criteria_InList.OWNER_ID == null) || (i_Params_Get_Teacher_report_By_Criteria_InList.OWNER_ID == 0)) { i_Params_Get_Teacher_report_By_Criteria_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Teacher_report_By_Criteria_InList.START_ROW == null) { i_Params_Get_Teacher_report_By_Criteria_InList.START_ROW = 0; }
if ((i_Params_Get_Teacher_report_By_Criteria_InList.END_ROW == null) || (i_Params_Get_Teacher_report_By_Criteria_InList.END_ROW == 0)) { i_Params_Get_Teacher_report_By_Criteria_InList.END_ROW = 1000000; }
oParams_Get_Teacher_report_By_Criteria_InList_SP.OWNER_ID = i_Params_Get_Teacher_report_By_Criteria_InList.OWNER_ID;
oParams_Get_Teacher_report_By_Criteria_InList_SP.DESCRIPTION = i_Params_Get_Teacher_report_By_Criteria_InList.DESCRIPTION;
if ( i_Params_Get_Teacher_report_By_Criteria_InList.TEACHER_ID_LIST == null)
{
i_Params_Get_Teacher_report_By_Criteria_InList.TEACHER_ID_LIST = new List<Int32?>();
}
oParams_Get_Teacher_report_By_Criteria_InList_SP.TEACHER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Teacher_report_By_Criteria_InList.TEACHER_ID_LIST);
if ( i_Params_Get_Teacher_report_By_Criteria_InList.STUDENT_ID_LIST == null)
{
i_Params_Get_Teacher_report_By_Criteria_InList.STUDENT_ID_LIST = new List<Int32?>();
}
oParams_Get_Teacher_report_By_Criteria_InList_SP.STUDENT_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Teacher_report_By_Criteria_InList.STUDENT_ID_LIST);
oParams_Get_Teacher_report_By_Criteria_InList_SP.START_ROW = i_Params_Get_Teacher_report_By_Criteria_InList.START_ROW;
oParams_Get_Teacher_report_By_Criteria_InList_SP.END_ROW = i_Params_Get_Teacher_report_By_Criteria_InList.END_ROW;
oParams_Get_Teacher_report_By_Criteria_InList_SP.TOTAL_COUNT = i_Params_Get_Teacher_report_By_Criteria_InList.TOTAL_COUNT;
List<DALC.Teacher_report> oList_DBEntries = _AppContext.Get_Teacher_report_By_Criteria_InList(i_Params_Get_Teacher_report_By_Criteria_InList.DESCRIPTION,i_Params_Get_Teacher_report_By_Criteria_InList.TEACHER_ID_LIST,i_Params_Get_Teacher_report_By_Criteria_InList.STUDENT_ID_LIST,i_Params_Get_Teacher_report_By_Criteria_InList.OWNER_ID,i_Params_Get_Teacher_report_By_Criteria_InList.START_ROW,i_Params_Get_Teacher_report_By_Criteria_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_report = new Teacher_report();
oTools.CopyPropValues(oDBEntry, oTeacher_report);

oTeacher_report.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oTeacher_report.My_Teacher);

oTeacher_report.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oTeacher_report.My_Student);

oList.Add(oTeacher_report);
}
}
i_Params_Get_Teacher_report_By_Criteria_InList.TOTAL_COUNT = oParams_Get_Teacher_report_By_Criteria_InList_SP.TOTAL_COUNT;
i_Params_Get_Teacher_report_By_Criteria_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_report_By_Criteria_InList_Adv");}
return oList;
}
public List<Teacher_report> Get_Teacher_report_By_Where_InList_Adv(Params_Get_Teacher_report_By_Where_InList i_Params_Get_Teacher_report_By_Where_InList)
{
List<Teacher_report> oList = new List<Teacher_report>();
Teacher_report oTeacher_report = new Teacher_report();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0; 
Params_Get_Teacher_report_By_Where_InList_SP oParams_Get_Teacher_report_By_Where_InList_SP = new Params_Get_Teacher_report_By_Where_InList_SP();
Params_Get_Teacher_By_TEACHER_ID oParams_Get_Teacher_By_TEACHER_ID = new Params_Get_Teacher_By_TEACHER_ID();
Params_Get_Student_By_STUDENT_ID oParams_Get_Student_By_STUDENT_ID = new Params_Get_Student_By_STUDENT_ID();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_report_By_Where_InList_Adv");}
#region Body Section.
if ((i_Params_Get_Teacher_report_By_Where_InList.OWNER_ID == null) || (i_Params_Get_Teacher_report_By_Where_InList.OWNER_ID == 0)) { i_Params_Get_Teacher_report_By_Where_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Teacher_report_By_Where_InList.START_ROW == null) { i_Params_Get_Teacher_report_By_Where_InList.START_ROW = 0; }
if ((i_Params_Get_Teacher_report_By_Where_InList.END_ROW == null) || (i_Params_Get_Teacher_report_By_Where_InList.END_ROW == 0)) { i_Params_Get_Teacher_report_By_Where_InList.END_ROW = 1000000; }
oParams_Get_Teacher_report_By_Where_InList_SP.OWNER_ID = i_Params_Get_Teacher_report_By_Where_InList.OWNER_ID;
oParams_Get_Teacher_report_By_Where_InList_SP.DESCRIPTION = i_Params_Get_Teacher_report_By_Where_InList.DESCRIPTION;
if ( i_Params_Get_Teacher_report_By_Where_InList.TEACHER_ID_LIST == null)
{
i_Params_Get_Teacher_report_By_Where_InList.TEACHER_ID_LIST = new List<Int32?>();
}
oParams_Get_Teacher_report_By_Where_InList_SP.TEACHER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Teacher_report_By_Where_InList.TEACHER_ID_LIST);
if ( i_Params_Get_Teacher_report_By_Where_InList.STUDENT_ID_LIST == null)
{
i_Params_Get_Teacher_report_By_Where_InList.STUDENT_ID_LIST = new List<Int32?>();
}
oParams_Get_Teacher_report_By_Where_InList_SP.STUDENT_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Teacher_report_By_Where_InList.STUDENT_ID_LIST);
oParams_Get_Teacher_report_By_Where_InList_SP.START_ROW = i_Params_Get_Teacher_report_By_Where_InList.START_ROW;
oParams_Get_Teacher_report_By_Where_InList_SP.END_ROW = i_Params_Get_Teacher_report_By_Where_InList.END_ROW;
oParams_Get_Teacher_report_By_Where_InList_SP.TOTAL_COUNT = i_Params_Get_Teacher_report_By_Where_InList.TOTAL_COUNT;
List<DALC.Teacher_report> oList_DBEntries = _AppContext.Get_Teacher_report_By_Where_InList(i_Params_Get_Teacher_report_By_Where_InList.DESCRIPTION,i_Params_Get_Teacher_report_By_Where_InList.TEACHER_ID_LIST,i_Params_Get_Teacher_report_By_Where_InList.STUDENT_ID_LIST,i_Params_Get_Teacher_report_By_Where_InList.OWNER_ID,i_Params_Get_Teacher_report_By_Where_InList.START_ROW,i_Params_Get_Teacher_report_By_Where_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_report = new Teacher_report();
oTools.CopyPropValues(oDBEntry, oTeacher_report);

oTeacher_report.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oTeacher_report.My_Teacher);

oTeacher_report.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oTeacher_report.My_Student);

oList.Add(oTeacher_report);
}
}
i_Params_Get_Teacher_report_By_Where_InList.TOTAL_COUNT = oParams_Get_Teacher_report_By_Where_InList_SP.TOTAL_COUNT;
i_Params_Get_Teacher_report_By_Where_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_report_By_Where_InList_Adv");}
return oList;
}
public List<Question_report> Get_Question_report_By_Criteria_InList_Adv(Params_Get_Question_report_By_Criteria_InList i_Params_Get_Question_report_By_Criteria_InList)
{
List<Question_report> oList = new List<Question_report>();
Question_report oQuestion_report = new Question_report();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0; 
Params_Get_Question_report_By_Criteria_InList_SP oParams_Get_Question_report_By_Criteria_InList_SP = new Params_Get_Question_report_By_Criteria_InList_SP();
Params_Get_Student_By_STUDENT_ID oParams_Get_Student_By_STUDENT_ID = new Params_Get_Student_By_STUDENT_ID();
Params_Get_Teacher_By_TEACHER_ID oParams_Get_Teacher_By_TEACHER_ID = new Params_Get_Teacher_By_TEACHER_ID();
Params_Get_Question_By_QUESTION_ID oParams_Get_Question_By_QUESTION_ID = new Params_Get_Question_By_QUESTION_ID();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Question_report_By_Criteria_InList_Adv");}
#region Body Section.
if ((i_Params_Get_Question_report_By_Criteria_InList.OWNER_ID == null) || (i_Params_Get_Question_report_By_Criteria_InList.OWNER_ID == 0)) { i_Params_Get_Question_report_By_Criteria_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Question_report_By_Criteria_InList.START_ROW == null) { i_Params_Get_Question_report_By_Criteria_InList.START_ROW = 0; }
if ((i_Params_Get_Question_report_By_Criteria_InList.END_ROW == null) || (i_Params_Get_Question_report_By_Criteria_InList.END_ROW == 0)) { i_Params_Get_Question_report_By_Criteria_InList.END_ROW = 1000000; }
oParams_Get_Question_report_By_Criteria_InList_SP.OWNER_ID = i_Params_Get_Question_report_By_Criteria_InList.OWNER_ID;
oParams_Get_Question_report_By_Criteria_InList_SP.DESCRIPTION = i_Params_Get_Question_report_By_Criteria_InList.DESCRIPTION;
if ( i_Params_Get_Question_report_By_Criteria_InList.STUDENT_ID_LIST == null)
{
i_Params_Get_Question_report_By_Criteria_InList.STUDENT_ID_LIST = new List<Int32?>();
}
oParams_Get_Question_report_By_Criteria_InList_SP.STUDENT_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Question_report_By_Criteria_InList.STUDENT_ID_LIST);
if ( i_Params_Get_Question_report_By_Criteria_InList.TEACHER_ID_LIST == null)
{
i_Params_Get_Question_report_By_Criteria_InList.TEACHER_ID_LIST = new List<Int32?>();
}
oParams_Get_Question_report_By_Criteria_InList_SP.TEACHER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Question_report_By_Criteria_InList.TEACHER_ID_LIST);
if ( i_Params_Get_Question_report_By_Criteria_InList.QUESTION_ID_LIST == null)
{
i_Params_Get_Question_report_By_Criteria_InList.QUESTION_ID_LIST = new List<Int32?>();
}
oParams_Get_Question_report_By_Criteria_InList_SP.QUESTION_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Question_report_By_Criteria_InList.QUESTION_ID_LIST);
oParams_Get_Question_report_By_Criteria_InList_SP.START_ROW = i_Params_Get_Question_report_By_Criteria_InList.START_ROW;
oParams_Get_Question_report_By_Criteria_InList_SP.END_ROW = i_Params_Get_Question_report_By_Criteria_InList.END_ROW;
oParams_Get_Question_report_By_Criteria_InList_SP.TOTAL_COUNT = i_Params_Get_Question_report_By_Criteria_InList.TOTAL_COUNT;
List<DALC.Question_report> oList_DBEntries = _AppContext.Get_Question_report_By_Criteria_InList(i_Params_Get_Question_report_By_Criteria_InList.DESCRIPTION,i_Params_Get_Question_report_By_Criteria_InList.STUDENT_ID_LIST,i_Params_Get_Question_report_By_Criteria_InList.TEACHER_ID_LIST,i_Params_Get_Question_report_By_Criteria_InList.QUESTION_ID_LIST,i_Params_Get_Question_report_By_Criteria_InList.OWNER_ID,i_Params_Get_Question_report_By_Criteria_InList.START_ROW,i_Params_Get_Question_report_By_Criteria_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oQuestion_report = new Question_report();
oTools.CopyPropValues(oDBEntry, oQuestion_report);

oQuestion_report.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oQuestion_report.My_Student);

oQuestion_report.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oQuestion_report.My_Teacher);

oQuestion_report.My_Question = new Question();
oTools.CopyPropValues(oDBEntry.My_Question, oQuestion_report.My_Question);

oList.Add(oQuestion_report);
}
}
i_Params_Get_Question_report_By_Criteria_InList.TOTAL_COUNT = oParams_Get_Question_report_By_Criteria_InList_SP.TOTAL_COUNT;
i_Params_Get_Question_report_By_Criteria_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Question_report_By_Criteria_InList_Adv");}
return oList;
}
public List<Question_report> Get_Question_report_By_Where_InList_Adv(Params_Get_Question_report_By_Where_InList i_Params_Get_Question_report_By_Where_InList)
{
List<Question_report> oList = new List<Question_report>();
Question_report oQuestion_report = new Question_report();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0; 
Params_Get_Question_report_By_Where_InList_SP oParams_Get_Question_report_By_Where_InList_SP = new Params_Get_Question_report_By_Where_InList_SP();
Params_Get_Student_By_STUDENT_ID oParams_Get_Student_By_STUDENT_ID = new Params_Get_Student_By_STUDENT_ID();
Params_Get_Teacher_By_TEACHER_ID oParams_Get_Teacher_By_TEACHER_ID = new Params_Get_Teacher_By_TEACHER_ID();
Params_Get_Question_By_QUESTION_ID oParams_Get_Question_By_QUESTION_ID = new Params_Get_Question_By_QUESTION_ID();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Question_report_By_Where_InList_Adv");}
#region Body Section.
if ((i_Params_Get_Question_report_By_Where_InList.OWNER_ID == null) || (i_Params_Get_Question_report_By_Where_InList.OWNER_ID == 0)) { i_Params_Get_Question_report_By_Where_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Question_report_By_Where_InList.START_ROW == null) { i_Params_Get_Question_report_By_Where_InList.START_ROW = 0; }
if ((i_Params_Get_Question_report_By_Where_InList.END_ROW == null) || (i_Params_Get_Question_report_By_Where_InList.END_ROW == 0)) { i_Params_Get_Question_report_By_Where_InList.END_ROW = 1000000; }
oParams_Get_Question_report_By_Where_InList_SP.OWNER_ID = i_Params_Get_Question_report_By_Where_InList.OWNER_ID;
oParams_Get_Question_report_By_Where_InList_SP.DESCRIPTION = i_Params_Get_Question_report_By_Where_InList.DESCRIPTION;
if ( i_Params_Get_Question_report_By_Where_InList.STUDENT_ID_LIST == null)
{
i_Params_Get_Question_report_By_Where_InList.STUDENT_ID_LIST = new List<Int32?>();
}
oParams_Get_Question_report_By_Where_InList_SP.STUDENT_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Question_report_By_Where_InList.STUDENT_ID_LIST);
if ( i_Params_Get_Question_report_By_Where_InList.TEACHER_ID_LIST == null)
{
i_Params_Get_Question_report_By_Where_InList.TEACHER_ID_LIST = new List<Int32?>();
}
oParams_Get_Question_report_By_Where_InList_SP.TEACHER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Question_report_By_Where_InList.TEACHER_ID_LIST);
if ( i_Params_Get_Question_report_By_Where_InList.QUESTION_ID_LIST == null)
{
i_Params_Get_Question_report_By_Where_InList.QUESTION_ID_LIST = new List<Int32?>();
}
oParams_Get_Question_report_By_Where_InList_SP.QUESTION_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Question_report_By_Where_InList.QUESTION_ID_LIST);
oParams_Get_Question_report_By_Where_InList_SP.START_ROW = i_Params_Get_Question_report_By_Where_InList.START_ROW;
oParams_Get_Question_report_By_Where_InList_SP.END_ROW = i_Params_Get_Question_report_By_Where_InList.END_ROW;
oParams_Get_Question_report_By_Where_InList_SP.TOTAL_COUNT = i_Params_Get_Question_report_By_Where_InList.TOTAL_COUNT;
List<DALC.Question_report> oList_DBEntries = _AppContext.Get_Question_report_By_Where_InList(i_Params_Get_Question_report_By_Where_InList.DESCRIPTION,i_Params_Get_Question_report_By_Where_InList.STUDENT_ID_LIST,i_Params_Get_Question_report_By_Where_InList.TEACHER_ID_LIST,i_Params_Get_Question_report_By_Where_InList.QUESTION_ID_LIST,i_Params_Get_Question_report_By_Where_InList.OWNER_ID,i_Params_Get_Question_report_By_Where_InList.START_ROW,i_Params_Get_Question_report_By_Where_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oQuestion_report = new Question_report();
oTools.CopyPropValues(oDBEntry, oQuestion_report);

oQuestion_report.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oQuestion_report.My_Student);

oQuestion_report.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oQuestion_report.My_Teacher);

oQuestion_report.My_Question = new Question();
oTools.CopyPropValues(oDBEntry.My_Question, oQuestion_report.My_Question);

oList.Add(oQuestion_report);
}
}
i_Params_Get_Question_report_By_Where_InList.TOTAL_COUNT = oParams_Get_Question_report_By_Where_InList_SP.TOTAL_COUNT;
i_Params_Get_Question_report_By_Where_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Question_report_By_Where_InList_Adv");}
return oList;
}
public List<Answer_report> Get_Answer_report_By_Criteria_InList_Adv(Params_Get_Answer_report_By_Criteria_InList i_Params_Get_Answer_report_By_Criteria_InList)
{
List<Answer_report> oList = new List<Answer_report>();
Answer_report oAnswer_report = new Answer_report();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0; 
Params_Get_Answer_report_By_Criteria_InList_SP oParams_Get_Answer_report_By_Criteria_InList_SP = new Params_Get_Answer_report_By_Criteria_InList_SP();
Params_Get_Teacher_By_TEACHER_ID oParams_Get_Teacher_By_TEACHER_ID = new Params_Get_Teacher_By_TEACHER_ID();
Params_Get_Student_By_STUDENT_ID oParams_Get_Student_By_STUDENT_ID = new Params_Get_Student_By_STUDENT_ID();
Params_Get_Answer_By_ANSWER_ID oParams_Get_Answer_By_ANSWER_ID = new Params_Get_Answer_By_ANSWER_ID();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Answer_report_By_Criteria_InList_Adv");}
#region Body Section.
if ((i_Params_Get_Answer_report_By_Criteria_InList.OWNER_ID == null) || (i_Params_Get_Answer_report_By_Criteria_InList.OWNER_ID == 0)) { i_Params_Get_Answer_report_By_Criteria_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Answer_report_By_Criteria_InList.START_ROW == null) { i_Params_Get_Answer_report_By_Criteria_InList.START_ROW = 0; }
if ((i_Params_Get_Answer_report_By_Criteria_InList.END_ROW == null) || (i_Params_Get_Answer_report_By_Criteria_InList.END_ROW == 0)) { i_Params_Get_Answer_report_By_Criteria_InList.END_ROW = 1000000; }
oParams_Get_Answer_report_By_Criteria_InList_SP.OWNER_ID = i_Params_Get_Answer_report_By_Criteria_InList.OWNER_ID;
oParams_Get_Answer_report_By_Criteria_InList_SP.DESCRIPTION = i_Params_Get_Answer_report_By_Criteria_InList.DESCRIPTION;
if ( i_Params_Get_Answer_report_By_Criteria_InList.TEACHER_ID_LIST == null)
{
i_Params_Get_Answer_report_By_Criteria_InList.TEACHER_ID_LIST = new List<Int32?>();
}
oParams_Get_Answer_report_By_Criteria_InList_SP.TEACHER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Answer_report_By_Criteria_InList.TEACHER_ID_LIST);
if ( i_Params_Get_Answer_report_By_Criteria_InList.STUDENT_ID_LIST == null)
{
i_Params_Get_Answer_report_By_Criteria_InList.STUDENT_ID_LIST = new List<Int32?>();
}
oParams_Get_Answer_report_By_Criteria_InList_SP.STUDENT_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Answer_report_By_Criteria_InList.STUDENT_ID_LIST);
if ( i_Params_Get_Answer_report_By_Criteria_InList.ANSWER_ID_LIST == null)
{
i_Params_Get_Answer_report_By_Criteria_InList.ANSWER_ID_LIST = new List<Int32?>();
}
oParams_Get_Answer_report_By_Criteria_InList_SP.ANSWER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Answer_report_By_Criteria_InList.ANSWER_ID_LIST);
oParams_Get_Answer_report_By_Criteria_InList_SP.START_ROW = i_Params_Get_Answer_report_By_Criteria_InList.START_ROW;
oParams_Get_Answer_report_By_Criteria_InList_SP.END_ROW = i_Params_Get_Answer_report_By_Criteria_InList.END_ROW;
oParams_Get_Answer_report_By_Criteria_InList_SP.TOTAL_COUNT = i_Params_Get_Answer_report_By_Criteria_InList.TOTAL_COUNT;
List<DALC.Answer_report> oList_DBEntries = _AppContext.Get_Answer_report_By_Criteria_InList(i_Params_Get_Answer_report_By_Criteria_InList.DESCRIPTION,i_Params_Get_Answer_report_By_Criteria_InList.TEACHER_ID_LIST,i_Params_Get_Answer_report_By_Criteria_InList.STUDENT_ID_LIST,i_Params_Get_Answer_report_By_Criteria_InList.ANSWER_ID_LIST,i_Params_Get_Answer_report_By_Criteria_InList.OWNER_ID,i_Params_Get_Answer_report_By_Criteria_InList.START_ROW,i_Params_Get_Answer_report_By_Criteria_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oAnswer_report = new Answer_report();
oTools.CopyPropValues(oDBEntry, oAnswer_report);

oAnswer_report.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oAnswer_report.My_Teacher);

oAnswer_report.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oAnswer_report.My_Student);

oAnswer_report.My_Answer = new Answer();
oTools.CopyPropValues(oDBEntry.My_Answer, oAnswer_report.My_Answer);

oList.Add(oAnswer_report);
}
}
i_Params_Get_Answer_report_By_Criteria_InList.TOTAL_COUNT = oParams_Get_Answer_report_By_Criteria_InList_SP.TOTAL_COUNT;
i_Params_Get_Answer_report_By_Criteria_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Answer_report_By_Criteria_InList_Adv");}
return oList;
}
public List<Answer_report> Get_Answer_report_By_Where_InList_Adv(Params_Get_Answer_report_By_Where_InList i_Params_Get_Answer_report_By_Where_InList)
{
List<Answer_report> oList = new List<Answer_report>();
Answer_report oAnswer_report = new Answer_report();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0; 
Params_Get_Answer_report_By_Where_InList_SP oParams_Get_Answer_report_By_Where_InList_SP = new Params_Get_Answer_report_By_Where_InList_SP();
Params_Get_Teacher_By_TEACHER_ID oParams_Get_Teacher_By_TEACHER_ID = new Params_Get_Teacher_By_TEACHER_ID();
Params_Get_Student_By_STUDENT_ID oParams_Get_Student_By_STUDENT_ID = new Params_Get_Student_By_STUDENT_ID();
Params_Get_Answer_By_ANSWER_ID oParams_Get_Answer_By_ANSWER_ID = new Params_Get_Answer_By_ANSWER_ID();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Answer_report_By_Where_InList_Adv");}
#region Body Section.
if ((i_Params_Get_Answer_report_By_Where_InList.OWNER_ID == null) || (i_Params_Get_Answer_report_By_Where_InList.OWNER_ID == 0)) { i_Params_Get_Answer_report_By_Where_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Answer_report_By_Where_InList.START_ROW == null) { i_Params_Get_Answer_report_By_Where_InList.START_ROW = 0; }
if ((i_Params_Get_Answer_report_By_Where_InList.END_ROW == null) || (i_Params_Get_Answer_report_By_Where_InList.END_ROW == 0)) { i_Params_Get_Answer_report_By_Where_InList.END_ROW = 1000000; }
oParams_Get_Answer_report_By_Where_InList_SP.OWNER_ID = i_Params_Get_Answer_report_By_Where_InList.OWNER_ID;
oParams_Get_Answer_report_By_Where_InList_SP.DESCRIPTION = i_Params_Get_Answer_report_By_Where_InList.DESCRIPTION;
if ( i_Params_Get_Answer_report_By_Where_InList.TEACHER_ID_LIST == null)
{
i_Params_Get_Answer_report_By_Where_InList.TEACHER_ID_LIST = new List<Int32?>();
}
oParams_Get_Answer_report_By_Where_InList_SP.TEACHER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Answer_report_By_Where_InList.TEACHER_ID_LIST);
if ( i_Params_Get_Answer_report_By_Where_InList.STUDENT_ID_LIST == null)
{
i_Params_Get_Answer_report_By_Where_InList.STUDENT_ID_LIST = new List<Int32?>();
}
oParams_Get_Answer_report_By_Where_InList_SP.STUDENT_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Answer_report_By_Where_InList.STUDENT_ID_LIST);
if ( i_Params_Get_Answer_report_By_Where_InList.ANSWER_ID_LIST == null)
{
i_Params_Get_Answer_report_By_Where_InList.ANSWER_ID_LIST = new List<Int32?>();
}
oParams_Get_Answer_report_By_Where_InList_SP.ANSWER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Answer_report_By_Where_InList.ANSWER_ID_LIST);
oParams_Get_Answer_report_By_Where_InList_SP.START_ROW = i_Params_Get_Answer_report_By_Where_InList.START_ROW;
oParams_Get_Answer_report_By_Where_InList_SP.END_ROW = i_Params_Get_Answer_report_By_Where_InList.END_ROW;
oParams_Get_Answer_report_By_Where_InList_SP.TOTAL_COUNT = i_Params_Get_Answer_report_By_Where_InList.TOTAL_COUNT;
List<DALC.Answer_report> oList_DBEntries = _AppContext.Get_Answer_report_By_Where_InList(i_Params_Get_Answer_report_By_Where_InList.DESCRIPTION,i_Params_Get_Answer_report_By_Where_InList.TEACHER_ID_LIST,i_Params_Get_Answer_report_By_Where_InList.STUDENT_ID_LIST,i_Params_Get_Answer_report_By_Where_InList.ANSWER_ID_LIST,i_Params_Get_Answer_report_By_Where_InList.OWNER_ID,i_Params_Get_Answer_report_By_Where_InList.START_ROW,i_Params_Get_Answer_report_By_Where_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oAnswer_report = new Answer_report();
oTools.CopyPropValues(oDBEntry, oAnswer_report);

oAnswer_report.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oAnswer_report.My_Teacher);

oAnswer_report.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oAnswer_report.My_Student);

oAnswer_report.My_Answer = new Answer();
oTools.CopyPropValues(oDBEntry.My_Answer, oAnswer_report.My_Answer);

oList.Add(oAnswer_report);
}
}
i_Params_Get_Answer_report_By_Where_InList.TOTAL_COUNT = oParams_Get_Answer_report_By_Where_InList_SP.TOTAL_COUNT;
i_Params_Get_Answer_report_By_Where_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Answer_report_By_Where_InList_Adv");}
return oList;
}
public List<Teacher_rank> Get_Teacher_rank_By_Criteria_InList_Adv(Params_Get_Teacher_rank_By_Criteria_InList i_Params_Get_Teacher_rank_By_Criteria_InList)
{
List<Teacher_rank> oList = new List<Teacher_rank>();
Teacher_rank oTeacher_rank = new Teacher_rank();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0; 
Params_Get_Teacher_rank_By_Criteria_InList_SP oParams_Get_Teacher_rank_By_Criteria_InList_SP = new Params_Get_Teacher_rank_By_Criteria_InList_SP();
Params_Get_Teacher_By_TEACHER_ID oParams_Get_Teacher_By_TEACHER_ID = new Params_Get_Teacher_By_TEACHER_ID();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_rank_By_Criteria_InList_Adv");}
#region Body Section.
if ((i_Params_Get_Teacher_rank_By_Criteria_InList.OWNER_ID == null) || (i_Params_Get_Teacher_rank_By_Criteria_InList.OWNER_ID == 0)) { i_Params_Get_Teacher_rank_By_Criteria_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Teacher_rank_By_Criteria_InList.START_ROW == null) { i_Params_Get_Teacher_rank_By_Criteria_InList.START_ROW = 0; }
if ((i_Params_Get_Teacher_rank_By_Criteria_InList.END_ROW == null) || (i_Params_Get_Teacher_rank_By_Criteria_InList.END_ROW == 0)) { i_Params_Get_Teacher_rank_By_Criteria_InList.END_ROW = 1000000; }
oParams_Get_Teacher_rank_By_Criteria_InList_SP.OWNER_ID = i_Params_Get_Teacher_rank_By_Criteria_InList.OWNER_ID;
oParams_Get_Teacher_rank_By_Criteria_InList_SP.DESCRIPTION = i_Params_Get_Teacher_rank_By_Criteria_InList.DESCRIPTION;
if ( i_Params_Get_Teacher_rank_By_Criteria_InList.TEACHER_ID_LIST == null)
{
i_Params_Get_Teacher_rank_By_Criteria_InList.TEACHER_ID_LIST = new List<Int32?>();
}
oParams_Get_Teacher_rank_By_Criteria_InList_SP.TEACHER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Teacher_rank_By_Criteria_InList.TEACHER_ID_LIST);
oParams_Get_Teacher_rank_By_Criteria_InList_SP.START_ROW = i_Params_Get_Teacher_rank_By_Criteria_InList.START_ROW;
oParams_Get_Teacher_rank_By_Criteria_InList_SP.END_ROW = i_Params_Get_Teacher_rank_By_Criteria_InList.END_ROW;
oParams_Get_Teacher_rank_By_Criteria_InList_SP.TOTAL_COUNT = i_Params_Get_Teacher_rank_By_Criteria_InList.TOTAL_COUNT;
List<DALC.Teacher_rank> oList_DBEntries = _AppContext.Get_Teacher_rank_By_Criteria_InList(i_Params_Get_Teacher_rank_By_Criteria_InList.DESCRIPTION,i_Params_Get_Teacher_rank_By_Criteria_InList.TEACHER_ID_LIST,i_Params_Get_Teacher_rank_By_Criteria_InList.OWNER_ID,i_Params_Get_Teacher_rank_By_Criteria_InList.START_ROW,i_Params_Get_Teacher_rank_By_Criteria_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_rank = new Teacher_rank();
oTools.CopyPropValues(oDBEntry, oTeacher_rank);

oTeacher_rank.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oTeacher_rank.My_Teacher);

oList.Add(oTeacher_rank);
}
}
i_Params_Get_Teacher_rank_By_Criteria_InList.TOTAL_COUNT = oParams_Get_Teacher_rank_By_Criteria_InList_SP.TOTAL_COUNT;
i_Params_Get_Teacher_rank_By_Criteria_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_rank_By_Criteria_InList_Adv");}
return oList;
}
public List<Teacher_rank> Get_Teacher_rank_By_Where_InList_Adv(Params_Get_Teacher_rank_By_Where_InList i_Params_Get_Teacher_rank_By_Where_InList)
{
List<Teacher_rank> oList = new List<Teacher_rank>();
Teacher_rank oTeacher_rank = new Teacher_rank();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0; 
Params_Get_Teacher_rank_By_Where_InList_SP oParams_Get_Teacher_rank_By_Where_InList_SP = new Params_Get_Teacher_rank_By_Where_InList_SP();
Params_Get_Teacher_By_TEACHER_ID oParams_Get_Teacher_By_TEACHER_ID = new Params_Get_Teacher_By_TEACHER_ID();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_rank_By_Where_InList_Adv");}
#region Body Section.
if ((i_Params_Get_Teacher_rank_By_Where_InList.OWNER_ID == null) || (i_Params_Get_Teacher_rank_By_Where_InList.OWNER_ID == 0)) { i_Params_Get_Teacher_rank_By_Where_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Teacher_rank_By_Where_InList.START_ROW == null) { i_Params_Get_Teacher_rank_By_Where_InList.START_ROW = 0; }
if ((i_Params_Get_Teacher_rank_By_Where_InList.END_ROW == null) || (i_Params_Get_Teacher_rank_By_Where_InList.END_ROW == 0)) { i_Params_Get_Teacher_rank_By_Where_InList.END_ROW = 1000000; }
oParams_Get_Teacher_rank_By_Where_InList_SP.OWNER_ID = i_Params_Get_Teacher_rank_By_Where_InList.OWNER_ID;
oParams_Get_Teacher_rank_By_Where_InList_SP.DESCRIPTION = i_Params_Get_Teacher_rank_By_Where_InList.DESCRIPTION;
if ( i_Params_Get_Teacher_rank_By_Where_InList.TEACHER_ID_LIST == null)
{
i_Params_Get_Teacher_rank_By_Where_InList.TEACHER_ID_LIST = new List<Int32?>();
}
oParams_Get_Teacher_rank_By_Where_InList_SP.TEACHER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Teacher_rank_By_Where_InList.TEACHER_ID_LIST);
oParams_Get_Teacher_rank_By_Where_InList_SP.START_ROW = i_Params_Get_Teacher_rank_By_Where_InList.START_ROW;
oParams_Get_Teacher_rank_By_Where_InList_SP.END_ROW = i_Params_Get_Teacher_rank_By_Where_InList.END_ROW;
oParams_Get_Teacher_rank_By_Where_InList_SP.TOTAL_COUNT = i_Params_Get_Teacher_rank_By_Where_InList.TOTAL_COUNT;
List<DALC.Teacher_rank> oList_DBEntries = _AppContext.Get_Teacher_rank_By_Where_InList(i_Params_Get_Teacher_rank_By_Where_InList.DESCRIPTION,i_Params_Get_Teacher_rank_By_Where_InList.TEACHER_ID_LIST,i_Params_Get_Teacher_rank_By_Where_InList.OWNER_ID,i_Params_Get_Teacher_rank_By_Where_InList.START_ROW,i_Params_Get_Teacher_rank_By_Where_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_rank = new Teacher_rank();
oTools.CopyPropValues(oDBEntry, oTeacher_rank);

oTeacher_rank.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oTeacher_rank.My_Teacher);

oList.Add(oTeacher_rank);
}
}
i_Params_Get_Teacher_rank_By_Where_InList.TOTAL_COUNT = oParams_Get_Teacher_rank_By_Where_InList_SP.TOTAL_COUNT;
i_Params_Get_Teacher_rank_By_Where_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_rank_By_Where_InList_Adv");}
return oList;
}
public List<Teacher_category> Get_Teacher_category_By_Criteria_InList_Adv(Params_Get_Teacher_category_By_Criteria_InList i_Params_Get_Teacher_category_By_Criteria_InList)
{
List<Teacher_category> oList = new List<Teacher_category>();
Teacher_category oTeacher_category = new Teacher_category();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0; 
Params_Get_Teacher_category_By_Criteria_InList_SP oParams_Get_Teacher_category_By_Criteria_InList_SP = new Params_Get_Teacher_category_By_Criteria_InList_SP();
Params_Get_Teacher_By_TEACHER_ID oParams_Get_Teacher_By_TEACHER_ID = new Params_Get_Teacher_By_TEACHER_ID();
Params_Get_Category_By_CATEGORY_ID oParams_Get_Category_By_CATEGORY_ID = new Params_Get_Category_By_CATEGORY_ID();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_category_By_Criteria_InList_Adv");}
#region Body Section.
if ((i_Params_Get_Teacher_category_By_Criteria_InList.OWNER_ID == null) || (i_Params_Get_Teacher_category_By_Criteria_InList.OWNER_ID == 0)) { i_Params_Get_Teacher_category_By_Criteria_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Teacher_category_By_Criteria_InList.START_ROW == null) { i_Params_Get_Teacher_category_By_Criteria_InList.START_ROW = 0; }
if ((i_Params_Get_Teacher_category_By_Criteria_InList.END_ROW == null) || (i_Params_Get_Teacher_category_By_Criteria_InList.END_ROW == 0)) { i_Params_Get_Teacher_category_By_Criteria_InList.END_ROW = 1000000; }
oParams_Get_Teacher_category_By_Criteria_InList_SP.OWNER_ID = i_Params_Get_Teacher_category_By_Criteria_InList.OWNER_ID;
oParams_Get_Teacher_category_By_Criteria_InList_SP.DESCRIPTION = i_Params_Get_Teacher_category_By_Criteria_InList.DESCRIPTION;
if ( i_Params_Get_Teacher_category_By_Criteria_InList.TEACHER_ID_LIST == null)
{
i_Params_Get_Teacher_category_By_Criteria_InList.TEACHER_ID_LIST = new List<Int32?>();
}
oParams_Get_Teacher_category_By_Criteria_InList_SP.TEACHER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Teacher_category_By_Criteria_InList.TEACHER_ID_LIST);
if ( i_Params_Get_Teacher_category_By_Criteria_InList.CATEGORY_ID_LIST == null)
{
i_Params_Get_Teacher_category_By_Criteria_InList.CATEGORY_ID_LIST = new List<Int32?>();
}
oParams_Get_Teacher_category_By_Criteria_InList_SP.CATEGORY_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Teacher_category_By_Criteria_InList.CATEGORY_ID_LIST);
oParams_Get_Teacher_category_By_Criteria_InList_SP.START_ROW = i_Params_Get_Teacher_category_By_Criteria_InList.START_ROW;
oParams_Get_Teacher_category_By_Criteria_InList_SP.END_ROW = i_Params_Get_Teacher_category_By_Criteria_InList.END_ROW;
oParams_Get_Teacher_category_By_Criteria_InList_SP.TOTAL_COUNT = i_Params_Get_Teacher_category_By_Criteria_InList.TOTAL_COUNT;
List<DALC.Teacher_category> oList_DBEntries = _AppContext.Get_Teacher_category_By_Criteria_InList(i_Params_Get_Teacher_category_By_Criteria_InList.DESCRIPTION,i_Params_Get_Teacher_category_By_Criteria_InList.TEACHER_ID_LIST,i_Params_Get_Teacher_category_By_Criteria_InList.CATEGORY_ID_LIST,i_Params_Get_Teacher_category_By_Criteria_InList.OWNER_ID,i_Params_Get_Teacher_category_By_Criteria_InList.START_ROW,i_Params_Get_Teacher_category_By_Criteria_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_category = new Teacher_category();
oTools.CopyPropValues(oDBEntry, oTeacher_category);

oTeacher_category.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oTeacher_category.My_Teacher);

oTeacher_category.My_Category = new Category();
oTools.CopyPropValues(oDBEntry.My_Category, oTeacher_category.My_Category);

oList.Add(oTeacher_category);
}
}
i_Params_Get_Teacher_category_By_Criteria_InList.TOTAL_COUNT = oParams_Get_Teacher_category_By_Criteria_InList_SP.TOTAL_COUNT;
i_Params_Get_Teacher_category_By_Criteria_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_category_By_Criteria_InList_Adv");}
return oList;
}
public List<Teacher_category> Get_Teacher_category_By_Where_InList_Adv(Params_Get_Teacher_category_By_Where_InList i_Params_Get_Teacher_category_By_Where_InList)
{
List<Teacher_category> oList = new List<Teacher_category>();
Teacher_category oTeacher_category = new Teacher_category();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0; 
Params_Get_Teacher_category_By_Where_InList_SP oParams_Get_Teacher_category_By_Where_InList_SP = new Params_Get_Teacher_category_By_Where_InList_SP();
Params_Get_Teacher_By_TEACHER_ID oParams_Get_Teacher_By_TEACHER_ID = new Params_Get_Teacher_By_TEACHER_ID();
Params_Get_Category_By_CATEGORY_ID oParams_Get_Category_By_CATEGORY_ID = new Params_Get_Category_By_CATEGORY_ID();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_category_By_Where_InList_Adv");}
#region Body Section.
if ((i_Params_Get_Teacher_category_By_Where_InList.OWNER_ID == null) || (i_Params_Get_Teacher_category_By_Where_InList.OWNER_ID == 0)) { i_Params_Get_Teacher_category_By_Where_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Teacher_category_By_Where_InList.START_ROW == null) { i_Params_Get_Teacher_category_By_Where_InList.START_ROW = 0; }
if ((i_Params_Get_Teacher_category_By_Where_InList.END_ROW == null) || (i_Params_Get_Teacher_category_By_Where_InList.END_ROW == 0)) { i_Params_Get_Teacher_category_By_Where_InList.END_ROW = 1000000; }
oParams_Get_Teacher_category_By_Where_InList_SP.OWNER_ID = i_Params_Get_Teacher_category_By_Where_InList.OWNER_ID;
oParams_Get_Teacher_category_By_Where_InList_SP.DESCRIPTION = i_Params_Get_Teacher_category_By_Where_InList.DESCRIPTION;
if ( i_Params_Get_Teacher_category_By_Where_InList.TEACHER_ID_LIST == null)
{
i_Params_Get_Teacher_category_By_Where_InList.TEACHER_ID_LIST = new List<Int32?>();
}
oParams_Get_Teacher_category_By_Where_InList_SP.TEACHER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Teacher_category_By_Where_InList.TEACHER_ID_LIST);
if ( i_Params_Get_Teacher_category_By_Where_InList.CATEGORY_ID_LIST == null)
{
i_Params_Get_Teacher_category_By_Where_InList.CATEGORY_ID_LIST = new List<Int32?>();
}
oParams_Get_Teacher_category_By_Where_InList_SP.CATEGORY_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Teacher_category_By_Where_InList.CATEGORY_ID_LIST);
oParams_Get_Teacher_category_By_Where_InList_SP.START_ROW = i_Params_Get_Teacher_category_By_Where_InList.START_ROW;
oParams_Get_Teacher_category_By_Where_InList_SP.END_ROW = i_Params_Get_Teacher_category_By_Where_InList.END_ROW;
oParams_Get_Teacher_category_By_Where_InList_SP.TOTAL_COUNT = i_Params_Get_Teacher_category_By_Where_InList.TOTAL_COUNT;
List<DALC.Teacher_category> oList_DBEntries = _AppContext.Get_Teacher_category_By_Where_InList(i_Params_Get_Teacher_category_By_Where_InList.DESCRIPTION,i_Params_Get_Teacher_category_By_Where_InList.TEACHER_ID_LIST,i_Params_Get_Teacher_category_By_Where_InList.CATEGORY_ID_LIST,i_Params_Get_Teacher_category_By_Where_InList.OWNER_ID,i_Params_Get_Teacher_category_By_Where_InList.START_ROW,i_Params_Get_Teacher_category_By_Where_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_category = new Teacher_category();
oTools.CopyPropValues(oDBEntry, oTeacher_category);

oTeacher_category.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oTeacher_category.My_Teacher);

oTeacher_category.My_Category = new Category();
oTools.CopyPropValues(oDBEntry.My_Category, oTeacher_category.My_Category);

oList.Add(oTeacher_category);
}
}
i_Params_Get_Teacher_category_By_Where_InList.TOTAL_COUNT = oParams_Get_Teacher_category_By_Where_InList_SP.TOTAL_COUNT;
i_Params_Get_Teacher_category_By_Where_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_category_By_Where_InList_Adv");}
return oList;
}
public List<Favorite_teacher> Get_Favorite_teacher_By_Criteria_InList_Adv(Params_Get_Favorite_teacher_By_Criteria_InList i_Params_Get_Favorite_teacher_By_Criteria_InList)
{
List<Favorite_teacher> oList = new List<Favorite_teacher>();
Favorite_teacher oFavorite_teacher = new Favorite_teacher();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0; 
Params_Get_Favorite_teacher_By_Criteria_InList_SP oParams_Get_Favorite_teacher_By_Criteria_InList_SP = new Params_Get_Favorite_teacher_By_Criteria_InList_SP();
Params_Get_Teacher_By_TEACHER_ID oParams_Get_Teacher_By_TEACHER_ID = new Params_Get_Teacher_By_TEACHER_ID();
Params_Get_Student_By_STUDENT_ID oParams_Get_Student_By_STUDENT_ID = new Params_Get_Student_By_STUDENT_ID();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Favorite_teacher_By_Criteria_InList_Adv");}
#region Body Section.
if ((i_Params_Get_Favorite_teacher_By_Criteria_InList.OWNER_ID == null) || (i_Params_Get_Favorite_teacher_By_Criteria_InList.OWNER_ID == 0)) { i_Params_Get_Favorite_teacher_By_Criteria_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Favorite_teacher_By_Criteria_InList.START_ROW == null) { i_Params_Get_Favorite_teacher_By_Criteria_InList.START_ROW = 0; }
if ((i_Params_Get_Favorite_teacher_By_Criteria_InList.END_ROW == null) || (i_Params_Get_Favorite_teacher_By_Criteria_InList.END_ROW == 0)) { i_Params_Get_Favorite_teacher_By_Criteria_InList.END_ROW = 1000000; }
oParams_Get_Favorite_teacher_By_Criteria_InList_SP.OWNER_ID = i_Params_Get_Favorite_teacher_By_Criteria_InList.OWNER_ID;
oParams_Get_Favorite_teacher_By_Criteria_InList_SP.DESCRIPTION = i_Params_Get_Favorite_teacher_By_Criteria_InList.DESCRIPTION;
if ( i_Params_Get_Favorite_teacher_By_Criteria_InList.TEACHER_ID_LIST == null)
{
i_Params_Get_Favorite_teacher_By_Criteria_InList.TEACHER_ID_LIST = new List<Int32?>();
}
oParams_Get_Favorite_teacher_By_Criteria_InList_SP.TEACHER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Favorite_teacher_By_Criteria_InList.TEACHER_ID_LIST);
if ( i_Params_Get_Favorite_teacher_By_Criteria_InList.STUDENT_ID_LIST == null)
{
i_Params_Get_Favorite_teacher_By_Criteria_InList.STUDENT_ID_LIST = new List<Int32?>();
}
oParams_Get_Favorite_teacher_By_Criteria_InList_SP.STUDENT_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Favorite_teacher_By_Criteria_InList.STUDENT_ID_LIST);
oParams_Get_Favorite_teacher_By_Criteria_InList_SP.START_ROW = i_Params_Get_Favorite_teacher_By_Criteria_InList.START_ROW;
oParams_Get_Favorite_teacher_By_Criteria_InList_SP.END_ROW = i_Params_Get_Favorite_teacher_By_Criteria_InList.END_ROW;
oParams_Get_Favorite_teacher_By_Criteria_InList_SP.TOTAL_COUNT = i_Params_Get_Favorite_teacher_By_Criteria_InList.TOTAL_COUNT;
List<DALC.Favorite_teacher> oList_DBEntries = _AppContext.Get_Favorite_teacher_By_Criteria_InList(i_Params_Get_Favorite_teacher_By_Criteria_InList.DESCRIPTION,i_Params_Get_Favorite_teacher_By_Criteria_InList.TEACHER_ID_LIST,i_Params_Get_Favorite_teacher_By_Criteria_InList.STUDENT_ID_LIST,i_Params_Get_Favorite_teacher_By_Criteria_InList.OWNER_ID,i_Params_Get_Favorite_teacher_By_Criteria_InList.START_ROW,i_Params_Get_Favorite_teacher_By_Criteria_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oFavorite_teacher = new Favorite_teacher();
oTools.CopyPropValues(oDBEntry, oFavorite_teacher);

oFavorite_teacher.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oFavorite_teacher.My_Teacher);

oFavorite_teacher.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oFavorite_teacher.My_Student);

oList.Add(oFavorite_teacher);
}
}
i_Params_Get_Favorite_teacher_By_Criteria_InList.TOTAL_COUNT = oParams_Get_Favorite_teacher_By_Criteria_InList_SP.TOTAL_COUNT;
i_Params_Get_Favorite_teacher_By_Criteria_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Favorite_teacher_By_Criteria_InList_Adv");}
return oList;
}
public List<Favorite_teacher> Get_Favorite_teacher_By_Where_InList_Adv(Params_Get_Favorite_teacher_By_Where_InList i_Params_Get_Favorite_teacher_By_Where_InList)
{
List<Favorite_teacher> oList = new List<Favorite_teacher>();
Favorite_teacher oFavorite_teacher = new Favorite_teacher();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0; 
Params_Get_Favorite_teacher_By_Where_InList_SP oParams_Get_Favorite_teacher_By_Where_InList_SP = new Params_Get_Favorite_teacher_By_Where_InList_SP();
Params_Get_Teacher_By_TEACHER_ID oParams_Get_Teacher_By_TEACHER_ID = new Params_Get_Teacher_By_TEACHER_ID();
Params_Get_Student_By_STUDENT_ID oParams_Get_Student_By_STUDENT_ID = new Params_Get_Student_By_STUDENT_ID();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Favorite_teacher_By_Where_InList_Adv");}
#region Body Section.
if ((i_Params_Get_Favorite_teacher_By_Where_InList.OWNER_ID == null) || (i_Params_Get_Favorite_teacher_By_Where_InList.OWNER_ID == 0)) { i_Params_Get_Favorite_teacher_By_Where_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Favorite_teacher_By_Where_InList.START_ROW == null) { i_Params_Get_Favorite_teacher_By_Where_InList.START_ROW = 0; }
if ((i_Params_Get_Favorite_teacher_By_Where_InList.END_ROW == null) || (i_Params_Get_Favorite_teacher_By_Where_InList.END_ROW == 0)) { i_Params_Get_Favorite_teacher_By_Where_InList.END_ROW = 1000000; }
oParams_Get_Favorite_teacher_By_Where_InList_SP.OWNER_ID = i_Params_Get_Favorite_teacher_By_Where_InList.OWNER_ID;
oParams_Get_Favorite_teacher_By_Where_InList_SP.DESCRIPTION = i_Params_Get_Favorite_teacher_By_Where_InList.DESCRIPTION;
if ( i_Params_Get_Favorite_teacher_By_Where_InList.TEACHER_ID_LIST == null)
{
i_Params_Get_Favorite_teacher_By_Where_InList.TEACHER_ID_LIST = new List<Int32?>();
}
oParams_Get_Favorite_teacher_By_Where_InList_SP.TEACHER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Favorite_teacher_By_Where_InList.TEACHER_ID_LIST);
if ( i_Params_Get_Favorite_teacher_By_Where_InList.STUDENT_ID_LIST == null)
{
i_Params_Get_Favorite_teacher_By_Where_InList.STUDENT_ID_LIST = new List<Int32?>();
}
oParams_Get_Favorite_teacher_By_Where_InList_SP.STUDENT_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Favorite_teacher_By_Where_InList.STUDENT_ID_LIST);
oParams_Get_Favorite_teacher_By_Where_InList_SP.START_ROW = i_Params_Get_Favorite_teacher_By_Where_InList.START_ROW;
oParams_Get_Favorite_teacher_By_Where_InList_SP.END_ROW = i_Params_Get_Favorite_teacher_By_Where_InList.END_ROW;
oParams_Get_Favorite_teacher_By_Where_InList_SP.TOTAL_COUNT = i_Params_Get_Favorite_teacher_By_Where_InList.TOTAL_COUNT;
List<DALC.Favorite_teacher> oList_DBEntries = _AppContext.Get_Favorite_teacher_By_Where_InList(i_Params_Get_Favorite_teacher_By_Where_InList.DESCRIPTION,i_Params_Get_Favorite_teacher_By_Where_InList.TEACHER_ID_LIST,i_Params_Get_Favorite_teacher_By_Where_InList.STUDENT_ID_LIST,i_Params_Get_Favorite_teacher_By_Where_InList.OWNER_ID,i_Params_Get_Favorite_teacher_By_Where_InList.START_ROW,i_Params_Get_Favorite_teacher_By_Where_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oFavorite_teacher = new Favorite_teacher();
oTools.CopyPropValues(oDBEntry, oFavorite_teacher);

oFavorite_teacher.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oFavorite_teacher.My_Teacher);

oFavorite_teacher.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oFavorite_teacher.My_Student);

oList.Add(oFavorite_teacher);
}
}
i_Params_Get_Favorite_teacher_By_Where_InList.TOTAL_COUNT = oParams_Get_Favorite_teacher_By_Where_InList_SP.TOTAL_COUNT;
i_Params_Get_Favorite_teacher_By_Where_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Favorite_teacher_By_Where_InList_Adv");}
return oList;
}
public List<Teacher_favorite> Get_Teacher_favorite_By_Criteria_InList_Adv(Params_Get_Teacher_favorite_By_Criteria_InList i_Params_Get_Teacher_favorite_By_Criteria_InList)
{
List<Teacher_favorite> oList = new List<Teacher_favorite>();
Teacher_favorite oTeacher_favorite = new Teacher_favorite();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0; 
Params_Get_Teacher_favorite_By_Criteria_InList_SP oParams_Get_Teacher_favorite_By_Criteria_InList_SP = new Params_Get_Teacher_favorite_By_Criteria_InList_SP();
Params_Get_Teacher_By_TEACHER_ID oParams_Get_Teacher_By_TEACHER_ID = new Params_Get_Teacher_By_TEACHER_ID();
Params_Get_Student_By_STUDENT_ID oParams_Get_Student_By_STUDENT_ID = new Params_Get_Student_By_STUDENT_ID();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_favorite_By_Criteria_InList_Adv");}
#region Body Section.
if ((i_Params_Get_Teacher_favorite_By_Criteria_InList.OWNER_ID == null) || (i_Params_Get_Teacher_favorite_By_Criteria_InList.OWNER_ID == 0)) { i_Params_Get_Teacher_favorite_By_Criteria_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Teacher_favorite_By_Criteria_InList.START_ROW == null) { i_Params_Get_Teacher_favorite_By_Criteria_InList.START_ROW = 0; }
if ((i_Params_Get_Teacher_favorite_By_Criteria_InList.END_ROW == null) || (i_Params_Get_Teacher_favorite_By_Criteria_InList.END_ROW == 0)) { i_Params_Get_Teacher_favorite_By_Criteria_InList.END_ROW = 1000000; }
oParams_Get_Teacher_favorite_By_Criteria_InList_SP.OWNER_ID = i_Params_Get_Teacher_favorite_By_Criteria_InList.OWNER_ID;
oParams_Get_Teacher_favorite_By_Criteria_InList_SP.DESCRIPTION = i_Params_Get_Teacher_favorite_By_Criteria_InList.DESCRIPTION;
if ( i_Params_Get_Teacher_favorite_By_Criteria_InList.TEACHER_ID_LIST == null)
{
i_Params_Get_Teacher_favorite_By_Criteria_InList.TEACHER_ID_LIST = new List<Int32?>();
}
oParams_Get_Teacher_favorite_By_Criteria_InList_SP.TEACHER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Teacher_favorite_By_Criteria_InList.TEACHER_ID_LIST);
if ( i_Params_Get_Teacher_favorite_By_Criteria_InList.STUDENT_ID_LIST == null)
{
i_Params_Get_Teacher_favorite_By_Criteria_InList.STUDENT_ID_LIST = new List<Int32?>();
}
oParams_Get_Teacher_favorite_By_Criteria_InList_SP.STUDENT_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Teacher_favorite_By_Criteria_InList.STUDENT_ID_LIST);
oParams_Get_Teacher_favorite_By_Criteria_InList_SP.START_ROW = i_Params_Get_Teacher_favorite_By_Criteria_InList.START_ROW;
oParams_Get_Teacher_favorite_By_Criteria_InList_SP.END_ROW = i_Params_Get_Teacher_favorite_By_Criteria_InList.END_ROW;
oParams_Get_Teacher_favorite_By_Criteria_InList_SP.TOTAL_COUNT = i_Params_Get_Teacher_favorite_By_Criteria_InList.TOTAL_COUNT;
List<DALC.Teacher_favorite> oList_DBEntries = _AppContext.Get_Teacher_favorite_By_Criteria_InList(i_Params_Get_Teacher_favorite_By_Criteria_InList.DESCRIPTION,i_Params_Get_Teacher_favorite_By_Criteria_InList.TEACHER_ID_LIST,i_Params_Get_Teacher_favorite_By_Criteria_InList.STUDENT_ID_LIST,i_Params_Get_Teacher_favorite_By_Criteria_InList.OWNER_ID,i_Params_Get_Teacher_favorite_By_Criteria_InList.START_ROW,i_Params_Get_Teacher_favorite_By_Criteria_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_favorite = new Teacher_favorite();
oTools.CopyPropValues(oDBEntry, oTeacher_favorite);

oTeacher_favorite.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oTeacher_favorite.My_Teacher);

oTeacher_favorite.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oTeacher_favorite.My_Student);

oList.Add(oTeacher_favorite);
}
}
i_Params_Get_Teacher_favorite_By_Criteria_InList.TOTAL_COUNT = oParams_Get_Teacher_favorite_By_Criteria_InList_SP.TOTAL_COUNT;
i_Params_Get_Teacher_favorite_By_Criteria_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_favorite_By_Criteria_InList_Adv");}
return oList;
}
public List<Teacher_favorite> Get_Teacher_favorite_By_Where_InList_Adv(Params_Get_Teacher_favorite_By_Where_InList i_Params_Get_Teacher_favorite_By_Where_InList)
{
List<Teacher_favorite> oList = new List<Teacher_favorite>();
Teacher_favorite oTeacher_favorite = new Teacher_favorite();
Tools.Tools oTools = new Tools.Tools();
long? tmp_TOTAL_COUNT = 0; 
Params_Get_Teacher_favorite_By_Where_InList_SP oParams_Get_Teacher_favorite_By_Where_InList_SP = new Params_Get_Teacher_favorite_By_Where_InList_SP();
Params_Get_Teacher_By_TEACHER_ID oParams_Get_Teacher_By_TEACHER_ID = new Params_Get_Teacher_By_TEACHER_ID();
Params_Get_Student_By_STUDENT_ID oParams_Get_Student_By_STUDENT_ID = new Params_Get_Student_By_STUDENT_ID();
if (OnPreEvent_General != null){OnPreEvent_General("Get_Teacher_favorite_By_Where_InList_Adv");}
#region Body Section.
if ((i_Params_Get_Teacher_favorite_By_Where_InList.OWNER_ID == null) || (i_Params_Get_Teacher_favorite_By_Where_InList.OWNER_ID == 0)) { i_Params_Get_Teacher_favorite_By_Where_InList.OWNER_ID = this.OwnerID; }
if (i_Params_Get_Teacher_favorite_By_Where_InList.START_ROW == null) { i_Params_Get_Teacher_favorite_By_Where_InList.START_ROW = 0; }
if ((i_Params_Get_Teacher_favorite_By_Where_InList.END_ROW == null) || (i_Params_Get_Teacher_favorite_By_Where_InList.END_ROW == 0)) { i_Params_Get_Teacher_favorite_By_Where_InList.END_ROW = 1000000; }
oParams_Get_Teacher_favorite_By_Where_InList_SP.OWNER_ID = i_Params_Get_Teacher_favorite_By_Where_InList.OWNER_ID;
oParams_Get_Teacher_favorite_By_Where_InList_SP.DESCRIPTION = i_Params_Get_Teacher_favorite_By_Where_InList.DESCRIPTION;
if ( i_Params_Get_Teacher_favorite_By_Where_InList.TEACHER_ID_LIST == null)
{
i_Params_Get_Teacher_favorite_By_Where_InList.TEACHER_ID_LIST = new List<Int32?>();
}
oParams_Get_Teacher_favorite_By_Where_InList_SP.TEACHER_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Teacher_favorite_By_Where_InList.TEACHER_ID_LIST);
if ( i_Params_Get_Teacher_favorite_By_Where_InList.STUDENT_ID_LIST == null)
{
i_Params_Get_Teacher_favorite_By_Where_InList.STUDENT_ID_LIST = new List<Int32?>();
}
oParams_Get_Teacher_favorite_By_Where_InList_SP.STUDENT_ID_LIST = oTools.Convert_List_To_Comma_Separated<Int32?>(i_Params_Get_Teacher_favorite_By_Where_InList.STUDENT_ID_LIST);
oParams_Get_Teacher_favorite_By_Where_InList_SP.START_ROW = i_Params_Get_Teacher_favorite_By_Where_InList.START_ROW;
oParams_Get_Teacher_favorite_By_Where_InList_SP.END_ROW = i_Params_Get_Teacher_favorite_By_Where_InList.END_ROW;
oParams_Get_Teacher_favorite_By_Where_InList_SP.TOTAL_COUNT = i_Params_Get_Teacher_favorite_By_Where_InList.TOTAL_COUNT;
List<DALC.Teacher_favorite> oList_DBEntries = _AppContext.Get_Teacher_favorite_By_Where_InList(i_Params_Get_Teacher_favorite_By_Where_InList.DESCRIPTION,i_Params_Get_Teacher_favorite_By_Where_InList.TEACHER_ID_LIST,i_Params_Get_Teacher_favorite_By_Where_InList.STUDENT_ID_LIST,i_Params_Get_Teacher_favorite_By_Where_InList.OWNER_ID,i_Params_Get_Teacher_favorite_By_Where_InList.START_ROW,i_Params_Get_Teacher_favorite_By_Where_InList.END_ROW,ref tmp_TOTAL_COUNT);
if (oList_DBEntries != null)
{
foreach (var oDBEntry in oList_DBEntries)
{
oTeacher_favorite = new Teacher_favorite();
oTools.CopyPropValues(oDBEntry, oTeacher_favorite);

oTeacher_favorite.My_Teacher = new Teacher();
oTools.CopyPropValues(oDBEntry.My_Teacher, oTeacher_favorite.My_Teacher);

oTeacher_favorite.My_Student = new Student();
oTools.CopyPropValues(oDBEntry.My_Student, oTeacher_favorite.My_Student);

oList.Add(oTeacher_favorite);
}
}
i_Params_Get_Teacher_favorite_By_Where_InList.TOTAL_COUNT = oParams_Get_Teacher_favorite_By_Where_InList_SP.TOTAL_COUNT;
i_Params_Get_Teacher_favorite_By_Where_InList.TOTAL_COUNT = tmp_TOTAL_COUNT;
#endregion
if (OnPostEvent_General != null){OnPostEvent_General("Get_Teacher_favorite_By_Where_InList_Adv");}
return oList;
}
}
}
