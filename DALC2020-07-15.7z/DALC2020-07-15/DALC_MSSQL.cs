using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Dynamic;

namespace DALC
{
public partial class MSSQL_DALC : IDALC
{
public Answer Get_Answer_By_ANSWER_ID ( Int32? ANSWER_ID)
{
Answer o = new Answer();
dynamic p = new ExpandoObject();
p.ANSWER_ID = ANSWER_ID;
IEnumerable<IDataRecord> oQuery = ExecuteSelectQuery("UPG_GET_ANSWER_BY_ANSWER_ID", p);
var R = oQuery.FirstOrDefault();
if (R != null)
{
oTools.CopyPropValues_FromDataRecord(R, o);
}
return o;
}
public Answer_report Get_Answer_report_By_ANSWER_REPORT_ID ( Int32? ANSWER_REPORT_ID)
{
Answer_report o = new Answer_report();
dynamic p = new ExpandoObject();
p.ANSWER_REPORT_ID = ANSWER_REPORT_ID;
IEnumerable<IDataRecord> oQuery = ExecuteSelectQuery("UPG_GET_ANSWER_REPORT_BY_ANSWER_REPORT_ID", p);
var R = oQuery.FirstOrDefault();
if (R != null)
{
oTools.CopyPropValues_FromDataRecord(R, o);
}
return o;
}
public Appreciate Get_Appreciate_By_APPRECIATE_ID ( Int32? APPRECIATE_ID)
{
Appreciate o = new Appreciate();
dynamic p = new ExpandoObject();
p.APPRECIATE_ID = APPRECIATE_ID;
IEnumerable<IDataRecord> oQuery = ExecuteSelectQuery("UPG_GET_APPRECIATE_BY_APPRECIATE_ID", p);
var R = oQuery.FirstOrDefault();
if (R != null)
{
oTools.CopyPropValues_FromDataRecord(R, o);
}
return o;
}
public Article Get_Article_By_ARTICLE_ID ( Int32? ARTICLE_ID)
{
Article o = new Article();
dynamic p = new ExpandoObject();
p.ARTICLE_ID = ARTICLE_ID;
IEnumerable<IDataRecord> oQuery = ExecuteSelectQuery("UPG_GET_ARTICLE_BY_ARTICLE_ID", p);
var R = oQuery.FirstOrDefault();
if (R != null)
{
oTools.CopyPropValues_FromDataRecord(R, o);
}
return o;
}
public Category Get_Category_By_CATEGORY_ID ( Int32? CATEGORY_ID)
{
Category o = new Category();
dynamic p = new ExpandoObject();
p.CATEGORY_ID = CATEGORY_ID;
IEnumerable<IDataRecord> oQuery = ExecuteSelectQuery("UPG_GET_CATEGORY_BY_CATEGORY_ID", p);
var R = oQuery.FirstOrDefault();
if (R != null)
{
oTools.CopyPropValues_FromDataRecord(R, o);
}
return o;
}
public Evaluation Get_Evaluation_By_EVALUATION_ID ( Int32? EVALUATION_ID)
{
Evaluation o = new Evaluation();
dynamic p = new ExpandoObject();
p.EVALUATION_ID = EVALUATION_ID;
IEnumerable<IDataRecord> oQuery = ExecuteSelectQuery("UPG_GET_EVALUATION_BY_EVALUATION_ID", p);
var R = oQuery.FirstOrDefault();
if (R != null)
{
oTools.CopyPropValues_FromDataRecord(R, o);
}
return o;
}
public Favorite_category Get_Favorite_category_By_FAVORITE_CATEGORY_ID ( Int32? FAVORITE_CATEGORY_ID)
{
Favorite_category o = new Favorite_category();
dynamic p = new ExpandoObject();
p.FAVORITE_CATEGORY_ID = FAVORITE_CATEGORY_ID;
IEnumerable<IDataRecord> oQuery = ExecuteSelectQuery("UPG_GET_FAVORITE_CATEGORY_BY_FAVORITE_CATEGORY_ID", p);
var R = oQuery.FirstOrDefault();
if (R != null)
{
oTools.CopyPropValues_FromDataRecord(R, o);
}
return o;
}
public Favorite_teacher Get_Favorite_teacher_By_FAVORITE_TEACHER_ID ( Int32? FAVORITE_TEACHER_ID)
{
Favorite_teacher o = new Favorite_teacher();
dynamic p = new ExpandoObject();
p.FAVORITE_TEACHER_ID = FAVORITE_TEACHER_ID;
IEnumerable<IDataRecord> oQuery = ExecuteSelectQuery("UPG_GET_FAVORITE_TEACHER_BY_FAVORITE_TEACHER_ID", p);
var R = oQuery.FirstOrDefault();
if (R != null)
{
oTools.CopyPropValues_FromDataRecord(R, o);
}
return o;
}
public Mark_question Get_Mark_question_By_MARK_QUESTION_ID ( Int32? MARK_QUESTION_ID)
{
Mark_question o = new Mark_question();
dynamic p = new ExpandoObject();
p.MARK_QUESTION_ID = MARK_QUESTION_ID;
IEnumerable<IDataRecord> oQuery = ExecuteSelectQuery("UPG_GET_MARK_QUESTION_BY_MARK_QUESTION_ID", p);
var R = oQuery.FirstOrDefault();
if (R != null)
{
oTools.CopyPropValues_FromDataRecord(R, o);
}
return o;
}
public Notification Get_Notification_By_NOTIFICATION_ID ( Int32? NOTIFICATION_ID)
{
Notification o = new Notification();
dynamic p = new ExpandoObject();
p.NOTIFICATION_ID = NOTIFICATION_ID;
IEnumerable<IDataRecord> oQuery = ExecuteSelectQuery("UPG_GET_NOTIFICATION_BY_NOTIFICATION_ID", p);
var R = oQuery.FirstOrDefault();
if (R != null)
{
oTools.CopyPropValues_FromDataRecord(R, o);
}
return o;
}
public Owner Get_Owner_By_OWNER_ID ( Int32? OWNER_ID)
{
Owner o = new Owner();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> oQuery = ExecuteSelectQuery("UPG_GET_OWNER_BY_OWNER_ID", p);
var R = oQuery.FirstOrDefault();
if (R != null)
{
oTools.CopyPropValues_FromDataRecord(R, o);
}
return o;
}
public Question Get_Question_By_QUESTION_ID ( Int32? QUESTION_ID)
{
Question o = new Question();
dynamic p = new ExpandoObject();
p.QUESTION_ID = QUESTION_ID;
IEnumerable<IDataRecord> oQuery = ExecuteSelectQuery("UPG_GET_QUESTION_BY_QUESTION_ID", p);
var R = oQuery.FirstOrDefault();
if (R != null)
{
oTools.CopyPropValues_FromDataRecord(R, o);
}
return o;
}
public Question_report Get_Question_report_By_QUESTION_REPORT_ID ( Int32? QUESTION_REPORT_ID)
{
Question_report o = new Question_report();
dynamic p = new ExpandoObject();
p.QUESTION_REPORT_ID = QUESTION_REPORT_ID;
IEnumerable<IDataRecord> oQuery = ExecuteSelectQuery("UPG_GET_QUESTION_REPORT_BY_QUESTION_REPORT_ID", p);
var R = oQuery.FirstOrDefault();
if (R != null)
{
oTools.CopyPropValues_FromDataRecord(R, o);
}
return o;
}
public Question_token Get_Question_token_By_QUESTION_TOKEN_ID ( long? QUESTION_TOKEN_ID)
{
Question_token o = new Question_token();
dynamic p = new ExpandoObject();
p.QUESTION_TOKEN_ID = QUESTION_TOKEN_ID;
IEnumerable<IDataRecord> oQuery = ExecuteSelectQuery("UPG_GET_QUESTION_TOKEN_BY_QUESTION_TOKEN_ID", p);
var R = oQuery.FirstOrDefault();
if (R != null)
{
oTools.CopyPropValues_FromDataRecord(R, o);
}
return o;
}
public Report_article Get_Report_article_By_REPORT_ARTICLE_ID ( Int32? REPORT_ARTICLE_ID)
{
Report_article o = new Report_article();
dynamic p = new ExpandoObject();
p.REPORT_ARTICLE_ID = REPORT_ARTICLE_ID;
IEnumerable<IDataRecord> oQuery = ExecuteSelectQuery("UPG_GET_REPORT_ARTICLE_BY_REPORT_ARTICLE_ID", p);
var R = oQuery.FirstOrDefault();
if (R != null)
{
oTools.CopyPropValues_FromDataRecord(R, o);
}
return o;
}
public Student Get_Student_By_STUDENT_ID ( Int32? STUDENT_ID)
{
Student o = new Student();
dynamic p = new ExpandoObject();
p.STUDENT_ID = STUDENT_ID;
IEnumerable<IDataRecord> oQuery = ExecuteSelectQuery("UPG_GET_STUDENT_BY_STUDENT_ID", p);
var R = oQuery.FirstOrDefault();
if (R != null)
{
oTools.CopyPropValues_FromDataRecord(R, o);
}
return o;
}
public Student_report Get_Student_report_By_STUDENT_REPORT_ID ( Int32? STUDENT_REPORT_ID)
{
Student_report o = new Student_report();
dynamic p = new ExpandoObject();
p.STUDENT_REPORT_ID = STUDENT_REPORT_ID;
IEnumerable<IDataRecord> oQuery = ExecuteSelectQuery("UPG_GET_STUDENT_REPORT_BY_STUDENT_REPORT_ID", p);
var R = oQuery.FirstOrDefault();
if (R != null)
{
oTools.CopyPropValues_FromDataRecord(R, o);
}
return o;
}
public Teacher Get_Teacher_By_TEACHER_ID ( Int32? TEACHER_ID)
{
Teacher o = new Teacher();
dynamic p = new ExpandoObject();
p.TEACHER_ID = TEACHER_ID;
IEnumerable<IDataRecord> oQuery = ExecuteSelectQuery("UPG_GET_TEACHER_BY_TEACHER_ID", p);
var R = oQuery.FirstOrDefault();
if (R != null)
{
oTools.CopyPropValues_FromDataRecord(R, o);
}
return o;
}
public Teacher_category Get_Teacher_category_By_TEACHER_CATEGORY_ID ( Int32? TEACHER_CATEGORY_ID)
{
Teacher_category o = new Teacher_category();
dynamic p = new ExpandoObject();
p.TEACHER_CATEGORY_ID = TEACHER_CATEGORY_ID;
IEnumerable<IDataRecord> oQuery = ExecuteSelectQuery("UPG_GET_TEACHER_CATEGORY_BY_TEACHER_CATEGORY_ID", p);
var R = oQuery.FirstOrDefault();
if (R != null)
{
oTools.CopyPropValues_FromDataRecord(R, o);
}
return o;
}
public Teacher_favorite Get_Teacher_favorite_By_TEACHER_FAVORITE_ID ( Int32? TEACHER_FAVORITE_ID)
{
Teacher_favorite o = new Teacher_favorite();
dynamic p = new ExpandoObject();
p.TEACHER_FAVORITE_ID = TEACHER_FAVORITE_ID;
IEnumerable<IDataRecord> oQuery = ExecuteSelectQuery("UPG_GET_TEACHER_FAVORITE_BY_TEACHER_FAVORITE_ID", p);
var R = oQuery.FirstOrDefault();
if (R != null)
{
oTools.CopyPropValues_FromDataRecord(R, o);
}
return o;
}
public Teacher_rank Get_Teacher_rank_By_TEACHER_RANK_ID ( Int32? TEACHER_RANK_ID)
{
Teacher_rank o = new Teacher_rank();
dynamic p = new ExpandoObject();
p.TEACHER_RANK_ID = TEACHER_RANK_ID;
IEnumerable<IDataRecord> oQuery = ExecuteSelectQuery("UPG_GET_TEACHER_RANK_BY_TEACHER_RANK_ID", p);
var R = oQuery.FirstOrDefault();
if (R != null)
{
oTools.CopyPropValues_FromDataRecord(R, o);
}
return o;
}
public Teacher_report Get_Teacher_report_By_TEACHER_REPORT_ID ( Int32? TEACHER_REPORT_ID)
{
Teacher_report o = new Teacher_report();
dynamic p = new ExpandoObject();
p.TEACHER_REPORT_ID = TEACHER_REPORT_ID;
IEnumerable<IDataRecord> oQuery = ExecuteSelectQuery("UPG_GET_TEACHER_REPORT_BY_TEACHER_REPORT_ID", p);
var R = oQuery.FirstOrDefault();
if (R != null)
{
oTools.CopyPropValues_FromDataRecord(R, o);
}
return o;
}
public User Get_User_By_USER_ID ( long? USER_ID)
{
User o = new User();
dynamic p = new ExpandoObject();
p.USER_ID = USER_ID;
IEnumerable<IDataRecord> oQuery = ExecuteSelectQuery("UPG_GET_USER_BY_USER_ID", p);
var R = oQuery.FirstOrDefault();
if (R != null)
{
oTools.CopyPropValues_FromDataRecord(R, o);
}
return o;
}
public Answer Get_Answer_By_ANSWER_ID_Adv ( Int32? ANSWER_ID)
{
Answer o = new Answer();
dynamic p = new ExpandoObject();
p.ANSWER_ID = ANSWER_ID;
IEnumerable<IDataRecord> oQuery = ExecuteSelectQuery("UPG_GET_ANSWER_BY_ANSWER_ID_ADV", p);
var R = oQuery.FirstOrDefault();
if (R != null)
{
oTools.CopyPropValues_FromDataRecord(R, o);

o.My_Question = new Question();
o.My_Question.QUESTION_ID = Convert.IsDBNull(R["T_QUESTION_QUESTION_ID"]) ? default : Convert.ToInt32(R["T_QUESTION_QUESTION_ID"]);o.My_Question.STUDENT_ID = Convert.IsDBNull(R["T_QUESTION_STUDENT_ID"]) ? default : Convert.ToInt32(R["T_QUESTION_STUDENT_ID"]);o.My_Question.CATEGORY_ID = Convert.IsDBNull(R["T_QUESTION_CATEGORY_ID"]) ? default : Convert.ToInt32(R["T_QUESTION_CATEGORY_ID"]);o.My_Question.TEACHER_ID = Convert.IsDBNull(R["T_QUESTION_TEACHER_ID"]) ? default : Convert.ToInt32(R["T_QUESTION_TEACHER_ID"]);o.My_Question.DESCRIPTION = Convert.IsDBNull(R["T_QUESTION_DESCRIPTION"]) ? default : Convert.ToString(R["T_QUESTION_DESCRIPTION"]);o.My_Question.IS_ANSWERED = Convert.IsDBNull(R["T_QUESTION_IS_ANSWERED"]) ? default : Convert.ToBoolean(R["T_QUESTION_IS_ANSWERED"]);o.My_Question.IS_ACTIVE = Convert.IsDBNull(R["T_QUESTION_IS_ACTIVE"]) ? default : Convert.ToBoolean(R["T_QUESTION_IS_ACTIVE"]);o.My_Question.REPORTS = Convert.IsDBNull(R["T_QUESTION_REPORTS"]) ? default : Convert.ToInt32(R["T_QUESTION_REPORTS"]);o.My_Question.ENTRY_USER_ID = Convert.IsDBNull(R["T_QUESTION_ENTRY_USER_ID"]) ? default : Convert.ToInt64(R["T_QUESTION_ENTRY_USER_ID"]);o.My_Question.ENTRY_DATE = Convert.IsDBNull(R["T_QUESTION_ENTRY_DATE"]) ? default : Convert.ToString(R["T_QUESTION_ENTRY_DATE"]);o.My_Question.OWNER_ID = Convert.IsDBNull(R["T_QUESTION_OWNER_ID"]) ? default : Convert.ToInt32(R["T_QUESTION_OWNER_ID"]);
o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(R["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(R["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(R["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(R["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(R["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(R["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(R["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(R["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(R["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(R["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(R["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(R["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(R["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(R["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(R["T_TEACHER_EMAIL"]) ? default : Convert.ToString(R["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(R["T_TEACHER_MOBILE"]) ? default : Convert.ToString(R["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(R["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(R["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(R["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(R["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(R["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(R["T_TEACHER_OWNER_ID"]);
}
return o;
}
public Answer_report Get_Answer_report_By_ANSWER_REPORT_ID_Adv ( Int32? ANSWER_REPORT_ID)
{
Answer_report o = new Answer_report();
dynamic p = new ExpandoObject();
p.ANSWER_REPORT_ID = ANSWER_REPORT_ID;
IEnumerable<IDataRecord> oQuery = ExecuteSelectQuery("UPG_GET_ANSWER_REPORT_BY_ANSWER_REPORT_ID_ADV", p);
var R = oQuery.FirstOrDefault();
if (R != null)
{
oTools.CopyPropValues_FromDataRecord(R, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(R["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(R["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(R["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(R["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(R["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(R["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(R["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(R["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(R["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(R["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(R["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(R["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(R["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(R["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(R["T_TEACHER_EMAIL"]) ? default : Convert.ToString(R["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(R["T_TEACHER_MOBILE"]) ? default : Convert.ToString(R["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(R["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(R["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(R["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(R["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(R["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(R["T_TEACHER_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(R["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(R["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(R["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(R["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(R["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(R["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(R["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(R["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(R["T_STUDENT_EMAIL"]) ? default : Convert.ToString(R["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(R["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(R["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(R["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(R["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(R["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(R["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(R["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(R["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(R["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(R["T_STUDENT_OWNER_ID"]);
o.My_Answer = new Answer();
o.My_Answer.ANSWER_ID = Convert.IsDBNull(R["T_ANSWER_ANSWER_ID"]) ? default : Convert.ToInt32(R["T_ANSWER_ANSWER_ID"]);o.My_Answer.QUESTION_ID = Convert.IsDBNull(R["T_ANSWER_QUESTION_ID"]) ? default : Convert.ToInt32(R["T_ANSWER_QUESTION_ID"]);o.My_Answer.TEACHER_ID = Convert.IsDBNull(R["T_ANSWER_TEACHER_ID"]) ? default : Convert.ToInt32(R["T_ANSWER_TEACHER_ID"]);o.My_Answer.DESCRIPTION = Convert.IsDBNull(R["T_ANSWER_DESCRIPTION"]) ? default : Convert.ToString(R["T_ANSWER_DESCRIPTION"]);o.My_Answer.SCORE = Convert.IsDBNull(R["T_ANSWER_SCORE"]) ? default : Convert.ToDecimal(R["T_ANSWER_SCORE"]);o.My_Answer.REVIEWS = Convert.IsDBNull(R["T_ANSWER_REVIEWS"]) ? default : Convert.ToInt32(R["T_ANSWER_REVIEWS"]);o.My_Answer.REPORTS = Convert.IsDBNull(R["T_ANSWER_REPORTS"]) ? default : Convert.ToInt32(R["T_ANSWER_REPORTS"]);o.My_Answer.IS_ACTIVE = Convert.IsDBNull(R["T_ANSWER_IS_ACTIVE"]) ? default : Convert.ToBoolean(R["T_ANSWER_IS_ACTIVE"]);o.My_Answer.ENTRY_USER_ID = Convert.IsDBNull(R["T_ANSWER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(R["T_ANSWER_ENTRY_USER_ID"]);o.My_Answer.ENTRY_DATE = Convert.IsDBNull(R["T_ANSWER_ENTRY_DATE"]) ? default : Convert.ToString(R["T_ANSWER_ENTRY_DATE"]);o.My_Answer.OWNER_ID = Convert.IsDBNull(R["T_ANSWER_OWNER_ID"]) ? default : Convert.ToInt32(R["T_ANSWER_OWNER_ID"]);
}
return o;
}
public Appreciate Get_Appreciate_By_APPRECIATE_ID_Adv ( Int32? APPRECIATE_ID)
{
Appreciate o = new Appreciate();
dynamic p = new ExpandoObject();
p.APPRECIATE_ID = APPRECIATE_ID;
IEnumerable<IDataRecord> oQuery = ExecuteSelectQuery("UPG_GET_APPRECIATE_BY_APPRECIATE_ID_ADV", p);
var R = oQuery.FirstOrDefault();
if (R != null)
{
oTools.CopyPropValues_FromDataRecord(R, o);

o.My_Article = new Article();
o.My_Article.ARTICLE_ID = Convert.IsDBNull(R["T_ARTICLE_ARTICLE_ID"]) ? default : Convert.ToInt32(R["T_ARTICLE_ARTICLE_ID"]);o.My_Article.TEACHER_ID = Convert.IsDBNull(R["T_ARTICLE_TEACHER_ID"]) ? default : Convert.ToInt32(R["T_ARTICLE_TEACHER_ID"]);o.My_Article.CATEGORY_ID = Convert.IsDBNull(R["T_ARTICLE_CATEGORY_ID"]) ? default : Convert.ToInt32(R["T_ARTICLE_CATEGORY_ID"]);o.My_Article.TITLE = Convert.IsDBNull(R["T_ARTICLE_TITLE"]) ? default : Convert.ToString(R["T_ARTICLE_TITLE"]);o.My_Article.DESCRIPTION = Convert.IsDBNull(R["T_ARTICLE_DESCRIPTION"]) ? default : Convert.ToString(R["T_ARTICLE_DESCRIPTION"]);o.My_Article.APPLAUDS = Convert.IsDBNull(R["T_ARTICLE_APPLAUDS"]) ? default : Convert.ToInt32(R["T_ARTICLE_APPLAUDS"]);o.My_Article.REPORTS = Convert.IsDBNull(R["T_ARTICLE_REPORTS"]) ? default : Convert.ToInt32(R["T_ARTICLE_REPORTS"]);o.My_Article.IS_BLOCKED = Convert.IsDBNull(R["T_ARTICLE_IS_BLOCKED"]) ? default : Convert.ToBoolean(R["T_ARTICLE_IS_BLOCKED"]);o.My_Article.ENTRY_USER_ID = Convert.IsDBNull(R["T_ARTICLE_ENTRY_USER_ID"]) ? default : Convert.ToInt64(R["T_ARTICLE_ENTRY_USER_ID"]);o.My_Article.ENTRY_DATE = Convert.IsDBNull(R["T_ARTICLE_ENTRY_DATE"]) ? default : Convert.ToString(R["T_ARTICLE_ENTRY_DATE"]);o.My_Article.OWNER_ID = Convert.IsDBNull(R["T_ARTICLE_OWNER_ID"]) ? default : Convert.ToInt32(R["T_ARTICLE_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(R["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(R["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(R["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(R["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(R["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(R["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(R["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(R["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(R["T_STUDENT_EMAIL"]) ? default : Convert.ToString(R["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(R["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(R["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(R["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(R["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(R["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(R["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(R["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(R["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(R["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(R["T_STUDENT_OWNER_ID"]);
}
return o;
}
public Article Get_Article_By_ARTICLE_ID_Adv ( Int32? ARTICLE_ID)
{
Article o = new Article();
dynamic p = new ExpandoObject();
p.ARTICLE_ID = ARTICLE_ID;
IEnumerable<IDataRecord> oQuery = ExecuteSelectQuery("UPG_GET_ARTICLE_BY_ARTICLE_ID_ADV", p);
var R = oQuery.FirstOrDefault();
if (R != null)
{
oTools.CopyPropValues_FromDataRecord(R, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(R["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(R["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(R["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(R["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(R["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(R["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(R["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(R["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(R["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(R["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(R["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(R["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(R["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(R["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(R["T_TEACHER_EMAIL"]) ? default : Convert.ToString(R["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(R["T_TEACHER_MOBILE"]) ? default : Convert.ToString(R["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(R["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(R["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(R["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(R["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(R["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(R["T_TEACHER_OWNER_ID"]);
o.My_Category = new Category();
o.My_Category.CATEGORY_ID = Convert.IsDBNull(R["T_CATEGORY_CATEGORY_ID"]) ? default : Convert.ToInt32(R["T_CATEGORY_CATEGORY_ID"]);o.My_Category.NAME = Convert.IsDBNull(R["T_CATEGORY_NAME"]) ? default : Convert.ToString(R["T_CATEGORY_NAME"]);o.My_Category.DECRIPTION = Convert.IsDBNull(R["T_CATEGORY_DECRIPTION"]) ? default : Convert.ToString(R["T_CATEGORY_DECRIPTION"]);o.My_Category.ENTRY_USER_ID = Convert.IsDBNull(R["T_CATEGORY_ENTRY_USER_ID"]) ? default : Convert.ToInt64(R["T_CATEGORY_ENTRY_USER_ID"]);o.My_Category.ENTRY_DATE = Convert.IsDBNull(R["T_CATEGORY_ENTRY_DATE"]) ? default : Convert.ToString(R["T_CATEGORY_ENTRY_DATE"]);o.My_Category.OWNER_ID = Convert.IsDBNull(R["T_CATEGORY_OWNER_ID"]) ? default : Convert.ToInt32(R["T_CATEGORY_OWNER_ID"]);
}
return o;
}
public Category Get_Category_By_CATEGORY_ID_Adv ( Int32? CATEGORY_ID)
{
Category o = new Category();
dynamic p = new ExpandoObject();
p.CATEGORY_ID = CATEGORY_ID;
IEnumerable<IDataRecord> oQuery = ExecuteSelectQuery("UPG_GET_CATEGORY_BY_CATEGORY_ID_ADV", p);
var R = oQuery.FirstOrDefault();
if (R != null)
{
oTools.CopyPropValues_FromDataRecord(R, o);

}
return o;
}
public Evaluation Get_Evaluation_By_EVALUATION_ID_Adv ( Int32? EVALUATION_ID)
{
Evaluation o = new Evaluation();
dynamic p = new ExpandoObject();
p.EVALUATION_ID = EVALUATION_ID;
IEnumerable<IDataRecord> oQuery = ExecuteSelectQuery("UPG_GET_EVALUATION_BY_EVALUATION_ID_ADV", p);
var R = oQuery.FirstOrDefault();
if (R != null)
{
oTools.CopyPropValues_FromDataRecord(R, o);

o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(R["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(R["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(R["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(R["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(R["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(R["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(R["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(R["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(R["T_STUDENT_EMAIL"]) ? default : Convert.ToString(R["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(R["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(R["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(R["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(R["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(R["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(R["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(R["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(R["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(R["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(R["T_STUDENT_OWNER_ID"]);
o.My_Answer = new Answer();
o.My_Answer.ANSWER_ID = Convert.IsDBNull(R["T_ANSWER_ANSWER_ID"]) ? default : Convert.ToInt32(R["T_ANSWER_ANSWER_ID"]);o.My_Answer.QUESTION_ID = Convert.IsDBNull(R["T_ANSWER_QUESTION_ID"]) ? default : Convert.ToInt32(R["T_ANSWER_QUESTION_ID"]);o.My_Answer.TEACHER_ID = Convert.IsDBNull(R["T_ANSWER_TEACHER_ID"]) ? default : Convert.ToInt32(R["T_ANSWER_TEACHER_ID"]);o.My_Answer.DESCRIPTION = Convert.IsDBNull(R["T_ANSWER_DESCRIPTION"]) ? default : Convert.ToString(R["T_ANSWER_DESCRIPTION"]);o.My_Answer.SCORE = Convert.IsDBNull(R["T_ANSWER_SCORE"]) ? default : Convert.ToDecimal(R["T_ANSWER_SCORE"]);o.My_Answer.REVIEWS = Convert.IsDBNull(R["T_ANSWER_REVIEWS"]) ? default : Convert.ToInt32(R["T_ANSWER_REVIEWS"]);o.My_Answer.REPORTS = Convert.IsDBNull(R["T_ANSWER_REPORTS"]) ? default : Convert.ToInt32(R["T_ANSWER_REPORTS"]);o.My_Answer.IS_ACTIVE = Convert.IsDBNull(R["T_ANSWER_IS_ACTIVE"]) ? default : Convert.ToBoolean(R["T_ANSWER_IS_ACTIVE"]);o.My_Answer.ENTRY_USER_ID = Convert.IsDBNull(R["T_ANSWER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(R["T_ANSWER_ENTRY_USER_ID"]);o.My_Answer.ENTRY_DATE = Convert.IsDBNull(R["T_ANSWER_ENTRY_DATE"]) ? default : Convert.ToString(R["T_ANSWER_ENTRY_DATE"]);o.My_Answer.OWNER_ID = Convert.IsDBNull(R["T_ANSWER_OWNER_ID"]) ? default : Convert.ToInt32(R["T_ANSWER_OWNER_ID"]);
}
return o;
}
public Favorite_category Get_Favorite_category_By_FAVORITE_CATEGORY_ID_Adv ( Int32? FAVORITE_CATEGORY_ID)
{
Favorite_category o = new Favorite_category();
dynamic p = new ExpandoObject();
p.FAVORITE_CATEGORY_ID = FAVORITE_CATEGORY_ID;
IEnumerable<IDataRecord> oQuery = ExecuteSelectQuery("UPG_GET_FAVORITE_CATEGORY_BY_FAVORITE_CATEGORY_ID_ADV", p);
var R = oQuery.FirstOrDefault();
if (R != null)
{
oTools.CopyPropValues_FromDataRecord(R, o);

o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(R["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(R["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(R["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(R["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(R["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(R["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(R["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(R["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(R["T_STUDENT_EMAIL"]) ? default : Convert.ToString(R["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(R["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(R["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(R["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(R["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(R["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(R["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(R["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(R["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(R["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(R["T_STUDENT_OWNER_ID"]);
o.My_Category = new Category();
o.My_Category.CATEGORY_ID = Convert.IsDBNull(R["T_CATEGORY_CATEGORY_ID"]) ? default : Convert.ToInt32(R["T_CATEGORY_CATEGORY_ID"]);o.My_Category.NAME = Convert.IsDBNull(R["T_CATEGORY_NAME"]) ? default : Convert.ToString(R["T_CATEGORY_NAME"]);o.My_Category.DECRIPTION = Convert.IsDBNull(R["T_CATEGORY_DECRIPTION"]) ? default : Convert.ToString(R["T_CATEGORY_DECRIPTION"]);o.My_Category.ENTRY_USER_ID = Convert.IsDBNull(R["T_CATEGORY_ENTRY_USER_ID"]) ? default : Convert.ToInt64(R["T_CATEGORY_ENTRY_USER_ID"]);o.My_Category.ENTRY_DATE = Convert.IsDBNull(R["T_CATEGORY_ENTRY_DATE"]) ? default : Convert.ToString(R["T_CATEGORY_ENTRY_DATE"]);o.My_Category.OWNER_ID = Convert.IsDBNull(R["T_CATEGORY_OWNER_ID"]) ? default : Convert.ToInt32(R["T_CATEGORY_OWNER_ID"]);
}
return o;
}
public Favorite_teacher Get_Favorite_teacher_By_FAVORITE_TEACHER_ID_Adv ( Int32? FAVORITE_TEACHER_ID)
{
Favorite_teacher o = new Favorite_teacher();
dynamic p = new ExpandoObject();
p.FAVORITE_TEACHER_ID = FAVORITE_TEACHER_ID;
IEnumerable<IDataRecord> oQuery = ExecuteSelectQuery("UPG_GET_FAVORITE_TEACHER_BY_FAVORITE_TEACHER_ID_ADV", p);
var R = oQuery.FirstOrDefault();
if (R != null)
{
oTools.CopyPropValues_FromDataRecord(R, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(R["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(R["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(R["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(R["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(R["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(R["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(R["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(R["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(R["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(R["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(R["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(R["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(R["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(R["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(R["T_TEACHER_EMAIL"]) ? default : Convert.ToString(R["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(R["T_TEACHER_MOBILE"]) ? default : Convert.ToString(R["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(R["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(R["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(R["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(R["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(R["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(R["T_TEACHER_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(R["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(R["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(R["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(R["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(R["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(R["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(R["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(R["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(R["T_STUDENT_EMAIL"]) ? default : Convert.ToString(R["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(R["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(R["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(R["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(R["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(R["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(R["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(R["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(R["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(R["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(R["T_STUDENT_OWNER_ID"]);
}
return o;
}
public Mark_question Get_Mark_question_By_MARK_QUESTION_ID_Adv ( Int32? MARK_QUESTION_ID)
{
Mark_question o = new Mark_question();
dynamic p = new ExpandoObject();
p.MARK_QUESTION_ID = MARK_QUESTION_ID;
IEnumerable<IDataRecord> oQuery = ExecuteSelectQuery("UPG_GET_MARK_QUESTION_BY_MARK_QUESTION_ID_ADV", p);
var R = oQuery.FirstOrDefault();
if (R != null)
{
oTools.CopyPropValues_FromDataRecord(R, o);

o.My_Question = new Question();
o.My_Question.QUESTION_ID = Convert.IsDBNull(R["T_QUESTION_QUESTION_ID"]) ? default : Convert.ToInt32(R["T_QUESTION_QUESTION_ID"]);o.My_Question.STUDENT_ID = Convert.IsDBNull(R["T_QUESTION_STUDENT_ID"]) ? default : Convert.ToInt32(R["T_QUESTION_STUDENT_ID"]);o.My_Question.CATEGORY_ID = Convert.IsDBNull(R["T_QUESTION_CATEGORY_ID"]) ? default : Convert.ToInt32(R["T_QUESTION_CATEGORY_ID"]);o.My_Question.TEACHER_ID = Convert.IsDBNull(R["T_QUESTION_TEACHER_ID"]) ? default : Convert.ToInt32(R["T_QUESTION_TEACHER_ID"]);o.My_Question.DESCRIPTION = Convert.IsDBNull(R["T_QUESTION_DESCRIPTION"]) ? default : Convert.ToString(R["T_QUESTION_DESCRIPTION"]);o.My_Question.IS_ANSWERED = Convert.IsDBNull(R["T_QUESTION_IS_ANSWERED"]) ? default : Convert.ToBoolean(R["T_QUESTION_IS_ANSWERED"]);o.My_Question.IS_ACTIVE = Convert.IsDBNull(R["T_QUESTION_IS_ACTIVE"]) ? default : Convert.ToBoolean(R["T_QUESTION_IS_ACTIVE"]);o.My_Question.REPORTS = Convert.IsDBNull(R["T_QUESTION_REPORTS"]) ? default : Convert.ToInt32(R["T_QUESTION_REPORTS"]);o.My_Question.ENTRY_USER_ID = Convert.IsDBNull(R["T_QUESTION_ENTRY_USER_ID"]) ? default : Convert.ToInt64(R["T_QUESTION_ENTRY_USER_ID"]);o.My_Question.ENTRY_DATE = Convert.IsDBNull(R["T_QUESTION_ENTRY_DATE"]) ? default : Convert.ToString(R["T_QUESTION_ENTRY_DATE"]);o.My_Question.OWNER_ID = Convert.IsDBNull(R["T_QUESTION_OWNER_ID"]) ? default : Convert.ToInt32(R["T_QUESTION_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(R["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(R["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(R["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(R["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(R["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(R["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(R["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(R["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(R["T_STUDENT_EMAIL"]) ? default : Convert.ToString(R["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(R["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(R["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(R["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(R["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(R["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(R["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(R["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(R["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(R["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(R["T_STUDENT_OWNER_ID"]);
}
return o;
}
public Notification Get_Notification_By_NOTIFICATION_ID_Adv ( Int32? NOTIFICATION_ID)
{
Notification o = new Notification();
dynamic p = new ExpandoObject();
p.NOTIFICATION_ID = NOTIFICATION_ID;
IEnumerable<IDataRecord> oQuery = ExecuteSelectQuery("UPG_GET_NOTIFICATION_BY_NOTIFICATION_ID_ADV", p);
var R = oQuery.FirstOrDefault();
if (R != null)
{
oTools.CopyPropValues_FromDataRecord(R, o);

o.My_User = new User();
o.My_User.USER_ID = Convert.IsDBNull(R["T_USER_USER_ID"]) ? default : Convert.ToInt64(R["T_USER_USER_ID"]);o.My_User.OWNER_ID = Convert.IsDBNull(R["T_USER_OWNER_ID"]) ? default : Convert.ToInt32(R["T_USER_OWNER_ID"]);o.My_User.USERNAME = Convert.IsDBNull(R["T_USER_USERNAME"]) ? default : Convert.ToString(R["T_USER_USERNAME"]);o.My_User.PASSWORD = Convert.IsDBNull(R["T_USER_PASSWORD"]) ? default : Convert.ToString(R["T_USER_PASSWORD"]);o.My_User.USER_TYPE_CODE = Convert.IsDBNull(R["T_USER_USER_TYPE_CODE"]) ? default : Convert.ToString(R["T_USER_USER_TYPE_CODE"]);o.My_User.IS_LOGGED_IN = Convert.IsDBNull(R["T_USER_IS_LOGGED_IN"]) ? default : Convert.ToBoolean(R["T_USER_IS_LOGGED_IN"]);o.My_User.IS_ACTIVE = Convert.IsDBNull(R["T_USER_IS_ACTIVE"]) ? default : Convert.ToBoolean(R["T_USER_IS_ACTIVE"]);o.My_User.ENTRY_DATE = Convert.IsDBNull(R["T_USER_ENTRY_DATE"]) ? default : Convert.ToString(R["T_USER_ENTRY_DATE"]);
o.My_Question = new Question();
o.My_Question.QUESTION_ID = Convert.IsDBNull(R["T_QUESTION_QUESTION_ID"]) ? default : Convert.ToInt32(R["T_QUESTION_QUESTION_ID"]);o.My_Question.STUDENT_ID = Convert.IsDBNull(R["T_QUESTION_STUDENT_ID"]) ? default : Convert.ToInt32(R["T_QUESTION_STUDENT_ID"]);o.My_Question.CATEGORY_ID = Convert.IsDBNull(R["T_QUESTION_CATEGORY_ID"]) ? default : Convert.ToInt32(R["T_QUESTION_CATEGORY_ID"]);o.My_Question.TEACHER_ID = Convert.IsDBNull(R["T_QUESTION_TEACHER_ID"]) ? default : Convert.ToInt32(R["T_QUESTION_TEACHER_ID"]);o.My_Question.DESCRIPTION = Convert.IsDBNull(R["T_QUESTION_DESCRIPTION"]) ? default : Convert.ToString(R["T_QUESTION_DESCRIPTION"]);o.My_Question.IS_ANSWERED = Convert.IsDBNull(R["T_QUESTION_IS_ANSWERED"]) ? default : Convert.ToBoolean(R["T_QUESTION_IS_ANSWERED"]);o.My_Question.IS_ACTIVE = Convert.IsDBNull(R["T_QUESTION_IS_ACTIVE"]) ? default : Convert.ToBoolean(R["T_QUESTION_IS_ACTIVE"]);o.My_Question.REPORTS = Convert.IsDBNull(R["T_QUESTION_REPORTS"]) ? default : Convert.ToInt32(R["T_QUESTION_REPORTS"]);o.My_Question.ENTRY_USER_ID = Convert.IsDBNull(R["T_QUESTION_ENTRY_USER_ID"]) ? default : Convert.ToInt64(R["T_QUESTION_ENTRY_USER_ID"]);o.My_Question.ENTRY_DATE = Convert.IsDBNull(R["T_QUESTION_ENTRY_DATE"]) ? default : Convert.ToString(R["T_QUESTION_ENTRY_DATE"]);o.My_Question.OWNER_ID = Convert.IsDBNull(R["T_QUESTION_OWNER_ID"]) ? default : Convert.ToInt32(R["T_QUESTION_OWNER_ID"]);
o.My_Answer = new Answer();
o.My_Answer.ANSWER_ID = Convert.IsDBNull(R["T_ANSWER_ANSWER_ID"]) ? default : Convert.ToInt32(R["T_ANSWER_ANSWER_ID"]);o.My_Answer.QUESTION_ID = Convert.IsDBNull(R["T_ANSWER_QUESTION_ID"]) ? default : Convert.ToInt32(R["T_ANSWER_QUESTION_ID"]);o.My_Answer.TEACHER_ID = Convert.IsDBNull(R["T_ANSWER_TEACHER_ID"]) ? default : Convert.ToInt32(R["T_ANSWER_TEACHER_ID"]);o.My_Answer.DESCRIPTION = Convert.IsDBNull(R["T_ANSWER_DESCRIPTION"]) ? default : Convert.ToString(R["T_ANSWER_DESCRIPTION"]);o.My_Answer.SCORE = Convert.IsDBNull(R["T_ANSWER_SCORE"]) ? default : Convert.ToDecimal(R["T_ANSWER_SCORE"]);o.My_Answer.REVIEWS = Convert.IsDBNull(R["T_ANSWER_REVIEWS"]) ? default : Convert.ToInt32(R["T_ANSWER_REVIEWS"]);o.My_Answer.REPORTS = Convert.IsDBNull(R["T_ANSWER_REPORTS"]) ? default : Convert.ToInt32(R["T_ANSWER_REPORTS"]);o.My_Answer.IS_ACTIVE = Convert.IsDBNull(R["T_ANSWER_IS_ACTIVE"]) ? default : Convert.ToBoolean(R["T_ANSWER_IS_ACTIVE"]);o.My_Answer.ENTRY_USER_ID = Convert.IsDBNull(R["T_ANSWER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(R["T_ANSWER_ENTRY_USER_ID"]);o.My_Answer.ENTRY_DATE = Convert.IsDBNull(R["T_ANSWER_ENTRY_DATE"]) ? default : Convert.ToString(R["T_ANSWER_ENTRY_DATE"]);o.My_Answer.OWNER_ID = Convert.IsDBNull(R["T_ANSWER_OWNER_ID"]) ? default : Convert.ToInt32(R["T_ANSWER_OWNER_ID"]);
}
return o;
}
public Question Get_Question_By_QUESTION_ID_Adv ( Int32? QUESTION_ID)
{
Question o = new Question();
dynamic p = new ExpandoObject();
p.QUESTION_ID = QUESTION_ID;
IEnumerable<IDataRecord> oQuery = ExecuteSelectQuery("UPG_GET_QUESTION_BY_QUESTION_ID_ADV", p);
var R = oQuery.FirstOrDefault();
if (R != null)
{
oTools.CopyPropValues_FromDataRecord(R, o);

o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(R["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(R["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(R["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(R["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(R["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(R["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(R["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(R["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(R["T_STUDENT_EMAIL"]) ? default : Convert.ToString(R["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(R["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(R["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(R["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(R["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(R["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(R["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(R["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(R["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(R["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(R["T_STUDENT_OWNER_ID"]);
o.My_Category = new Category();
o.My_Category.CATEGORY_ID = Convert.IsDBNull(R["T_CATEGORY_CATEGORY_ID"]) ? default : Convert.ToInt32(R["T_CATEGORY_CATEGORY_ID"]);o.My_Category.NAME = Convert.IsDBNull(R["T_CATEGORY_NAME"]) ? default : Convert.ToString(R["T_CATEGORY_NAME"]);o.My_Category.DECRIPTION = Convert.IsDBNull(R["T_CATEGORY_DECRIPTION"]) ? default : Convert.ToString(R["T_CATEGORY_DECRIPTION"]);o.My_Category.ENTRY_USER_ID = Convert.IsDBNull(R["T_CATEGORY_ENTRY_USER_ID"]) ? default : Convert.ToInt64(R["T_CATEGORY_ENTRY_USER_ID"]);o.My_Category.ENTRY_DATE = Convert.IsDBNull(R["T_CATEGORY_ENTRY_DATE"]) ? default : Convert.ToString(R["T_CATEGORY_ENTRY_DATE"]);o.My_Category.OWNER_ID = Convert.IsDBNull(R["T_CATEGORY_OWNER_ID"]) ? default : Convert.ToInt32(R["T_CATEGORY_OWNER_ID"]);
o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(R["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(R["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(R["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(R["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(R["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(R["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(R["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(R["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(R["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(R["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(R["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(R["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(R["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(R["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(R["T_TEACHER_EMAIL"]) ? default : Convert.ToString(R["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(R["T_TEACHER_MOBILE"]) ? default : Convert.ToString(R["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(R["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(R["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(R["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(R["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(R["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(R["T_TEACHER_OWNER_ID"]);
}
return o;
}
public Question_report Get_Question_report_By_QUESTION_REPORT_ID_Adv ( Int32? QUESTION_REPORT_ID)
{
Question_report o = new Question_report();
dynamic p = new ExpandoObject();
p.QUESTION_REPORT_ID = QUESTION_REPORT_ID;
IEnumerable<IDataRecord> oQuery = ExecuteSelectQuery("UPG_GET_QUESTION_REPORT_BY_QUESTION_REPORT_ID_ADV", p);
var R = oQuery.FirstOrDefault();
if (R != null)
{
oTools.CopyPropValues_FromDataRecord(R, o);

o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(R["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(R["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(R["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(R["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(R["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(R["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(R["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(R["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(R["T_STUDENT_EMAIL"]) ? default : Convert.ToString(R["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(R["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(R["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(R["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(R["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(R["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(R["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(R["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(R["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(R["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(R["T_STUDENT_OWNER_ID"]);
o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(R["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(R["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(R["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(R["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(R["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(R["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(R["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(R["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(R["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(R["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(R["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(R["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(R["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(R["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(R["T_TEACHER_EMAIL"]) ? default : Convert.ToString(R["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(R["T_TEACHER_MOBILE"]) ? default : Convert.ToString(R["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(R["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(R["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(R["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(R["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(R["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(R["T_TEACHER_OWNER_ID"]);
o.My_Question = new Question();
o.My_Question.QUESTION_ID = Convert.IsDBNull(R["T_QUESTION_QUESTION_ID"]) ? default : Convert.ToInt32(R["T_QUESTION_QUESTION_ID"]);o.My_Question.STUDENT_ID = Convert.IsDBNull(R["T_QUESTION_STUDENT_ID"]) ? default : Convert.ToInt32(R["T_QUESTION_STUDENT_ID"]);o.My_Question.CATEGORY_ID = Convert.IsDBNull(R["T_QUESTION_CATEGORY_ID"]) ? default : Convert.ToInt32(R["T_QUESTION_CATEGORY_ID"]);o.My_Question.TEACHER_ID = Convert.IsDBNull(R["T_QUESTION_TEACHER_ID"]) ? default : Convert.ToInt32(R["T_QUESTION_TEACHER_ID"]);o.My_Question.DESCRIPTION = Convert.IsDBNull(R["T_QUESTION_DESCRIPTION"]) ? default : Convert.ToString(R["T_QUESTION_DESCRIPTION"]);o.My_Question.IS_ANSWERED = Convert.IsDBNull(R["T_QUESTION_IS_ANSWERED"]) ? default : Convert.ToBoolean(R["T_QUESTION_IS_ANSWERED"]);o.My_Question.IS_ACTIVE = Convert.IsDBNull(R["T_QUESTION_IS_ACTIVE"]) ? default : Convert.ToBoolean(R["T_QUESTION_IS_ACTIVE"]);o.My_Question.REPORTS = Convert.IsDBNull(R["T_QUESTION_REPORTS"]) ? default : Convert.ToInt32(R["T_QUESTION_REPORTS"]);o.My_Question.ENTRY_USER_ID = Convert.IsDBNull(R["T_QUESTION_ENTRY_USER_ID"]) ? default : Convert.ToInt64(R["T_QUESTION_ENTRY_USER_ID"]);o.My_Question.ENTRY_DATE = Convert.IsDBNull(R["T_QUESTION_ENTRY_DATE"]) ? default : Convert.ToString(R["T_QUESTION_ENTRY_DATE"]);o.My_Question.OWNER_ID = Convert.IsDBNull(R["T_QUESTION_OWNER_ID"]) ? default : Convert.ToInt32(R["T_QUESTION_OWNER_ID"]);
}
return o;
}
public Question_token Get_Question_token_By_QUESTION_TOKEN_ID_Adv ( long? QUESTION_TOKEN_ID)
{
Question_token o = new Question_token();
dynamic p = new ExpandoObject();
p.QUESTION_TOKEN_ID = QUESTION_TOKEN_ID;
IEnumerable<IDataRecord> oQuery = ExecuteSelectQuery("UPG_GET_QUESTION_TOKEN_BY_QUESTION_TOKEN_ID_ADV", p);
var R = oQuery.FirstOrDefault();
if (R != null)
{
oTools.CopyPropValues_FromDataRecord(R, o);

o.My_Question = new Question();
o.My_Question.QUESTION_ID = Convert.IsDBNull(R["T_QUESTION_QUESTION_ID"]) ? default : Convert.ToInt32(R["T_QUESTION_QUESTION_ID"]);o.My_Question.STUDENT_ID = Convert.IsDBNull(R["T_QUESTION_STUDENT_ID"]) ? default : Convert.ToInt32(R["T_QUESTION_STUDENT_ID"]);o.My_Question.CATEGORY_ID = Convert.IsDBNull(R["T_QUESTION_CATEGORY_ID"]) ? default : Convert.ToInt32(R["T_QUESTION_CATEGORY_ID"]);o.My_Question.TEACHER_ID = Convert.IsDBNull(R["T_QUESTION_TEACHER_ID"]) ? default : Convert.ToInt32(R["T_QUESTION_TEACHER_ID"]);o.My_Question.DESCRIPTION = Convert.IsDBNull(R["T_QUESTION_DESCRIPTION"]) ? default : Convert.ToString(R["T_QUESTION_DESCRIPTION"]);o.My_Question.IS_ANSWERED = Convert.IsDBNull(R["T_QUESTION_IS_ANSWERED"]) ? default : Convert.ToBoolean(R["T_QUESTION_IS_ANSWERED"]);o.My_Question.IS_ACTIVE = Convert.IsDBNull(R["T_QUESTION_IS_ACTIVE"]) ? default : Convert.ToBoolean(R["T_QUESTION_IS_ACTIVE"]);o.My_Question.REPORTS = Convert.IsDBNull(R["T_QUESTION_REPORTS"]) ? default : Convert.ToInt32(R["T_QUESTION_REPORTS"]);o.My_Question.ENTRY_USER_ID = Convert.IsDBNull(R["T_QUESTION_ENTRY_USER_ID"]) ? default : Convert.ToInt64(R["T_QUESTION_ENTRY_USER_ID"]);o.My_Question.ENTRY_DATE = Convert.IsDBNull(R["T_QUESTION_ENTRY_DATE"]) ? default : Convert.ToString(R["T_QUESTION_ENTRY_DATE"]);o.My_Question.OWNER_ID = Convert.IsDBNull(R["T_QUESTION_OWNER_ID"]) ? default : Convert.ToInt32(R["T_QUESTION_OWNER_ID"]);
}
return o;
}
public Report_article Get_Report_article_By_REPORT_ARTICLE_ID_Adv ( Int32? REPORT_ARTICLE_ID)
{
Report_article o = new Report_article();
dynamic p = new ExpandoObject();
p.REPORT_ARTICLE_ID = REPORT_ARTICLE_ID;
IEnumerable<IDataRecord> oQuery = ExecuteSelectQuery("UPG_GET_REPORT_ARTICLE_BY_REPORT_ARTICLE_ID_ADV", p);
var R = oQuery.FirstOrDefault();
if (R != null)
{
oTools.CopyPropValues_FromDataRecord(R, o);

o.My_Article = new Article();
o.My_Article.ARTICLE_ID = Convert.IsDBNull(R["T_ARTICLE_ARTICLE_ID"]) ? default : Convert.ToInt32(R["T_ARTICLE_ARTICLE_ID"]);o.My_Article.TEACHER_ID = Convert.IsDBNull(R["T_ARTICLE_TEACHER_ID"]) ? default : Convert.ToInt32(R["T_ARTICLE_TEACHER_ID"]);o.My_Article.CATEGORY_ID = Convert.IsDBNull(R["T_ARTICLE_CATEGORY_ID"]) ? default : Convert.ToInt32(R["T_ARTICLE_CATEGORY_ID"]);o.My_Article.TITLE = Convert.IsDBNull(R["T_ARTICLE_TITLE"]) ? default : Convert.ToString(R["T_ARTICLE_TITLE"]);o.My_Article.DESCRIPTION = Convert.IsDBNull(R["T_ARTICLE_DESCRIPTION"]) ? default : Convert.ToString(R["T_ARTICLE_DESCRIPTION"]);o.My_Article.APPLAUDS = Convert.IsDBNull(R["T_ARTICLE_APPLAUDS"]) ? default : Convert.ToInt32(R["T_ARTICLE_APPLAUDS"]);o.My_Article.REPORTS = Convert.IsDBNull(R["T_ARTICLE_REPORTS"]) ? default : Convert.ToInt32(R["T_ARTICLE_REPORTS"]);o.My_Article.IS_BLOCKED = Convert.IsDBNull(R["T_ARTICLE_IS_BLOCKED"]) ? default : Convert.ToBoolean(R["T_ARTICLE_IS_BLOCKED"]);o.My_Article.ENTRY_USER_ID = Convert.IsDBNull(R["T_ARTICLE_ENTRY_USER_ID"]) ? default : Convert.ToInt64(R["T_ARTICLE_ENTRY_USER_ID"]);o.My_Article.ENTRY_DATE = Convert.IsDBNull(R["T_ARTICLE_ENTRY_DATE"]) ? default : Convert.ToString(R["T_ARTICLE_ENTRY_DATE"]);o.My_Article.OWNER_ID = Convert.IsDBNull(R["T_ARTICLE_OWNER_ID"]) ? default : Convert.ToInt32(R["T_ARTICLE_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(R["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(R["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(R["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(R["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(R["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(R["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(R["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(R["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(R["T_STUDENT_EMAIL"]) ? default : Convert.ToString(R["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(R["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(R["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(R["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(R["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(R["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(R["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(R["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(R["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(R["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(R["T_STUDENT_OWNER_ID"]);
}
return o;
}
public Student Get_Student_By_STUDENT_ID_Adv ( Int32? STUDENT_ID)
{
Student o = new Student();
dynamic p = new ExpandoObject();
p.STUDENT_ID = STUDENT_ID;
IEnumerable<IDataRecord> oQuery = ExecuteSelectQuery("UPG_GET_STUDENT_BY_STUDENT_ID_ADV", p);
var R = oQuery.FirstOrDefault();
if (R != null)
{
oTools.CopyPropValues_FromDataRecord(R, o);

o.My_User = new User();
o.My_User.USER_ID = Convert.IsDBNull(R["T_USER_USER_ID"]) ? default : Convert.ToInt64(R["T_USER_USER_ID"]);o.My_User.OWNER_ID = Convert.IsDBNull(R["T_USER_OWNER_ID"]) ? default : Convert.ToInt32(R["T_USER_OWNER_ID"]);o.My_User.USERNAME = Convert.IsDBNull(R["T_USER_USERNAME"]) ? default : Convert.ToString(R["T_USER_USERNAME"]);o.My_User.PASSWORD = Convert.IsDBNull(R["T_USER_PASSWORD"]) ? default : Convert.ToString(R["T_USER_PASSWORD"]);o.My_User.USER_TYPE_CODE = Convert.IsDBNull(R["T_USER_USER_TYPE_CODE"]) ? default : Convert.ToString(R["T_USER_USER_TYPE_CODE"]);o.My_User.IS_LOGGED_IN = Convert.IsDBNull(R["T_USER_IS_LOGGED_IN"]) ? default : Convert.ToBoolean(R["T_USER_IS_LOGGED_IN"]);o.My_User.IS_ACTIVE = Convert.IsDBNull(R["T_USER_IS_ACTIVE"]) ? default : Convert.ToBoolean(R["T_USER_IS_ACTIVE"]);o.My_User.ENTRY_DATE = Convert.IsDBNull(R["T_USER_ENTRY_DATE"]) ? default : Convert.ToString(R["T_USER_ENTRY_DATE"]);
}
return o;
}
public Student_report Get_Student_report_By_STUDENT_REPORT_ID_Adv ( Int32? STUDENT_REPORT_ID)
{
Student_report o = new Student_report();
dynamic p = new ExpandoObject();
p.STUDENT_REPORT_ID = STUDENT_REPORT_ID;
IEnumerable<IDataRecord> oQuery = ExecuteSelectQuery("UPG_GET_STUDENT_REPORT_BY_STUDENT_REPORT_ID_ADV", p);
var R = oQuery.FirstOrDefault();
if (R != null)
{
oTools.CopyPropValues_FromDataRecord(R, o);

o.My_Reported_by_student = new Student();
o.My_Reported_by_student.STUDENT_ID = Convert.IsDBNull(R["T_REPORTED_BY_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(R["T_REPORTED_BY_STUDENT_STUDENT_ID"]);o.My_Reported_by_student.USER_ID = Convert.IsDBNull(R["T_REPORTED_BY_STUDENT_USER_ID"]) ? default : Convert.ToInt32(R["T_REPORTED_BY_STUDENT_USER_ID"]);o.My_Reported_by_student.FIRST_NAME = Convert.IsDBNull(R["T_REPORTED_BY_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(R["T_REPORTED_BY_STUDENT_FIRST_NAME"]);o.My_Reported_by_student.LAST_NAME = Convert.IsDBNull(R["T_REPORTED_BY_STUDENT_LAST_NAME"]) ? default : Convert.ToString(R["T_REPORTED_BY_STUDENT_LAST_NAME"]);o.My_Reported_by_student.EMAIL = Convert.IsDBNull(R["T_REPORTED_BY_STUDENT_EMAIL"]) ? default : Convert.ToString(R["T_REPORTED_BY_STUDENT_EMAIL"]);o.My_Reported_by_student.IS_BLOCKED = Convert.IsDBNull(R["T_REPORTED_BY_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(R["T_REPORTED_BY_STUDENT_IS_BLOCKED"]);o.My_Reported_by_student.PENDING_QUESTIONS = Convert.IsDBNull(R["T_REPORTED_BY_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(R["T_REPORTED_BY_STUDENT_PENDING_QUESTIONS"]);o.My_Reported_by_student.ENTRY_USER_ID = Convert.IsDBNull(R["T_REPORTED_BY_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(R["T_REPORTED_BY_STUDENT_ENTRY_USER_ID"]);o.My_Reported_by_student.ENTRY_DATE = Convert.IsDBNull(R["T_REPORTED_BY_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(R["T_REPORTED_BY_STUDENT_ENTRY_DATE"]);o.My_Reported_by_student.OWNER_ID = Convert.IsDBNull(R["T_REPORTED_BY_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(R["T_REPORTED_BY_STUDENT_OWNER_ID"]);
o.My_Reported_student = new Student();
o.My_Reported_student.STUDENT_ID = Convert.IsDBNull(R["T_REPORTED_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(R["T_REPORTED_STUDENT_STUDENT_ID"]);o.My_Reported_student.USER_ID = Convert.IsDBNull(R["T_REPORTED_STUDENT_USER_ID"]) ? default : Convert.ToInt32(R["T_REPORTED_STUDENT_USER_ID"]);o.My_Reported_student.FIRST_NAME = Convert.IsDBNull(R["T_REPORTED_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(R["T_REPORTED_STUDENT_FIRST_NAME"]);o.My_Reported_student.LAST_NAME = Convert.IsDBNull(R["T_REPORTED_STUDENT_LAST_NAME"]) ? default : Convert.ToString(R["T_REPORTED_STUDENT_LAST_NAME"]);o.My_Reported_student.EMAIL = Convert.IsDBNull(R["T_REPORTED_STUDENT_EMAIL"]) ? default : Convert.ToString(R["T_REPORTED_STUDENT_EMAIL"]);o.My_Reported_student.IS_BLOCKED = Convert.IsDBNull(R["T_REPORTED_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(R["T_REPORTED_STUDENT_IS_BLOCKED"]);o.My_Reported_student.PENDING_QUESTIONS = Convert.IsDBNull(R["T_REPORTED_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(R["T_REPORTED_STUDENT_PENDING_QUESTIONS"]);o.My_Reported_student.ENTRY_USER_ID = Convert.IsDBNull(R["T_REPORTED_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(R["T_REPORTED_STUDENT_ENTRY_USER_ID"]);o.My_Reported_student.ENTRY_DATE = Convert.IsDBNull(R["T_REPORTED_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(R["T_REPORTED_STUDENT_ENTRY_DATE"]);o.My_Reported_student.OWNER_ID = Convert.IsDBNull(R["T_REPORTED_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(R["T_REPORTED_STUDENT_OWNER_ID"]);
}
return o;
}
public Teacher Get_Teacher_By_TEACHER_ID_Adv ( Int32? TEACHER_ID)
{
Teacher o = new Teacher();
dynamic p = new ExpandoObject();
p.TEACHER_ID = TEACHER_ID;
IEnumerable<IDataRecord> oQuery = ExecuteSelectQuery("UPG_GET_TEACHER_BY_TEACHER_ID_ADV", p);
var R = oQuery.FirstOrDefault();
if (R != null)
{
oTools.CopyPropValues_FromDataRecord(R, o);

o.My_User = new User();
o.My_User.USER_ID = Convert.IsDBNull(R["T_USER_USER_ID"]) ? default : Convert.ToInt64(R["T_USER_USER_ID"]);o.My_User.OWNER_ID = Convert.IsDBNull(R["T_USER_OWNER_ID"]) ? default : Convert.ToInt32(R["T_USER_OWNER_ID"]);o.My_User.USERNAME = Convert.IsDBNull(R["T_USER_USERNAME"]) ? default : Convert.ToString(R["T_USER_USERNAME"]);o.My_User.PASSWORD = Convert.IsDBNull(R["T_USER_PASSWORD"]) ? default : Convert.ToString(R["T_USER_PASSWORD"]);o.My_User.USER_TYPE_CODE = Convert.IsDBNull(R["T_USER_USER_TYPE_CODE"]) ? default : Convert.ToString(R["T_USER_USER_TYPE_CODE"]);o.My_User.IS_LOGGED_IN = Convert.IsDBNull(R["T_USER_IS_LOGGED_IN"]) ? default : Convert.ToBoolean(R["T_USER_IS_LOGGED_IN"]);o.My_User.IS_ACTIVE = Convert.IsDBNull(R["T_USER_IS_ACTIVE"]) ? default : Convert.ToBoolean(R["T_USER_IS_ACTIVE"]);o.My_User.ENTRY_DATE = Convert.IsDBNull(R["T_USER_ENTRY_DATE"]) ? default : Convert.ToString(R["T_USER_ENTRY_DATE"]);
}
return o;
}
public Teacher_category Get_Teacher_category_By_TEACHER_CATEGORY_ID_Adv ( Int32? TEACHER_CATEGORY_ID)
{
Teacher_category o = new Teacher_category();
dynamic p = new ExpandoObject();
p.TEACHER_CATEGORY_ID = TEACHER_CATEGORY_ID;
IEnumerable<IDataRecord> oQuery = ExecuteSelectQuery("UPG_GET_TEACHER_CATEGORY_BY_TEACHER_CATEGORY_ID_ADV", p);
var R = oQuery.FirstOrDefault();
if (R != null)
{
oTools.CopyPropValues_FromDataRecord(R, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(R["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(R["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(R["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(R["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(R["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(R["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(R["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(R["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(R["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(R["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(R["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(R["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(R["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(R["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(R["T_TEACHER_EMAIL"]) ? default : Convert.ToString(R["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(R["T_TEACHER_MOBILE"]) ? default : Convert.ToString(R["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(R["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(R["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(R["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(R["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(R["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(R["T_TEACHER_OWNER_ID"]);
o.My_Category = new Category();
o.My_Category.CATEGORY_ID = Convert.IsDBNull(R["T_CATEGORY_CATEGORY_ID"]) ? default : Convert.ToInt32(R["T_CATEGORY_CATEGORY_ID"]);o.My_Category.NAME = Convert.IsDBNull(R["T_CATEGORY_NAME"]) ? default : Convert.ToString(R["T_CATEGORY_NAME"]);o.My_Category.DECRIPTION = Convert.IsDBNull(R["T_CATEGORY_DECRIPTION"]) ? default : Convert.ToString(R["T_CATEGORY_DECRIPTION"]);o.My_Category.ENTRY_USER_ID = Convert.IsDBNull(R["T_CATEGORY_ENTRY_USER_ID"]) ? default : Convert.ToInt64(R["T_CATEGORY_ENTRY_USER_ID"]);o.My_Category.ENTRY_DATE = Convert.IsDBNull(R["T_CATEGORY_ENTRY_DATE"]) ? default : Convert.ToString(R["T_CATEGORY_ENTRY_DATE"]);o.My_Category.OWNER_ID = Convert.IsDBNull(R["T_CATEGORY_OWNER_ID"]) ? default : Convert.ToInt32(R["T_CATEGORY_OWNER_ID"]);
}
return o;
}
public Teacher_favorite Get_Teacher_favorite_By_TEACHER_FAVORITE_ID_Adv ( Int32? TEACHER_FAVORITE_ID)
{
Teacher_favorite o = new Teacher_favorite();
dynamic p = new ExpandoObject();
p.TEACHER_FAVORITE_ID = TEACHER_FAVORITE_ID;
IEnumerable<IDataRecord> oQuery = ExecuteSelectQuery("UPG_GET_TEACHER_FAVORITE_BY_TEACHER_FAVORITE_ID_ADV", p);
var R = oQuery.FirstOrDefault();
if (R != null)
{
oTools.CopyPropValues_FromDataRecord(R, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(R["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(R["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(R["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(R["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(R["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(R["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(R["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(R["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(R["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(R["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(R["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(R["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(R["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(R["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(R["T_TEACHER_EMAIL"]) ? default : Convert.ToString(R["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(R["T_TEACHER_MOBILE"]) ? default : Convert.ToString(R["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(R["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(R["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(R["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(R["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(R["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(R["T_TEACHER_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(R["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(R["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(R["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(R["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(R["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(R["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(R["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(R["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(R["T_STUDENT_EMAIL"]) ? default : Convert.ToString(R["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(R["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(R["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(R["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(R["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(R["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(R["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(R["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(R["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(R["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(R["T_STUDENT_OWNER_ID"]);
}
return o;
}
public Teacher_rank Get_Teacher_rank_By_TEACHER_RANK_ID_Adv ( Int32? TEACHER_RANK_ID)
{
Teacher_rank o = new Teacher_rank();
dynamic p = new ExpandoObject();
p.TEACHER_RANK_ID = TEACHER_RANK_ID;
IEnumerable<IDataRecord> oQuery = ExecuteSelectQuery("UPG_GET_TEACHER_RANK_BY_TEACHER_RANK_ID_ADV", p);
var R = oQuery.FirstOrDefault();
if (R != null)
{
oTools.CopyPropValues_FromDataRecord(R, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(R["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(R["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(R["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(R["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(R["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(R["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(R["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(R["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(R["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(R["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(R["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(R["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(R["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(R["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(R["T_TEACHER_EMAIL"]) ? default : Convert.ToString(R["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(R["T_TEACHER_MOBILE"]) ? default : Convert.ToString(R["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(R["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(R["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(R["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(R["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(R["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(R["T_TEACHER_OWNER_ID"]);
}
return o;
}
public Teacher_report Get_Teacher_report_By_TEACHER_REPORT_ID_Adv ( Int32? TEACHER_REPORT_ID)
{
Teacher_report o = new Teacher_report();
dynamic p = new ExpandoObject();
p.TEACHER_REPORT_ID = TEACHER_REPORT_ID;
IEnumerable<IDataRecord> oQuery = ExecuteSelectQuery("UPG_GET_TEACHER_REPORT_BY_TEACHER_REPORT_ID_ADV", p);
var R = oQuery.FirstOrDefault();
if (R != null)
{
oTools.CopyPropValues_FromDataRecord(R, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(R["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(R["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(R["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(R["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(R["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(R["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(R["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(R["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(R["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(R["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(R["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(R["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(R["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(R["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(R["T_TEACHER_EMAIL"]) ? default : Convert.ToString(R["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(R["T_TEACHER_MOBILE"]) ? default : Convert.ToString(R["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(R["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(R["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(R["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(R["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(R["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(R["T_TEACHER_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(R["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(R["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(R["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(R["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(R["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(R["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(R["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(R["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(R["T_STUDENT_EMAIL"]) ? default : Convert.ToString(R["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(R["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(R["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(R["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(R["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(R["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(R["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(R["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(R["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(R["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(R["T_STUDENT_OWNER_ID"]);
}
return o;
}
public User Get_User_By_USER_ID_Adv ( long? USER_ID)
{
User o = new User();
dynamic p = new ExpandoObject();
p.USER_ID = USER_ID;
IEnumerable<IDataRecord> oQuery = ExecuteSelectQuery("UPG_GET_USER_BY_USER_ID_ADV", p);
var R = oQuery.FirstOrDefault();
if (R != null)
{
oTools.CopyPropValues_FromDataRecord(R, o);

}
return o;
}
public List<Answer> Get_Answer_By_ANSWER_ID_List ( List<Int32?> ANSWER_ID_LIST)
{
List<Answer> oList = new List<Answer>();
dynamic p = new ExpandoObject();
p.ANSWER_ID_LIST = string.Join(",", ANSWER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_ANSWER_BY_ANSWER_ID_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Answer o = new Answer();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Answer_report> Get_Answer_report_By_ANSWER_REPORT_ID_List ( List<Int32?> ANSWER_REPORT_ID_LIST)
{
List<Answer_report> oList = new List<Answer_report>();
dynamic p = new ExpandoObject();
p.ANSWER_REPORT_ID_LIST = string.Join(",", ANSWER_REPORT_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_ANSWER_REPORT_BY_ANSWER_REPORT_ID_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Answer_report o = new Answer_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Appreciate> Get_Appreciate_By_APPRECIATE_ID_List ( List<Int32?> APPRECIATE_ID_LIST)
{
List<Appreciate> oList = new List<Appreciate>();
dynamic p = new ExpandoObject();
p.APPRECIATE_ID_LIST = string.Join(",", APPRECIATE_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_APPRECIATE_BY_APPRECIATE_ID_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Appreciate o = new Appreciate();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Article> Get_Article_By_ARTICLE_ID_List ( List<Int32?> ARTICLE_ID_LIST)
{
List<Article> oList = new List<Article>();
dynamic p = new ExpandoObject();
p.ARTICLE_ID_LIST = string.Join(",", ARTICLE_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_ARTICLE_BY_ARTICLE_ID_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Article o = new Article();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Category> Get_Category_By_CATEGORY_ID_List ( List<Int32?> CATEGORY_ID_LIST)
{
List<Category> oList = new List<Category>();
dynamic p = new ExpandoObject();
p.CATEGORY_ID_LIST = string.Join(",", CATEGORY_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_CATEGORY_BY_CATEGORY_ID_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Category o = new Category();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Evaluation> Get_Evaluation_By_EVALUATION_ID_List ( List<Int32?> EVALUATION_ID_LIST)
{
List<Evaluation> oList = new List<Evaluation>();
dynamic p = new ExpandoObject();
p.EVALUATION_ID_LIST = string.Join(",", EVALUATION_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_EVALUATION_BY_EVALUATION_ID_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Evaluation o = new Evaluation();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Favorite_category> Get_Favorite_category_By_FAVORITE_CATEGORY_ID_List ( List<Int32?> FAVORITE_CATEGORY_ID_LIST)
{
List<Favorite_category> oList = new List<Favorite_category>();
dynamic p = new ExpandoObject();
p.FAVORITE_CATEGORY_ID_LIST = string.Join(",", FAVORITE_CATEGORY_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_FAVORITE_CATEGORY_BY_FAVORITE_CATEGORY_ID_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Favorite_category o = new Favorite_category();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Favorite_teacher> Get_Favorite_teacher_By_FAVORITE_TEACHER_ID_List ( List<Int32?> FAVORITE_TEACHER_ID_LIST)
{
List<Favorite_teacher> oList = new List<Favorite_teacher>();
dynamic p = new ExpandoObject();
p.FAVORITE_TEACHER_ID_LIST = string.Join(",", FAVORITE_TEACHER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_FAVORITE_TEACHER_BY_FAVORITE_TEACHER_ID_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Favorite_teacher o = new Favorite_teacher();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Mark_question> Get_Mark_question_By_MARK_QUESTION_ID_List ( List<Int32?> MARK_QUESTION_ID_LIST)
{
List<Mark_question> oList = new List<Mark_question>();
dynamic p = new ExpandoObject();
p.MARK_QUESTION_ID_LIST = string.Join(",", MARK_QUESTION_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_MARK_QUESTION_BY_MARK_QUESTION_ID_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Mark_question o = new Mark_question();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Notification> Get_Notification_By_NOTIFICATION_ID_List ( List<Int32?> NOTIFICATION_ID_LIST)
{
List<Notification> oList = new List<Notification>();
dynamic p = new ExpandoObject();
p.NOTIFICATION_ID_LIST = string.Join(",", NOTIFICATION_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_NOTIFICATION_BY_NOTIFICATION_ID_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Notification o = new Notification();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Owner> Get_Owner_By_OWNER_ID_List ( List<Int32?> OWNER_ID_LIST)
{
List<Owner> oList = new List<Owner>();
dynamic p = new ExpandoObject();
p.OWNER_ID_LIST = string.Join(",", OWNER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_OWNER_BY_OWNER_ID_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Owner o = new Owner();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Question> Get_Question_By_QUESTION_ID_List ( List<Int32?> QUESTION_ID_LIST)
{
List<Question> oList = new List<Question>();
dynamic p = new ExpandoObject();
p.QUESTION_ID_LIST = string.Join(",", QUESTION_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_QUESTION_BY_QUESTION_ID_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Question o = new Question();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Question_report> Get_Question_report_By_QUESTION_REPORT_ID_List ( List<Int32?> QUESTION_REPORT_ID_LIST)
{
List<Question_report> oList = new List<Question_report>();
dynamic p = new ExpandoObject();
p.QUESTION_REPORT_ID_LIST = string.Join(",", QUESTION_REPORT_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_QUESTION_REPORT_BY_QUESTION_REPORT_ID_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Question_report o = new Question_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Question_token> Get_Question_token_By_QUESTION_TOKEN_ID_List ( List<long?> QUESTION_TOKEN_ID_LIST)
{
List<Question_token> oList = new List<Question_token>();
dynamic p = new ExpandoObject();
p.QUESTION_TOKEN_ID_LIST = string.Join(",", QUESTION_TOKEN_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_QUESTION_TOKEN_BY_QUESTION_TOKEN_ID_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Question_token o = new Question_token();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Report_article> Get_Report_article_By_REPORT_ARTICLE_ID_List ( List<Int32?> REPORT_ARTICLE_ID_LIST)
{
List<Report_article> oList = new List<Report_article>();
dynamic p = new ExpandoObject();
p.REPORT_ARTICLE_ID_LIST = string.Join(",", REPORT_ARTICLE_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_REPORT_ARTICLE_BY_REPORT_ARTICLE_ID_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Report_article o = new Report_article();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Student> Get_Student_By_STUDENT_ID_List ( List<Int32?> STUDENT_ID_LIST)
{
List<Student> oList = new List<Student>();
dynamic p = new ExpandoObject();
p.STUDENT_ID_LIST = string.Join(",", STUDENT_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_STUDENT_BY_STUDENT_ID_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Student o = new Student();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Student_report> Get_Student_report_By_STUDENT_REPORT_ID_List ( List<Int32?> STUDENT_REPORT_ID_LIST)
{
List<Student_report> oList = new List<Student_report>();
dynamic p = new ExpandoObject();
p.STUDENT_REPORT_ID_LIST = string.Join(",", STUDENT_REPORT_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_STUDENT_REPORT_BY_STUDENT_REPORT_ID_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Student_report o = new Student_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Teacher> Get_Teacher_By_TEACHER_ID_List ( List<Int32?> TEACHER_ID_LIST)
{
List<Teacher> oList = new List<Teacher>();
dynamic p = new ExpandoObject();
p.TEACHER_ID_LIST = string.Join(",", TEACHER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_BY_TEACHER_ID_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher o = new Teacher();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Teacher_category> Get_Teacher_category_By_TEACHER_CATEGORY_ID_List ( List<Int32?> TEACHER_CATEGORY_ID_LIST)
{
List<Teacher_category> oList = new List<Teacher_category>();
dynamic p = new ExpandoObject();
p.TEACHER_CATEGORY_ID_LIST = string.Join(",", TEACHER_CATEGORY_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_CATEGORY_BY_TEACHER_CATEGORY_ID_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_category o = new Teacher_category();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Teacher_favorite> Get_Teacher_favorite_By_TEACHER_FAVORITE_ID_List ( List<Int32?> TEACHER_FAVORITE_ID_LIST)
{
List<Teacher_favorite> oList = new List<Teacher_favorite>();
dynamic p = new ExpandoObject();
p.TEACHER_FAVORITE_ID_LIST = string.Join(",", TEACHER_FAVORITE_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_FAVORITE_BY_TEACHER_FAVORITE_ID_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_favorite o = new Teacher_favorite();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Teacher_rank> Get_Teacher_rank_By_TEACHER_RANK_ID_List ( List<Int32?> TEACHER_RANK_ID_LIST)
{
List<Teacher_rank> oList = new List<Teacher_rank>();
dynamic p = new ExpandoObject();
p.TEACHER_RANK_ID_LIST = string.Join(",", TEACHER_RANK_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_RANK_BY_TEACHER_RANK_ID_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_rank o = new Teacher_rank();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Teacher_report> Get_Teacher_report_By_TEACHER_REPORT_ID_List ( List<Int32?> TEACHER_REPORT_ID_LIST)
{
List<Teacher_report> oList = new List<Teacher_report>();
dynamic p = new ExpandoObject();
p.TEACHER_REPORT_ID_LIST = string.Join(",", TEACHER_REPORT_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_REPORT_BY_TEACHER_REPORT_ID_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_report o = new Teacher_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<User> Get_User_By_USER_ID_List ( List<long?> USER_ID_LIST)
{
List<User> oList = new List<User>();
dynamic p = new ExpandoObject();
p.USER_ID_LIST = string.Join(",", USER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_USER_BY_USER_ID_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
User o = new User();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Answer> Get_Answer_By_ANSWER_ID_List_Adv ( List<Int32?> ANSWER_ID_LIST)
{
List<Answer> oList = new List<Answer>();
dynamic p = new ExpandoObject();
p.ANSWER_ID_LIST = string.Join(",", ANSWER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_ANSWER_BY_ANSWER_ID_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Answer o = new Answer();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Question = new Question();
o.My_Question.QUESTION_ID = Convert.IsDBNull(oRow["T_QUESTION_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_QUESTION_ID"]);o.My_Question.STUDENT_ID = Convert.IsDBNull(oRow["T_QUESTION_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_STUDENT_ID"]);o.My_Question.CATEGORY_ID = Convert.IsDBNull(oRow["T_QUESTION_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_CATEGORY_ID"]);o.My_Question.TEACHER_ID = Convert.IsDBNull(oRow["T_QUESTION_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_TEACHER_ID"]);o.My_Question.DESCRIPTION = Convert.IsDBNull(oRow["T_QUESTION_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_QUESTION_DESCRIPTION"]);o.My_Question.IS_ANSWERED = Convert.IsDBNull(oRow["T_QUESTION_IS_ANSWERED"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ANSWERED"]);o.My_Question.IS_ACTIVE = Convert.IsDBNull(oRow["T_QUESTION_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ACTIVE"]);o.My_Question.REPORTS = Convert.IsDBNull(oRow["T_QUESTION_REPORTS"]) ? default : Convert.ToInt32(oRow["T_QUESTION_REPORTS"]);o.My_Question.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_QUESTION_ENTRY_USER_ID"]);o.My_Question.ENTRY_DATE = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_QUESTION_ENTRY_DATE"]);o.My_Question.OWNER_ID = Convert.IsDBNull(oRow["T_QUESTION_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_OWNER_ID"]);
o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Answer_report> Get_Answer_report_By_ANSWER_REPORT_ID_List_Adv ( List<Int32?> ANSWER_REPORT_ID_LIST)
{
List<Answer_report> oList = new List<Answer_report>();
dynamic p = new ExpandoObject();
p.ANSWER_REPORT_ID_LIST = string.Join(",", ANSWER_REPORT_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_ANSWER_REPORT_BY_ANSWER_REPORT_ID_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Answer_report o = new Answer_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
o.My_Answer = new Answer();
o.My_Answer.ANSWER_ID = Convert.IsDBNull(oRow["T_ANSWER_ANSWER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_ANSWER_ID"]);o.My_Answer.QUESTION_ID = Convert.IsDBNull(oRow["T_ANSWER_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_QUESTION_ID"]);o.My_Answer.TEACHER_ID = Convert.IsDBNull(oRow["T_ANSWER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_TEACHER_ID"]);o.My_Answer.DESCRIPTION = Convert.IsDBNull(oRow["T_ANSWER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_ANSWER_DESCRIPTION"]);o.My_Answer.SCORE = Convert.IsDBNull(oRow["T_ANSWER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_ANSWER_SCORE"]);o.My_Answer.REVIEWS = Convert.IsDBNull(oRow["T_ANSWER_REVIEWS"]) ? default : Convert.ToInt32(oRow["T_ANSWER_REVIEWS"]);o.My_Answer.REPORTS = Convert.IsDBNull(oRow["T_ANSWER_REPORTS"]) ? default : Convert.ToInt32(oRow["T_ANSWER_REPORTS"]);o.My_Answer.IS_ACTIVE = Convert.IsDBNull(oRow["T_ANSWER_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_ANSWER_IS_ACTIVE"]);o.My_Answer.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_ANSWER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_ANSWER_ENTRY_USER_ID"]);o.My_Answer.ENTRY_DATE = Convert.IsDBNull(oRow["T_ANSWER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_ANSWER_ENTRY_DATE"]);o.My_Answer.OWNER_ID = Convert.IsDBNull(oRow["T_ANSWER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Appreciate> Get_Appreciate_By_APPRECIATE_ID_List_Adv ( List<Int32?> APPRECIATE_ID_LIST)
{
List<Appreciate> oList = new List<Appreciate>();
dynamic p = new ExpandoObject();
p.APPRECIATE_ID_LIST = string.Join(",", APPRECIATE_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_APPRECIATE_BY_APPRECIATE_ID_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Appreciate o = new Appreciate();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Article = new Article();
o.My_Article.ARTICLE_ID = Convert.IsDBNull(oRow["T_ARTICLE_ARTICLE_ID"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_ARTICLE_ID"]);o.My_Article.TEACHER_ID = Convert.IsDBNull(oRow["T_ARTICLE_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_TEACHER_ID"]);o.My_Article.CATEGORY_ID = Convert.IsDBNull(oRow["T_ARTICLE_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_CATEGORY_ID"]);o.My_Article.TITLE = Convert.IsDBNull(oRow["T_ARTICLE_TITLE"]) ? default : Convert.ToString(oRow["T_ARTICLE_TITLE"]);o.My_Article.DESCRIPTION = Convert.IsDBNull(oRow["T_ARTICLE_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_ARTICLE_DESCRIPTION"]);o.My_Article.APPLAUDS = Convert.IsDBNull(oRow["T_ARTICLE_APPLAUDS"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_APPLAUDS"]);o.My_Article.REPORTS = Convert.IsDBNull(oRow["T_ARTICLE_REPORTS"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_REPORTS"]);o.My_Article.IS_BLOCKED = Convert.IsDBNull(oRow["T_ARTICLE_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_ARTICLE_IS_BLOCKED"]);o.My_Article.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_ARTICLE_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_ARTICLE_ENTRY_USER_ID"]);o.My_Article.ENTRY_DATE = Convert.IsDBNull(oRow["T_ARTICLE_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_ARTICLE_ENTRY_DATE"]);o.My_Article.OWNER_ID = Convert.IsDBNull(oRow["T_ARTICLE_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Article> Get_Article_By_ARTICLE_ID_List_Adv ( List<Int32?> ARTICLE_ID_LIST)
{
List<Article> oList = new List<Article>();
dynamic p = new ExpandoObject();
p.ARTICLE_ID_LIST = string.Join(",", ARTICLE_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_ARTICLE_BY_ARTICLE_ID_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Article o = new Article();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Category = new Category();
o.My_Category.CATEGORY_ID = Convert.IsDBNull(oRow["T_CATEGORY_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_CATEGORY_ID"]);o.My_Category.NAME = Convert.IsDBNull(oRow["T_CATEGORY_NAME"]) ? default : Convert.ToString(oRow["T_CATEGORY_NAME"]);o.My_Category.DECRIPTION = Convert.IsDBNull(oRow["T_CATEGORY_DECRIPTION"]) ? default : Convert.ToString(oRow["T_CATEGORY_DECRIPTION"]);o.My_Category.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_CATEGORY_ENTRY_USER_ID"]);o.My_Category.ENTRY_DATE = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_CATEGORY_ENTRY_DATE"]);o.My_Category.OWNER_ID = Convert.IsDBNull(oRow["T_CATEGORY_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Category> Get_Category_By_CATEGORY_ID_List_Adv ( List<Int32?> CATEGORY_ID_LIST)
{
List<Category> oList = new List<Category>();
dynamic p = new ExpandoObject();
p.CATEGORY_ID_LIST = string.Join(",", CATEGORY_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_CATEGORY_BY_CATEGORY_ID_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Category o = new Category();
oTools.CopyPropValues_FromDataRecord(oRow, o);

oList.Add(o);
}
}
return oList;
}
public List<Evaluation> Get_Evaluation_By_EVALUATION_ID_List_Adv ( List<Int32?> EVALUATION_ID_LIST)
{
List<Evaluation> oList = new List<Evaluation>();
dynamic p = new ExpandoObject();
p.EVALUATION_ID_LIST = string.Join(",", EVALUATION_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_EVALUATION_BY_EVALUATION_ID_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Evaluation o = new Evaluation();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
o.My_Answer = new Answer();
o.My_Answer.ANSWER_ID = Convert.IsDBNull(oRow["T_ANSWER_ANSWER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_ANSWER_ID"]);o.My_Answer.QUESTION_ID = Convert.IsDBNull(oRow["T_ANSWER_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_QUESTION_ID"]);o.My_Answer.TEACHER_ID = Convert.IsDBNull(oRow["T_ANSWER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_TEACHER_ID"]);o.My_Answer.DESCRIPTION = Convert.IsDBNull(oRow["T_ANSWER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_ANSWER_DESCRIPTION"]);o.My_Answer.SCORE = Convert.IsDBNull(oRow["T_ANSWER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_ANSWER_SCORE"]);o.My_Answer.REVIEWS = Convert.IsDBNull(oRow["T_ANSWER_REVIEWS"]) ? default : Convert.ToInt32(oRow["T_ANSWER_REVIEWS"]);o.My_Answer.REPORTS = Convert.IsDBNull(oRow["T_ANSWER_REPORTS"]) ? default : Convert.ToInt32(oRow["T_ANSWER_REPORTS"]);o.My_Answer.IS_ACTIVE = Convert.IsDBNull(oRow["T_ANSWER_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_ANSWER_IS_ACTIVE"]);o.My_Answer.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_ANSWER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_ANSWER_ENTRY_USER_ID"]);o.My_Answer.ENTRY_DATE = Convert.IsDBNull(oRow["T_ANSWER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_ANSWER_ENTRY_DATE"]);o.My_Answer.OWNER_ID = Convert.IsDBNull(oRow["T_ANSWER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Favorite_category> Get_Favorite_category_By_FAVORITE_CATEGORY_ID_List_Adv ( List<Int32?> FAVORITE_CATEGORY_ID_LIST)
{
List<Favorite_category> oList = new List<Favorite_category>();
dynamic p = new ExpandoObject();
p.FAVORITE_CATEGORY_ID_LIST = string.Join(",", FAVORITE_CATEGORY_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_FAVORITE_CATEGORY_BY_FAVORITE_CATEGORY_ID_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Favorite_category o = new Favorite_category();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
o.My_Category = new Category();
o.My_Category.CATEGORY_ID = Convert.IsDBNull(oRow["T_CATEGORY_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_CATEGORY_ID"]);o.My_Category.NAME = Convert.IsDBNull(oRow["T_CATEGORY_NAME"]) ? default : Convert.ToString(oRow["T_CATEGORY_NAME"]);o.My_Category.DECRIPTION = Convert.IsDBNull(oRow["T_CATEGORY_DECRIPTION"]) ? default : Convert.ToString(oRow["T_CATEGORY_DECRIPTION"]);o.My_Category.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_CATEGORY_ENTRY_USER_ID"]);o.My_Category.ENTRY_DATE = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_CATEGORY_ENTRY_DATE"]);o.My_Category.OWNER_ID = Convert.IsDBNull(oRow["T_CATEGORY_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Favorite_teacher> Get_Favorite_teacher_By_FAVORITE_TEACHER_ID_List_Adv ( List<Int32?> FAVORITE_TEACHER_ID_LIST)
{
List<Favorite_teacher> oList = new List<Favorite_teacher>();
dynamic p = new ExpandoObject();
p.FAVORITE_TEACHER_ID_LIST = string.Join(",", FAVORITE_TEACHER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_FAVORITE_TEACHER_BY_FAVORITE_TEACHER_ID_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Favorite_teacher o = new Favorite_teacher();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Mark_question> Get_Mark_question_By_MARK_QUESTION_ID_List_Adv ( List<Int32?> MARK_QUESTION_ID_LIST)
{
List<Mark_question> oList = new List<Mark_question>();
dynamic p = new ExpandoObject();
p.MARK_QUESTION_ID_LIST = string.Join(",", MARK_QUESTION_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_MARK_QUESTION_BY_MARK_QUESTION_ID_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Mark_question o = new Mark_question();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Question = new Question();
o.My_Question.QUESTION_ID = Convert.IsDBNull(oRow["T_QUESTION_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_QUESTION_ID"]);o.My_Question.STUDENT_ID = Convert.IsDBNull(oRow["T_QUESTION_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_STUDENT_ID"]);o.My_Question.CATEGORY_ID = Convert.IsDBNull(oRow["T_QUESTION_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_CATEGORY_ID"]);o.My_Question.TEACHER_ID = Convert.IsDBNull(oRow["T_QUESTION_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_TEACHER_ID"]);o.My_Question.DESCRIPTION = Convert.IsDBNull(oRow["T_QUESTION_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_QUESTION_DESCRIPTION"]);o.My_Question.IS_ANSWERED = Convert.IsDBNull(oRow["T_QUESTION_IS_ANSWERED"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ANSWERED"]);o.My_Question.IS_ACTIVE = Convert.IsDBNull(oRow["T_QUESTION_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ACTIVE"]);o.My_Question.REPORTS = Convert.IsDBNull(oRow["T_QUESTION_REPORTS"]) ? default : Convert.ToInt32(oRow["T_QUESTION_REPORTS"]);o.My_Question.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_QUESTION_ENTRY_USER_ID"]);o.My_Question.ENTRY_DATE = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_QUESTION_ENTRY_DATE"]);o.My_Question.OWNER_ID = Convert.IsDBNull(oRow["T_QUESTION_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Notification> Get_Notification_By_NOTIFICATION_ID_List_Adv ( List<Int32?> NOTIFICATION_ID_LIST)
{
List<Notification> oList = new List<Notification>();
dynamic p = new ExpandoObject();
p.NOTIFICATION_ID_LIST = string.Join(",", NOTIFICATION_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_NOTIFICATION_BY_NOTIFICATION_ID_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Notification o = new Notification();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_User = new User();
o.My_User.USER_ID = Convert.IsDBNull(oRow["T_USER_USER_ID"]) ? default : Convert.ToInt64(oRow["T_USER_USER_ID"]);o.My_User.OWNER_ID = Convert.IsDBNull(oRow["T_USER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_USER_OWNER_ID"]);o.My_User.USERNAME = Convert.IsDBNull(oRow["T_USER_USERNAME"]) ? default : Convert.ToString(oRow["T_USER_USERNAME"]);o.My_User.PASSWORD = Convert.IsDBNull(oRow["T_USER_PASSWORD"]) ? default : Convert.ToString(oRow["T_USER_PASSWORD"]);o.My_User.USER_TYPE_CODE = Convert.IsDBNull(oRow["T_USER_USER_TYPE_CODE"]) ? default : Convert.ToString(oRow["T_USER_USER_TYPE_CODE"]);o.My_User.IS_LOGGED_IN = Convert.IsDBNull(oRow["T_USER_IS_LOGGED_IN"]) ? default : Convert.ToBoolean(oRow["T_USER_IS_LOGGED_IN"]);o.My_User.IS_ACTIVE = Convert.IsDBNull(oRow["T_USER_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_USER_IS_ACTIVE"]);o.My_User.ENTRY_DATE = Convert.IsDBNull(oRow["T_USER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_USER_ENTRY_DATE"]);
o.My_Question = new Question();
o.My_Question.QUESTION_ID = Convert.IsDBNull(oRow["T_QUESTION_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_QUESTION_ID"]);o.My_Question.STUDENT_ID = Convert.IsDBNull(oRow["T_QUESTION_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_STUDENT_ID"]);o.My_Question.CATEGORY_ID = Convert.IsDBNull(oRow["T_QUESTION_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_CATEGORY_ID"]);o.My_Question.TEACHER_ID = Convert.IsDBNull(oRow["T_QUESTION_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_TEACHER_ID"]);o.My_Question.DESCRIPTION = Convert.IsDBNull(oRow["T_QUESTION_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_QUESTION_DESCRIPTION"]);o.My_Question.IS_ANSWERED = Convert.IsDBNull(oRow["T_QUESTION_IS_ANSWERED"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ANSWERED"]);o.My_Question.IS_ACTIVE = Convert.IsDBNull(oRow["T_QUESTION_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ACTIVE"]);o.My_Question.REPORTS = Convert.IsDBNull(oRow["T_QUESTION_REPORTS"]) ? default : Convert.ToInt32(oRow["T_QUESTION_REPORTS"]);o.My_Question.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_QUESTION_ENTRY_USER_ID"]);o.My_Question.ENTRY_DATE = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_QUESTION_ENTRY_DATE"]);o.My_Question.OWNER_ID = Convert.IsDBNull(oRow["T_QUESTION_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_OWNER_ID"]);
o.My_Answer = new Answer();
o.My_Answer.ANSWER_ID = Convert.IsDBNull(oRow["T_ANSWER_ANSWER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_ANSWER_ID"]);o.My_Answer.QUESTION_ID = Convert.IsDBNull(oRow["T_ANSWER_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_QUESTION_ID"]);o.My_Answer.TEACHER_ID = Convert.IsDBNull(oRow["T_ANSWER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_TEACHER_ID"]);o.My_Answer.DESCRIPTION = Convert.IsDBNull(oRow["T_ANSWER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_ANSWER_DESCRIPTION"]);o.My_Answer.SCORE = Convert.IsDBNull(oRow["T_ANSWER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_ANSWER_SCORE"]);o.My_Answer.REVIEWS = Convert.IsDBNull(oRow["T_ANSWER_REVIEWS"]) ? default : Convert.ToInt32(oRow["T_ANSWER_REVIEWS"]);o.My_Answer.REPORTS = Convert.IsDBNull(oRow["T_ANSWER_REPORTS"]) ? default : Convert.ToInt32(oRow["T_ANSWER_REPORTS"]);o.My_Answer.IS_ACTIVE = Convert.IsDBNull(oRow["T_ANSWER_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_ANSWER_IS_ACTIVE"]);o.My_Answer.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_ANSWER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_ANSWER_ENTRY_USER_ID"]);o.My_Answer.ENTRY_DATE = Convert.IsDBNull(oRow["T_ANSWER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_ANSWER_ENTRY_DATE"]);o.My_Answer.OWNER_ID = Convert.IsDBNull(oRow["T_ANSWER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Question> Get_Question_By_QUESTION_ID_List_Adv ( List<Int32?> QUESTION_ID_LIST)
{
List<Question> oList = new List<Question>();
dynamic p = new ExpandoObject();
p.QUESTION_ID_LIST = string.Join(",", QUESTION_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_QUESTION_BY_QUESTION_ID_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Question o = new Question();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
o.My_Category = new Category();
o.My_Category.CATEGORY_ID = Convert.IsDBNull(oRow["T_CATEGORY_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_CATEGORY_ID"]);o.My_Category.NAME = Convert.IsDBNull(oRow["T_CATEGORY_NAME"]) ? default : Convert.ToString(oRow["T_CATEGORY_NAME"]);o.My_Category.DECRIPTION = Convert.IsDBNull(oRow["T_CATEGORY_DECRIPTION"]) ? default : Convert.ToString(oRow["T_CATEGORY_DECRIPTION"]);o.My_Category.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_CATEGORY_ENTRY_USER_ID"]);o.My_Category.ENTRY_DATE = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_CATEGORY_ENTRY_DATE"]);o.My_Category.OWNER_ID = Convert.IsDBNull(oRow["T_CATEGORY_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_OWNER_ID"]);
o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Question_report> Get_Question_report_By_QUESTION_REPORT_ID_List_Adv ( List<Int32?> QUESTION_REPORT_ID_LIST)
{
List<Question_report> oList = new List<Question_report>();
dynamic p = new ExpandoObject();
p.QUESTION_REPORT_ID_LIST = string.Join(",", QUESTION_REPORT_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_QUESTION_REPORT_BY_QUESTION_REPORT_ID_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Question_report o = new Question_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Question = new Question();
o.My_Question.QUESTION_ID = Convert.IsDBNull(oRow["T_QUESTION_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_QUESTION_ID"]);o.My_Question.STUDENT_ID = Convert.IsDBNull(oRow["T_QUESTION_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_STUDENT_ID"]);o.My_Question.CATEGORY_ID = Convert.IsDBNull(oRow["T_QUESTION_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_CATEGORY_ID"]);o.My_Question.TEACHER_ID = Convert.IsDBNull(oRow["T_QUESTION_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_TEACHER_ID"]);o.My_Question.DESCRIPTION = Convert.IsDBNull(oRow["T_QUESTION_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_QUESTION_DESCRIPTION"]);o.My_Question.IS_ANSWERED = Convert.IsDBNull(oRow["T_QUESTION_IS_ANSWERED"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ANSWERED"]);o.My_Question.IS_ACTIVE = Convert.IsDBNull(oRow["T_QUESTION_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ACTIVE"]);o.My_Question.REPORTS = Convert.IsDBNull(oRow["T_QUESTION_REPORTS"]) ? default : Convert.ToInt32(oRow["T_QUESTION_REPORTS"]);o.My_Question.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_QUESTION_ENTRY_USER_ID"]);o.My_Question.ENTRY_DATE = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_QUESTION_ENTRY_DATE"]);o.My_Question.OWNER_ID = Convert.IsDBNull(oRow["T_QUESTION_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Question_token> Get_Question_token_By_QUESTION_TOKEN_ID_List_Adv ( List<long?> QUESTION_TOKEN_ID_LIST)
{
List<Question_token> oList = new List<Question_token>();
dynamic p = new ExpandoObject();
p.QUESTION_TOKEN_ID_LIST = string.Join(",", QUESTION_TOKEN_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_QUESTION_TOKEN_BY_QUESTION_TOKEN_ID_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Question_token o = new Question_token();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Question = new Question();
o.My_Question.QUESTION_ID = Convert.IsDBNull(oRow["T_QUESTION_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_QUESTION_ID"]);o.My_Question.STUDENT_ID = Convert.IsDBNull(oRow["T_QUESTION_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_STUDENT_ID"]);o.My_Question.CATEGORY_ID = Convert.IsDBNull(oRow["T_QUESTION_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_CATEGORY_ID"]);o.My_Question.TEACHER_ID = Convert.IsDBNull(oRow["T_QUESTION_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_TEACHER_ID"]);o.My_Question.DESCRIPTION = Convert.IsDBNull(oRow["T_QUESTION_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_QUESTION_DESCRIPTION"]);o.My_Question.IS_ANSWERED = Convert.IsDBNull(oRow["T_QUESTION_IS_ANSWERED"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ANSWERED"]);o.My_Question.IS_ACTIVE = Convert.IsDBNull(oRow["T_QUESTION_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ACTIVE"]);o.My_Question.REPORTS = Convert.IsDBNull(oRow["T_QUESTION_REPORTS"]) ? default : Convert.ToInt32(oRow["T_QUESTION_REPORTS"]);o.My_Question.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_QUESTION_ENTRY_USER_ID"]);o.My_Question.ENTRY_DATE = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_QUESTION_ENTRY_DATE"]);o.My_Question.OWNER_ID = Convert.IsDBNull(oRow["T_QUESTION_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Report_article> Get_Report_article_By_REPORT_ARTICLE_ID_List_Adv ( List<Int32?> REPORT_ARTICLE_ID_LIST)
{
List<Report_article> oList = new List<Report_article>();
dynamic p = new ExpandoObject();
p.REPORT_ARTICLE_ID_LIST = string.Join(",", REPORT_ARTICLE_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_REPORT_ARTICLE_BY_REPORT_ARTICLE_ID_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Report_article o = new Report_article();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Article = new Article();
o.My_Article.ARTICLE_ID = Convert.IsDBNull(oRow["T_ARTICLE_ARTICLE_ID"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_ARTICLE_ID"]);o.My_Article.TEACHER_ID = Convert.IsDBNull(oRow["T_ARTICLE_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_TEACHER_ID"]);o.My_Article.CATEGORY_ID = Convert.IsDBNull(oRow["T_ARTICLE_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_CATEGORY_ID"]);o.My_Article.TITLE = Convert.IsDBNull(oRow["T_ARTICLE_TITLE"]) ? default : Convert.ToString(oRow["T_ARTICLE_TITLE"]);o.My_Article.DESCRIPTION = Convert.IsDBNull(oRow["T_ARTICLE_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_ARTICLE_DESCRIPTION"]);o.My_Article.APPLAUDS = Convert.IsDBNull(oRow["T_ARTICLE_APPLAUDS"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_APPLAUDS"]);o.My_Article.REPORTS = Convert.IsDBNull(oRow["T_ARTICLE_REPORTS"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_REPORTS"]);o.My_Article.IS_BLOCKED = Convert.IsDBNull(oRow["T_ARTICLE_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_ARTICLE_IS_BLOCKED"]);o.My_Article.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_ARTICLE_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_ARTICLE_ENTRY_USER_ID"]);o.My_Article.ENTRY_DATE = Convert.IsDBNull(oRow["T_ARTICLE_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_ARTICLE_ENTRY_DATE"]);o.My_Article.OWNER_ID = Convert.IsDBNull(oRow["T_ARTICLE_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Student> Get_Student_By_STUDENT_ID_List_Adv ( List<Int32?> STUDENT_ID_LIST)
{
List<Student> oList = new List<Student>();
dynamic p = new ExpandoObject();
p.STUDENT_ID_LIST = string.Join(",", STUDENT_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_STUDENT_BY_STUDENT_ID_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Student o = new Student();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_User = new User();
o.My_User.USER_ID = Convert.IsDBNull(oRow["T_USER_USER_ID"]) ? default : Convert.ToInt64(oRow["T_USER_USER_ID"]);o.My_User.OWNER_ID = Convert.IsDBNull(oRow["T_USER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_USER_OWNER_ID"]);o.My_User.USERNAME = Convert.IsDBNull(oRow["T_USER_USERNAME"]) ? default : Convert.ToString(oRow["T_USER_USERNAME"]);o.My_User.PASSWORD = Convert.IsDBNull(oRow["T_USER_PASSWORD"]) ? default : Convert.ToString(oRow["T_USER_PASSWORD"]);o.My_User.USER_TYPE_CODE = Convert.IsDBNull(oRow["T_USER_USER_TYPE_CODE"]) ? default : Convert.ToString(oRow["T_USER_USER_TYPE_CODE"]);o.My_User.IS_LOGGED_IN = Convert.IsDBNull(oRow["T_USER_IS_LOGGED_IN"]) ? default : Convert.ToBoolean(oRow["T_USER_IS_LOGGED_IN"]);o.My_User.IS_ACTIVE = Convert.IsDBNull(oRow["T_USER_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_USER_IS_ACTIVE"]);o.My_User.ENTRY_DATE = Convert.IsDBNull(oRow["T_USER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_USER_ENTRY_DATE"]);
oList.Add(o);
}
}
return oList;
}
public List<Student_report> Get_Student_report_By_STUDENT_REPORT_ID_List_Adv ( List<Int32?> STUDENT_REPORT_ID_LIST)
{
List<Student_report> oList = new List<Student_report>();
dynamic p = new ExpandoObject();
p.STUDENT_REPORT_ID_LIST = string.Join(",", STUDENT_REPORT_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_STUDENT_REPORT_BY_STUDENT_REPORT_ID_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Student_report o = new Student_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Reported_by_student = new Student();
o.My_Reported_by_student.STUDENT_ID = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_REPORTED_BY_STUDENT_STUDENT_ID"]);o.My_Reported_by_student.USER_ID = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_REPORTED_BY_STUDENT_USER_ID"]);o.My_Reported_by_student.FIRST_NAME = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_REPORTED_BY_STUDENT_FIRST_NAME"]);o.My_Reported_by_student.LAST_NAME = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_REPORTED_BY_STUDENT_LAST_NAME"]);o.My_Reported_by_student.EMAIL = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_REPORTED_BY_STUDENT_EMAIL"]);o.My_Reported_by_student.IS_BLOCKED = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_REPORTED_BY_STUDENT_IS_BLOCKED"]);o.My_Reported_by_student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_REPORTED_BY_STUDENT_PENDING_QUESTIONS"]);o.My_Reported_by_student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_REPORTED_BY_STUDENT_ENTRY_USER_ID"]);o.My_Reported_by_student.ENTRY_DATE = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_REPORTED_BY_STUDENT_ENTRY_DATE"]);o.My_Reported_by_student.OWNER_ID = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_REPORTED_BY_STUDENT_OWNER_ID"]);
o.My_Reported_student = new Student();
o.My_Reported_student.STUDENT_ID = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_REPORTED_STUDENT_STUDENT_ID"]);o.My_Reported_student.USER_ID = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_REPORTED_STUDENT_USER_ID"]);o.My_Reported_student.FIRST_NAME = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_REPORTED_STUDENT_FIRST_NAME"]);o.My_Reported_student.LAST_NAME = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_REPORTED_STUDENT_LAST_NAME"]);o.My_Reported_student.EMAIL = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_REPORTED_STUDENT_EMAIL"]);o.My_Reported_student.IS_BLOCKED = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_REPORTED_STUDENT_IS_BLOCKED"]);o.My_Reported_student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_REPORTED_STUDENT_PENDING_QUESTIONS"]);o.My_Reported_student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_REPORTED_STUDENT_ENTRY_USER_ID"]);o.My_Reported_student.ENTRY_DATE = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_REPORTED_STUDENT_ENTRY_DATE"]);o.My_Reported_student.OWNER_ID = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_REPORTED_STUDENT_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Teacher> Get_Teacher_By_TEACHER_ID_List_Adv ( List<Int32?> TEACHER_ID_LIST)
{
List<Teacher> oList = new List<Teacher>();
dynamic p = new ExpandoObject();
p.TEACHER_ID_LIST = string.Join(",", TEACHER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_BY_TEACHER_ID_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher o = new Teacher();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_User = new User();
o.My_User.USER_ID = Convert.IsDBNull(oRow["T_USER_USER_ID"]) ? default : Convert.ToInt64(oRow["T_USER_USER_ID"]);o.My_User.OWNER_ID = Convert.IsDBNull(oRow["T_USER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_USER_OWNER_ID"]);o.My_User.USERNAME = Convert.IsDBNull(oRow["T_USER_USERNAME"]) ? default : Convert.ToString(oRow["T_USER_USERNAME"]);o.My_User.PASSWORD = Convert.IsDBNull(oRow["T_USER_PASSWORD"]) ? default : Convert.ToString(oRow["T_USER_PASSWORD"]);o.My_User.USER_TYPE_CODE = Convert.IsDBNull(oRow["T_USER_USER_TYPE_CODE"]) ? default : Convert.ToString(oRow["T_USER_USER_TYPE_CODE"]);o.My_User.IS_LOGGED_IN = Convert.IsDBNull(oRow["T_USER_IS_LOGGED_IN"]) ? default : Convert.ToBoolean(oRow["T_USER_IS_LOGGED_IN"]);o.My_User.IS_ACTIVE = Convert.IsDBNull(oRow["T_USER_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_USER_IS_ACTIVE"]);o.My_User.ENTRY_DATE = Convert.IsDBNull(oRow["T_USER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_USER_ENTRY_DATE"]);
oList.Add(o);
}
}
return oList;
}
public List<Teacher_category> Get_Teacher_category_By_TEACHER_CATEGORY_ID_List_Adv ( List<Int32?> TEACHER_CATEGORY_ID_LIST)
{
List<Teacher_category> oList = new List<Teacher_category>();
dynamic p = new ExpandoObject();
p.TEACHER_CATEGORY_ID_LIST = string.Join(",", TEACHER_CATEGORY_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_CATEGORY_BY_TEACHER_CATEGORY_ID_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_category o = new Teacher_category();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Category = new Category();
o.My_Category.CATEGORY_ID = Convert.IsDBNull(oRow["T_CATEGORY_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_CATEGORY_ID"]);o.My_Category.NAME = Convert.IsDBNull(oRow["T_CATEGORY_NAME"]) ? default : Convert.ToString(oRow["T_CATEGORY_NAME"]);o.My_Category.DECRIPTION = Convert.IsDBNull(oRow["T_CATEGORY_DECRIPTION"]) ? default : Convert.ToString(oRow["T_CATEGORY_DECRIPTION"]);o.My_Category.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_CATEGORY_ENTRY_USER_ID"]);o.My_Category.ENTRY_DATE = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_CATEGORY_ENTRY_DATE"]);o.My_Category.OWNER_ID = Convert.IsDBNull(oRow["T_CATEGORY_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Teacher_favorite> Get_Teacher_favorite_By_TEACHER_FAVORITE_ID_List_Adv ( List<Int32?> TEACHER_FAVORITE_ID_LIST)
{
List<Teacher_favorite> oList = new List<Teacher_favorite>();
dynamic p = new ExpandoObject();
p.TEACHER_FAVORITE_ID_LIST = string.Join(",", TEACHER_FAVORITE_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_FAVORITE_BY_TEACHER_FAVORITE_ID_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_favorite o = new Teacher_favorite();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Teacher_rank> Get_Teacher_rank_By_TEACHER_RANK_ID_List_Adv ( List<Int32?> TEACHER_RANK_ID_LIST)
{
List<Teacher_rank> oList = new List<Teacher_rank>();
dynamic p = new ExpandoObject();
p.TEACHER_RANK_ID_LIST = string.Join(",", TEACHER_RANK_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_RANK_BY_TEACHER_RANK_ID_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_rank o = new Teacher_rank();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Teacher_report> Get_Teacher_report_By_TEACHER_REPORT_ID_List_Adv ( List<Int32?> TEACHER_REPORT_ID_LIST)
{
List<Teacher_report> oList = new List<Teacher_report>();
dynamic p = new ExpandoObject();
p.TEACHER_REPORT_ID_LIST = string.Join(",", TEACHER_REPORT_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_REPORT_BY_TEACHER_REPORT_ID_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_report o = new Teacher_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<User> Get_User_By_USER_ID_List_Adv ( List<long?> USER_ID_LIST)
{
List<User> oList = new List<User>();
dynamic p = new ExpandoObject();
p.USER_ID_LIST = string.Join(",", USER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_USER_BY_USER_ID_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
User o = new User();
oTools.CopyPropValues_FromDataRecord(oRow, o);

oList.Add(o);
}
}
return oList;
}
public List<Answer> Get_Answer_By_OWNER_ID ( Int32? OWNER_ID)
{
List<Answer> oList = new List<Answer>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_ANSWER_BY_OWNER_ID", p);
if (R != null)
{
foreach (var oRow in R)
{
Answer o = new Answer();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Answer> Get_Answer_By_QUESTION_ID ( Int32? QUESTION_ID)
{
List<Answer> oList = new List<Answer>();
dynamic p = new ExpandoObject();
p.QUESTION_ID = QUESTION_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_ANSWER_BY_QUESTION_ID", p);
if (R != null)
{
foreach (var oRow in R)
{
Answer o = new Answer();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Answer> Get_Answer_By_TEACHER_ID ( Int32? TEACHER_ID)
{
List<Answer> oList = new List<Answer>();
dynamic p = new ExpandoObject();
p.TEACHER_ID = TEACHER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_ANSWER_BY_TEACHER_ID", p);
if (R != null)
{
foreach (var oRow in R)
{
Answer o = new Answer();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Answer_report> Get_Answer_report_By_OWNER_ID ( Int32? OWNER_ID)
{
List<Answer_report> oList = new List<Answer_report>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_ANSWER_REPORT_BY_OWNER_ID", p);
if (R != null)
{
foreach (var oRow in R)
{
Answer_report o = new Answer_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Answer_report> Get_Answer_report_By_TEACHER_ID ( Int32? TEACHER_ID)
{
List<Answer_report> oList = new List<Answer_report>();
dynamic p = new ExpandoObject();
p.TEACHER_ID = TEACHER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_ANSWER_REPORT_BY_TEACHER_ID", p);
if (R != null)
{
foreach (var oRow in R)
{
Answer_report o = new Answer_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Answer_report> Get_Answer_report_By_STUDENT_ID ( Int32? STUDENT_ID)
{
List<Answer_report> oList = new List<Answer_report>();
dynamic p = new ExpandoObject();
p.STUDENT_ID = STUDENT_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_ANSWER_REPORT_BY_STUDENT_ID", p);
if (R != null)
{
foreach (var oRow in R)
{
Answer_report o = new Answer_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Answer_report> Get_Answer_report_By_ANSWER_ID ( Int32? ANSWER_ID)
{
List<Answer_report> oList = new List<Answer_report>();
dynamic p = new ExpandoObject();
p.ANSWER_ID = ANSWER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_ANSWER_REPORT_BY_ANSWER_ID", p);
if (R != null)
{
foreach (var oRow in R)
{
Answer_report o = new Answer_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Appreciate> Get_Appreciate_By_OWNER_ID ( Int32? OWNER_ID)
{
List<Appreciate> oList = new List<Appreciate>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_APPRECIATE_BY_OWNER_ID", p);
if (R != null)
{
foreach (var oRow in R)
{
Appreciate o = new Appreciate();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Appreciate> Get_Appreciate_By_ARTICLE_ID ( Int32? ARTICLE_ID)
{
List<Appreciate> oList = new List<Appreciate>();
dynamic p = new ExpandoObject();
p.ARTICLE_ID = ARTICLE_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_APPRECIATE_BY_ARTICLE_ID", p);
if (R != null)
{
foreach (var oRow in R)
{
Appreciate o = new Appreciate();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Appreciate> Get_Appreciate_By_STUDENT_ID ( Int32? STUDENT_ID)
{
List<Appreciate> oList = new List<Appreciate>();
dynamic p = new ExpandoObject();
p.STUDENT_ID = STUDENT_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_APPRECIATE_BY_STUDENT_ID", p);
if (R != null)
{
foreach (var oRow in R)
{
Appreciate o = new Appreciate();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Article> Get_Article_By_OWNER_ID ( Int32? OWNER_ID)
{
List<Article> oList = new List<Article>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_ARTICLE_BY_OWNER_ID", p);
if (R != null)
{
foreach (var oRow in R)
{
Article o = new Article();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Article> Get_Article_By_TEACHER_ID ( Int32? TEACHER_ID)
{
List<Article> oList = new List<Article>();
dynamic p = new ExpandoObject();
p.TEACHER_ID = TEACHER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_ARTICLE_BY_TEACHER_ID", p);
if (R != null)
{
foreach (var oRow in R)
{
Article o = new Article();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Article> Get_Article_By_CATEGORY_ID ( Int32? CATEGORY_ID)
{
List<Article> oList = new List<Article>();
dynamic p = new ExpandoObject();
p.CATEGORY_ID = CATEGORY_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_ARTICLE_BY_CATEGORY_ID", p);
if (R != null)
{
foreach (var oRow in R)
{
Article o = new Article();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Category> Get_Category_By_OWNER_ID ( Int32? OWNER_ID)
{
List<Category> oList = new List<Category>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_CATEGORY_BY_OWNER_ID", p);
if (R != null)
{
foreach (var oRow in R)
{
Category o = new Category();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Evaluation> Get_Evaluation_By_OWNER_ID ( Int32? OWNER_ID)
{
List<Evaluation> oList = new List<Evaluation>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_EVALUATION_BY_OWNER_ID", p);
if (R != null)
{
foreach (var oRow in R)
{
Evaluation o = new Evaluation();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Evaluation> Get_Evaluation_By_STUDENT_ID ( Int32? STUDENT_ID)
{
List<Evaluation> oList = new List<Evaluation>();
dynamic p = new ExpandoObject();
p.STUDENT_ID = STUDENT_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_EVALUATION_BY_STUDENT_ID", p);
if (R != null)
{
foreach (var oRow in R)
{
Evaluation o = new Evaluation();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Evaluation> Get_Evaluation_By_ANSWER_ID ( Int32? ANSWER_ID)
{
List<Evaluation> oList = new List<Evaluation>();
dynamic p = new ExpandoObject();
p.ANSWER_ID = ANSWER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_EVALUATION_BY_ANSWER_ID", p);
if (R != null)
{
foreach (var oRow in R)
{
Evaluation o = new Evaluation();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Favorite_category> Get_Favorite_category_By_STUDENT_ID ( Int32? STUDENT_ID)
{
List<Favorite_category> oList = new List<Favorite_category>();
dynamic p = new ExpandoObject();
p.STUDENT_ID = STUDENT_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_FAVORITE_CATEGORY_BY_STUDENT_ID", p);
if (R != null)
{
foreach (var oRow in R)
{
Favorite_category o = new Favorite_category();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Favorite_category> Get_Favorite_category_By_CATEGORY_ID ( Int32? CATEGORY_ID)
{
List<Favorite_category> oList = new List<Favorite_category>();
dynamic p = new ExpandoObject();
p.CATEGORY_ID = CATEGORY_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_FAVORITE_CATEGORY_BY_CATEGORY_ID", p);
if (R != null)
{
foreach (var oRow in R)
{
Favorite_category o = new Favorite_category();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Favorite_category> Get_Favorite_category_By_OWNER_ID ( Int32? OWNER_ID)
{
List<Favorite_category> oList = new List<Favorite_category>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_FAVORITE_CATEGORY_BY_OWNER_ID", p);
if (R != null)
{
foreach (var oRow in R)
{
Favorite_category o = new Favorite_category();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Favorite_teacher> Get_Favorite_teacher_By_TEACHER_ID ( Int32? TEACHER_ID)
{
List<Favorite_teacher> oList = new List<Favorite_teacher>();
dynamic p = new ExpandoObject();
p.TEACHER_ID = TEACHER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_FAVORITE_TEACHER_BY_TEACHER_ID", p);
if (R != null)
{
foreach (var oRow in R)
{
Favorite_teacher o = new Favorite_teacher();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Favorite_teacher> Get_Favorite_teacher_By_STUDENT_ID ( Int32? STUDENT_ID)
{
List<Favorite_teacher> oList = new List<Favorite_teacher>();
dynamic p = new ExpandoObject();
p.STUDENT_ID = STUDENT_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_FAVORITE_TEACHER_BY_STUDENT_ID", p);
if (R != null)
{
foreach (var oRow in R)
{
Favorite_teacher o = new Favorite_teacher();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Favorite_teacher> Get_Favorite_teacher_By_OWNER_ID ( Int32? OWNER_ID)
{
List<Favorite_teacher> oList = new List<Favorite_teacher>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_FAVORITE_TEACHER_BY_OWNER_ID", p);
if (R != null)
{
foreach (var oRow in R)
{
Favorite_teacher o = new Favorite_teacher();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Mark_question> Get_Mark_question_By_OWNER_ID ( Int32? OWNER_ID)
{
List<Mark_question> oList = new List<Mark_question>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_MARK_QUESTION_BY_OWNER_ID", p);
if (R != null)
{
foreach (var oRow in R)
{
Mark_question o = new Mark_question();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Mark_question> Get_Mark_question_By_QUESTION_ID ( Int32? QUESTION_ID)
{
List<Mark_question> oList = new List<Mark_question>();
dynamic p = new ExpandoObject();
p.QUESTION_ID = QUESTION_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_MARK_QUESTION_BY_QUESTION_ID", p);
if (R != null)
{
foreach (var oRow in R)
{
Mark_question o = new Mark_question();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Mark_question> Get_Mark_question_By_STUDENT_ID ( Int32? STUDENT_ID)
{
List<Mark_question> oList = new List<Mark_question>();
dynamic p = new ExpandoObject();
p.STUDENT_ID = STUDENT_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_MARK_QUESTION_BY_STUDENT_ID", p);
if (R != null)
{
foreach (var oRow in R)
{
Mark_question o = new Mark_question();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Notification> Get_Notification_By_OWNER_ID ( Int32? OWNER_ID)
{
List<Notification> oList = new List<Notification>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_NOTIFICATION_BY_OWNER_ID", p);
if (R != null)
{
foreach (var oRow in R)
{
Notification o = new Notification();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Notification> Get_Notification_By_USER_ID ( Int32? USER_ID)
{
List<Notification> oList = new List<Notification>();
dynamic p = new ExpandoObject();
p.USER_ID = USER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_NOTIFICATION_BY_USER_ID", p);
if (R != null)
{
foreach (var oRow in R)
{
Notification o = new Notification();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Notification> Get_Notification_By_QUESTION_ID ( Int32? QUESTION_ID)
{
List<Notification> oList = new List<Notification>();
dynamic p = new ExpandoObject();
p.QUESTION_ID = QUESTION_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_NOTIFICATION_BY_QUESTION_ID", p);
if (R != null)
{
foreach (var oRow in R)
{
Notification o = new Notification();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Notification> Get_Notification_By_ANSWER_ID ( Int32? ANSWER_ID)
{
List<Notification> oList = new List<Notification>();
dynamic p = new ExpandoObject();
p.ANSWER_ID = ANSWER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_NOTIFICATION_BY_ANSWER_ID", p);
if (R != null)
{
foreach (var oRow in R)
{
Notification o = new Notification();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Question> Get_Question_By_OWNER_ID ( Int32? OWNER_ID)
{
List<Question> oList = new List<Question>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_QUESTION_BY_OWNER_ID", p);
if (R != null)
{
foreach (var oRow in R)
{
Question o = new Question();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Question> Get_Question_By_STUDENT_ID ( Int32? STUDENT_ID)
{
List<Question> oList = new List<Question>();
dynamic p = new ExpandoObject();
p.STUDENT_ID = STUDENT_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_QUESTION_BY_STUDENT_ID", p);
if (R != null)
{
foreach (var oRow in R)
{
Question o = new Question();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Question> Get_Question_By_CATEGORY_ID ( Int32? CATEGORY_ID)
{
List<Question> oList = new List<Question>();
dynamic p = new ExpandoObject();
p.CATEGORY_ID = CATEGORY_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_QUESTION_BY_CATEGORY_ID", p);
if (R != null)
{
foreach (var oRow in R)
{
Question o = new Question();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Question> Get_Question_By_TEACHER_ID ( Int32? TEACHER_ID)
{
List<Question> oList = new List<Question>();
dynamic p = new ExpandoObject();
p.TEACHER_ID = TEACHER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_QUESTION_BY_TEACHER_ID", p);
if (R != null)
{
foreach (var oRow in R)
{
Question o = new Question();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Question_report> Get_Question_report_By_OWNER_ID ( Int32? OWNER_ID)
{
List<Question_report> oList = new List<Question_report>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_QUESTION_REPORT_BY_OWNER_ID", p);
if (R != null)
{
foreach (var oRow in R)
{
Question_report o = new Question_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Question_report> Get_Question_report_By_STUDENT_ID ( Int32? STUDENT_ID)
{
List<Question_report> oList = new List<Question_report>();
dynamic p = new ExpandoObject();
p.STUDENT_ID = STUDENT_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_QUESTION_REPORT_BY_STUDENT_ID", p);
if (R != null)
{
foreach (var oRow in R)
{
Question_report o = new Question_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Question_report> Get_Question_report_By_TEACHER_ID ( Int32? TEACHER_ID)
{
List<Question_report> oList = new List<Question_report>();
dynamic p = new ExpandoObject();
p.TEACHER_ID = TEACHER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_QUESTION_REPORT_BY_TEACHER_ID", p);
if (R != null)
{
foreach (var oRow in R)
{
Question_report o = new Question_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Question_report> Get_Question_report_By_QUESTION_ID ( Int32? QUESTION_ID)
{
List<Question_report> oList = new List<Question_report>();
dynamic p = new ExpandoObject();
p.QUESTION_ID = QUESTION_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_QUESTION_REPORT_BY_QUESTION_ID", p);
if (R != null)
{
foreach (var oRow in R)
{
Question_report o = new Question_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Question_token> Get_Question_token_By_PART ( string PART)
{
List<Question_token> oList = new List<Question_token>();
dynamic p = new ExpandoObject();
p.PART = PART;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_QUESTION_TOKEN_BY_PART", p);
if (R != null)
{
foreach (var oRow in R)
{
Question_token o = new Question_token();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Question_token> Get_Question_token_By_OWNER_ID ( Int32? OWNER_ID)
{
List<Question_token> oList = new List<Question_token>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_QUESTION_TOKEN_BY_OWNER_ID", p);
if (R != null)
{
foreach (var oRow in R)
{
Question_token o = new Question_token();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Question_token> Get_Question_token_By_QUESTION_ID ( long? QUESTION_ID)
{
List<Question_token> oList = new List<Question_token>();
dynamic p = new ExpandoObject();
p.QUESTION_ID = QUESTION_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_QUESTION_TOKEN_BY_QUESTION_ID", p);
if (R != null)
{
foreach (var oRow in R)
{
Question_token o = new Question_token();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Report_article> Get_Report_article_By_OWNER_ID ( Int32? OWNER_ID)
{
List<Report_article> oList = new List<Report_article>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_REPORT_ARTICLE_BY_OWNER_ID", p);
if (R != null)
{
foreach (var oRow in R)
{
Report_article o = new Report_article();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Report_article> Get_Report_article_By_ARTICLE_ID ( Int32? ARTICLE_ID)
{
List<Report_article> oList = new List<Report_article>();
dynamic p = new ExpandoObject();
p.ARTICLE_ID = ARTICLE_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_REPORT_ARTICLE_BY_ARTICLE_ID", p);
if (R != null)
{
foreach (var oRow in R)
{
Report_article o = new Report_article();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Report_article> Get_Report_article_By_STUDENT_ID ( Int32? STUDENT_ID)
{
List<Report_article> oList = new List<Report_article>();
dynamic p = new ExpandoObject();
p.STUDENT_ID = STUDENT_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_REPORT_ARTICLE_BY_STUDENT_ID", p);
if (R != null)
{
foreach (var oRow in R)
{
Report_article o = new Report_article();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Student> Get_Student_By_OWNER_ID ( Int32? OWNER_ID)
{
List<Student> oList = new List<Student>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_STUDENT_BY_OWNER_ID", p);
if (R != null)
{
foreach (var oRow in R)
{
Student o = new Student();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Student> Get_Student_By_USER_ID ( Int32? USER_ID)
{
List<Student> oList = new List<Student>();
dynamic p = new ExpandoObject();
p.USER_ID = USER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_STUDENT_BY_USER_ID", p);
if (R != null)
{
foreach (var oRow in R)
{
Student o = new Student();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Student_report> Get_Student_report_By_OWNER_ID ( Int32? OWNER_ID)
{
List<Student_report> oList = new List<Student_report>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_STUDENT_REPORT_BY_OWNER_ID", p);
if (R != null)
{
foreach (var oRow in R)
{
Student_report o = new Student_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Student_report> Get_Student_report_By_REPORTED_BY_STUDENT_ID ( Int32? REPORTED_BY_STUDENT_ID)
{
List<Student_report> oList = new List<Student_report>();
dynamic p = new ExpandoObject();
p.REPORTED_BY_STUDENT_ID = REPORTED_BY_STUDENT_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_STUDENT_REPORT_BY_REPORTED_BY_STUDENT_ID", p);
if (R != null)
{
foreach (var oRow in R)
{
Student_report o = new Student_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Student_report> Get_Student_report_By_REPORTED_STUDENT_ID ( Int32? REPORTED_STUDENT_ID)
{
List<Student_report> oList = new List<Student_report>();
dynamic p = new ExpandoObject();
p.REPORTED_STUDENT_ID = REPORTED_STUDENT_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_STUDENT_REPORT_BY_REPORTED_STUDENT_ID", p);
if (R != null)
{
foreach (var oRow in R)
{
Student_report o = new Student_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Teacher> Get_Teacher_By_OWNER_ID ( Int32? OWNER_ID)
{
List<Teacher> oList = new List<Teacher>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_BY_OWNER_ID", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher o = new Teacher();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Teacher> Get_Teacher_By_USER_ID ( Int32? USER_ID)
{
List<Teacher> oList = new List<Teacher>();
dynamic p = new ExpandoObject();
p.USER_ID = USER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_BY_USER_ID", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher o = new Teacher();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Teacher_category> Get_Teacher_category_By_OWNER_ID ( Int32? OWNER_ID)
{
List<Teacher_category> oList = new List<Teacher_category>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_CATEGORY_BY_OWNER_ID", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_category o = new Teacher_category();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Teacher_category> Get_Teacher_category_By_TEACHER_ID ( Int32? TEACHER_ID)
{
List<Teacher_category> oList = new List<Teacher_category>();
dynamic p = new ExpandoObject();
p.TEACHER_ID = TEACHER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_CATEGORY_BY_TEACHER_ID", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_category o = new Teacher_category();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Teacher_category> Get_Teacher_category_By_CATEGORY_ID ( Int32? CATEGORY_ID)
{
List<Teacher_category> oList = new List<Teacher_category>();
dynamic p = new ExpandoObject();
p.CATEGORY_ID = CATEGORY_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_CATEGORY_BY_CATEGORY_ID", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_category o = new Teacher_category();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Teacher_favorite> Get_Teacher_favorite_By_OWNER_ID ( Int32? OWNER_ID)
{
List<Teacher_favorite> oList = new List<Teacher_favorite>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_FAVORITE_BY_OWNER_ID", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_favorite o = new Teacher_favorite();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Teacher_favorite> Get_Teacher_favorite_By_TEACHER_ID ( Int32? TEACHER_ID)
{
List<Teacher_favorite> oList = new List<Teacher_favorite>();
dynamic p = new ExpandoObject();
p.TEACHER_ID = TEACHER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_FAVORITE_BY_TEACHER_ID", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_favorite o = new Teacher_favorite();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Teacher_favorite> Get_Teacher_favorite_By_STUDENT_ID ( Int32? STUDENT_ID)
{
List<Teacher_favorite> oList = new List<Teacher_favorite>();
dynamic p = new ExpandoObject();
p.STUDENT_ID = STUDENT_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_FAVORITE_BY_STUDENT_ID", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_favorite o = new Teacher_favorite();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Teacher_rank> Get_Teacher_rank_By_TEACHER_ID ( Int32? TEACHER_ID)
{
List<Teacher_rank> oList = new List<Teacher_rank>();
dynamic p = new ExpandoObject();
p.TEACHER_ID = TEACHER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_RANK_BY_TEACHER_ID", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_rank o = new Teacher_rank();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Teacher_rank> Get_Teacher_rank_By_OWNER_ID ( Int32? OWNER_ID)
{
List<Teacher_rank> oList = new List<Teacher_rank>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_RANK_BY_OWNER_ID", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_rank o = new Teacher_rank();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Teacher_report> Get_Teacher_report_By_OWNER_ID ( Int32? OWNER_ID)
{
List<Teacher_report> oList = new List<Teacher_report>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_REPORT_BY_OWNER_ID", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_report o = new Teacher_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Teacher_report> Get_Teacher_report_By_TEACHER_ID ( Int32? TEACHER_ID)
{
List<Teacher_report> oList = new List<Teacher_report>();
dynamic p = new ExpandoObject();
p.TEACHER_ID = TEACHER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_REPORT_BY_TEACHER_ID", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_report o = new Teacher_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Teacher_report> Get_Teacher_report_By_STUDENT_ID ( Int32? STUDENT_ID)
{
List<Teacher_report> oList = new List<Teacher_report>();
dynamic p = new ExpandoObject();
p.STUDENT_ID = STUDENT_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_REPORT_BY_STUDENT_ID", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_report o = new Teacher_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<User> Get_User_By_OWNER_ID ( Int32? OWNER_ID)
{
List<User> oList = new List<User>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_USER_BY_OWNER_ID", p);
if (R != null)
{
foreach (var oRow in R)
{
User o = new User();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<User> Get_User_By_USERNAME ( string USERNAME)
{
List<User> oList = new List<User>();
dynamic p = new ExpandoObject();
p.USERNAME = USERNAME;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_USER_BY_USERNAME", p);
if (R != null)
{
foreach (var oRow in R)
{
User o = new User();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Answer> Get_Answer_By_OWNER_ID_Adv ( Int32? OWNER_ID)
{
List<Answer> oList = new List<Answer>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_ANSWER_BY_OWNER_ID_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Answer o = new Answer();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Question = new Question();
o.My_Question.QUESTION_ID = Convert.IsDBNull(oRow["T_QUESTION_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_QUESTION_ID"]);o.My_Question.STUDENT_ID = Convert.IsDBNull(oRow["T_QUESTION_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_STUDENT_ID"]);o.My_Question.CATEGORY_ID = Convert.IsDBNull(oRow["T_QUESTION_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_CATEGORY_ID"]);o.My_Question.TEACHER_ID = Convert.IsDBNull(oRow["T_QUESTION_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_TEACHER_ID"]);o.My_Question.DESCRIPTION = Convert.IsDBNull(oRow["T_QUESTION_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_QUESTION_DESCRIPTION"]);o.My_Question.IS_ANSWERED = Convert.IsDBNull(oRow["T_QUESTION_IS_ANSWERED"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ANSWERED"]);o.My_Question.IS_ACTIVE = Convert.IsDBNull(oRow["T_QUESTION_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ACTIVE"]);o.My_Question.REPORTS = Convert.IsDBNull(oRow["T_QUESTION_REPORTS"]) ? default : Convert.ToInt32(oRow["T_QUESTION_REPORTS"]);o.My_Question.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_QUESTION_ENTRY_USER_ID"]);o.My_Question.ENTRY_DATE = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_QUESTION_ENTRY_DATE"]);o.My_Question.OWNER_ID = Convert.IsDBNull(oRow["T_QUESTION_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_OWNER_ID"]);
o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Answer> Get_Answer_By_QUESTION_ID_Adv ( Int32? QUESTION_ID)
{
List<Answer> oList = new List<Answer>();
dynamic p = new ExpandoObject();
p.QUESTION_ID = QUESTION_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_ANSWER_BY_QUESTION_ID_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Answer o = new Answer();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Question = new Question();
o.My_Question.QUESTION_ID = Convert.IsDBNull(oRow["T_QUESTION_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_QUESTION_ID"]);o.My_Question.STUDENT_ID = Convert.IsDBNull(oRow["T_QUESTION_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_STUDENT_ID"]);o.My_Question.CATEGORY_ID = Convert.IsDBNull(oRow["T_QUESTION_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_CATEGORY_ID"]);o.My_Question.TEACHER_ID = Convert.IsDBNull(oRow["T_QUESTION_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_TEACHER_ID"]);o.My_Question.DESCRIPTION = Convert.IsDBNull(oRow["T_QUESTION_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_QUESTION_DESCRIPTION"]);o.My_Question.IS_ANSWERED = Convert.IsDBNull(oRow["T_QUESTION_IS_ANSWERED"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ANSWERED"]);o.My_Question.IS_ACTIVE = Convert.IsDBNull(oRow["T_QUESTION_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ACTIVE"]);o.My_Question.REPORTS = Convert.IsDBNull(oRow["T_QUESTION_REPORTS"]) ? default : Convert.ToInt32(oRow["T_QUESTION_REPORTS"]);o.My_Question.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_QUESTION_ENTRY_USER_ID"]);o.My_Question.ENTRY_DATE = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_QUESTION_ENTRY_DATE"]);o.My_Question.OWNER_ID = Convert.IsDBNull(oRow["T_QUESTION_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_OWNER_ID"]);
o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Answer> Get_Answer_By_TEACHER_ID_Adv ( Int32? TEACHER_ID)
{
List<Answer> oList = new List<Answer>();
dynamic p = new ExpandoObject();
p.TEACHER_ID = TEACHER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_ANSWER_BY_TEACHER_ID_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Answer o = new Answer();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Question = new Question();
o.My_Question.QUESTION_ID = Convert.IsDBNull(oRow["T_QUESTION_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_QUESTION_ID"]);o.My_Question.STUDENT_ID = Convert.IsDBNull(oRow["T_QUESTION_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_STUDENT_ID"]);o.My_Question.CATEGORY_ID = Convert.IsDBNull(oRow["T_QUESTION_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_CATEGORY_ID"]);o.My_Question.TEACHER_ID = Convert.IsDBNull(oRow["T_QUESTION_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_TEACHER_ID"]);o.My_Question.DESCRIPTION = Convert.IsDBNull(oRow["T_QUESTION_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_QUESTION_DESCRIPTION"]);o.My_Question.IS_ANSWERED = Convert.IsDBNull(oRow["T_QUESTION_IS_ANSWERED"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ANSWERED"]);o.My_Question.IS_ACTIVE = Convert.IsDBNull(oRow["T_QUESTION_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ACTIVE"]);o.My_Question.REPORTS = Convert.IsDBNull(oRow["T_QUESTION_REPORTS"]) ? default : Convert.ToInt32(oRow["T_QUESTION_REPORTS"]);o.My_Question.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_QUESTION_ENTRY_USER_ID"]);o.My_Question.ENTRY_DATE = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_QUESTION_ENTRY_DATE"]);o.My_Question.OWNER_ID = Convert.IsDBNull(oRow["T_QUESTION_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_OWNER_ID"]);
o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Answer_report> Get_Answer_report_By_OWNER_ID_Adv ( Int32? OWNER_ID)
{
List<Answer_report> oList = new List<Answer_report>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_ANSWER_REPORT_BY_OWNER_ID_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Answer_report o = new Answer_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
o.My_Answer = new Answer();
o.My_Answer.ANSWER_ID = Convert.IsDBNull(oRow["T_ANSWER_ANSWER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_ANSWER_ID"]);o.My_Answer.QUESTION_ID = Convert.IsDBNull(oRow["T_ANSWER_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_QUESTION_ID"]);o.My_Answer.TEACHER_ID = Convert.IsDBNull(oRow["T_ANSWER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_TEACHER_ID"]);o.My_Answer.DESCRIPTION = Convert.IsDBNull(oRow["T_ANSWER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_ANSWER_DESCRIPTION"]);o.My_Answer.SCORE = Convert.IsDBNull(oRow["T_ANSWER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_ANSWER_SCORE"]);o.My_Answer.REVIEWS = Convert.IsDBNull(oRow["T_ANSWER_REVIEWS"]) ? default : Convert.ToInt32(oRow["T_ANSWER_REVIEWS"]);o.My_Answer.REPORTS = Convert.IsDBNull(oRow["T_ANSWER_REPORTS"]) ? default : Convert.ToInt32(oRow["T_ANSWER_REPORTS"]);o.My_Answer.IS_ACTIVE = Convert.IsDBNull(oRow["T_ANSWER_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_ANSWER_IS_ACTIVE"]);o.My_Answer.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_ANSWER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_ANSWER_ENTRY_USER_ID"]);o.My_Answer.ENTRY_DATE = Convert.IsDBNull(oRow["T_ANSWER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_ANSWER_ENTRY_DATE"]);o.My_Answer.OWNER_ID = Convert.IsDBNull(oRow["T_ANSWER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Answer_report> Get_Answer_report_By_TEACHER_ID_Adv ( Int32? TEACHER_ID)
{
List<Answer_report> oList = new List<Answer_report>();
dynamic p = new ExpandoObject();
p.TEACHER_ID = TEACHER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_ANSWER_REPORT_BY_TEACHER_ID_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Answer_report o = new Answer_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
o.My_Answer = new Answer();
o.My_Answer.ANSWER_ID = Convert.IsDBNull(oRow["T_ANSWER_ANSWER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_ANSWER_ID"]);o.My_Answer.QUESTION_ID = Convert.IsDBNull(oRow["T_ANSWER_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_QUESTION_ID"]);o.My_Answer.TEACHER_ID = Convert.IsDBNull(oRow["T_ANSWER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_TEACHER_ID"]);o.My_Answer.DESCRIPTION = Convert.IsDBNull(oRow["T_ANSWER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_ANSWER_DESCRIPTION"]);o.My_Answer.SCORE = Convert.IsDBNull(oRow["T_ANSWER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_ANSWER_SCORE"]);o.My_Answer.REVIEWS = Convert.IsDBNull(oRow["T_ANSWER_REVIEWS"]) ? default : Convert.ToInt32(oRow["T_ANSWER_REVIEWS"]);o.My_Answer.REPORTS = Convert.IsDBNull(oRow["T_ANSWER_REPORTS"]) ? default : Convert.ToInt32(oRow["T_ANSWER_REPORTS"]);o.My_Answer.IS_ACTIVE = Convert.IsDBNull(oRow["T_ANSWER_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_ANSWER_IS_ACTIVE"]);o.My_Answer.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_ANSWER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_ANSWER_ENTRY_USER_ID"]);o.My_Answer.ENTRY_DATE = Convert.IsDBNull(oRow["T_ANSWER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_ANSWER_ENTRY_DATE"]);o.My_Answer.OWNER_ID = Convert.IsDBNull(oRow["T_ANSWER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Answer_report> Get_Answer_report_By_STUDENT_ID_Adv ( Int32? STUDENT_ID)
{
List<Answer_report> oList = new List<Answer_report>();
dynamic p = new ExpandoObject();
p.STUDENT_ID = STUDENT_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_ANSWER_REPORT_BY_STUDENT_ID_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Answer_report o = new Answer_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
o.My_Answer = new Answer();
o.My_Answer.ANSWER_ID = Convert.IsDBNull(oRow["T_ANSWER_ANSWER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_ANSWER_ID"]);o.My_Answer.QUESTION_ID = Convert.IsDBNull(oRow["T_ANSWER_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_QUESTION_ID"]);o.My_Answer.TEACHER_ID = Convert.IsDBNull(oRow["T_ANSWER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_TEACHER_ID"]);o.My_Answer.DESCRIPTION = Convert.IsDBNull(oRow["T_ANSWER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_ANSWER_DESCRIPTION"]);o.My_Answer.SCORE = Convert.IsDBNull(oRow["T_ANSWER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_ANSWER_SCORE"]);o.My_Answer.REVIEWS = Convert.IsDBNull(oRow["T_ANSWER_REVIEWS"]) ? default : Convert.ToInt32(oRow["T_ANSWER_REVIEWS"]);o.My_Answer.REPORTS = Convert.IsDBNull(oRow["T_ANSWER_REPORTS"]) ? default : Convert.ToInt32(oRow["T_ANSWER_REPORTS"]);o.My_Answer.IS_ACTIVE = Convert.IsDBNull(oRow["T_ANSWER_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_ANSWER_IS_ACTIVE"]);o.My_Answer.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_ANSWER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_ANSWER_ENTRY_USER_ID"]);o.My_Answer.ENTRY_DATE = Convert.IsDBNull(oRow["T_ANSWER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_ANSWER_ENTRY_DATE"]);o.My_Answer.OWNER_ID = Convert.IsDBNull(oRow["T_ANSWER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Answer_report> Get_Answer_report_By_ANSWER_ID_Adv ( Int32? ANSWER_ID)
{
List<Answer_report> oList = new List<Answer_report>();
dynamic p = new ExpandoObject();
p.ANSWER_ID = ANSWER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_ANSWER_REPORT_BY_ANSWER_ID_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Answer_report o = new Answer_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
o.My_Answer = new Answer();
o.My_Answer.ANSWER_ID = Convert.IsDBNull(oRow["T_ANSWER_ANSWER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_ANSWER_ID"]);o.My_Answer.QUESTION_ID = Convert.IsDBNull(oRow["T_ANSWER_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_QUESTION_ID"]);o.My_Answer.TEACHER_ID = Convert.IsDBNull(oRow["T_ANSWER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_TEACHER_ID"]);o.My_Answer.DESCRIPTION = Convert.IsDBNull(oRow["T_ANSWER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_ANSWER_DESCRIPTION"]);o.My_Answer.SCORE = Convert.IsDBNull(oRow["T_ANSWER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_ANSWER_SCORE"]);o.My_Answer.REVIEWS = Convert.IsDBNull(oRow["T_ANSWER_REVIEWS"]) ? default : Convert.ToInt32(oRow["T_ANSWER_REVIEWS"]);o.My_Answer.REPORTS = Convert.IsDBNull(oRow["T_ANSWER_REPORTS"]) ? default : Convert.ToInt32(oRow["T_ANSWER_REPORTS"]);o.My_Answer.IS_ACTIVE = Convert.IsDBNull(oRow["T_ANSWER_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_ANSWER_IS_ACTIVE"]);o.My_Answer.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_ANSWER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_ANSWER_ENTRY_USER_ID"]);o.My_Answer.ENTRY_DATE = Convert.IsDBNull(oRow["T_ANSWER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_ANSWER_ENTRY_DATE"]);o.My_Answer.OWNER_ID = Convert.IsDBNull(oRow["T_ANSWER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Appreciate> Get_Appreciate_By_OWNER_ID_Adv ( Int32? OWNER_ID)
{
List<Appreciate> oList = new List<Appreciate>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_APPRECIATE_BY_OWNER_ID_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Appreciate o = new Appreciate();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Article = new Article();
o.My_Article.ARTICLE_ID = Convert.IsDBNull(oRow["T_ARTICLE_ARTICLE_ID"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_ARTICLE_ID"]);o.My_Article.TEACHER_ID = Convert.IsDBNull(oRow["T_ARTICLE_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_TEACHER_ID"]);o.My_Article.CATEGORY_ID = Convert.IsDBNull(oRow["T_ARTICLE_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_CATEGORY_ID"]);o.My_Article.TITLE = Convert.IsDBNull(oRow["T_ARTICLE_TITLE"]) ? default : Convert.ToString(oRow["T_ARTICLE_TITLE"]);o.My_Article.DESCRIPTION = Convert.IsDBNull(oRow["T_ARTICLE_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_ARTICLE_DESCRIPTION"]);o.My_Article.APPLAUDS = Convert.IsDBNull(oRow["T_ARTICLE_APPLAUDS"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_APPLAUDS"]);o.My_Article.REPORTS = Convert.IsDBNull(oRow["T_ARTICLE_REPORTS"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_REPORTS"]);o.My_Article.IS_BLOCKED = Convert.IsDBNull(oRow["T_ARTICLE_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_ARTICLE_IS_BLOCKED"]);o.My_Article.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_ARTICLE_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_ARTICLE_ENTRY_USER_ID"]);o.My_Article.ENTRY_DATE = Convert.IsDBNull(oRow["T_ARTICLE_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_ARTICLE_ENTRY_DATE"]);o.My_Article.OWNER_ID = Convert.IsDBNull(oRow["T_ARTICLE_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Appreciate> Get_Appreciate_By_ARTICLE_ID_Adv ( Int32? ARTICLE_ID)
{
List<Appreciate> oList = new List<Appreciate>();
dynamic p = new ExpandoObject();
p.ARTICLE_ID = ARTICLE_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_APPRECIATE_BY_ARTICLE_ID_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Appreciate o = new Appreciate();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Article = new Article();
o.My_Article.ARTICLE_ID = Convert.IsDBNull(oRow["T_ARTICLE_ARTICLE_ID"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_ARTICLE_ID"]);o.My_Article.TEACHER_ID = Convert.IsDBNull(oRow["T_ARTICLE_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_TEACHER_ID"]);o.My_Article.CATEGORY_ID = Convert.IsDBNull(oRow["T_ARTICLE_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_CATEGORY_ID"]);o.My_Article.TITLE = Convert.IsDBNull(oRow["T_ARTICLE_TITLE"]) ? default : Convert.ToString(oRow["T_ARTICLE_TITLE"]);o.My_Article.DESCRIPTION = Convert.IsDBNull(oRow["T_ARTICLE_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_ARTICLE_DESCRIPTION"]);o.My_Article.APPLAUDS = Convert.IsDBNull(oRow["T_ARTICLE_APPLAUDS"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_APPLAUDS"]);o.My_Article.REPORTS = Convert.IsDBNull(oRow["T_ARTICLE_REPORTS"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_REPORTS"]);o.My_Article.IS_BLOCKED = Convert.IsDBNull(oRow["T_ARTICLE_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_ARTICLE_IS_BLOCKED"]);o.My_Article.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_ARTICLE_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_ARTICLE_ENTRY_USER_ID"]);o.My_Article.ENTRY_DATE = Convert.IsDBNull(oRow["T_ARTICLE_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_ARTICLE_ENTRY_DATE"]);o.My_Article.OWNER_ID = Convert.IsDBNull(oRow["T_ARTICLE_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Appreciate> Get_Appreciate_By_STUDENT_ID_Adv ( Int32? STUDENT_ID)
{
List<Appreciate> oList = new List<Appreciate>();
dynamic p = new ExpandoObject();
p.STUDENT_ID = STUDENT_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_APPRECIATE_BY_STUDENT_ID_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Appreciate o = new Appreciate();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Article = new Article();
o.My_Article.ARTICLE_ID = Convert.IsDBNull(oRow["T_ARTICLE_ARTICLE_ID"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_ARTICLE_ID"]);o.My_Article.TEACHER_ID = Convert.IsDBNull(oRow["T_ARTICLE_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_TEACHER_ID"]);o.My_Article.CATEGORY_ID = Convert.IsDBNull(oRow["T_ARTICLE_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_CATEGORY_ID"]);o.My_Article.TITLE = Convert.IsDBNull(oRow["T_ARTICLE_TITLE"]) ? default : Convert.ToString(oRow["T_ARTICLE_TITLE"]);o.My_Article.DESCRIPTION = Convert.IsDBNull(oRow["T_ARTICLE_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_ARTICLE_DESCRIPTION"]);o.My_Article.APPLAUDS = Convert.IsDBNull(oRow["T_ARTICLE_APPLAUDS"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_APPLAUDS"]);o.My_Article.REPORTS = Convert.IsDBNull(oRow["T_ARTICLE_REPORTS"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_REPORTS"]);o.My_Article.IS_BLOCKED = Convert.IsDBNull(oRow["T_ARTICLE_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_ARTICLE_IS_BLOCKED"]);o.My_Article.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_ARTICLE_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_ARTICLE_ENTRY_USER_ID"]);o.My_Article.ENTRY_DATE = Convert.IsDBNull(oRow["T_ARTICLE_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_ARTICLE_ENTRY_DATE"]);o.My_Article.OWNER_ID = Convert.IsDBNull(oRow["T_ARTICLE_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Article> Get_Article_By_OWNER_ID_Adv ( Int32? OWNER_ID)
{
List<Article> oList = new List<Article>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_ARTICLE_BY_OWNER_ID_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Article o = new Article();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Category = new Category();
o.My_Category.CATEGORY_ID = Convert.IsDBNull(oRow["T_CATEGORY_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_CATEGORY_ID"]);o.My_Category.NAME = Convert.IsDBNull(oRow["T_CATEGORY_NAME"]) ? default : Convert.ToString(oRow["T_CATEGORY_NAME"]);o.My_Category.DECRIPTION = Convert.IsDBNull(oRow["T_CATEGORY_DECRIPTION"]) ? default : Convert.ToString(oRow["T_CATEGORY_DECRIPTION"]);o.My_Category.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_CATEGORY_ENTRY_USER_ID"]);o.My_Category.ENTRY_DATE = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_CATEGORY_ENTRY_DATE"]);o.My_Category.OWNER_ID = Convert.IsDBNull(oRow["T_CATEGORY_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Article> Get_Article_By_TEACHER_ID_Adv ( Int32? TEACHER_ID)
{
List<Article> oList = new List<Article>();
dynamic p = new ExpandoObject();
p.TEACHER_ID = TEACHER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_ARTICLE_BY_TEACHER_ID_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Article o = new Article();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Category = new Category();
o.My_Category.CATEGORY_ID = Convert.IsDBNull(oRow["T_CATEGORY_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_CATEGORY_ID"]);o.My_Category.NAME = Convert.IsDBNull(oRow["T_CATEGORY_NAME"]) ? default : Convert.ToString(oRow["T_CATEGORY_NAME"]);o.My_Category.DECRIPTION = Convert.IsDBNull(oRow["T_CATEGORY_DECRIPTION"]) ? default : Convert.ToString(oRow["T_CATEGORY_DECRIPTION"]);o.My_Category.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_CATEGORY_ENTRY_USER_ID"]);o.My_Category.ENTRY_DATE = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_CATEGORY_ENTRY_DATE"]);o.My_Category.OWNER_ID = Convert.IsDBNull(oRow["T_CATEGORY_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Article> Get_Article_By_CATEGORY_ID_Adv ( Int32? CATEGORY_ID)
{
List<Article> oList = new List<Article>();
dynamic p = new ExpandoObject();
p.CATEGORY_ID = CATEGORY_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_ARTICLE_BY_CATEGORY_ID_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Article o = new Article();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Category = new Category();
o.My_Category.CATEGORY_ID = Convert.IsDBNull(oRow["T_CATEGORY_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_CATEGORY_ID"]);o.My_Category.NAME = Convert.IsDBNull(oRow["T_CATEGORY_NAME"]) ? default : Convert.ToString(oRow["T_CATEGORY_NAME"]);o.My_Category.DECRIPTION = Convert.IsDBNull(oRow["T_CATEGORY_DECRIPTION"]) ? default : Convert.ToString(oRow["T_CATEGORY_DECRIPTION"]);o.My_Category.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_CATEGORY_ENTRY_USER_ID"]);o.My_Category.ENTRY_DATE = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_CATEGORY_ENTRY_DATE"]);o.My_Category.OWNER_ID = Convert.IsDBNull(oRow["T_CATEGORY_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Category> Get_Category_By_OWNER_ID_Adv ( Int32? OWNER_ID)
{
List<Category> oList = new List<Category>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_CATEGORY_BY_OWNER_ID_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Category o = new Category();
oTools.CopyPropValues_FromDataRecord(oRow, o);

oList.Add(o);
}
}
return oList;
}
public List<Evaluation> Get_Evaluation_By_OWNER_ID_Adv ( Int32? OWNER_ID)
{
List<Evaluation> oList = new List<Evaluation>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_EVALUATION_BY_OWNER_ID_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Evaluation o = new Evaluation();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
o.My_Answer = new Answer();
o.My_Answer.ANSWER_ID = Convert.IsDBNull(oRow["T_ANSWER_ANSWER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_ANSWER_ID"]);o.My_Answer.QUESTION_ID = Convert.IsDBNull(oRow["T_ANSWER_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_QUESTION_ID"]);o.My_Answer.TEACHER_ID = Convert.IsDBNull(oRow["T_ANSWER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_TEACHER_ID"]);o.My_Answer.DESCRIPTION = Convert.IsDBNull(oRow["T_ANSWER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_ANSWER_DESCRIPTION"]);o.My_Answer.SCORE = Convert.IsDBNull(oRow["T_ANSWER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_ANSWER_SCORE"]);o.My_Answer.REVIEWS = Convert.IsDBNull(oRow["T_ANSWER_REVIEWS"]) ? default : Convert.ToInt32(oRow["T_ANSWER_REVIEWS"]);o.My_Answer.REPORTS = Convert.IsDBNull(oRow["T_ANSWER_REPORTS"]) ? default : Convert.ToInt32(oRow["T_ANSWER_REPORTS"]);o.My_Answer.IS_ACTIVE = Convert.IsDBNull(oRow["T_ANSWER_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_ANSWER_IS_ACTIVE"]);o.My_Answer.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_ANSWER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_ANSWER_ENTRY_USER_ID"]);o.My_Answer.ENTRY_DATE = Convert.IsDBNull(oRow["T_ANSWER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_ANSWER_ENTRY_DATE"]);o.My_Answer.OWNER_ID = Convert.IsDBNull(oRow["T_ANSWER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Evaluation> Get_Evaluation_By_STUDENT_ID_Adv ( Int32? STUDENT_ID)
{
List<Evaluation> oList = new List<Evaluation>();
dynamic p = new ExpandoObject();
p.STUDENT_ID = STUDENT_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_EVALUATION_BY_STUDENT_ID_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Evaluation o = new Evaluation();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
o.My_Answer = new Answer();
o.My_Answer.ANSWER_ID = Convert.IsDBNull(oRow["T_ANSWER_ANSWER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_ANSWER_ID"]);o.My_Answer.QUESTION_ID = Convert.IsDBNull(oRow["T_ANSWER_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_QUESTION_ID"]);o.My_Answer.TEACHER_ID = Convert.IsDBNull(oRow["T_ANSWER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_TEACHER_ID"]);o.My_Answer.DESCRIPTION = Convert.IsDBNull(oRow["T_ANSWER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_ANSWER_DESCRIPTION"]);o.My_Answer.SCORE = Convert.IsDBNull(oRow["T_ANSWER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_ANSWER_SCORE"]);o.My_Answer.REVIEWS = Convert.IsDBNull(oRow["T_ANSWER_REVIEWS"]) ? default : Convert.ToInt32(oRow["T_ANSWER_REVIEWS"]);o.My_Answer.REPORTS = Convert.IsDBNull(oRow["T_ANSWER_REPORTS"]) ? default : Convert.ToInt32(oRow["T_ANSWER_REPORTS"]);o.My_Answer.IS_ACTIVE = Convert.IsDBNull(oRow["T_ANSWER_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_ANSWER_IS_ACTIVE"]);o.My_Answer.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_ANSWER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_ANSWER_ENTRY_USER_ID"]);o.My_Answer.ENTRY_DATE = Convert.IsDBNull(oRow["T_ANSWER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_ANSWER_ENTRY_DATE"]);o.My_Answer.OWNER_ID = Convert.IsDBNull(oRow["T_ANSWER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Evaluation> Get_Evaluation_By_ANSWER_ID_Adv ( Int32? ANSWER_ID)
{
List<Evaluation> oList = new List<Evaluation>();
dynamic p = new ExpandoObject();
p.ANSWER_ID = ANSWER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_EVALUATION_BY_ANSWER_ID_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Evaluation o = new Evaluation();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
o.My_Answer = new Answer();
o.My_Answer.ANSWER_ID = Convert.IsDBNull(oRow["T_ANSWER_ANSWER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_ANSWER_ID"]);o.My_Answer.QUESTION_ID = Convert.IsDBNull(oRow["T_ANSWER_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_QUESTION_ID"]);o.My_Answer.TEACHER_ID = Convert.IsDBNull(oRow["T_ANSWER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_TEACHER_ID"]);o.My_Answer.DESCRIPTION = Convert.IsDBNull(oRow["T_ANSWER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_ANSWER_DESCRIPTION"]);o.My_Answer.SCORE = Convert.IsDBNull(oRow["T_ANSWER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_ANSWER_SCORE"]);o.My_Answer.REVIEWS = Convert.IsDBNull(oRow["T_ANSWER_REVIEWS"]) ? default : Convert.ToInt32(oRow["T_ANSWER_REVIEWS"]);o.My_Answer.REPORTS = Convert.IsDBNull(oRow["T_ANSWER_REPORTS"]) ? default : Convert.ToInt32(oRow["T_ANSWER_REPORTS"]);o.My_Answer.IS_ACTIVE = Convert.IsDBNull(oRow["T_ANSWER_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_ANSWER_IS_ACTIVE"]);o.My_Answer.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_ANSWER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_ANSWER_ENTRY_USER_ID"]);o.My_Answer.ENTRY_DATE = Convert.IsDBNull(oRow["T_ANSWER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_ANSWER_ENTRY_DATE"]);o.My_Answer.OWNER_ID = Convert.IsDBNull(oRow["T_ANSWER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Favorite_category> Get_Favorite_category_By_STUDENT_ID_Adv ( Int32? STUDENT_ID)
{
List<Favorite_category> oList = new List<Favorite_category>();
dynamic p = new ExpandoObject();
p.STUDENT_ID = STUDENT_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_FAVORITE_CATEGORY_BY_STUDENT_ID_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Favorite_category o = new Favorite_category();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
o.My_Category = new Category();
o.My_Category.CATEGORY_ID = Convert.IsDBNull(oRow["T_CATEGORY_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_CATEGORY_ID"]);o.My_Category.NAME = Convert.IsDBNull(oRow["T_CATEGORY_NAME"]) ? default : Convert.ToString(oRow["T_CATEGORY_NAME"]);o.My_Category.DECRIPTION = Convert.IsDBNull(oRow["T_CATEGORY_DECRIPTION"]) ? default : Convert.ToString(oRow["T_CATEGORY_DECRIPTION"]);o.My_Category.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_CATEGORY_ENTRY_USER_ID"]);o.My_Category.ENTRY_DATE = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_CATEGORY_ENTRY_DATE"]);o.My_Category.OWNER_ID = Convert.IsDBNull(oRow["T_CATEGORY_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Favorite_category> Get_Favorite_category_By_CATEGORY_ID_Adv ( Int32? CATEGORY_ID)
{
List<Favorite_category> oList = new List<Favorite_category>();
dynamic p = new ExpandoObject();
p.CATEGORY_ID = CATEGORY_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_FAVORITE_CATEGORY_BY_CATEGORY_ID_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Favorite_category o = new Favorite_category();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
o.My_Category = new Category();
o.My_Category.CATEGORY_ID = Convert.IsDBNull(oRow["T_CATEGORY_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_CATEGORY_ID"]);o.My_Category.NAME = Convert.IsDBNull(oRow["T_CATEGORY_NAME"]) ? default : Convert.ToString(oRow["T_CATEGORY_NAME"]);o.My_Category.DECRIPTION = Convert.IsDBNull(oRow["T_CATEGORY_DECRIPTION"]) ? default : Convert.ToString(oRow["T_CATEGORY_DECRIPTION"]);o.My_Category.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_CATEGORY_ENTRY_USER_ID"]);o.My_Category.ENTRY_DATE = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_CATEGORY_ENTRY_DATE"]);o.My_Category.OWNER_ID = Convert.IsDBNull(oRow["T_CATEGORY_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Favorite_category> Get_Favorite_category_By_OWNER_ID_Adv ( Int32? OWNER_ID)
{
List<Favorite_category> oList = new List<Favorite_category>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_FAVORITE_CATEGORY_BY_OWNER_ID_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Favorite_category o = new Favorite_category();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
o.My_Category = new Category();
o.My_Category.CATEGORY_ID = Convert.IsDBNull(oRow["T_CATEGORY_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_CATEGORY_ID"]);o.My_Category.NAME = Convert.IsDBNull(oRow["T_CATEGORY_NAME"]) ? default : Convert.ToString(oRow["T_CATEGORY_NAME"]);o.My_Category.DECRIPTION = Convert.IsDBNull(oRow["T_CATEGORY_DECRIPTION"]) ? default : Convert.ToString(oRow["T_CATEGORY_DECRIPTION"]);o.My_Category.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_CATEGORY_ENTRY_USER_ID"]);o.My_Category.ENTRY_DATE = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_CATEGORY_ENTRY_DATE"]);o.My_Category.OWNER_ID = Convert.IsDBNull(oRow["T_CATEGORY_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Favorite_teacher> Get_Favorite_teacher_By_TEACHER_ID_Adv ( Int32? TEACHER_ID)
{
List<Favorite_teacher> oList = new List<Favorite_teacher>();
dynamic p = new ExpandoObject();
p.TEACHER_ID = TEACHER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_FAVORITE_TEACHER_BY_TEACHER_ID_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Favorite_teacher o = new Favorite_teacher();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Favorite_teacher> Get_Favorite_teacher_By_STUDENT_ID_Adv ( Int32? STUDENT_ID)
{
List<Favorite_teacher> oList = new List<Favorite_teacher>();
dynamic p = new ExpandoObject();
p.STUDENT_ID = STUDENT_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_FAVORITE_TEACHER_BY_STUDENT_ID_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Favorite_teacher o = new Favorite_teacher();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Favorite_teacher> Get_Favorite_teacher_By_OWNER_ID_Adv ( Int32? OWNER_ID)
{
List<Favorite_teacher> oList = new List<Favorite_teacher>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_FAVORITE_TEACHER_BY_OWNER_ID_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Favorite_teacher o = new Favorite_teacher();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Mark_question> Get_Mark_question_By_OWNER_ID_Adv ( Int32? OWNER_ID)
{
List<Mark_question> oList = new List<Mark_question>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_MARK_QUESTION_BY_OWNER_ID_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Mark_question o = new Mark_question();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Question = new Question();
o.My_Question.QUESTION_ID = Convert.IsDBNull(oRow["T_QUESTION_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_QUESTION_ID"]);o.My_Question.STUDENT_ID = Convert.IsDBNull(oRow["T_QUESTION_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_STUDENT_ID"]);o.My_Question.CATEGORY_ID = Convert.IsDBNull(oRow["T_QUESTION_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_CATEGORY_ID"]);o.My_Question.TEACHER_ID = Convert.IsDBNull(oRow["T_QUESTION_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_TEACHER_ID"]);o.My_Question.DESCRIPTION = Convert.IsDBNull(oRow["T_QUESTION_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_QUESTION_DESCRIPTION"]);o.My_Question.IS_ANSWERED = Convert.IsDBNull(oRow["T_QUESTION_IS_ANSWERED"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ANSWERED"]);o.My_Question.IS_ACTIVE = Convert.IsDBNull(oRow["T_QUESTION_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ACTIVE"]);o.My_Question.REPORTS = Convert.IsDBNull(oRow["T_QUESTION_REPORTS"]) ? default : Convert.ToInt32(oRow["T_QUESTION_REPORTS"]);o.My_Question.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_QUESTION_ENTRY_USER_ID"]);o.My_Question.ENTRY_DATE = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_QUESTION_ENTRY_DATE"]);o.My_Question.OWNER_ID = Convert.IsDBNull(oRow["T_QUESTION_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Mark_question> Get_Mark_question_By_QUESTION_ID_Adv ( Int32? QUESTION_ID)
{
List<Mark_question> oList = new List<Mark_question>();
dynamic p = new ExpandoObject();
p.QUESTION_ID = QUESTION_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_MARK_QUESTION_BY_QUESTION_ID_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Mark_question o = new Mark_question();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Question = new Question();
o.My_Question.QUESTION_ID = Convert.IsDBNull(oRow["T_QUESTION_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_QUESTION_ID"]);o.My_Question.STUDENT_ID = Convert.IsDBNull(oRow["T_QUESTION_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_STUDENT_ID"]);o.My_Question.CATEGORY_ID = Convert.IsDBNull(oRow["T_QUESTION_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_CATEGORY_ID"]);o.My_Question.TEACHER_ID = Convert.IsDBNull(oRow["T_QUESTION_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_TEACHER_ID"]);o.My_Question.DESCRIPTION = Convert.IsDBNull(oRow["T_QUESTION_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_QUESTION_DESCRIPTION"]);o.My_Question.IS_ANSWERED = Convert.IsDBNull(oRow["T_QUESTION_IS_ANSWERED"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ANSWERED"]);o.My_Question.IS_ACTIVE = Convert.IsDBNull(oRow["T_QUESTION_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ACTIVE"]);o.My_Question.REPORTS = Convert.IsDBNull(oRow["T_QUESTION_REPORTS"]) ? default : Convert.ToInt32(oRow["T_QUESTION_REPORTS"]);o.My_Question.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_QUESTION_ENTRY_USER_ID"]);o.My_Question.ENTRY_DATE = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_QUESTION_ENTRY_DATE"]);o.My_Question.OWNER_ID = Convert.IsDBNull(oRow["T_QUESTION_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Mark_question> Get_Mark_question_By_STUDENT_ID_Adv ( Int32? STUDENT_ID)
{
List<Mark_question> oList = new List<Mark_question>();
dynamic p = new ExpandoObject();
p.STUDENT_ID = STUDENT_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_MARK_QUESTION_BY_STUDENT_ID_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Mark_question o = new Mark_question();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Question = new Question();
o.My_Question.QUESTION_ID = Convert.IsDBNull(oRow["T_QUESTION_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_QUESTION_ID"]);o.My_Question.STUDENT_ID = Convert.IsDBNull(oRow["T_QUESTION_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_STUDENT_ID"]);o.My_Question.CATEGORY_ID = Convert.IsDBNull(oRow["T_QUESTION_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_CATEGORY_ID"]);o.My_Question.TEACHER_ID = Convert.IsDBNull(oRow["T_QUESTION_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_TEACHER_ID"]);o.My_Question.DESCRIPTION = Convert.IsDBNull(oRow["T_QUESTION_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_QUESTION_DESCRIPTION"]);o.My_Question.IS_ANSWERED = Convert.IsDBNull(oRow["T_QUESTION_IS_ANSWERED"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ANSWERED"]);o.My_Question.IS_ACTIVE = Convert.IsDBNull(oRow["T_QUESTION_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ACTIVE"]);o.My_Question.REPORTS = Convert.IsDBNull(oRow["T_QUESTION_REPORTS"]) ? default : Convert.ToInt32(oRow["T_QUESTION_REPORTS"]);o.My_Question.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_QUESTION_ENTRY_USER_ID"]);o.My_Question.ENTRY_DATE = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_QUESTION_ENTRY_DATE"]);o.My_Question.OWNER_ID = Convert.IsDBNull(oRow["T_QUESTION_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Notification> Get_Notification_By_OWNER_ID_Adv ( Int32? OWNER_ID)
{
List<Notification> oList = new List<Notification>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_NOTIFICATION_BY_OWNER_ID_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Notification o = new Notification();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_User = new User();
o.My_User.USER_ID = Convert.IsDBNull(oRow["T_USER_USER_ID"]) ? default : Convert.ToInt64(oRow["T_USER_USER_ID"]);o.My_User.OWNER_ID = Convert.IsDBNull(oRow["T_USER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_USER_OWNER_ID"]);o.My_User.USERNAME = Convert.IsDBNull(oRow["T_USER_USERNAME"]) ? default : Convert.ToString(oRow["T_USER_USERNAME"]);o.My_User.PASSWORD = Convert.IsDBNull(oRow["T_USER_PASSWORD"]) ? default : Convert.ToString(oRow["T_USER_PASSWORD"]);o.My_User.USER_TYPE_CODE = Convert.IsDBNull(oRow["T_USER_USER_TYPE_CODE"]) ? default : Convert.ToString(oRow["T_USER_USER_TYPE_CODE"]);o.My_User.IS_LOGGED_IN = Convert.IsDBNull(oRow["T_USER_IS_LOGGED_IN"]) ? default : Convert.ToBoolean(oRow["T_USER_IS_LOGGED_IN"]);o.My_User.IS_ACTIVE = Convert.IsDBNull(oRow["T_USER_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_USER_IS_ACTIVE"]);o.My_User.ENTRY_DATE = Convert.IsDBNull(oRow["T_USER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_USER_ENTRY_DATE"]);
o.My_Question = new Question();
o.My_Question.QUESTION_ID = Convert.IsDBNull(oRow["T_QUESTION_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_QUESTION_ID"]);o.My_Question.STUDENT_ID = Convert.IsDBNull(oRow["T_QUESTION_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_STUDENT_ID"]);o.My_Question.CATEGORY_ID = Convert.IsDBNull(oRow["T_QUESTION_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_CATEGORY_ID"]);o.My_Question.TEACHER_ID = Convert.IsDBNull(oRow["T_QUESTION_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_TEACHER_ID"]);o.My_Question.DESCRIPTION = Convert.IsDBNull(oRow["T_QUESTION_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_QUESTION_DESCRIPTION"]);o.My_Question.IS_ANSWERED = Convert.IsDBNull(oRow["T_QUESTION_IS_ANSWERED"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ANSWERED"]);o.My_Question.IS_ACTIVE = Convert.IsDBNull(oRow["T_QUESTION_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ACTIVE"]);o.My_Question.REPORTS = Convert.IsDBNull(oRow["T_QUESTION_REPORTS"]) ? default : Convert.ToInt32(oRow["T_QUESTION_REPORTS"]);o.My_Question.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_QUESTION_ENTRY_USER_ID"]);o.My_Question.ENTRY_DATE = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_QUESTION_ENTRY_DATE"]);o.My_Question.OWNER_ID = Convert.IsDBNull(oRow["T_QUESTION_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_OWNER_ID"]);
o.My_Answer = new Answer();
o.My_Answer.ANSWER_ID = Convert.IsDBNull(oRow["T_ANSWER_ANSWER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_ANSWER_ID"]);o.My_Answer.QUESTION_ID = Convert.IsDBNull(oRow["T_ANSWER_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_QUESTION_ID"]);o.My_Answer.TEACHER_ID = Convert.IsDBNull(oRow["T_ANSWER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_TEACHER_ID"]);o.My_Answer.DESCRIPTION = Convert.IsDBNull(oRow["T_ANSWER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_ANSWER_DESCRIPTION"]);o.My_Answer.SCORE = Convert.IsDBNull(oRow["T_ANSWER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_ANSWER_SCORE"]);o.My_Answer.REVIEWS = Convert.IsDBNull(oRow["T_ANSWER_REVIEWS"]) ? default : Convert.ToInt32(oRow["T_ANSWER_REVIEWS"]);o.My_Answer.REPORTS = Convert.IsDBNull(oRow["T_ANSWER_REPORTS"]) ? default : Convert.ToInt32(oRow["T_ANSWER_REPORTS"]);o.My_Answer.IS_ACTIVE = Convert.IsDBNull(oRow["T_ANSWER_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_ANSWER_IS_ACTIVE"]);o.My_Answer.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_ANSWER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_ANSWER_ENTRY_USER_ID"]);o.My_Answer.ENTRY_DATE = Convert.IsDBNull(oRow["T_ANSWER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_ANSWER_ENTRY_DATE"]);o.My_Answer.OWNER_ID = Convert.IsDBNull(oRow["T_ANSWER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Notification> Get_Notification_By_USER_ID_Adv ( Int32? USER_ID)
{
List<Notification> oList = new List<Notification>();
dynamic p = new ExpandoObject();
p.USER_ID = USER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_NOTIFICATION_BY_USER_ID_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Notification o = new Notification();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_User = new User();
o.My_User.USER_ID = Convert.IsDBNull(oRow["T_USER_USER_ID"]) ? default : Convert.ToInt64(oRow["T_USER_USER_ID"]);o.My_User.OWNER_ID = Convert.IsDBNull(oRow["T_USER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_USER_OWNER_ID"]);o.My_User.USERNAME = Convert.IsDBNull(oRow["T_USER_USERNAME"]) ? default : Convert.ToString(oRow["T_USER_USERNAME"]);o.My_User.PASSWORD = Convert.IsDBNull(oRow["T_USER_PASSWORD"]) ? default : Convert.ToString(oRow["T_USER_PASSWORD"]);o.My_User.USER_TYPE_CODE = Convert.IsDBNull(oRow["T_USER_USER_TYPE_CODE"]) ? default : Convert.ToString(oRow["T_USER_USER_TYPE_CODE"]);o.My_User.IS_LOGGED_IN = Convert.IsDBNull(oRow["T_USER_IS_LOGGED_IN"]) ? default : Convert.ToBoolean(oRow["T_USER_IS_LOGGED_IN"]);o.My_User.IS_ACTIVE = Convert.IsDBNull(oRow["T_USER_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_USER_IS_ACTIVE"]);o.My_User.ENTRY_DATE = Convert.IsDBNull(oRow["T_USER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_USER_ENTRY_DATE"]);
o.My_Question = new Question();
o.My_Question.QUESTION_ID = Convert.IsDBNull(oRow["T_QUESTION_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_QUESTION_ID"]);o.My_Question.STUDENT_ID = Convert.IsDBNull(oRow["T_QUESTION_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_STUDENT_ID"]);o.My_Question.CATEGORY_ID = Convert.IsDBNull(oRow["T_QUESTION_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_CATEGORY_ID"]);o.My_Question.TEACHER_ID = Convert.IsDBNull(oRow["T_QUESTION_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_TEACHER_ID"]);o.My_Question.DESCRIPTION = Convert.IsDBNull(oRow["T_QUESTION_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_QUESTION_DESCRIPTION"]);o.My_Question.IS_ANSWERED = Convert.IsDBNull(oRow["T_QUESTION_IS_ANSWERED"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ANSWERED"]);o.My_Question.IS_ACTIVE = Convert.IsDBNull(oRow["T_QUESTION_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ACTIVE"]);o.My_Question.REPORTS = Convert.IsDBNull(oRow["T_QUESTION_REPORTS"]) ? default : Convert.ToInt32(oRow["T_QUESTION_REPORTS"]);o.My_Question.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_QUESTION_ENTRY_USER_ID"]);o.My_Question.ENTRY_DATE = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_QUESTION_ENTRY_DATE"]);o.My_Question.OWNER_ID = Convert.IsDBNull(oRow["T_QUESTION_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_OWNER_ID"]);
o.My_Answer = new Answer();
o.My_Answer.ANSWER_ID = Convert.IsDBNull(oRow["T_ANSWER_ANSWER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_ANSWER_ID"]);o.My_Answer.QUESTION_ID = Convert.IsDBNull(oRow["T_ANSWER_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_QUESTION_ID"]);o.My_Answer.TEACHER_ID = Convert.IsDBNull(oRow["T_ANSWER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_TEACHER_ID"]);o.My_Answer.DESCRIPTION = Convert.IsDBNull(oRow["T_ANSWER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_ANSWER_DESCRIPTION"]);o.My_Answer.SCORE = Convert.IsDBNull(oRow["T_ANSWER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_ANSWER_SCORE"]);o.My_Answer.REVIEWS = Convert.IsDBNull(oRow["T_ANSWER_REVIEWS"]) ? default : Convert.ToInt32(oRow["T_ANSWER_REVIEWS"]);o.My_Answer.REPORTS = Convert.IsDBNull(oRow["T_ANSWER_REPORTS"]) ? default : Convert.ToInt32(oRow["T_ANSWER_REPORTS"]);o.My_Answer.IS_ACTIVE = Convert.IsDBNull(oRow["T_ANSWER_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_ANSWER_IS_ACTIVE"]);o.My_Answer.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_ANSWER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_ANSWER_ENTRY_USER_ID"]);o.My_Answer.ENTRY_DATE = Convert.IsDBNull(oRow["T_ANSWER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_ANSWER_ENTRY_DATE"]);o.My_Answer.OWNER_ID = Convert.IsDBNull(oRow["T_ANSWER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Notification> Get_Notification_By_QUESTION_ID_Adv ( Int32? QUESTION_ID)
{
List<Notification> oList = new List<Notification>();
dynamic p = new ExpandoObject();
p.QUESTION_ID = QUESTION_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_NOTIFICATION_BY_QUESTION_ID_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Notification o = new Notification();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_User = new User();
o.My_User.USER_ID = Convert.IsDBNull(oRow["T_USER_USER_ID"]) ? default : Convert.ToInt64(oRow["T_USER_USER_ID"]);o.My_User.OWNER_ID = Convert.IsDBNull(oRow["T_USER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_USER_OWNER_ID"]);o.My_User.USERNAME = Convert.IsDBNull(oRow["T_USER_USERNAME"]) ? default : Convert.ToString(oRow["T_USER_USERNAME"]);o.My_User.PASSWORD = Convert.IsDBNull(oRow["T_USER_PASSWORD"]) ? default : Convert.ToString(oRow["T_USER_PASSWORD"]);o.My_User.USER_TYPE_CODE = Convert.IsDBNull(oRow["T_USER_USER_TYPE_CODE"]) ? default : Convert.ToString(oRow["T_USER_USER_TYPE_CODE"]);o.My_User.IS_LOGGED_IN = Convert.IsDBNull(oRow["T_USER_IS_LOGGED_IN"]) ? default : Convert.ToBoolean(oRow["T_USER_IS_LOGGED_IN"]);o.My_User.IS_ACTIVE = Convert.IsDBNull(oRow["T_USER_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_USER_IS_ACTIVE"]);o.My_User.ENTRY_DATE = Convert.IsDBNull(oRow["T_USER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_USER_ENTRY_DATE"]);
o.My_Question = new Question();
o.My_Question.QUESTION_ID = Convert.IsDBNull(oRow["T_QUESTION_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_QUESTION_ID"]);o.My_Question.STUDENT_ID = Convert.IsDBNull(oRow["T_QUESTION_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_STUDENT_ID"]);o.My_Question.CATEGORY_ID = Convert.IsDBNull(oRow["T_QUESTION_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_CATEGORY_ID"]);o.My_Question.TEACHER_ID = Convert.IsDBNull(oRow["T_QUESTION_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_TEACHER_ID"]);o.My_Question.DESCRIPTION = Convert.IsDBNull(oRow["T_QUESTION_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_QUESTION_DESCRIPTION"]);o.My_Question.IS_ANSWERED = Convert.IsDBNull(oRow["T_QUESTION_IS_ANSWERED"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ANSWERED"]);o.My_Question.IS_ACTIVE = Convert.IsDBNull(oRow["T_QUESTION_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ACTIVE"]);o.My_Question.REPORTS = Convert.IsDBNull(oRow["T_QUESTION_REPORTS"]) ? default : Convert.ToInt32(oRow["T_QUESTION_REPORTS"]);o.My_Question.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_QUESTION_ENTRY_USER_ID"]);o.My_Question.ENTRY_DATE = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_QUESTION_ENTRY_DATE"]);o.My_Question.OWNER_ID = Convert.IsDBNull(oRow["T_QUESTION_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_OWNER_ID"]);
o.My_Answer = new Answer();
o.My_Answer.ANSWER_ID = Convert.IsDBNull(oRow["T_ANSWER_ANSWER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_ANSWER_ID"]);o.My_Answer.QUESTION_ID = Convert.IsDBNull(oRow["T_ANSWER_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_QUESTION_ID"]);o.My_Answer.TEACHER_ID = Convert.IsDBNull(oRow["T_ANSWER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_TEACHER_ID"]);o.My_Answer.DESCRIPTION = Convert.IsDBNull(oRow["T_ANSWER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_ANSWER_DESCRIPTION"]);o.My_Answer.SCORE = Convert.IsDBNull(oRow["T_ANSWER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_ANSWER_SCORE"]);o.My_Answer.REVIEWS = Convert.IsDBNull(oRow["T_ANSWER_REVIEWS"]) ? default : Convert.ToInt32(oRow["T_ANSWER_REVIEWS"]);o.My_Answer.REPORTS = Convert.IsDBNull(oRow["T_ANSWER_REPORTS"]) ? default : Convert.ToInt32(oRow["T_ANSWER_REPORTS"]);o.My_Answer.IS_ACTIVE = Convert.IsDBNull(oRow["T_ANSWER_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_ANSWER_IS_ACTIVE"]);o.My_Answer.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_ANSWER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_ANSWER_ENTRY_USER_ID"]);o.My_Answer.ENTRY_DATE = Convert.IsDBNull(oRow["T_ANSWER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_ANSWER_ENTRY_DATE"]);o.My_Answer.OWNER_ID = Convert.IsDBNull(oRow["T_ANSWER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Notification> Get_Notification_By_ANSWER_ID_Adv ( Int32? ANSWER_ID)
{
List<Notification> oList = new List<Notification>();
dynamic p = new ExpandoObject();
p.ANSWER_ID = ANSWER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_NOTIFICATION_BY_ANSWER_ID_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Notification o = new Notification();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_User = new User();
o.My_User.USER_ID = Convert.IsDBNull(oRow["T_USER_USER_ID"]) ? default : Convert.ToInt64(oRow["T_USER_USER_ID"]);o.My_User.OWNER_ID = Convert.IsDBNull(oRow["T_USER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_USER_OWNER_ID"]);o.My_User.USERNAME = Convert.IsDBNull(oRow["T_USER_USERNAME"]) ? default : Convert.ToString(oRow["T_USER_USERNAME"]);o.My_User.PASSWORD = Convert.IsDBNull(oRow["T_USER_PASSWORD"]) ? default : Convert.ToString(oRow["T_USER_PASSWORD"]);o.My_User.USER_TYPE_CODE = Convert.IsDBNull(oRow["T_USER_USER_TYPE_CODE"]) ? default : Convert.ToString(oRow["T_USER_USER_TYPE_CODE"]);o.My_User.IS_LOGGED_IN = Convert.IsDBNull(oRow["T_USER_IS_LOGGED_IN"]) ? default : Convert.ToBoolean(oRow["T_USER_IS_LOGGED_IN"]);o.My_User.IS_ACTIVE = Convert.IsDBNull(oRow["T_USER_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_USER_IS_ACTIVE"]);o.My_User.ENTRY_DATE = Convert.IsDBNull(oRow["T_USER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_USER_ENTRY_DATE"]);
o.My_Question = new Question();
o.My_Question.QUESTION_ID = Convert.IsDBNull(oRow["T_QUESTION_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_QUESTION_ID"]);o.My_Question.STUDENT_ID = Convert.IsDBNull(oRow["T_QUESTION_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_STUDENT_ID"]);o.My_Question.CATEGORY_ID = Convert.IsDBNull(oRow["T_QUESTION_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_CATEGORY_ID"]);o.My_Question.TEACHER_ID = Convert.IsDBNull(oRow["T_QUESTION_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_TEACHER_ID"]);o.My_Question.DESCRIPTION = Convert.IsDBNull(oRow["T_QUESTION_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_QUESTION_DESCRIPTION"]);o.My_Question.IS_ANSWERED = Convert.IsDBNull(oRow["T_QUESTION_IS_ANSWERED"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ANSWERED"]);o.My_Question.IS_ACTIVE = Convert.IsDBNull(oRow["T_QUESTION_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ACTIVE"]);o.My_Question.REPORTS = Convert.IsDBNull(oRow["T_QUESTION_REPORTS"]) ? default : Convert.ToInt32(oRow["T_QUESTION_REPORTS"]);o.My_Question.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_QUESTION_ENTRY_USER_ID"]);o.My_Question.ENTRY_DATE = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_QUESTION_ENTRY_DATE"]);o.My_Question.OWNER_ID = Convert.IsDBNull(oRow["T_QUESTION_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_OWNER_ID"]);
o.My_Answer = new Answer();
o.My_Answer.ANSWER_ID = Convert.IsDBNull(oRow["T_ANSWER_ANSWER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_ANSWER_ID"]);o.My_Answer.QUESTION_ID = Convert.IsDBNull(oRow["T_ANSWER_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_QUESTION_ID"]);o.My_Answer.TEACHER_ID = Convert.IsDBNull(oRow["T_ANSWER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_TEACHER_ID"]);o.My_Answer.DESCRIPTION = Convert.IsDBNull(oRow["T_ANSWER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_ANSWER_DESCRIPTION"]);o.My_Answer.SCORE = Convert.IsDBNull(oRow["T_ANSWER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_ANSWER_SCORE"]);o.My_Answer.REVIEWS = Convert.IsDBNull(oRow["T_ANSWER_REVIEWS"]) ? default : Convert.ToInt32(oRow["T_ANSWER_REVIEWS"]);o.My_Answer.REPORTS = Convert.IsDBNull(oRow["T_ANSWER_REPORTS"]) ? default : Convert.ToInt32(oRow["T_ANSWER_REPORTS"]);o.My_Answer.IS_ACTIVE = Convert.IsDBNull(oRow["T_ANSWER_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_ANSWER_IS_ACTIVE"]);o.My_Answer.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_ANSWER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_ANSWER_ENTRY_USER_ID"]);o.My_Answer.ENTRY_DATE = Convert.IsDBNull(oRow["T_ANSWER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_ANSWER_ENTRY_DATE"]);o.My_Answer.OWNER_ID = Convert.IsDBNull(oRow["T_ANSWER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Question> Get_Question_By_OWNER_ID_Adv ( Int32? OWNER_ID)
{
List<Question> oList = new List<Question>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_QUESTION_BY_OWNER_ID_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Question o = new Question();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
o.My_Category = new Category();
o.My_Category.CATEGORY_ID = Convert.IsDBNull(oRow["T_CATEGORY_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_CATEGORY_ID"]);o.My_Category.NAME = Convert.IsDBNull(oRow["T_CATEGORY_NAME"]) ? default : Convert.ToString(oRow["T_CATEGORY_NAME"]);o.My_Category.DECRIPTION = Convert.IsDBNull(oRow["T_CATEGORY_DECRIPTION"]) ? default : Convert.ToString(oRow["T_CATEGORY_DECRIPTION"]);o.My_Category.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_CATEGORY_ENTRY_USER_ID"]);o.My_Category.ENTRY_DATE = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_CATEGORY_ENTRY_DATE"]);o.My_Category.OWNER_ID = Convert.IsDBNull(oRow["T_CATEGORY_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_OWNER_ID"]);
o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Question> Get_Question_By_STUDENT_ID_Adv ( Int32? STUDENT_ID)
{
List<Question> oList = new List<Question>();
dynamic p = new ExpandoObject();
p.STUDENT_ID = STUDENT_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_QUESTION_BY_STUDENT_ID_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Question o = new Question();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
o.My_Category = new Category();
o.My_Category.CATEGORY_ID = Convert.IsDBNull(oRow["T_CATEGORY_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_CATEGORY_ID"]);o.My_Category.NAME = Convert.IsDBNull(oRow["T_CATEGORY_NAME"]) ? default : Convert.ToString(oRow["T_CATEGORY_NAME"]);o.My_Category.DECRIPTION = Convert.IsDBNull(oRow["T_CATEGORY_DECRIPTION"]) ? default : Convert.ToString(oRow["T_CATEGORY_DECRIPTION"]);o.My_Category.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_CATEGORY_ENTRY_USER_ID"]);o.My_Category.ENTRY_DATE = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_CATEGORY_ENTRY_DATE"]);o.My_Category.OWNER_ID = Convert.IsDBNull(oRow["T_CATEGORY_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_OWNER_ID"]);
o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Question> Get_Question_By_CATEGORY_ID_Adv ( Int32? CATEGORY_ID)
{
List<Question> oList = new List<Question>();
dynamic p = new ExpandoObject();
p.CATEGORY_ID = CATEGORY_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_QUESTION_BY_CATEGORY_ID_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Question o = new Question();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
o.My_Category = new Category();
o.My_Category.CATEGORY_ID = Convert.IsDBNull(oRow["T_CATEGORY_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_CATEGORY_ID"]);o.My_Category.NAME = Convert.IsDBNull(oRow["T_CATEGORY_NAME"]) ? default : Convert.ToString(oRow["T_CATEGORY_NAME"]);o.My_Category.DECRIPTION = Convert.IsDBNull(oRow["T_CATEGORY_DECRIPTION"]) ? default : Convert.ToString(oRow["T_CATEGORY_DECRIPTION"]);o.My_Category.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_CATEGORY_ENTRY_USER_ID"]);o.My_Category.ENTRY_DATE = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_CATEGORY_ENTRY_DATE"]);o.My_Category.OWNER_ID = Convert.IsDBNull(oRow["T_CATEGORY_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_OWNER_ID"]);
o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Question> Get_Question_By_TEACHER_ID_Adv ( Int32? TEACHER_ID)
{
List<Question> oList = new List<Question>();
dynamic p = new ExpandoObject();
p.TEACHER_ID = TEACHER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_QUESTION_BY_TEACHER_ID_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Question o = new Question();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
o.My_Category = new Category();
o.My_Category.CATEGORY_ID = Convert.IsDBNull(oRow["T_CATEGORY_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_CATEGORY_ID"]);o.My_Category.NAME = Convert.IsDBNull(oRow["T_CATEGORY_NAME"]) ? default : Convert.ToString(oRow["T_CATEGORY_NAME"]);o.My_Category.DECRIPTION = Convert.IsDBNull(oRow["T_CATEGORY_DECRIPTION"]) ? default : Convert.ToString(oRow["T_CATEGORY_DECRIPTION"]);o.My_Category.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_CATEGORY_ENTRY_USER_ID"]);o.My_Category.ENTRY_DATE = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_CATEGORY_ENTRY_DATE"]);o.My_Category.OWNER_ID = Convert.IsDBNull(oRow["T_CATEGORY_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_OWNER_ID"]);
o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Question_report> Get_Question_report_By_OWNER_ID_Adv ( Int32? OWNER_ID)
{
List<Question_report> oList = new List<Question_report>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_QUESTION_REPORT_BY_OWNER_ID_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Question_report o = new Question_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Question = new Question();
o.My_Question.QUESTION_ID = Convert.IsDBNull(oRow["T_QUESTION_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_QUESTION_ID"]);o.My_Question.STUDENT_ID = Convert.IsDBNull(oRow["T_QUESTION_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_STUDENT_ID"]);o.My_Question.CATEGORY_ID = Convert.IsDBNull(oRow["T_QUESTION_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_CATEGORY_ID"]);o.My_Question.TEACHER_ID = Convert.IsDBNull(oRow["T_QUESTION_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_TEACHER_ID"]);o.My_Question.DESCRIPTION = Convert.IsDBNull(oRow["T_QUESTION_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_QUESTION_DESCRIPTION"]);o.My_Question.IS_ANSWERED = Convert.IsDBNull(oRow["T_QUESTION_IS_ANSWERED"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ANSWERED"]);o.My_Question.IS_ACTIVE = Convert.IsDBNull(oRow["T_QUESTION_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ACTIVE"]);o.My_Question.REPORTS = Convert.IsDBNull(oRow["T_QUESTION_REPORTS"]) ? default : Convert.ToInt32(oRow["T_QUESTION_REPORTS"]);o.My_Question.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_QUESTION_ENTRY_USER_ID"]);o.My_Question.ENTRY_DATE = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_QUESTION_ENTRY_DATE"]);o.My_Question.OWNER_ID = Convert.IsDBNull(oRow["T_QUESTION_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Question_report> Get_Question_report_By_STUDENT_ID_Adv ( Int32? STUDENT_ID)
{
List<Question_report> oList = new List<Question_report>();
dynamic p = new ExpandoObject();
p.STUDENT_ID = STUDENT_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_QUESTION_REPORT_BY_STUDENT_ID_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Question_report o = new Question_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Question = new Question();
o.My_Question.QUESTION_ID = Convert.IsDBNull(oRow["T_QUESTION_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_QUESTION_ID"]);o.My_Question.STUDENT_ID = Convert.IsDBNull(oRow["T_QUESTION_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_STUDENT_ID"]);o.My_Question.CATEGORY_ID = Convert.IsDBNull(oRow["T_QUESTION_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_CATEGORY_ID"]);o.My_Question.TEACHER_ID = Convert.IsDBNull(oRow["T_QUESTION_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_TEACHER_ID"]);o.My_Question.DESCRIPTION = Convert.IsDBNull(oRow["T_QUESTION_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_QUESTION_DESCRIPTION"]);o.My_Question.IS_ANSWERED = Convert.IsDBNull(oRow["T_QUESTION_IS_ANSWERED"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ANSWERED"]);o.My_Question.IS_ACTIVE = Convert.IsDBNull(oRow["T_QUESTION_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ACTIVE"]);o.My_Question.REPORTS = Convert.IsDBNull(oRow["T_QUESTION_REPORTS"]) ? default : Convert.ToInt32(oRow["T_QUESTION_REPORTS"]);o.My_Question.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_QUESTION_ENTRY_USER_ID"]);o.My_Question.ENTRY_DATE = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_QUESTION_ENTRY_DATE"]);o.My_Question.OWNER_ID = Convert.IsDBNull(oRow["T_QUESTION_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Question_report> Get_Question_report_By_TEACHER_ID_Adv ( Int32? TEACHER_ID)
{
List<Question_report> oList = new List<Question_report>();
dynamic p = new ExpandoObject();
p.TEACHER_ID = TEACHER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_QUESTION_REPORT_BY_TEACHER_ID_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Question_report o = new Question_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Question = new Question();
o.My_Question.QUESTION_ID = Convert.IsDBNull(oRow["T_QUESTION_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_QUESTION_ID"]);o.My_Question.STUDENT_ID = Convert.IsDBNull(oRow["T_QUESTION_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_STUDENT_ID"]);o.My_Question.CATEGORY_ID = Convert.IsDBNull(oRow["T_QUESTION_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_CATEGORY_ID"]);o.My_Question.TEACHER_ID = Convert.IsDBNull(oRow["T_QUESTION_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_TEACHER_ID"]);o.My_Question.DESCRIPTION = Convert.IsDBNull(oRow["T_QUESTION_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_QUESTION_DESCRIPTION"]);o.My_Question.IS_ANSWERED = Convert.IsDBNull(oRow["T_QUESTION_IS_ANSWERED"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ANSWERED"]);o.My_Question.IS_ACTIVE = Convert.IsDBNull(oRow["T_QUESTION_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ACTIVE"]);o.My_Question.REPORTS = Convert.IsDBNull(oRow["T_QUESTION_REPORTS"]) ? default : Convert.ToInt32(oRow["T_QUESTION_REPORTS"]);o.My_Question.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_QUESTION_ENTRY_USER_ID"]);o.My_Question.ENTRY_DATE = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_QUESTION_ENTRY_DATE"]);o.My_Question.OWNER_ID = Convert.IsDBNull(oRow["T_QUESTION_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Question_report> Get_Question_report_By_QUESTION_ID_Adv ( Int32? QUESTION_ID)
{
List<Question_report> oList = new List<Question_report>();
dynamic p = new ExpandoObject();
p.QUESTION_ID = QUESTION_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_QUESTION_REPORT_BY_QUESTION_ID_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Question_report o = new Question_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Question = new Question();
o.My_Question.QUESTION_ID = Convert.IsDBNull(oRow["T_QUESTION_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_QUESTION_ID"]);o.My_Question.STUDENT_ID = Convert.IsDBNull(oRow["T_QUESTION_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_STUDENT_ID"]);o.My_Question.CATEGORY_ID = Convert.IsDBNull(oRow["T_QUESTION_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_CATEGORY_ID"]);o.My_Question.TEACHER_ID = Convert.IsDBNull(oRow["T_QUESTION_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_TEACHER_ID"]);o.My_Question.DESCRIPTION = Convert.IsDBNull(oRow["T_QUESTION_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_QUESTION_DESCRIPTION"]);o.My_Question.IS_ANSWERED = Convert.IsDBNull(oRow["T_QUESTION_IS_ANSWERED"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ANSWERED"]);o.My_Question.IS_ACTIVE = Convert.IsDBNull(oRow["T_QUESTION_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ACTIVE"]);o.My_Question.REPORTS = Convert.IsDBNull(oRow["T_QUESTION_REPORTS"]) ? default : Convert.ToInt32(oRow["T_QUESTION_REPORTS"]);o.My_Question.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_QUESTION_ENTRY_USER_ID"]);o.My_Question.ENTRY_DATE = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_QUESTION_ENTRY_DATE"]);o.My_Question.OWNER_ID = Convert.IsDBNull(oRow["T_QUESTION_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Question_token> Get_Question_token_By_PART_Adv ( string PART)
{
List<Question_token> oList = new List<Question_token>();
dynamic p = new ExpandoObject();
p.PART = PART;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_QUESTION_TOKEN_BY_PART_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Question_token o = new Question_token();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Question = new Question();
o.My_Question.QUESTION_ID = Convert.IsDBNull(oRow["T_QUESTION_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_QUESTION_ID"]);o.My_Question.STUDENT_ID = Convert.IsDBNull(oRow["T_QUESTION_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_STUDENT_ID"]);o.My_Question.CATEGORY_ID = Convert.IsDBNull(oRow["T_QUESTION_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_CATEGORY_ID"]);o.My_Question.TEACHER_ID = Convert.IsDBNull(oRow["T_QUESTION_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_TEACHER_ID"]);o.My_Question.DESCRIPTION = Convert.IsDBNull(oRow["T_QUESTION_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_QUESTION_DESCRIPTION"]);o.My_Question.IS_ANSWERED = Convert.IsDBNull(oRow["T_QUESTION_IS_ANSWERED"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ANSWERED"]);o.My_Question.IS_ACTIVE = Convert.IsDBNull(oRow["T_QUESTION_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ACTIVE"]);o.My_Question.REPORTS = Convert.IsDBNull(oRow["T_QUESTION_REPORTS"]) ? default : Convert.ToInt32(oRow["T_QUESTION_REPORTS"]);o.My_Question.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_QUESTION_ENTRY_USER_ID"]);o.My_Question.ENTRY_DATE = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_QUESTION_ENTRY_DATE"]);o.My_Question.OWNER_ID = Convert.IsDBNull(oRow["T_QUESTION_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Question_token> Get_Question_token_By_OWNER_ID_Adv ( Int32? OWNER_ID)
{
List<Question_token> oList = new List<Question_token>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_QUESTION_TOKEN_BY_OWNER_ID_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Question_token o = new Question_token();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Question = new Question();
o.My_Question.QUESTION_ID = Convert.IsDBNull(oRow["T_QUESTION_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_QUESTION_ID"]);o.My_Question.STUDENT_ID = Convert.IsDBNull(oRow["T_QUESTION_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_STUDENT_ID"]);o.My_Question.CATEGORY_ID = Convert.IsDBNull(oRow["T_QUESTION_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_CATEGORY_ID"]);o.My_Question.TEACHER_ID = Convert.IsDBNull(oRow["T_QUESTION_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_TEACHER_ID"]);o.My_Question.DESCRIPTION = Convert.IsDBNull(oRow["T_QUESTION_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_QUESTION_DESCRIPTION"]);o.My_Question.IS_ANSWERED = Convert.IsDBNull(oRow["T_QUESTION_IS_ANSWERED"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ANSWERED"]);o.My_Question.IS_ACTIVE = Convert.IsDBNull(oRow["T_QUESTION_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ACTIVE"]);o.My_Question.REPORTS = Convert.IsDBNull(oRow["T_QUESTION_REPORTS"]) ? default : Convert.ToInt32(oRow["T_QUESTION_REPORTS"]);o.My_Question.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_QUESTION_ENTRY_USER_ID"]);o.My_Question.ENTRY_DATE = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_QUESTION_ENTRY_DATE"]);o.My_Question.OWNER_ID = Convert.IsDBNull(oRow["T_QUESTION_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Question_token> Get_Question_token_By_QUESTION_ID_Adv ( long? QUESTION_ID)
{
List<Question_token> oList = new List<Question_token>();
dynamic p = new ExpandoObject();
p.QUESTION_ID = QUESTION_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_QUESTION_TOKEN_BY_QUESTION_ID_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Question_token o = new Question_token();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Question = new Question();
o.My_Question.QUESTION_ID = Convert.IsDBNull(oRow["T_QUESTION_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_QUESTION_ID"]);o.My_Question.STUDENT_ID = Convert.IsDBNull(oRow["T_QUESTION_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_STUDENT_ID"]);o.My_Question.CATEGORY_ID = Convert.IsDBNull(oRow["T_QUESTION_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_CATEGORY_ID"]);o.My_Question.TEACHER_ID = Convert.IsDBNull(oRow["T_QUESTION_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_TEACHER_ID"]);o.My_Question.DESCRIPTION = Convert.IsDBNull(oRow["T_QUESTION_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_QUESTION_DESCRIPTION"]);o.My_Question.IS_ANSWERED = Convert.IsDBNull(oRow["T_QUESTION_IS_ANSWERED"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ANSWERED"]);o.My_Question.IS_ACTIVE = Convert.IsDBNull(oRow["T_QUESTION_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ACTIVE"]);o.My_Question.REPORTS = Convert.IsDBNull(oRow["T_QUESTION_REPORTS"]) ? default : Convert.ToInt32(oRow["T_QUESTION_REPORTS"]);o.My_Question.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_QUESTION_ENTRY_USER_ID"]);o.My_Question.ENTRY_DATE = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_QUESTION_ENTRY_DATE"]);o.My_Question.OWNER_ID = Convert.IsDBNull(oRow["T_QUESTION_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Report_article> Get_Report_article_By_OWNER_ID_Adv ( Int32? OWNER_ID)
{
List<Report_article> oList = new List<Report_article>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_REPORT_ARTICLE_BY_OWNER_ID_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Report_article o = new Report_article();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Article = new Article();
o.My_Article.ARTICLE_ID = Convert.IsDBNull(oRow["T_ARTICLE_ARTICLE_ID"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_ARTICLE_ID"]);o.My_Article.TEACHER_ID = Convert.IsDBNull(oRow["T_ARTICLE_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_TEACHER_ID"]);o.My_Article.CATEGORY_ID = Convert.IsDBNull(oRow["T_ARTICLE_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_CATEGORY_ID"]);o.My_Article.TITLE = Convert.IsDBNull(oRow["T_ARTICLE_TITLE"]) ? default : Convert.ToString(oRow["T_ARTICLE_TITLE"]);o.My_Article.DESCRIPTION = Convert.IsDBNull(oRow["T_ARTICLE_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_ARTICLE_DESCRIPTION"]);o.My_Article.APPLAUDS = Convert.IsDBNull(oRow["T_ARTICLE_APPLAUDS"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_APPLAUDS"]);o.My_Article.REPORTS = Convert.IsDBNull(oRow["T_ARTICLE_REPORTS"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_REPORTS"]);o.My_Article.IS_BLOCKED = Convert.IsDBNull(oRow["T_ARTICLE_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_ARTICLE_IS_BLOCKED"]);o.My_Article.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_ARTICLE_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_ARTICLE_ENTRY_USER_ID"]);o.My_Article.ENTRY_DATE = Convert.IsDBNull(oRow["T_ARTICLE_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_ARTICLE_ENTRY_DATE"]);o.My_Article.OWNER_ID = Convert.IsDBNull(oRow["T_ARTICLE_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Report_article> Get_Report_article_By_ARTICLE_ID_Adv ( Int32? ARTICLE_ID)
{
List<Report_article> oList = new List<Report_article>();
dynamic p = new ExpandoObject();
p.ARTICLE_ID = ARTICLE_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_REPORT_ARTICLE_BY_ARTICLE_ID_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Report_article o = new Report_article();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Article = new Article();
o.My_Article.ARTICLE_ID = Convert.IsDBNull(oRow["T_ARTICLE_ARTICLE_ID"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_ARTICLE_ID"]);o.My_Article.TEACHER_ID = Convert.IsDBNull(oRow["T_ARTICLE_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_TEACHER_ID"]);o.My_Article.CATEGORY_ID = Convert.IsDBNull(oRow["T_ARTICLE_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_CATEGORY_ID"]);o.My_Article.TITLE = Convert.IsDBNull(oRow["T_ARTICLE_TITLE"]) ? default : Convert.ToString(oRow["T_ARTICLE_TITLE"]);o.My_Article.DESCRIPTION = Convert.IsDBNull(oRow["T_ARTICLE_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_ARTICLE_DESCRIPTION"]);o.My_Article.APPLAUDS = Convert.IsDBNull(oRow["T_ARTICLE_APPLAUDS"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_APPLAUDS"]);o.My_Article.REPORTS = Convert.IsDBNull(oRow["T_ARTICLE_REPORTS"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_REPORTS"]);o.My_Article.IS_BLOCKED = Convert.IsDBNull(oRow["T_ARTICLE_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_ARTICLE_IS_BLOCKED"]);o.My_Article.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_ARTICLE_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_ARTICLE_ENTRY_USER_ID"]);o.My_Article.ENTRY_DATE = Convert.IsDBNull(oRow["T_ARTICLE_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_ARTICLE_ENTRY_DATE"]);o.My_Article.OWNER_ID = Convert.IsDBNull(oRow["T_ARTICLE_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Report_article> Get_Report_article_By_STUDENT_ID_Adv ( Int32? STUDENT_ID)
{
List<Report_article> oList = new List<Report_article>();
dynamic p = new ExpandoObject();
p.STUDENT_ID = STUDENT_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_REPORT_ARTICLE_BY_STUDENT_ID_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Report_article o = new Report_article();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Article = new Article();
o.My_Article.ARTICLE_ID = Convert.IsDBNull(oRow["T_ARTICLE_ARTICLE_ID"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_ARTICLE_ID"]);o.My_Article.TEACHER_ID = Convert.IsDBNull(oRow["T_ARTICLE_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_TEACHER_ID"]);o.My_Article.CATEGORY_ID = Convert.IsDBNull(oRow["T_ARTICLE_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_CATEGORY_ID"]);o.My_Article.TITLE = Convert.IsDBNull(oRow["T_ARTICLE_TITLE"]) ? default : Convert.ToString(oRow["T_ARTICLE_TITLE"]);o.My_Article.DESCRIPTION = Convert.IsDBNull(oRow["T_ARTICLE_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_ARTICLE_DESCRIPTION"]);o.My_Article.APPLAUDS = Convert.IsDBNull(oRow["T_ARTICLE_APPLAUDS"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_APPLAUDS"]);o.My_Article.REPORTS = Convert.IsDBNull(oRow["T_ARTICLE_REPORTS"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_REPORTS"]);o.My_Article.IS_BLOCKED = Convert.IsDBNull(oRow["T_ARTICLE_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_ARTICLE_IS_BLOCKED"]);o.My_Article.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_ARTICLE_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_ARTICLE_ENTRY_USER_ID"]);o.My_Article.ENTRY_DATE = Convert.IsDBNull(oRow["T_ARTICLE_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_ARTICLE_ENTRY_DATE"]);o.My_Article.OWNER_ID = Convert.IsDBNull(oRow["T_ARTICLE_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Student> Get_Student_By_OWNER_ID_Adv ( Int32? OWNER_ID)
{
List<Student> oList = new List<Student>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_STUDENT_BY_OWNER_ID_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Student o = new Student();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_User = new User();
o.My_User.USER_ID = Convert.IsDBNull(oRow["T_USER_USER_ID"]) ? default : Convert.ToInt64(oRow["T_USER_USER_ID"]);o.My_User.OWNER_ID = Convert.IsDBNull(oRow["T_USER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_USER_OWNER_ID"]);o.My_User.USERNAME = Convert.IsDBNull(oRow["T_USER_USERNAME"]) ? default : Convert.ToString(oRow["T_USER_USERNAME"]);o.My_User.PASSWORD = Convert.IsDBNull(oRow["T_USER_PASSWORD"]) ? default : Convert.ToString(oRow["T_USER_PASSWORD"]);o.My_User.USER_TYPE_CODE = Convert.IsDBNull(oRow["T_USER_USER_TYPE_CODE"]) ? default : Convert.ToString(oRow["T_USER_USER_TYPE_CODE"]);o.My_User.IS_LOGGED_IN = Convert.IsDBNull(oRow["T_USER_IS_LOGGED_IN"]) ? default : Convert.ToBoolean(oRow["T_USER_IS_LOGGED_IN"]);o.My_User.IS_ACTIVE = Convert.IsDBNull(oRow["T_USER_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_USER_IS_ACTIVE"]);o.My_User.ENTRY_DATE = Convert.IsDBNull(oRow["T_USER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_USER_ENTRY_DATE"]);
oList.Add(o);
}
}
return oList;
}
public List<Student> Get_Student_By_USER_ID_Adv ( Int32? USER_ID)
{
List<Student> oList = new List<Student>();
dynamic p = new ExpandoObject();
p.USER_ID = USER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_STUDENT_BY_USER_ID_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Student o = new Student();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_User = new User();
o.My_User.USER_ID = Convert.IsDBNull(oRow["T_USER_USER_ID"]) ? default : Convert.ToInt64(oRow["T_USER_USER_ID"]);o.My_User.OWNER_ID = Convert.IsDBNull(oRow["T_USER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_USER_OWNER_ID"]);o.My_User.USERNAME = Convert.IsDBNull(oRow["T_USER_USERNAME"]) ? default : Convert.ToString(oRow["T_USER_USERNAME"]);o.My_User.PASSWORD = Convert.IsDBNull(oRow["T_USER_PASSWORD"]) ? default : Convert.ToString(oRow["T_USER_PASSWORD"]);o.My_User.USER_TYPE_CODE = Convert.IsDBNull(oRow["T_USER_USER_TYPE_CODE"]) ? default : Convert.ToString(oRow["T_USER_USER_TYPE_CODE"]);o.My_User.IS_LOGGED_IN = Convert.IsDBNull(oRow["T_USER_IS_LOGGED_IN"]) ? default : Convert.ToBoolean(oRow["T_USER_IS_LOGGED_IN"]);o.My_User.IS_ACTIVE = Convert.IsDBNull(oRow["T_USER_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_USER_IS_ACTIVE"]);o.My_User.ENTRY_DATE = Convert.IsDBNull(oRow["T_USER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_USER_ENTRY_DATE"]);
oList.Add(o);
}
}
return oList;
}
public List<Student_report> Get_Student_report_By_OWNER_ID_Adv ( Int32? OWNER_ID)
{
List<Student_report> oList = new List<Student_report>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_STUDENT_REPORT_BY_OWNER_ID_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Student_report o = new Student_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Reported_by_student = new Student();
o.My_Reported_by_student.STUDENT_ID = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_REPORTED_BY_STUDENT_STUDENT_ID"]);o.My_Reported_by_student.USER_ID = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_REPORTED_BY_STUDENT_USER_ID"]);o.My_Reported_by_student.FIRST_NAME = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_REPORTED_BY_STUDENT_FIRST_NAME"]);o.My_Reported_by_student.LAST_NAME = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_REPORTED_BY_STUDENT_LAST_NAME"]);o.My_Reported_by_student.EMAIL = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_REPORTED_BY_STUDENT_EMAIL"]);o.My_Reported_by_student.IS_BLOCKED = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_REPORTED_BY_STUDENT_IS_BLOCKED"]);o.My_Reported_by_student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_REPORTED_BY_STUDENT_PENDING_QUESTIONS"]);o.My_Reported_by_student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_REPORTED_BY_STUDENT_ENTRY_USER_ID"]);o.My_Reported_by_student.ENTRY_DATE = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_REPORTED_BY_STUDENT_ENTRY_DATE"]);o.My_Reported_by_student.OWNER_ID = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_REPORTED_BY_STUDENT_OWNER_ID"]);
o.My_Reported_student = new Student();
o.My_Reported_student.STUDENT_ID = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_REPORTED_STUDENT_STUDENT_ID"]);o.My_Reported_student.USER_ID = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_REPORTED_STUDENT_USER_ID"]);o.My_Reported_student.FIRST_NAME = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_REPORTED_STUDENT_FIRST_NAME"]);o.My_Reported_student.LAST_NAME = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_REPORTED_STUDENT_LAST_NAME"]);o.My_Reported_student.EMAIL = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_REPORTED_STUDENT_EMAIL"]);o.My_Reported_student.IS_BLOCKED = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_REPORTED_STUDENT_IS_BLOCKED"]);o.My_Reported_student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_REPORTED_STUDENT_PENDING_QUESTIONS"]);o.My_Reported_student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_REPORTED_STUDENT_ENTRY_USER_ID"]);o.My_Reported_student.ENTRY_DATE = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_REPORTED_STUDENT_ENTRY_DATE"]);o.My_Reported_student.OWNER_ID = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_REPORTED_STUDENT_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Student_report> Get_Student_report_By_REPORTED_BY_STUDENT_ID_Adv ( Int32? REPORTED_BY_STUDENT_ID)
{
List<Student_report> oList = new List<Student_report>();
dynamic p = new ExpandoObject();
p.REPORTED_BY_STUDENT_ID = REPORTED_BY_STUDENT_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_STUDENT_REPORT_BY_REPORTED_BY_STUDENT_ID_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Student_report o = new Student_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Reported_by_student = new Student();
o.My_Reported_by_student.STUDENT_ID = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_REPORTED_BY_STUDENT_STUDENT_ID"]);o.My_Reported_by_student.USER_ID = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_REPORTED_BY_STUDENT_USER_ID"]);o.My_Reported_by_student.FIRST_NAME = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_REPORTED_BY_STUDENT_FIRST_NAME"]);o.My_Reported_by_student.LAST_NAME = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_REPORTED_BY_STUDENT_LAST_NAME"]);o.My_Reported_by_student.EMAIL = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_REPORTED_BY_STUDENT_EMAIL"]);o.My_Reported_by_student.IS_BLOCKED = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_REPORTED_BY_STUDENT_IS_BLOCKED"]);o.My_Reported_by_student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_REPORTED_BY_STUDENT_PENDING_QUESTIONS"]);o.My_Reported_by_student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_REPORTED_BY_STUDENT_ENTRY_USER_ID"]);o.My_Reported_by_student.ENTRY_DATE = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_REPORTED_BY_STUDENT_ENTRY_DATE"]);o.My_Reported_by_student.OWNER_ID = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_REPORTED_BY_STUDENT_OWNER_ID"]);
o.My_Reported_student = new Student();
o.My_Reported_student.STUDENT_ID = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_REPORTED_STUDENT_STUDENT_ID"]);o.My_Reported_student.USER_ID = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_REPORTED_STUDENT_USER_ID"]);o.My_Reported_student.FIRST_NAME = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_REPORTED_STUDENT_FIRST_NAME"]);o.My_Reported_student.LAST_NAME = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_REPORTED_STUDENT_LAST_NAME"]);o.My_Reported_student.EMAIL = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_REPORTED_STUDENT_EMAIL"]);o.My_Reported_student.IS_BLOCKED = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_REPORTED_STUDENT_IS_BLOCKED"]);o.My_Reported_student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_REPORTED_STUDENT_PENDING_QUESTIONS"]);o.My_Reported_student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_REPORTED_STUDENT_ENTRY_USER_ID"]);o.My_Reported_student.ENTRY_DATE = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_REPORTED_STUDENT_ENTRY_DATE"]);o.My_Reported_student.OWNER_ID = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_REPORTED_STUDENT_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Student_report> Get_Student_report_By_REPORTED_STUDENT_ID_Adv ( Int32? REPORTED_STUDENT_ID)
{
List<Student_report> oList = new List<Student_report>();
dynamic p = new ExpandoObject();
p.REPORTED_STUDENT_ID = REPORTED_STUDENT_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_STUDENT_REPORT_BY_REPORTED_STUDENT_ID_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Student_report o = new Student_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Reported_by_student = new Student();
o.My_Reported_by_student.STUDENT_ID = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_REPORTED_BY_STUDENT_STUDENT_ID"]);o.My_Reported_by_student.USER_ID = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_REPORTED_BY_STUDENT_USER_ID"]);o.My_Reported_by_student.FIRST_NAME = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_REPORTED_BY_STUDENT_FIRST_NAME"]);o.My_Reported_by_student.LAST_NAME = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_REPORTED_BY_STUDENT_LAST_NAME"]);o.My_Reported_by_student.EMAIL = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_REPORTED_BY_STUDENT_EMAIL"]);o.My_Reported_by_student.IS_BLOCKED = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_REPORTED_BY_STUDENT_IS_BLOCKED"]);o.My_Reported_by_student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_REPORTED_BY_STUDENT_PENDING_QUESTIONS"]);o.My_Reported_by_student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_REPORTED_BY_STUDENT_ENTRY_USER_ID"]);o.My_Reported_by_student.ENTRY_DATE = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_REPORTED_BY_STUDENT_ENTRY_DATE"]);o.My_Reported_by_student.OWNER_ID = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_REPORTED_BY_STUDENT_OWNER_ID"]);
o.My_Reported_student = new Student();
o.My_Reported_student.STUDENT_ID = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_REPORTED_STUDENT_STUDENT_ID"]);o.My_Reported_student.USER_ID = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_REPORTED_STUDENT_USER_ID"]);o.My_Reported_student.FIRST_NAME = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_REPORTED_STUDENT_FIRST_NAME"]);o.My_Reported_student.LAST_NAME = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_REPORTED_STUDENT_LAST_NAME"]);o.My_Reported_student.EMAIL = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_REPORTED_STUDENT_EMAIL"]);o.My_Reported_student.IS_BLOCKED = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_REPORTED_STUDENT_IS_BLOCKED"]);o.My_Reported_student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_REPORTED_STUDENT_PENDING_QUESTIONS"]);o.My_Reported_student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_REPORTED_STUDENT_ENTRY_USER_ID"]);o.My_Reported_student.ENTRY_DATE = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_REPORTED_STUDENT_ENTRY_DATE"]);o.My_Reported_student.OWNER_ID = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_REPORTED_STUDENT_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Teacher> Get_Teacher_By_OWNER_ID_Adv ( Int32? OWNER_ID)
{
List<Teacher> oList = new List<Teacher>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_BY_OWNER_ID_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher o = new Teacher();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_User = new User();
o.My_User.USER_ID = Convert.IsDBNull(oRow["T_USER_USER_ID"]) ? default : Convert.ToInt64(oRow["T_USER_USER_ID"]);o.My_User.OWNER_ID = Convert.IsDBNull(oRow["T_USER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_USER_OWNER_ID"]);o.My_User.USERNAME = Convert.IsDBNull(oRow["T_USER_USERNAME"]) ? default : Convert.ToString(oRow["T_USER_USERNAME"]);o.My_User.PASSWORD = Convert.IsDBNull(oRow["T_USER_PASSWORD"]) ? default : Convert.ToString(oRow["T_USER_PASSWORD"]);o.My_User.USER_TYPE_CODE = Convert.IsDBNull(oRow["T_USER_USER_TYPE_CODE"]) ? default : Convert.ToString(oRow["T_USER_USER_TYPE_CODE"]);o.My_User.IS_LOGGED_IN = Convert.IsDBNull(oRow["T_USER_IS_LOGGED_IN"]) ? default : Convert.ToBoolean(oRow["T_USER_IS_LOGGED_IN"]);o.My_User.IS_ACTIVE = Convert.IsDBNull(oRow["T_USER_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_USER_IS_ACTIVE"]);o.My_User.ENTRY_DATE = Convert.IsDBNull(oRow["T_USER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_USER_ENTRY_DATE"]);
oList.Add(o);
}
}
return oList;
}
public List<Teacher> Get_Teacher_By_USER_ID_Adv ( Int32? USER_ID)
{
List<Teacher> oList = new List<Teacher>();
dynamic p = new ExpandoObject();
p.USER_ID = USER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_BY_USER_ID_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher o = new Teacher();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_User = new User();
o.My_User.USER_ID = Convert.IsDBNull(oRow["T_USER_USER_ID"]) ? default : Convert.ToInt64(oRow["T_USER_USER_ID"]);o.My_User.OWNER_ID = Convert.IsDBNull(oRow["T_USER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_USER_OWNER_ID"]);o.My_User.USERNAME = Convert.IsDBNull(oRow["T_USER_USERNAME"]) ? default : Convert.ToString(oRow["T_USER_USERNAME"]);o.My_User.PASSWORD = Convert.IsDBNull(oRow["T_USER_PASSWORD"]) ? default : Convert.ToString(oRow["T_USER_PASSWORD"]);o.My_User.USER_TYPE_CODE = Convert.IsDBNull(oRow["T_USER_USER_TYPE_CODE"]) ? default : Convert.ToString(oRow["T_USER_USER_TYPE_CODE"]);o.My_User.IS_LOGGED_IN = Convert.IsDBNull(oRow["T_USER_IS_LOGGED_IN"]) ? default : Convert.ToBoolean(oRow["T_USER_IS_LOGGED_IN"]);o.My_User.IS_ACTIVE = Convert.IsDBNull(oRow["T_USER_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_USER_IS_ACTIVE"]);o.My_User.ENTRY_DATE = Convert.IsDBNull(oRow["T_USER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_USER_ENTRY_DATE"]);
oList.Add(o);
}
}
return oList;
}
public List<Teacher_category> Get_Teacher_category_By_OWNER_ID_Adv ( Int32? OWNER_ID)
{
List<Teacher_category> oList = new List<Teacher_category>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_CATEGORY_BY_OWNER_ID_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_category o = new Teacher_category();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Category = new Category();
o.My_Category.CATEGORY_ID = Convert.IsDBNull(oRow["T_CATEGORY_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_CATEGORY_ID"]);o.My_Category.NAME = Convert.IsDBNull(oRow["T_CATEGORY_NAME"]) ? default : Convert.ToString(oRow["T_CATEGORY_NAME"]);o.My_Category.DECRIPTION = Convert.IsDBNull(oRow["T_CATEGORY_DECRIPTION"]) ? default : Convert.ToString(oRow["T_CATEGORY_DECRIPTION"]);o.My_Category.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_CATEGORY_ENTRY_USER_ID"]);o.My_Category.ENTRY_DATE = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_CATEGORY_ENTRY_DATE"]);o.My_Category.OWNER_ID = Convert.IsDBNull(oRow["T_CATEGORY_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Teacher_category> Get_Teacher_category_By_TEACHER_ID_Adv ( Int32? TEACHER_ID)
{
List<Teacher_category> oList = new List<Teacher_category>();
dynamic p = new ExpandoObject();
p.TEACHER_ID = TEACHER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_CATEGORY_BY_TEACHER_ID_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_category o = new Teacher_category();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Category = new Category();
o.My_Category.CATEGORY_ID = Convert.IsDBNull(oRow["T_CATEGORY_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_CATEGORY_ID"]);o.My_Category.NAME = Convert.IsDBNull(oRow["T_CATEGORY_NAME"]) ? default : Convert.ToString(oRow["T_CATEGORY_NAME"]);o.My_Category.DECRIPTION = Convert.IsDBNull(oRow["T_CATEGORY_DECRIPTION"]) ? default : Convert.ToString(oRow["T_CATEGORY_DECRIPTION"]);o.My_Category.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_CATEGORY_ENTRY_USER_ID"]);o.My_Category.ENTRY_DATE = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_CATEGORY_ENTRY_DATE"]);o.My_Category.OWNER_ID = Convert.IsDBNull(oRow["T_CATEGORY_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Teacher_category> Get_Teacher_category_By_CATEGORY_ID_Adv ( Int32? CATEGORY_ID)
{
List<Teacher_category> oList = new List<Teacher_category>();
dynamic p = new ExpandoObject();
p.CATEGORY_ID = CATEGORY_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_CATEGORY_BY_CATEGORY_ID_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_category o = new Teacher_category();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Category = new Category();
o.My_Category.CATEGORY_ID = Convert.IsDBNull(oRow["T_CATEGORY_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_CATEGORY_ID"]);o.My_Category.NAME = Convert.IsDBNull(oRow["T_CATEGORY_NAME"]) ? default : Convert.ToString(oRow["T_CATEGORY_NAME"]);o.My_Category.DECRIPTION = Convert.IsDBNull(oRow["T_CATEGORY_DECRIPTION"]) ? default : Convert.ToString(oRow["T_CATEGORY_DECRIPTION"]);o.My_Category.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_CATEGORY_ENTRY_USER_ID"]);o.My_Category.ENTRY_DATE = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_CATEGORY_ENTRY_DATE"]);o.My_Category.OWNER_ID = Convert.IsDBNull(oRow["T_CATEGORY_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Teacher_favorite> Get_Teacher_favorite_By_OWNER_ID_Adv ( Int32? OWNER_ID)
{
List<Teacher_favorite> oList = new List<Teacher_favorite>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_FAVORITE_BY_OWNER_ID_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_favorite o = new Teacher_favorite();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Teacher_favorite> Get_Teacher_favorite_By_TEACHER_ID_Adv ( Int32? TEACHER_ID)
{
List<Teacher_favorite> oList = new List<Teacher_favorite>();
dynamic p = new ExpandoObject();
p.TEACHER_ID = TEACHER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_FAVORITE_BY_TEACHER_ID_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_favorite o = new Teacher_favorite();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Teacher_favorite> Get_Teacher_favorite_By_STUDENT_ID_Adv ( Int32? STUDENT_ID)
{
List<Teacher_favorite> oList = new List<Teacher_favorite>();
dynamic p = new ExpandoObject();
p.STUDENT_ID = STUDENT_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_FAVORITE_BY_STUDENT_ID_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_favorite o = new Teacher_favorite();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Teacher_rank> Get_Teacher_rank_By_TEACHER_ID_Adv ( Int32? TEACHER_ID)
{
List<Teacher_rank> oList = new List<Teacher_rank>();
dynamic p = new ExpandoObject();
p.TEACHER_ID = TEACHER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_RANK_BY_TEACHER_ID_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_rank o = new Teacher_rank();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Teacher_rank> Get_Teacher_rank_By_OWNER_ID_Adv ( Int32? OWNER_ID)
{
List<Teacher_rank> oList = new List<Teacher_rank>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_RANK_BY_OWNER_ID_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_rank o = new Teacher_rank();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Teacher_report> Get_Teacher_report_By_OWNER_ID_Adv ( Int32? OWNER_ID)
{
List<Teacher_report> oList = new List<Teacher_report>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_REPORT_BY_OWNER_ID_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_report o = new Teacher_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Teacher_report> Get_Teacher_report_By_TEACHER_ID_Adv ( Int32? TEACHER_ID)
{
List<Teacher_report> oList = new List<Teacher_report>();
dynamic p = new ExpandoObject();
p.TEACHER_ID = TEACHER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_REPORT_BY_TEACHER_ID_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_report o = new Teacher_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Teacher_report> Get_Teacher_report_By_STUDENT_ID_Adv ( Int32? STUDENT_ID)
{
List<Teacher_report> oList = new List<Teacher_report>();
dynamic p = new ExpandoObject();
p.STUDENT_ID = STUDENT_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_REPORT_BY_STUDENT_ID_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_report o = new Teacher_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<User> Get_User_By_OWNER_ID_Adv ( Int32? OWNER_ID)
{
List<User> oList = new List<User>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_USER_BY_OWNER_ID_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
User o = new User();
oTools.CopyPropValues_FromDataRecord(oRow, o);

oList.Add(o);
}
}
return oList;
}
public List<User> Get_User_By_USERNAME_Adv ( string USERNAME)
{
List<User> oList = new List<User>();
dynamic p = new ExpandoObject();
p.USERNAME = USERNAME;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_USER_BY_USERNAME_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
User o = new User();
oTools.CopyPropValues_FromDataRecord(oRow, o);

oList.Add(o);
}
}
return oList;
}
public List<Answer> Get_Answer_By_QUESTION_ID_List ( List<Int32?> QUESTION_ID_LIST)
{
List<Answer> oList = new List<Answer>();
dynamic p = new ExpandoObject();
p.QUESTION_ID_LIST = string.Join(",", QUESTION_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_ANSWER_BY_QUESTION_ID_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Answer o = new Answer();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Answer> Get_Answer_By_TEACHER_ID_List ( List<Int32?> TEACHER_ID_LIST)
{
List<Answer> oList = new List<Answer>();
dynamic p = new ExpandoObject();
p.TEACHER_ID_LIST = string.Join(",", TEACHER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_ANSWER_BY_TEACHER_ID_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Answer o = new Answer();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Answer_report> Get_Answer_report_By_TEACHER_ID_List ( List<Int32?> TEACHER_ID_LIST)
{
List<Answer_report> oList = new List<Answer_report>();
dynamic p = new ExpandoObject();
p.TEACHER_ID_LIST = string.Join(",", TEACHER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_ANSWER_REPORT_BY_TEACHER_ID_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Answer_report o = new Answer_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Answer_report> Get_Answer_report_By_STUDENT_ID_List ( List<Int32?> STUDENT_ID_LIST)
{
List<Answer_report> oList = new List<Answer_report>();
dynamic p = new ExpandoObject();
p.STUDENT_ID_LIST = string.Join(",", STUDENT_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_ANSWER_REPORT_BY_STUDENT_ID_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Answer_report o = new Answer_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Answer_report> Get_Answer_report_By_ANSWER_ID_List ( List<Int32?> ANSWER_ID_LIST)
{
List<Answer_report> oList = new List<Answer_report>();
dynamic p = new ExpandoObject();
p.ANSWER_ID_LIST = string.Join(",", ANSWER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_ANSWER_REPORT_BY_ANSWER_ID_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Answer_report o = new Answer_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Appreciate> Get_Appreciate_By_ARTICLE_ID_List ( List<Int32?> ARTICLE_ID_LIST)
{
List<Appreciate> oList = new List<Appreciate>();
dynamic p = new ExpandoObject();
p.ARTICLE_ID_LIST = string.Join(",", ARTICLE_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_APPRECIATE_BY_ARTICLE_ID_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Appreciate o = new Appreciate();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Appreciate> Get_Appreciate_By_STUDENT_ID_List ( List<Int32?> STUDENT_ID_LIST)
{
List<Appreciate> oList = new List<Appreciate>();
dynamic p = new ExpandoObject();
p.STUDENT_ID_LIST = string.Join(",", STUDENT_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_APPRECIATE_BY_STUDENT_ID_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Appreciate o = new Appreciate();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Article> Get_Article_By_TEACHER_ID_List ( List<Int32?> TEACHER_ID_LIST)
{
List<Article> oList = new List<Article>();
dynamic p = new ExpandoObject();
p.TEACHER_ID_LIST = string.Join(",", TEACHER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_ARTICLE_BY_TEACHER_ID_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Article o = new Article();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Article> Get_Article_By_CATEGORY_ID_List ( List<Int32?> CATEGORY_ID_LIST)
{
List<Article> oList = new List<Article>();
dynamic p = new ExpandoObject();
p.CATEGORY_ID_LIST = string.Join(",", CATEGORY_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_ARTICLE_BY_CATEGORY_ID_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Article o = new Article();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Evaluation> Get_Evaluation_By_STUDENT_ID_List ( List<Int32?> STUDENT_ID_LIST)
{
List<Evaluation> oList = new List<Evaluation>();
dynamic p = new ExpandoObject();
p.STUDENT_ID_LIST = string.Join(",", STUDENT_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_EVALUATION_BY_STUDENT_ID_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Evaluation o = new Evaluation();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Evaluation> Get_Evaluation_By_ANSWER_ID_List ( List<Int32?> ANSWER_ID_LIST)
{
List<Evaluation> oList = new List<Evaluation>();
dynamic p = new ExpandoObject();
p.ANSWER_ID_LIST = string.Join(",", ANSWER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_EVALUATION_BY_ANSWER_ID_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Evaluation o = new Evaluation();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Favorite_category> Get_Favorite_category_By_STUDENT_ID_List ( List<Int32?> STUDENT_ID_LIST)
{
List<Favorite_category> oList = new List<Favorite_category>();
dynamic p = new ExpandoObject();
p.STUDENT_ID_LIST = string.Join(",", STUDENT_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_FAVORITE_CATEGORY_BY_STUDENT_ID_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Favorite_category o = new Favorite_category();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Favorite_category> Get_Favorite_category_By_CATEGORY_ID_List ( List<Int32?> CATEGORY_ID_LIST)
{
List<Favorite_category> oList = new List<Favorite_category>();
dynamic p = new ExpandoObject();
p.CATEGORY_ID_LIST = string.Join(",", CATEGORY_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_FAVORITE_CATEGORY_BY_CATEGORY_ID_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Favorite_category o = new Favorite_category();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Favorite_teacher> Get_Favorite_teacher_By_TEACHER_ID_List ( List<Int32?> TEACHER_ID_LIST)
{
List<Favorite_teacher> oList = new List<Favorite_teacher>();
dynamic p = new ExpandoObject();
p.TEACHER_ID_LIST = string.Join(",", TEACHER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_FAVORITE_TEACHER_BY_TEACHER_ID_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Favorite_teacher o = new Favorite_teacher();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Favorite_teacher> Get_Favorite_teacher_By_STUDENT_ID_List ( List<Int32?> STUDENT_ID_LIST)
{
List<Favorite_teacher> oList = new List<Favorite_teacher>();
dynamic p = new ExpandoObject();
p.STUDENT_ID_LIST = string.Join(",", STUDENT_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_FAVORITE_TEACHER_BY_STUDENT_ID_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Favorite_teacher o = new Favorite_teacher();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Mark_question> Get_Mark_question_By_QUESTION_ID_List ( List<Int32?> QUESTION_ID_LIST)
{
List<Mark_question> oList = new List<Mark_question>();
dynamic p = new ExpandoObject();
p.QUESTION_ID_LIST = string.Join(",", QUESTION_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_MARK_QUESTION_BY_QUESTION_ID_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Mark_question o = new Mark_question();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Mark_question> Get_Mark_question_By_STUDENT_ID_List ( List<Int32?> STUDENT_ID_LIST)
{
List<Mark_question> oList = new List<Mark_question>();
dynamic p = new ExpandoObject();
p.STUDENT_ID_LIST = string.Join(",", STUDENT_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_MARK_QUESTION_BY_STUDENT_ID_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Mark_question o = new Mark_question();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Notification> Get_Notification_By_USER_ID_List ( List<Int32?> USER_ID_LIST)
{
List<Notification> oList = new List<Notification>();
dynamic p = new ExpandoObject();
p.USER_ID_LIST = string.Join(",", USER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_NOTIFICATION_BY_USER_ID_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Notification o = new Notification();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Notification> Get_Notification_By_QUESTION_ID_List ( List<Int32?> QUESTION_ID_LIST)
{
List<Notification> oList = new List<Notification>();
dynamic p = new ExpandoObject();
p.QUESTION_ID_LIST = string.Join(",", QUESTION_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_NOTIFICATION_BY_QUESTION_ID_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Notification o = new Notification();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Notification> Get_Notification_By_ANSWER_ID_List ( List<Int32?> ANSWER_ID_LIST)
{
List<Notification> oList = new List<Notification>();
dynamic p = new ExpandoObject();
p.ANSWER_ID_LIST = string.Join(",", ANSWER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_NOTIFICATION_BY_ANSWER_ID_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Notification o = new Notification();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Question> Get_Question_By_STUDENT_ID_List ( List<Int32?> STUDENT_ID_LIST)
{
List<Question> oList = new List<Question>();
dynamic p = new ExpandoObject();
p.STUDENT_ID_LIST = string.Join(",", STUDENT_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_QUESTION_BY_STUDENT_ID_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Question o = new Question();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Question> Get_Question_By_CATEGORY_ID_List ( List<Int32?> CATEGORY_ID_LIST)
{
List<Question> oList = new List<Question>();
dynamic p = new ExpandoObject();
p.CATEGORY_ID_LIST = string.Join(",", CATEGORY_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_QUESTION_BY_CATEGORY_ID_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Question o = new Question();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Question> Get_Question_By_TEACHER_ID_List ( List<Int32?> TEACHER_ID_LIST)
{
List<Question> oList = new List<Question>();
dynamic p = new ExpandoObject();
p.TEACHER_ID_LIST = string.Join(",", TEACHER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_QUESTION_BY_TEACHER_ID_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Question o = new Question();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Question_report> Get_Question_report_By_STUDENT_ID_List ( List<Int32?> STUDENT_ID_LIST)
{
List<Question_report> oList = new List<Question_report>();
dynamic p = new ExpandoObject();
p.STUDENT_ID_LIST = string.Join(",", STUDENT_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_QUESTION_REPORT_BY_STUDENT_ID_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Question_report o = new Question_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Question_report> Get_Question_report_By_TEACHER_ID_List ( List<Int32?> TEACHER_ID_LIST)
{
List<Question_report> oList = new List<Question_report>();
dynamic p = new ExpandoObject();
p.TEACHER_ID_LIST = string.Join(",", TEACHER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_QUESTION_REPORT_BY_TEACHER_ID_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Question_report o = new Question_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Question_report> Get_Question_report_By_QUESTION_ID_List ( List<Int32?> QUESTION_ID_LIST)
{
List<Question_report> oList = new List<Question_report>();
dynamic p = new ExpandoObject();
p.QUESTION_ID_LIST = string.Join(",", QUESTION_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_QUESTION_REPORT_BY_QUESTION_ID_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Question_report o = new Question_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Question_token> Get_Question_token_By_QUESTION_ID_List ( List<long?> QUESTION_ID_LIST)
{
List<Question_token> oList = new List<Question_token>();
dynamic p = new ExpandoObject();
p.QUESTION_ID_LIST = string.Join(",", QUESTION_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_QUESTION_TOKEN_BY_QUESTION_ID_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Question_token o = new Question_token();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Report_article> Get_Report_article_By_ARTICLE_ID_List ( List<Int32?> ARTICLE_ID_LIST)
{
List<Report_article> oList = new List<Report_article>();
dynamic p = new ExpandoObject();
p.ARTICLE_ID_LIST = string.Join(",", ARTICLE_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_REPORT_ARTICLE_BY_ARTICLE_ID_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Report_article o = new Report_article();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Report_article> Get_Report_article_By_STUDENT_ID_List ( List<Int32?> STUDENT_ID_LIST)
{
List<Report_article> oList = new List<Report_article>();
dynamic p = new ExpandoObject();
p.STUDENT_ID_LIST = string.Join(",", STUDENT_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_REPORT_ARTICLE_BY_STUDENT_ID_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Report_article o = new Report_article();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Student> Get_Student_By_USER_ID_List ( List<Int32?> USER_ID_LIST)
{
List<Student> oList = new List<Student>();
dynamic p = new ExpandoObject();
p.USER_ID_LIST = string.Join(",", USER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_STUDENT_BY_USER_ID_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Student o = new Student();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Student_report> Get_Student_report_By_REPORTED_BY_STUDENT_ID_List ( List<Int32?> REPORTED_BY_STUDENT_ID_LIST)
{
List<Student_report> oList = new List<Student_report>();
dynamic p = new ExpandoObject();
p.REPORTED_BY_STUDENT_ID_LIST = string.Join(",", REPORTED_BY_STUDENT_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_STUDENT_REPORT_BY_REPORTED_BY_STUDENT_ID_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Student_report o = new Student_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Student_report> Get_Student_report_By_REPORTED_STUDENT_ID_List ( List<Int32?> REPORTED_STUDENT_ID_LIST)
{
List<Student_report> oList = new List<Student_report>();
dynamic p = new ExpandoObject();
p.REPORTED_STUDENT_ID_LIST = string.Join(",", REPORTED_STUDENT_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_STUDENT_REPORT_BY_REPORTED_STUDENT_ID_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Student_report o = new Student_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Teacher> Get_Teacher_By_USER_ID_List ( List<Int32?> USER_ID_LIST)
{
List<Teacher> oList = new List<Teacher>();
dynamic p = new ExpandoObject();
p.USER_ID_LIST = string.Join(",", USER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_BY_USER_ID_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher o = new Teacher();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Teacher_category> Get_Teacher_category_By_TEACHER_ID_List ( List<Int32?> TEACHER_ID_LIST)
{
List<Teacher_category> oList = new List<Teacher_category>();
dynamic p = new ExpandoObject();
p.TEACHER_ID_LIST = string.Join(",", TEACHER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_CATEGORY_BY_TEACHER_ID_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_category o = new Teacher_category();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Teacher_category> Get_Teacher_category_By_CATEGORY_ID_List ( List<Int32?> CATEGORY_ID_LIST)
{
List<Teacher_category> oList = new List<Teacher_category>();
dynamic p = new ExpandoObject();
p.CATEGORY_ID_LIST = string.Join(",", CATEGORY_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_CATEGORY_BY_CATEGORY_ID_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_category o = new Teacher_category();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Teacher_favorite> Get_Teacher_favorite_By_TEACHER_ID_List ( List<Int32?> TEACHER_ID_LIST)
{
List<Teacher_favorite> oList = new List<Teacher_favorite>();
dynamic p = new ExpandoObject();
p.TEACHER_ID_LIST = string.Join(",", TEACHER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_FAVORITE_BY_TEACHER_ID_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_favorite o = new Teacher_favorite();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Teacher_favorite> Get_Teacher_favorite_By_STUDENT_ID_List ( List<Int32?> STUDENT_ID_LIST)
{
List<Teacher_favorite> oList = new List<Teacher_favorite>();
dynamic p = new ExpandoObject();
p.STUDENT_ID_LIST = string.Join(",", STUDENT_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_FAVORITE_BY_STUDENT_ID_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_favorite o = new Teacher_favorite();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Teacher_rank> Get_Teacher_rank_By_TEACHER_ID_List ( List<Int32?> TEACHER_ID_LIST)
{
List<Teacher_rank> oList = new List<Teacher_rank>();
dynamic p = new ExpandoObject();
p.TEACHER_ID_LIST = string.Join(",", TEACHER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_RANK_BY_TEACHER_ID_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_rank o = new Teacher_rank();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Teacher_report> Get_Teacher_report_By_TEACHER_ID_List ( List<Int32?> TEACHER_ID_LIST)
{
List<Teacher_report> oList = new List<Teacher_report>();
dynamic p = new ExpandoObject();
p.TEACHER_ID_LIST = string.Join(",", TEACHER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_REPORT_BY_TEACHER_ID_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_report o = new Teacher_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Teacher_report> Get_Teacher_report_By_STUDENT_ID_List ( List<Int32?> STUDENT_ID_LIST)
{
List<Teacher_report> oList = new List<Teacher_report>();
dynamic p = new ExpandoObject();
p.STUDENT_ID_LIST = string.Join(",", STUDENT_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_REPORT_BY_STUDENT_ID_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_report o = new Teacher_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
return oList;
}
public List<Answer> Get_Answer_By_QUESTION_ID_List_Adv ( List<Int32?> QUESTION_ID_LIST)
{
List<Answer> oList = new List<Answer>();
dynamic p = new ExpandoObject();
p.QUESTION_ID_LIST = string.Join(",", QUESTION_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_ANSWER_BY_QUESTION_ID_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Answer o = new Answer();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Question = new Question();
o.My_Question.QUESTION_ID = Convert.IsDBNull(oRow["T_QUESTION_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_QUESTION_ID"]);o.My_Question.STUDENT_ID = Convert.IsDBNull(oRow["T_QUESTION_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_STUDENT_ID"]);o.My_Question.CATEGORY_ID = Convert.IsDBNull(oRow["T_QUESTION_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_CATEGORY_ID"]);o.My_Question.TEACHER_ID = Convert.IsDBNull(oRow["T_QUESTION_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_TEACHER_ID"]);o.My_Question.DESCRIPTION = Convert.IsDBNull(oRow["T_QUESTION_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_QUESTION_DESCRIPTION"]);o.My_Question.IS_ANSWERED = Convert.IsDBNull(oRow["T_QUESTION_IS_ANSWERED"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ANSWERED"]);o.My_Question.IS_ACTIVE = Convert.IsDBNull(oRow["T_QUESTION_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ACTIVE"]);o.My_Question.REPORTS = Convert.IsDBNull(oRow["T_QUESTION_REPORTS"]) ? default : Convert.ToInt32(oRow["T_QUESTION_REPORTS"]);o.My_Question.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_QUESTION_ENTRY_USER_ID"]);o.My_Question.ENTRY_DATE = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_QUESTION_ENTRY_DATE"]);o.My_Question.OWNER_ID = Convert.IsDBNull(oRow["T_QUESTION_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_OWNER_ID"]);
o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Answer> Get_Answer_By_TEACHER_ID_List_Adv ( List<Int32?> TEACHER_ID_LIST)
{
List<Answer> oList = new List<Answer>();
dynamic p = new ExpandoObject();
p.TEACHER_ID_LIST = string.Join(",", TEACHER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_ANSWER_BY_TEACHER_ID_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Answer o = new Answer();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Question = new Question();
o.My_Question.QUESTION_ID = Convert.IsDBNull(oRow["T_QUESTION_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_QUESTION_ID"]);o.My_Question.STUDENT_ID = Convert.IsDBNull(oRow["T_QUESTION_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_STUDENT_ID"]);o.My_Question.CATEGORY_ID = Convert.IsDBNull(oRow["T_QUESTION_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_CATEGORY_ID"]);o.My_Question.TEACHER_ID = Convert.IsDBNull(oRow["T_QUESTION_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_TEACHER_ID"]);o.My_Question.DESCRIPTION = Convert.IsDBNull(oRow["T_QUESTION_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_QUESTION_DESCRIPTION"]);o.My_Question.IS_ANSWERED = Convert.IsDBNull(oRow["T_QUESTION_IS_ANSWERED"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ANSWERED"]);o.My_Question.IS_ACTIVE = Convert.IsDBNull(oRow["T_QUESTION_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ACTIVE"]);o.My_Question.REPORTS = Convert.IsDBNull(oRow["T_QUESTION_REPORTS"]) ? default : Convert.ToInt32(oRow["T_QUESTION_REPORTS"]);o.My_Question.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_QUESTION_ENTRY_USER_ID"]);o.My_Question.ENTRY_DATE = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_QUESTION_ENTRY_DATE"]);o.My_Question.OWNER_ID = Convert.IsDBNull(oRow["T_QUESTION_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_OWNER_ID"]);
o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Answer_report> Get_Answer_report_By_TEACHER_ID_List_Adv ( List<Int32?> TEACHER_ID_LIST)
{
List<Answer_report> oList = new List<Answer_report>();
dynamic p = new ExpandoObject();
p.TEACHER_ID_LIST = string.Join(",", TEACHER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_ANSWER_REPORT_BY_TEACHER_ID_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Answer_report o = new Answer_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
o.My_Answer = new Answer();
o.My_Answer.ANSWER_ID = Convert.IsDBNull(oRow["T_ANSWER_ANSWER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_ANSWER_ID"]);o.My_Answer.QUESTION_ID = Convert.IsDBNull(oRow["T_ANSWER_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_QUESTION_ID"]);o.My_Answer.TEACHER_ID = Convert.IsDBNull(oRow["T_ANSWER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_TEACHER_ID"]);o.My_Answer.DESCRIPTION = Convert.IsDBNull(oRow["T_ANSWER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_ANSWER_DESCRIPTION"]);o.My_Answer.SCORE = Convert.IsDBNull(oRow["T_ANSWER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_ANSWER_SCORE"]);o.My_Answer.REVIEWS = Convert.IsDBNull(oRow["T_ANSWER_REVIEWS"]) ? default : Convert.ToInt32(oRow["T_ANSWER_REVIEWS"]);o.My_Answer.REPORTS = Convert.IsDBNull(oRow["T_ANSWER_REPORTS"]) ? default : Convert.ToInt32(oRow["T_ANSWER_REPORTS"]);o.My_Answer.IS_ACTIVE = Convert.IsDBNull(oRow["T_ANSWER_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_ANSWER_IS_ACTIVE"]);o.My_Answer.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_ANSWER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_ANSWER_ENTRY_USER_ID"]);o.My_Answer.ENTRY_DATE = Convert.IsDBNull(oRow["T_ANSWER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_ANSWER_ENTRY_DATE"]);o.My_Answer.OWNER_ID = Convert.IsDBNull(oRow["T_ANSWER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Answer_report> Get_Answer_report_By_STUDENT_ID_List_Adv ( List<Int32?> STUDENT_ID_LIST)
{
List<Answer_report> oList = new List<Answer_report>();
dynamic p = new ExpandoObject();
p.STUDENT_ID_LIST = string.Join(",", STUDENT_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_ANSWER_REPORT_BY_STUDENT_ID_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Answer_report o = new Answer_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
o.My_Answer = new Answer();
o.My_Answer.ANSWER_ID = Convert.IsDBNull(oRow["T_ANSWER_ANSWER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_ANSWER_ID"]);o.My_Answer.QUESTION_ID = Convert.IsDBNull(oRow["T_ANSWER_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_QUESTION_ID"]);o.My_Answer.TEACHER_ID = Convert.IsDBNull(oRow["T_ANSWER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_TEACHER_ID"]);o.My_Answer.DESCRIPTION = Convert.IsDBNull(oRow["T_ANSWER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_ANSWER_DESCRIPTION"]);o.My_Answer.SCORE = Convert.IsDBNull(oRow["T_ANSWER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_ANSWER_SCORE"]);o.My_Answer.REVIEWS = Convert.IsDBNull(oRow["T_ANSWER_REVIEWS"]) ? default : Convert.ToInt32(oRow["T_ANSWER_REVIEWS"]);o.My_Answer.REPORTS = Convert.IsDBNull(oRow["T_ANSWER_REPORTS"]) ? default : Convert.ToInt32(oRow["T_ANSWER_REPORTS"]);o.My_Answer.IS_ACTIVE = Convert.IsDBNull(oRow["T_ANSWER_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_ANSWER_IS_ACTIVE"]);o.My_Answer.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_ANSWER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_ANSWER_ENTRY_USER_ID"]);o.My_Answer.ENTRY_DATE = Convert.IsDBNull(oRow["T_ANSWER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_ANSWER_ENTRY_DATE"]);o.My_Answer.OWNER_ID = Convert.IsDBNull(oRow["T_ANSWER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Answer_report> Get_Answer_report_By_ANSWER_ID_List_Adv ( List<Int32?> ANSWER_ID_LIST)
{
List<Answer_report> oList = new List<Answer_report>();
dynamic p = new ExpandoObject();
p.ANSWER_ID_LIST = string.Join(",", ANSWER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_ANSWER_REPORT_BY_ANSWER_ID_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Answer_report o = new Answer_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
o.My_Answer = new Answer();
o.My_Answer.ANSWER_ID = Convert.IsDBNull(oRow["T_ANSWER_ANSWER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_ANSWER_ID"]);o.My_Answer.QUESTION_ID = Convert.IsDBNull(oRow["T_ANSWER_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_QUESTION_ID"]);o.My_Answer.TEACHER_ID = Convert.IsDBNull(oRow["T_ANSWER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_TEACHER_ID"]);o.My_Answer.DESCRIPTION = Convert.IsDBNull(oRow["T_ANSWER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_ANSWER_DESCRIPTION"]);o.My_Answer.SCORE = Convert.IsDBNull(oRow["T_ANSWER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_ANSWER_SCORE"]);o.My_Answer.REVIEWS = Convert.IsDBNull(oRow["T_ANSWER_REVIEWS"]) ? default : Convert.ToInt32(oRow["T_ANSWER_REVIEWS"]);o.My_Answer.REPORTS = Convert.IsDBNull(oRow["T_ANSWER_REPORTS"]) ? default : Convert.ToInt32(oRow["T_ANSWER_REPORTS"]);o.My_Answer.IS_ACTIVE = Convert.IsDBNull(oRow["T_ANSWER_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_ANSWER_IS_ACTIVE"]);o.My_Answer.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_ANSWER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_ANSWER_ENTRY_USER_ID"]);o.My_Answer.ENTRY_DATE = Convert.IsDBNull(oRow["T_ANSWER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_ANSWER_ENTRY_DATE"]);o.My_Answer.OWNER_ID = Convert.IsDBNull(oRow["T_ANSWER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Appreciate> Get_Appreciate_By_ARTICLE_ID_List_Adv ( List<Int32?> ARTICLE_ID_LIST)
{
List<Appreciate> oList = new List<Appreciate>();
dynamic p = new ExpandoObject();
p.ARTICLE_ID_LIST = string.Join(",", ARTICLE_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_APPRECIATE_BY_ARTICLE_ID_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Appreciate o = new Appreciate();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Article = new Article();
o.My_Article.ARTICLE_ID = Convert.IsDBNull(oRow["T_ARTICLE_ARTICLE_ID"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_ARTICLE_ID"]);o.My_Article.TEACHER_ID = Convert.IsDBNull(oRow["T_ARTICLE_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_TEACHER_ID"]);o.My_Article.CATEGORY_ID = Convert.IsDBNull(oRow["T_ARTICLE_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_CATEGORY_ID"]);o.My_Article.TITLE = Convert.IsDBNull(oRow["T_ARTICLE_TITLE"]) ? default : Convert.ToString(oRow["T_ARTICLE_TITLE"]);o.My_Article.DESCRIPTION = Convert.IsDBNull(oRow["T_ARTICLE_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_ARTICLE_DESCRIPTION"]);o.My_Article.APPLAUDS = Convert.IsDBNull(oRow["T_ARTICLE_APPLAUDS"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_APPLAUDS"]);o.My_Article.REPORTS = Convert.IsDBNull(oRow["T_ARTICLE_REPORTS"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_REPORTS"]);o.My_Article.IS_BLOCKED = Convert.IsDBNull(oRow["T_ARTICLE_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_ARTICLE_IS_BLOCKED"]);o.My_Article.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_ARTICLE_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_ARTICLE_ENTRY_USER_ID"]);o.My_Article.ENTRY_DATE = Convert.IsDBNull(oRow["T_ARTICLE_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_ARTICLE_ENTRY_DATE"]);o.My_Article.OWNER_ID = Convert.IsDBNull(oRow["T_ARTICLE_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Appreciate> Get_Appreciate_By_STUDENT_ID_List_Adv ( List<Int32?> STUDENT_ID_LIST)
{
List<Appreciate> oList = new List<Appreciate>();
dynamic p = new ExpandoObject();
p.STUDENT_ID_LIST = string.Join(",", STUDENT_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_APPRECIATE_BY_STUDENT_ID_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Appreciate o = new Appreciate();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Article = new Article();
o.My_Article.ARTICLE_ID = Convert.IsDBNull(oRow["T_ARTICLE_ARTICLE_ID"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_ARTICLE_ID"]);o.My_Article.TEACHER_ID = Convert.IsDBNull(oRow["T_ARTICLE_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_TEACHER_ID"]);o.My_Article.CATEGORY_ID = Convert.IsDBNull(oRow["T_ARTICLE_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_CATEGORY_ID"]);o.My_Article.TITLE = Convert.IsDBNull(oRow["T_ARTICLE_TITLE"]) ? default : Convert.ToString(oRow["T_ARTICLE_TITLE"]);o.My_Article.DESCRIPTION = Convert.IsDBNull(oRow["T_ARTICLE_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_ARTICLE_DESCRIPTION"]);o.My_Article.APPLAUDS = Convert.IsDBNull(oRow["T_ARTICLE_APPLAUDS"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_APPLAUDS"]);o.My_Article.REPORTS = Convert.IsDBNull(oRow["T_ARTICLE_REPORTS"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_REPORTS"]);o.My_Article.IS_BLOCKED = Convert.IsDBNull(oRow["T_ARTICLE_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_ARTICLE_IS_BLOCKED"]);o.My_Article.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_ARTICLE_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_ARTICLE_ENTRY_USER_ID"]);o.My_Article.ENTRY_DATE = Convert.IsDBNull(oRow["T_ARTICLE_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_ARTICLE_ENTRY_DATE"]);o.My_Article.OWNER_ID = Convert.IsDBNull(oRow["T_ARTICLE_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Article> Get_Article_By_TEACHER_ID_List_Adv ( List<Int32?> TEACHER_ID_LIST)
{
List<Article> oList = new List<Article>();
dynamic p = new ExpandoObject();
p.TEACHER_ID_LIST = string.Join(",", TEACHER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_ARTICLE_BY_TEACHER_ID_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Article o = new Article();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Category = new Category();
o.My_Category.CATEGORY_ID = Convert.IsDBNull(oRow["T_CATEGORY_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_CATEGORY_ID"]);o.My_Category.NAME = Convert.IsDBNull(oRow["T_CATEGORY_NAME"]) ? default : Convert.ToString(oRow["T_CATEGORY_NAME"]);o.My_Category.DECRIPTION = Convert.IsDBNull(oRow["T_CATEGORY_DECRIPTION"]) ? default : Convert.ToString(oRow["T_CATEGORY_DECRIPTION"]);o.My_Category.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_CATEGORY_ENTRY_USER_ID"]);o.My_Category.ENTRY_DATE = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_CATEGORY_ENTRY_DATE"]);o.My_Category.OWNER_ID = Convert.IsDBNull(oRow["T_CATEGORY_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Article> Get_Article_By_CATEGORY_ID_List_Adv ( List<Int32?> CATEGORY_ID_LIST)
{
List<Article> oList = new List<Article>();
dynamic p = new ExpandoObject();
p.CATEGORY_ID_LIST = string.Join(",", CATEGORY_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_ARTICLE_BY_CATEGORY_ID_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Article o = new Article();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Category = new Category();
o.My_Category.CATEGORY_ID = Convert.IsDBNull(oRow["T_CATEGORY_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_CATEGORY_ID"]);o.My_Category.NAME = Convert.IsDBNull(oRow["T_CATEGORY_NAME"]) ? default : Convert.ToString(oRow["T_CATEGORY_NAME"]);o.My_Category.DECRIPTION = Convert.IsDBNull(oRow["T_CATEGORY_DECRIPTION"]) ? default : Convert.ToString(oRow["T_CATEGORY_DECRIPTION"]);o.My_Category.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_CATEGORY_ENTRY_USER_ID"]);o.My_Category.ENTRY_DATE = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_CATEGORY_ENTRY_DATE"]);o.My_Category.OWNER_ID = Convert.IsDBNull(oRow["T_CATEGORY_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Evaluation> Get_Evaluation_By_STUDENT_ID_List_Adv ( List<Int32?> STUDENT_ID_LIST)
{
List<Evaluation> oList = new List<Evaluation>();
dynamic p = new ExpandoObject();
p.STUDENT_ID_LIST = string.Join(",", STUDENT_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_EVALUATION_BY_STUDENT_ID_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Evaluation o = new Evaluation();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
o.My_Answer = new Answer();
o.My_Answer.ANSWER_ID = Convert.IsDBNull(oRow["T_ANSWER_ANSWER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_ANSWER_ID"]);o.My_Answer.QUESTION_ID = Convert.IsDBNull(oRow["T_ANSWER_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_QUESTION_ID"]);o.My_Answer.TEACHER_ID = Convert.IsDBNull(oRow["T_ANSWER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_TEACHER_ID"]);o.My_Answer.DESCRIPTION = Convert.IsDBNull(oRow["T_ANSWER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_ANSWER_DESCRIPTION"]);o.My_Answer.SCORE = Convert.IsDBNull(oRow["T_ANSWER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_ANSWER_SCORE"]);o.My_Answer.REVIEWS = Convert.IsDBNull(oRow["T_ANSWER_REVIEWS"]) ? default : Convert.ToInt32(oRow["T_ANSWER_REVIEWS"]);o.My_Answer.REPORTS = Convert.IsDBNull(oRow["T_ANSWER_REPORTS"]) ? default : Convert.ToInt32(oRow["T_ANSWER_REPORTS"]);o.My_Answer.IS_ACTIVE = Convert.IsDBNull(oRow["T_ANSWER_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_ANSWER_IS_ACTIVE"]);o.My_Answer.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_ANSWER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_ANSWER_ENTRY_USER_ID"]);o.My_Answer.ENTRY_DATE = Convert.IsDBNull(oRow["T_ANSWER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_ANSWER_ENTRY_DATE"]);o.My_Answer.OWNER_ID = Convert.IsDBNull(oRow["T_ANSWER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Evaluation> Get_Evaluation_By_ANSWER_ID_List_Adv ( List<Int32?> ANSWER_ID_LIST)
{
List<Evaluation> oList = new List<Evaluation>();
dynamic p = new ExpandoObject();
p.ANSWER_ID_LIST = string.Join(",", ANSWER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_EVALUATION_BY_ANSWER_ID_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Evaluation o = new Evaluation();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
o.My_Answer = new Answer();
o.My_Answer.ANSWER_ID = Convert.IsDBNull(oRow["T_ANSWER_ANSWER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_ANSWER_ID"]);o.My_Answer.QUESTION_ID = Convert.IsDBNull(oRow["T_ANSWER_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_QUESTION_ID"]);o.My_Answer.TEACHER_ID = Convert.IsDBNull(oRow["T_ANSWER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_TEACHER_ID"]);o.My_Answer.DESCRIPTION = Convert.IsDBNull(oRow["T_ANSWER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_ANSWER_DESCRIPTION"]);o.My_Answer.SCORE = Convert.IsDBNull(oRow["T_ANSWER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_ANSWER_SCORE"]);o.My_Answer.REVIEWS = Convert.IsDBNull(oRow["T_ANSWER_REVIEWS"]) ? default : Convert.ToInt32(oRow["T_ANSWER_REVIEWS"]);o.My_Answer.REPORTS = Convert.IsDBNull(oRow["T_ANSWER_REPORTS"]) ? default : Convert.ToInt32(oRow["T_ANSWER_REPORTS"]);o.My_Answer.IS_ACTIVE = Convert.IsDBNull(oRow["T_ANSWER_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_ANSWER_IS_ACTIVE"]);o.My_Answer.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_ANSWER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_ANSWER_ENTRY_USER_ID"]);o.My_Answer.ENTRY_DATE = Convert.IsDBNull(oRow["T_ANSWER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_ANSWER_ENTRY_DATE"]);o.My_Answer.OWNER_ID = Convert.IsDBNull(oRow["T_ANSWER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Favorite_category> Get_Favorite_category_By_STUDENT_ID_List_Adv ( List<Int32?> STUDENT_ID_LIST)
{
List<Favorite_category> oList = new List<Favorite_category>();
dynamic p = new ExpandoObject();
p.STUDENT_ID_LIST = string.Join(",", STUDENT_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_FAVORITE_CATEGORY_BY_STUDENT_ID_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Favorite_category o = new Favorite_category();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
o.My_Category = new Category();
o.My_Category.CATEGORY_ID = Convert.IsDBNull(oRow["T_CATEGORY_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_CATEGORY_ID"]);o.My_Category.NAME = Convert.IsDBNull(oRow["T_CATEGORY_NAME"]) ? default : Convert.ToString(oRow["T_CATEGORY_NAME"]);o.My_Category.DECRIPTION = Convert.IsDBNull(oRow["T_CATEGORY_DECRIPTION"]) ? default : Convert.ToString(oRow["T_CATEGORY_DECRIPTION"]);o.My_Category.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_CATEGORY_ENTRY_USER_ID"]);o.My_Category.ENTRY_DATE = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_CATEGORY_ENTRY_DATE"]);o.My_Category.OWNER_ID = Convert.IsDBNull(oRow["T_CATEGORY_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Favorite_category> Get_Favorite_category_By_CATEGORY_ID_List_Adv ( List<Int32?> CATEGORY_ID_LIST)
{
List<Favorite_category> oList = new List<Favorite_category>();
dynamic p = new ExpandoObject();
p.CATEGORY_ID_LIST = string.Join(",", CATEGORY_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_FAVORITE_CATEGORY_BY_CATEGORY_ID_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Favorite_category o = new Favorite_category();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
o.My_Category = new Category();
o.My_Category.CATEGORY_ID = Convert.IsDBNull(oRow["T_CATEGORY_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_CATEGORY_ID"]);o.My_Category.NAME = Convert.IsDBNull(oRow["T_CATEGORY_NAME"]) ? default : Convert.ToString(oRow["T_CATEGORY_NAME"]);o.My_Category.DECRIPTION = Convert.IsDBNull(oRow["T_CATEGORY_DECRIPTION"]) ? default : Convert.ToString(oRow["T_CATEGORY_DECRIPTION"]);o.My_Category.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_CATEGORY_ENTRY_USER_ID"]);o.My_Category.ENTRY_DATE = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_CATEGORY_ENTRY_DATE"]);o.My_Category.OWNER_ID = Convert.IsDBNull(oRow["T_CATEGORY_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Favorite_teacher> Get_Favorite_teacher_By_TEACHER_ID_List_Adv ( List<Int32?> TEACHER_ID_LIST)
{
List<Favorite_teacher> oList = new List<Favorite_teacher>();
dynamic p = new ExpandoObject();
p.TEACHER_ID_LIST = string.Join(",", TEACHER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_FAVORITE_TEACHER_BY_TEACHER_ID_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Favorite_teacher o = new Favorite_teacher();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Favorite_teacher> Get_Favorite_teacher_By_STUDENT_ID_List_Adv ( List<Int32?> STUDENT_ID_LIST)
{
List<Favorite_teacher> oList = new List<Favorite_teacher>();
dynamic p = new ExpandoObject();
p.STUDENT_ID_LIST = string.Join(",", STUDENT_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_FAVORITE_TEACHER_BY_STUDENT_ID_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Favorite_teacher o = new Favorite_teacher();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Mark_question> Get_Mark_question_By_QUESTION_ID_List_Adv ( List<Int32?> QUESTION_ID_LIST)
{
List<Mark_question> oList = new List<Mark_question>();
dynamic p = new ExpandoObject();
p.QUESTION_ID_LIST = string.Join(",", QUESTION_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_MARK_QUESTION_BY_QUESTION_ID_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Mark_question o = new Mark_question();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Question = new Question();
o.My_Question.QUESTION_ID = Convert.IsDBNull(oRow["T_QUESTION_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_QUESTION_ID"]);o.My_Question.STUDENT_ID = Convert.IsDBNull(oRow["T_QUESTION_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_STUDENT_ID"]);o.My_Question.CATEGORY_ID = Convert.IsDBNull(oRow["T_QUESTION_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_CATEGORY_ID"]);o.My_Question.TEACHER_ID = Convert.IsDBNull(oRow["T_QUESTION_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_TEACHER_ID"]);o.My_Question.DESCRIPTION = Convert.IsDBNull(oRow["T_QUESTION_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_QUESTION_DESCRIPTION"]);o.My_Question.IS_ANSWERED = Convert.IsDBNull(oRow["T_QUESTION_IS_ANSWERED"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ANSWERED"]);o.My_Question.IS_ACTIVE = Convert.IsDBNull(oRow["T_QUESTION_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ACTIVE"]);o.My_Question.REPORTS = Convert.IsDBNull(oRow["T_QUESTION_REPORTS"]) ? default : Convert.ToInt32(oRow["T_QUESTION_REPORTS"]);o.My_Question.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_QUESTION_ENTRY_USER_ID"]);o.My_Question.ENTRY_DATE = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_QUESTION_ENTRY_DATE"]);o.My_Question.OWNER_ID = Convert.IsDBNull(oRow["T_QUESTION_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Mark_question> Get_Mark_question_By_STUDENT_ID_List_Adv ( List<Int32?> STUDENT_ID_LIST)
{
List<Mark_question> oList = new List<Mark_question>();
dynamic p = new ExpandoObject();
p.STUDENT_ID_LIST = string.Join(",", STUDENT_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_MARK_QUESTION_BY_STUDENT_ID_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Mark_question o = new Mark_question();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Question = new Question();
o.My_Question.QUESTION_ID = Convert.IsDBNull(oRow["T_QUESTION_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_QUESTION_ID"]);o.My_Question.STUDENT_ID = Convert.IsDBNull(oRow["T_QUESTION_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_STUDENT_ID"]);o.My_Question.CATEGORY_ID = Convert.IsDBNull(oRow["T_QUESTION_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_CATEGORY_ID"]);o.My_Question.TEACHER_ID = Convert.IsDBNull(oRow["T_QUESTION_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_TEACHER_ID"]);o.My_Question.DESCRIPTION = Convert.IsDBNull(oRow["T_QUESTION_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_QUESTION_DESCRIPTION"]);o.My_Question.IS_ANSWERED = Convert.IsDBNull(oRow["T_QUESTION_IS_ANSWERED"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ANSWERED"]);o.My_Question.IS_ACTIVE = Convert.IsDBNull(oRow["T_QUESTION_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ACTIVE"]);o.My_Question.REPORTS = Convert.IsDBNull(oRow["T_QUESTION_REPORTS"]) ? default : Convert.ToInt32(oRow["T_QUESTION_REPORTS"]);o.My_Question.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_QUESTION_ENTRY_USER_ID"]);o.My_Question.ENTRY_DATE = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_QUESTION_ENTRY_DATE"]);o.My_Question.OWNER_ID = Convert.IsDBNull(oRow["T_QUESTION_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Notification> Get_Notification_By_USER_ID_List_Adv ( List<Int32?> USER_ID_LIST)
{
List<Notification> oList = new List<Notification>();
dynamic p = new ExpandoObject();
p.USER_ID_LIST = string.Join(",", USER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_NOTIFICATION_BY_USER_ID_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Notification o = new Notification();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_User = new User();
o.My_User.USER_ID = Convert.IsDBNull(oRow["T_USER_USER_ID"]) ? default : Convert.ToInt64(oRow["T_USER_USER_ID"]);o.My_User.OWNER_ID = Convert.IsDBNull(oRow["T_USER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_USER_OWNER_ID"]);o.My_User.USERNAME = Convert.IsDBNull(oRow["T_USER_USERNAME"]) ? default : Convert.ToString(oRow["T_USER_USERNAME"]);o.My_User.PASSWORD = Convert.IsDBNull(oRow["T_USER_PASSWORD"]) ? default : Convert.ToString(oRow["T_USER_PASSWORD"]);o.My_User.USER_TYPE_CODE = Convert.IsDBNull(oRow["T_USER_USER_TYPE_CODE"]) ? default : Convert.ToString(oRow["T_USER_USER_TYPE_CODE"]);o.My_User.IS_LOGGED_IN = Convert.IsDBNull(oRow["T_USER_IS_LOGGED_IN"]) ? default : Convert.ToBoolean(oRow["T_USER_IS_LOGGED_IN"]);o.My_User.IS_ACTIVE = Convert.IsDBNull(oRow["T_USER_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_USER_IS_ACTIVE"]);o.My_User.ENTRY_DATE = Convert.IsDBNull(oRow["T_USER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_USER_ENTRY_DATE"]);
o.My_Question = new Question();
o.My_Question.QUESTION_ID = Convert.IsDBNull(oRow["T_QUESTION_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_QUESTION_ID"]);o.My_Question.STUDENT_ID = Convert.IsDBNull(oRow["T_QUESTION_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_STUDENT_ID"]);o.My_Question.CATEGORY_ID = Convert.IsDBNull(oRow["T_QUESTION_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_CATEGORY_ID"]);o.My_Question.TEACHER_ID = Convert.IsDBNull(oRow["T_QUESTION_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_TEACHER_ID"]);o.My_Question.DESCRIPTION = Convert.IsDBNull(oRow["T_QUESTION_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_QUESTION_DESCRIPTION"]);o.My_Question.IS_ANSWERED = Convert.IsDBNull(oRow["T_QUESTION_IS_ANSWERED"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ANSWERED"]);o.My_Question.IS_ACTIVE = Convert.IsDBNull(oRow["T_QUESTION_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ACTIVE"]);o.My_Question.REPORTS = Convert.IsDBNull(oRow["T_QUESTION_REPORTS"]) ? default : Convert.ToInt32(oRow["T_QUESTION_REPORTS"]);o.My_Question.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_QUESTION_ENTRY_USER_ID"]);o.My_Question.ENTRY_DATE = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_QUESTION_ENTRY_DATE"]);o.My_Question.OWNER_ID = Convert.IsDBNull(oRow["T_QUESTION_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_OWNER_ID"]);
o.My_Answer = new Answer();
o.My_Answer.ANSWER_ID = Convert.IsDBNull(oRow["T_ANSWER_ANSWER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_ANSWER_ID"]);o.My_Answer.QUESTION_ID = Convert.IsDBNull(oRow["T_ANSWER_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_QUESTION_ID"]);o.My_Answer.TEACHER_ID = Convert.IsDBNull(oRow["T_ANSWER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_TEACHER_ID"]);o.My_Answer.DESCRIPTION = Convert.IsDBNull(oRow["T_ANSWER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_ANSWER_DESCRIPTION"]);o.My_Answer.SCORE = Convert.IsDBNull(oRow["T_ANSWER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_ANSWER_SCORE"]);o.My_Answer.REVIEWS = Convert.IsDBNull(oRow["T_ANSWER_REVIEWS"]) ? default : Convert.ToInt32(oRow["T_ANSWER_REVIEWS"]);o.My_Answer.REPORTS = Convert.IsDBNull(oRow["T_ANSWER_REPORTS"]) ? default : Convert.ToInt32(oRow["T_ANSWER_REPORTS"]);o.My_Answer.IS_ACTIVE = Convert.IsDBNull(oRow["T_ANSWER_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_ANSWER_IS_ACTIVE"]);o.My_Answer.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_ANSWER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_ANSWER_ENTRY_USER_ID"]);o.My_Answer.ENTRY_DATE = Convert.IsDBNull(oRow["T_ANSWER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_ANSWER_ENTRY_DATE"]);o.My_Answer.OWNER_ID = Convert.IsDBNull(oRow["T_ANSWER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Notification> Get_Notification_By_QUESTION_ID_List_Adv ( List<Int32?> QUESTION_ID_LIST)
{
List<Notification> oList = new List<Notification>();
dynamic p = new ExpandoObject();
p.QUESTION_ID_LIST = string.Join(",", QUESTION_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_NOTIFICATION_BY_QUESTION_ID_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Notification o = new Notification();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_User = new User();
o.My_User.USER_ID = Convert.IsDBNull(oRow["T_USER_USER_ID"]) ? default : Convert.ToInt64(oRow["T_USER_USER_ID"]);o.My_User.OWNER_ID = Convert.IsDBNull(oRow["T_USER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_USER_OWNER_ID"]);o.My_User.USERNAME = Convert.IsDBNull(oRow["T_USER_USERNAME"]) ? default : Convert.ToString(oRow["T_USER_USERNAME"]);o.My_User.PASSWORD = Convert.IsDBNull(oRow["T_USER_PASSWORD"]) ? default : Convert.ToString(oRow["T_USER_PASSWORD"]);o.My_User.USER_TYPE_CODE = Convert.IsDBNull(oRow["T_USER_USER_TYPE_CODE"]) ? default : Convert.ToString(oRow["T_USER_USER_TYPE_CODE"]);o.My_User.IS_LOGGED_IN = Convert.IsDBNull(oRow["T_USER_IS_LOGGED_IN"]) ? default : Convert.ToBoolean(oRow["T_USER_IS_LOGGED_IN"]);o.My_User.IS_ACTIVE = Convert.IsDBNull(oRow["T_USER_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_USER_IS_ACTIVE"]);o.My_User.ENTRY_DATE = Convert.IsDBNull(oRow["T_USER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_USER_ENTRY_DATE"]);
o.My_Question = new Question();
o.My_Question.QUESTION_ID = Convert.IsDBNull(oRow["T_QUESTION_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_QUESTION_ID"]);o.My_Question.STUDENT_ID = Convert.IsDBNull(oRow["T_QUESTION_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_STUDENT_ID"]);o.My_Question.CATEGORY_ID = Convert.IsDBNull(oRow["T_QUESTION_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_CATEGORY_ID"]);o.My_Question.TEACHER_ID = Convert.IsDBNull(oRow["T_QUESTION_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_TEACHER_ID"]);o.My_Question.DESCRIPTION = Convert.IsDBNull(oRow["T_QUESTION_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_QUESTION_DESCRIPTION"]);o.My_Question.IS_ANSWERED = Convert.IsDBNull(oRow["T_QUESTION_IS_ANSWERED"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ANSWERED"]);o.My_Question.IS_ACTIVE = Convert.IsDBNull(oRow["T_QUESTION_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ACTIVE"]);o.My_Question.REPORTS = Convert.IsDBNull(oRow["T_QUESTION_REPORTS"]) ? default : Convert.ToInt32(oRow["T_QUESTION_REPORTS"]);o.My_Question.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_QUESTION_ENTRY_USER_ID"]);o.My_Question.ENTRY_DATE = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_QUESTION_ENTRY_DATE"]);o.My_Question.OWNER_ID = Convert.IsDBNull(oRow["T_QUESTION_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_OWNER_ID"]);
o.My_Answer = new Answer();
o.My_Answer.ANSWER_ID = Convert.IsDBNull(oRow["T_ANSWER_ANSWER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_ANSWER_ID"]);o.My_Answer.QUESTION_ID = Convert.IsDBNull(oRow["T_ANSWER_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_QUESTION_ID"]);o.My_Answer.TEACHER_ID = Convert.IsDBNull(oRow["T_ANSWER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_TEACHER_ID"]);o.My_Answer.DESCRIPTION = Convert.IsDBNull(oRow["T_ANSWER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_ANSWER_DESCRIPTION"]);o.My_Answer.SCORE = Convert.IsDBNull(oRow["T_ANSWER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_ANSWER_SCORE"]);o.My_Answer.REVIEWS = Convert.IsDBNull(oRow["T_ANSWER_REVIEWS"]) ? default : Convert.ToInt32(oRow["T_ANSWER_REVIEWS"]);o.My_Answer.REPORTS = Convert.IsDBNull(oRow["T_ANSWER_REPORTS"]) ? default : Convert.ToInt32(oRow["T_ANSWER_REPORTS"]);o.My_Answer.IS_ACTIVE = Convert.IsDBNull(oRow["T_ANSWER_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_ANSWER_IS_ACTIVE"]);o.My_Answer.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_ANSWER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_ANSWER_ENTRY_USER_ID"]);o.My_Answer.ENTRY_DATE = Convert.IsDBNull(oRow["T_ANSWER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_ANSWER_ENTRY_DATE"]);o.My_Answer.OWNER_ID = Convert.IsDBNull(oRow["T_ANSWER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Notification> Get_Notification_By_ANSWER_ID_List_Adv ( List<Int32?> ANSWER_ID_LIST)
{
List<Notification> oList = new List<Notification>();
dynamic p = new ExpandoObject();
p.ANSWER_ID_LIST = string.Join(",", ANSWER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_NOTIFICATION_BY_ANSWER_ID_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Notification o = new Notification();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_User = new User();
o.My_User.USER_ID = Convert.IsDBNull(oRow["T_USER_USER_ID"]) ? default : Convert.ToInt64(oRow["T_USER_USER_ID"]);o.My_User.OWNER_ID = Convert.IsDBNull(oRow["T_USER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_USER_OWNER_ID"]);o.My_User.USERNAME = Convert.IsDBNull(oRow["T_USER_USERNAME"]) ? default : Convert.ToString(oRow["T_USER_USERNAME"]);o.My_User.PASSWORD = Convert.IsDBNull(oRow["T_USER_PASSWORD"]) ? default : Convert.ToString(oRow["T_USER_PASSWORD"]);o.My_User.USER_TYPE_CODE = Convert.IsDBNull(oRow["T_USER_USER_TYPE_CODE"]) ? default : Convert.ToString(oRow["T_USER_USER_TYPE_CODE"]);o.My_User.IS_LOGGED_IN = Convert.IsDBNull(oRow["T_USER_IS_LOGGED_IN"]) ? default : Convert.ToBoolean(oRow["T_USER_IS_LOGGED_IN"]);o.My_User.IS_ACTIVE = Convert.IsDBNull(oRow["T_USER_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_USER_IS_ACTIVE"]);o.My_User.ENTRY_DATE = Convert.IsDBNull(oRow["T_USER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_USER_ENTRY_DATE"]);
o.My_Question = new Question();
o.My_Question.QUESTION_ID = Convert.IsDBNull(oRow["T_QUESTION_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_QUESTION_ID"]);o.My_Question.STUDENT_ID = Convert.IsDBNull(oRow["T_QUESTION_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_STUDENT_ID"]);o.My_Question.CATEGORY_ID = Convert.IsDBNull(oRow["T_QUESTION_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_CATEGORY_ID"]);o.My_Question.TEACHER_ID = Convert.IsDBNull(oRow["T_QUESTION_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_TEACHER_ID"]);o.My_Question.DESCRIPTION = Convert.IsDBNull(oRow["T_QUESTION_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_QUESTION_DESCRIPTION"]);o.My_Question.IS_ANSWERED = Convert.IsDBNull(oRow["T_QUESTION_IS_ANSWERED"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ANSWERED"]);o.My_Question.IS_ACTIVE = Convert.IsDBNull(oRow["T_QUESTION_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ACTIVE"]);o.My_Question.REPORTS = Convert.IsDBNull(oRow["T_QUESTION_REPORTS"]) ? default : Convert.ToInt32(oRow["T_QUESTION_REPORTS"]);o.My_Question.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_QUESTION_ENTRY_USER_ID"]);o.My_Question.ENTRY_DATE = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_QUESTION_ENTRY_DATE"]);o.My_Question.OWNER_ID = Convert.IsDBNull(oRow["T_QUESTION_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_OWNER_ID"]);
o.My_Answer = new Answer();
o.My_Answer.ANSWER_ID = Convert.IsDBNull(oRow["T_ANSWER_ANSWER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_ANSWER_ID"]);o.My_Answer.QUESTION_ID = Convert.IsDBNull(oRow["T_ANSWER_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_QUESTION_ID"]);o.My_Answer.TEACHER_ID = Convert.IsDBNull(oRow["T_ANSWER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_TEACHER_ID"]);o.My_Answer.DESCRIPTION = Convert.IsDBNull(oRow["T_ANSWER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_ANSWER_DESCRIPTION"]);o.My_Answer.SCORE = Convert.IsDBNull(oRow["T_ANSWER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_ANSWER_SCORE"]);o.My_Answer.REVIEWS = Convert.IsDBNull(oRow["T_ANSWER_REVIEWS"]) ? default : Convert.ToInt32(oRow["T_ANSWER_REVIEWS"]);o.My_Answer.REPORTS = Convert.IsDBNull(oRow["T_ANSWER_REPORTS"]) ? default : Convert.ToInt32(oRow["T_ANSWER_REPORTS"]);o.My_Answer.IS_ACTIVE = Convert.IsDBNull(oRow["T_ANSWER_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_ANSWER_IS_ACTIVE"]);o.My_Answer.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_ANSWER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_ANSWER_ENTRY_USER_ID"]);o.My_Answer.ENTRY_DATE = Convert.IsDBNull(oRow["T_ANSWER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_ANSWER_ENTRY_DATE"]);o.My_Answer.OWNER_ID = Convert.IsDBNull(oRow["T_ANSWER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Question> Get_Question_By_STUDENT_ID_List_Adv ( List<Int32?> STUDENT_ID_LIST)
{
List<Question> oList = new List<Question>();
dynamic p = new ExpandoObject();
p.STUDENT_ID_LIST = string.Join(",", STUDENT_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_QUESTION_BY_STUDENT_ID_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Question o = new Question();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
o.My_Category = new Category();
o.My_Category.CATEGORY_ID = Convert.IsDBNull(oRow["T_CATEGORY_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_CATEGORY_ID"]);o.My_Category.NAME = Convert.IsDBNull(oRow["T_CATEGORY_NAME"]) ? default : Convert.ToString(oRow["T_CATEGORY_NAME"]);o.My_Category.DECRIPTION = Convert.IsDBNull(oRow["T_CATEGORY_DECRIPTION"]) ? default : Convert.ToString(oRow["T_CATEGORY_DECRIPTION"]);o.My_Category.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_CATEGORY_ENTRY_USER_ID"]);o.My_Category.ENTRY_DATE = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_CATEGORY_ENTRY_DATE"]);o.My_Category.OWNER_ID = Convert.IsDBNull(oRow["T_CATEGORY_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_OWNER_ID"]);
o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Question> Get_Question_By_CATEGORY_ID_List_Adv ( List<Int32?> CATEGORY_ID_LIST)
{
List<Question> oList = new List<Question>();
dynamic p = new ExpandoObject();
p.CATEGORY_ID_LIST = string.Join(",", CATEGORY_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_QUESTION_BY_CATEGORY_ID_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Question o = new Question();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
o.My_Category = new Category();
o.My_Category.CATEGORY_ID = Convert.IsDBNull(oRow["T_CATEGORY_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_CATEGORY_ID"]);o.My_Category.NAME = Convert.IsDBNull(oRow["T_CATEGORY_NAME"]) ? default : Convert.ToString(oRow["T_CATEGORY_NAME"]);o.My_Category.DECRIPTION = Convert.IsDBNull(oRow["T_CATEGORY_DECRIPTION"]) ? default : Convert.ToString(oRow["T_CATEGORY_DECRIPTION"]);o.My_Category.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_CATEGORY_ENTRY_USER_ID"]);o.My_Category.ENTRY_DATE = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_CATEGORY_ENTRY_DATE"]);o.My_Category.OWNER_ID = Convert.IsDBNull(oRow["T_CATEGORY_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_OWNER_ID"]);
o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Question> Get_Question_By_TEACHER_ID_List_Adv ( List<Int32?> TEACHER_ID_LIST)
{
List<Question> oList = new List<Question>();
dynamic p = new ExpandoObject();
p.TEACHER_ID_LIST = string.Join(",", TEACHER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_QUESTION_BY_TEACHER_ID_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Question o = new Question();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
o.My_Category = new Category();
o.My_Category.CATEGORY_ID = Convert.IsDBNull(oRow["T_CATEGORY_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_CATEGORY_ID"]);o.My_Category.NAME = Convert.IsDBNull(oRow["T_CATEGORY_NAME"]) ? default : Convert.ToString(oRow["T_CATEGORY_NAME"]);o.My_Category.DECRIPTION = Convert.IsDBNull(oRow["T_CATEGORY_DECRIPTION"]) ? default : Convert.ToString(oRow["T_CATEGORY_DECRIPTION"]);o.My_Category.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_CATEGORY_ENTRY_USER_ID"]);o.My_Category.ENTRY_DATE = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_CATEGORY_ENTRY_DATE"]);o.My_Category.OWNER_ID = Convert.IsDBNull(oRow["T_CATEGORY_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_OWNER_ID"]);
o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Question_report> Get_Question_report_By_STUDENT_ID_List_Adv ( List<Int32?> STUDENT_ID_LIST)
{
List<Question_report> oList = new List<Question_report>();
dynamic p = new ExpandoObject();
p.STUDENT_ID_LIST = string.Join(",", STUDENT_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_QUESTION_REPORT_BY_STUDENT_ID_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Question_report o = new Question_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Question = new Question();
o.My_Question.QUESTION_ID = Convert.IsDBNull(oRow["T_QUESTION_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_QUESTION_ID"]);o.My_Question.STUDENT_ID = Convert.IsDBNull(oRow["T_QUESTION_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_STUDENT_ID"]);o.My_Question.CATEGORY_ID = Convert.IsDBNull(oRow["T_QUESTION_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_CATEGORY_ID"]);o.My_Question.TEACHER_ID = Convert.IsDBNull(oRow["T_QUESTION_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_TEACHER_ID"]);o.My_Question.DESCRIPTION = Convert.IsDBNull(oRow["T_QUESTION_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_QUESTION_DESCRIPTION"]);o.My_Question.IS_ANSWERED = Convert.IsDBNull(oRow["T_QUESTION_IS_ANSWERED"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ANSWERED"]);o.My_Question.IS_ACTIVE = Convert.IsDBNull(oRow["T_QUESTION_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ACTIVE"]);o.My_Question.REPORTS = Convert.IsDBNull(oRow["T_QUESTION_REPORTS"]) ? default : Convert.ToInt32(oRow["T_QUESTION_REPORTS"]);o.My_Question.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_QUESTION_ENTRY_USER_ID"]);o.My_Question.ENTRY_DATE = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_QUESTION_ENTRY_DATE"]);o.My_Question.OWNER_ID = Convert.IsDBNull(oRow["T_QUESTION_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Question_report> Get_Question_report_By_TEACHER_ID_List_Adv ( List<Int32?> TEACHER_ID_LIST)
{
List<Question_report> oList = new List<Question_report>();
dynamic p = new ExpandoObject();
p.TEACHER_ID_LIST = string.Join(",", TEACHER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_QUESTION_REPORT_BY_TEACHER_ID_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Question_report o = new Question_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Question = new Question();
o.My_Question.QUESTION_ID = Convert.IsDBNull(oRow["T_QUESTION_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_QUESTION_ID"]);o.My_Question.STUDENT_ID = Convert.IsDBNull(oRow["T_QUESTION_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_STUDENT_ID"]);o.My_Question.CATEGORY_ID = Convert.IsDBNull(oRow["T_QUESTION_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_CATEGORY_ID"]);o.My_Question.TEACHER_ID = Convert.IsDBNull(oRow["T_QUESTION_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_TEACHER_ID"]);o.My_Question.DESCRIPTION = Convert.IsDBNull(oRow["T_QUESTION_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_QUESTION_DESCRIPTION"]);o.My_Question.IS_ANSWERED = Convert.IsDBNull(oRow["T_QUESTION_IS_ANSWERED"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ANSWERED"]);o.My_Question.IS_ACTIVE = Convert.IsDBNull(oRow["T_QUESTION_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ACTIVE"]);o.My_Question.REPORTS = Convert.IsDBNull(oRow["T_QUESTION_REPORTS"]) ? default : Convert.ToInt32(oRow["T_QUESTION_REPORTS"]);o.My_Question.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_QUESTION_ENTRY_USER_ID"]);o.My_Question.ENTRY_DATE = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_QUESTION_ENTRY_DATE"]);o.My_Question.OWNER_ID = Convert.IsDBNull(oRow["T_QUESTION_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Question_report> Get_Question_report_By_QUESTION_ID_List_Adv ( List<Int32?> QUESTION_ID_LIST)
{
List<Question_report> oList = new List<Question_report>();
dynamic p = new ExpandoObject();
p.QUESTION_ID_LIST = string.Join(",", QUESTION_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_QUESTION_REPORT_BY_QUESTION_ID_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Question_report o = new Question_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Question = new Question();
o.My_Question.QUESTION_ID = Convert.IsDBNull(oRow["T_QUESTION_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_QUESTION_ID"]);o.My_Question.STUDENT_ID = Convert.IsDBNull(oRow["T_QUESTION_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_STUDENT_ID"]);o.My_Question.CATEGORY_ID = Convert.IsDBNull(oRow["T_QUESTION_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_CATEGORY_ID"]);o.My_Question.TEACHER_ID = Convert.IsDBNull(oRow["T_QUESTION_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_TEACHER_ID"]);o.My_Question.DESCRIPTION = Convert.IsDBNull(oRow["T_QUESTION_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_QUESTION_DESCRIPTION"]);o.My_Question.IS_ANSWERED = Convert.IsDBNull(oRow["T_QUESTION_IS_ANSWERED"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ANSWERED"]);o.My_Question.IS_ACTIVE = Convert.IsDBNull(oRow["T_QUESTION_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ACTIVE"]);o.My_Question.REPORTS = Convert.IsDBNull(oRow["T_QUESTION_REPORTS"]) ? default : Convert.ToInt32(oRow["T_QUESTION_REPORTS"]);o.My_Question.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_QUESTION_ENTRY_USER_ID"]);o.My_Question.ENTRY_DATE = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_QUESTION_ENTRY_DATE"]);o.My_Question.OWNER_ID = Convert.IsDBNull(oRow["T_QUESTION_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Question_token> Get_Question_token_By_QUESTION_ID_List_Adv ( List<long?> QUESTION_ID_LIST)
{
List<Question_token> oList = new List<Question_token>();
dynamic p = new ExpandoObject();
p.QUESTION_ID_LIST = string.Join(",", QUESTION_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_QUESTION_TOKEN_BY_QUESTION_ID_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Question_token o = new Question_token();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Question = new Question();
o.My_Question.QUESTION_ID = Convert.IsDBNull(oRow["T_QUESTION_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_QUESTION_ID"]);o.My_Question.STUDENT_ID = Convert.IsDBNull(oRow["T_QUESTION_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_STUDENT_ID"]);o.My_Question.CATEGORY_ID = Convert.IsDBNull(oRow["T_QUESTION_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_CATEGORY_ID"]);o.My_Question.TEACHER_ID = Convert.IsDBNull(oRow["T_QUESTION_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_TEACHER_ID"]);o.My_Question.DESCRIPTION = Convert.IsDBNull(oRow["T_QUESTION_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_QUESTION_DESCRIPTION"]);o.My_Question.IS_ANSWERED = Convert.IsDBNull(oRow["T_QUESTION_IS_ANSWERED"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ANSWERED"]);o.My_Question.IS_ACTIVE = Convert.IsDBNull(oRow["T_QUESTION_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ACTIVE"]);o.My_Question.REPORTS = Convert.IsDBNull(oRow["T_QUESTION_REPORTS"]) ? default : Convert.ToInt32(oRow["T_QUESTION_REPORTS"]);o.My_Question.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_QUESTION_ENTRY_USER_ID"]);o.My_Question.ENTRY_DATE = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_QUESTION_ENTRY_DATE"]);o.My_Question.OWNER_ID = Convert.IsDBNull(oRow["T_QUESTION_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Report_article> Get_Report_article_By_ARTICLE_ID_List_Adv ( List<Int32?> ARTICLE_ID_LIST)
{
List<Report_article> oList = new List<Report_article>();
dynamic p = new ExpandoObject();
p.ARTICLE_ID_LIST = string.Join(",", ARTICLE_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_REPORT_ARTICLE_BY_ARTICLE_ID_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Report_article o = new Report_article();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Article = new Article();
o.My_Article.ARTICLE_ID = Convert.IsDBNull(oRow["T_ARTICLE_ARTICLE_ID"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_ARTICLE_ID"]);o.My_Article.TEACHER_ID = Convert.IsDBNull(oRow["T_ARTICLE_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_TEACHER_ID"]);o.My_Article.CATEGORY_ID = Convert.IsDBNull(oRow["T_ARTICLE_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_CATEGORY_ID"]);o.My_Article.TITLE = Convert.IsDBNull(oRow["T_ARTICLE_TITLE"]) ? default : Convert.ToString(oRow["T_ARTICLE_TITLE"]);o.My_Article.DESCRIPTION = Convert.IsDBNull(oRow["T_ARTICLE_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_ARTICLE_DESCRIPTION"]);o.My_Article.APPLAUDS = Convert.IsDBNull(oRow["T_ARTICLE_APPLAUDS"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_APPLAUDS"]);o.My_Article.REPORTS = Convert.IsDBNull(oRow["T_ARTICLE_REPORTS"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_REPORTS"]);o.My_Article.IS_BLOCKED = Convert.IsDBNull(oRow["T_ARTICLE_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_ARTICLE_IS_BLOCKED"]);o.My_Article.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_ARTICLE_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_ARTICLE_ENTRY_USER_ID"]);o.My_Article.ENTRY_DATE = Convert.IsDBNull(oRow["T_ARTICLE_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_ARTICLE_ENTRY_DATE"]);o.My_Article.OWNER_ID = Convert.IsDBNull(oRow["T_ARTICLE_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Report_article> Get_Report_article_By_STUDENT_ID_List_Adv ( List<Int32?> STUDENT_ID_LIST)
{
List<Report_article> oList = new List<Report_article>();
dynamic p = new ExpandoObject();
p.STUDENT_ID_LIST = string.Join(",", STUDENT_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_REPORT_ARTICLE_BY_STUDENT_ID_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Report_article o = new Report_article();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Article = new Article();
o.My_Article.ARTICLE_ID = Convert.IsDBNull(oRow["T_ARTICLE_ARTICLE_ID"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_ARTICLE_ID"]);o.My_Article.TEACHER_ID = Convert.IsDBNull(oRow["T_ARTICLE_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_TEACHER_ID"]);o.My_Article.CATEGORY_ID = Convert.IsDBNull(oRow["T_ARTICLE_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_CATEGORY_ID"]);o.My_Article.TITLE = Convert.IsDBNull(oRow["T_ARTICLE_TITLE"]) ? default : Convert.ToString(oRow["T_ARTICLE_TITLE"]);o.My_Article.DESCRIPTION = Convert.IsDBNull(oRow["T_ARTICLE_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_ARTICLE_DESCRIPTION"]);o.My_Article.APPLAUDS = Convert.IsDBNull(oRow["T_ARTICLE_APPLAUDS"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_APPLAUDS"]);o.My_Article.REPORTS = Convert.IsDBNull(oRow["T_ARTICLE_REPORTS"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_REPORTS"]);o.My_Article.IS_BLOCKED = Convert.IsDBNull(oRow["T_ARTICLE_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_ARTICLE_IS_BLOCKED"]);o.My_Article.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_ARTICLE_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_ARTICLE_ENTRY_USER_ID"]);o.My_Article.ENTRY_DATE = Convert.IsDBNull(oRow["T_ARTICLE_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_ARTICLE_ENTRY_DATE"]);o.My_Article.OWNER_ID = Convert.IsDBNull(oRow["T_ARTICLE_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Student> Get_Student_By_USER_ID_List_Adv ( List<Int32?> USER_ID_LIST)
{
List<Student> oList = new List<Student>();
dynamic p = new ExpandoObject();
p.USER_ID_LIST = string.Join(",", USER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_STUDENT_BY_USER_ID_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Student o = new Student();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_User = new User();
o.My_User.USER_ID = Convert.IsDBNull(oRow["T_USER_USER_ID"]) ? default : Convert.ToInt64(oRow["T_USER_USER_ID"]);o.My_User.OWNER_ID = Convert.IsDBNull(oRow["T_USER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_USER_OWNER_ID"]);o.My_User.USERNAME = Convert.IsDBNull(oRow["T_USER_USERNAME"]) ? default : Convert.ToString(oRow["T_USER_USERNAME"]);o.My_User.PASSWORD = Convert.IsDBNull(oRow["T_USER_PASSWORD"]) ? default : Convert.ToString(oRow["T_USER_PASSWORD"]);o.My_User.USER_TYPE_CODE = Convert.IsDBNull(oRow["T_USER_USER_TYPE_CODE"]) ? default : Convert.ToString(oRow["T_USER_USER_TYPE_CODE"]);o.My_User.IS_LOGGED_IN = Convert.IsDBNull(oRow["T_USER_IS_LOGGED_IN"]) ? default : Convert.ToBoolean(oRow["T_USER_IS_LOGGED_IN"]);o.My_User.IS_ACTIVE = Convert.IsDBNull(oRow["T_USER_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_USER_IS_ACTIVE"]);o.My_User.ENTRY_DATE = Convert.IsDBNull(oRow["T_USER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_USER_ENTRY_DATE"]);
oList.Add(o);
}
}
return oList;
}
public List<Student_report> Get_Student_report_By_REPORTED_BY_STUDENT_ID_List_Adv ( List<Int32?> REPORTED_BY_STUDENT_ID_LIST)
{
List<Student_report> oList = new List<Student_report>();
dynamic p = new ExpandoObject();
p.REPORTED_BY_STUDENT_ID_LIST = string.Join(",", REPORTED_BY_STUDENT_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_STUDENT_REPORT_BY_REPORTED_BY_STUDENT_ID_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Student_report o = new Student_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Reported_by_student = new Student();
o.My_Reported_by_student.STUDENT_ID = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_REPORTED_BY_STUDENT_STUDENT_ID"]);o.My_Reported_by_student.USER_ID = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_REPORTED_BY_STUDENT_USER_ID"]);o.My_Reported_by_student.FIRST_NAME = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_REPORTED_BY_STUDENT_FIRST_NAME"]);o.My_Reported_by_student.LAST_NAME = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_REPORTED_BY_STUDENT_LAST_NAME"]);o.My_Reported_by_student.EMAIL = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_REPORTED_BY_STUDENT_EMAIL"]);o.My_Reported_by_student.IS_BLOCKED = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_REPORTED_BY_STUDENT_IS_BLOCKED"]);o.My_Reported_by_student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_REPORTED_BY_STUDENT_PENDING_QUESTIONS"]);o.My_Reported_by_student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_REPORTED_BY_STUDENT_ENTRY_USER_ID"]);o.My_Reported_by_student.ENTRY_DATE = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_REPORTED_BY_STUDENT_ENTRY_DATE"]);o.My_Reported_by_student.OWNER_ID = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_REPORTED_BY_STUDENT_OWNER_ID"]);
o.My_Reported_student = new Student();
o.My_Reported_student.STUDENT_ID = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_REPORTED_STUDENT_STUDENT_ID"]);o.My_Reported_student.USER_ID = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_REPORTED_STUDENT_USER_ID"]);o.My_Reported_student.FIRST_NAME = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_REPORTED_STUDENT_FIRST_NAME"]);o.My_Reported_student.LAST_NAME = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_REPORTED_STUDENT_LAST_NAME"]);o.My_Reported_student.EMAIL = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_REPORTED_STUDENT_EMAIL"]);o.My_Reported_student.IS_BLOCKED = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_REPORTED_STUDENT_IS_BLOCKED"]);o.My_Reported_student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_REPORTED_STUDENT_PENDING_QUESTIONS"]);o.My_Reported_student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_REPORTED_STUDENT_ENTRY_USER_ID"]);o.My_Reported_student.ENTRY_DATE = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_REPORTED_STUDENT_ENTRY_DATE"]);o.My_Reported_student.OWNER_ID = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_REPORTED_STUDENT_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Student_report> Get_Student_report_By_REPORTED_STUDENT_ID_List_Adv ( List<Int32?> REPORTED_STUDENT_ID_LIST)
{
List<Student_report> oList = new List<Student_report>();
dynamic p = new ExpandoObject();
p.REPORTED_STUDENT_ID_LIST = string.Join(",", REPORTED_STUDENT_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_STUDENT_REPORT_BY_REPORTED_STUDENT_ID_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Student_report o = new Student_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Reported_by_student = new Student();
o.My_Reported_by_student.STUDENT_ID = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_REPORTED_BY_STUDENT_STUDENT_ID"]);o.My_Reported_by_student.USER_ID = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_REPORTED_BY_STUDENT_USER_ID"]);o.My_Reported_by_student.FIRST_NAME = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_REPORTED_BY_STUDENT_FIRST_NAME"]);o.My_Reported_by_student.LAST_NAME = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_REPORTED_BY_STUDENT_LAST_NAME"]);o.My_Reported_by_student.EMAIL = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_REPORTED_BY_STUDENT_EMAIL"]);o.My_Reported_by_student.IS_BLOCKED = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_REPORTED_BY_STUDENT_IS_BLOCKED"]);o.My_Reported_by_student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_REPORTED_BY_STUDENT_PENDING_QUESTIONS"]);o.My_Reported_by_student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_REPORTED_BY_STUDENT_ENTRY_USER_ID"]);o.My_Reported_by_student.ENTRY_DATE = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_REPORTED_BY_STUDENT_ENTRY_DATE"]);o.My_Reported_by_student.OWNER_ID = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_REPORTED_BY_STUDENT_OWNER_ID"]);
o.My_Reported_student = new Student();
o.My_Reported_student.STUDENT_ID = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_REPORTED_STUDENT_STUDENT_ID"]);o.My_Reported_student.USER_ID = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_REPORTED_STUDENT_USER_ID"]);o.My_Reported_student.FIRST_NAME = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_REPORTED_STUDENT_FIRST_NAME"]);o.My_Reported_student.LAST_NAME = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_REPORTED_STUDENT_LAST_NAME"]);o.My_Reported_student.EMAIL = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_REPORTED_STUDENT_EMAIL"]);o.My_Reported_student.IS_BLOCKED = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_REPORTED_STUDENT_IS_BLOCKED"]);o.My_Reported_student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_REPORTED_STUDENT_PENDING_QUESTIONS"]);o.My_Reported_student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_REPORTED_STUDENT_ENTRY_USER_ID"]);o.My_Reported_student.ENTRY_DATE = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_REPORTED_STUDENT_ENTRY_DATE"]);o.My_Reported_student.OWNER_ID = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_REPORTED_STUDENT_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Teacher> Get_Teacher_By_USER_ID_List_Adv ( List<Int32?> USER_ID_LIST)
{
List<Teacher> oList = new List<Teacher>();
dynamic p = new ExpandoObject();
p.USER_ID_LIST = string.Join(",", USER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_BY_USER_ID_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher o = new Teacher();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_User = new User();
o.My_User.USER_ID = Convert.IsDBNull(oRow["T_USER_USER_ID"]) ? default : Convert.ToInt64(oRow["T_USER_USER_ID"]);o.My_User.OWNER_ID = Convert.IsDBNull(oRow["T_USER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_USER_OWNER_ID"]);o.My_User.USERNAME = Convert.IsDBNull(oRow["T_USER_USERNAME"]) ? default : Convert.ToString(oRow["T_USER_USERNAME"]);o.My_User.PASSWORD = Convert.IsDBNull(oRow["T_USER_PASSWORD"]) ? default : Convert.ToString(oRow["T_USER_PASSWORD"]);o.My_User.USER_TYPE_CODE = Convert.IsDBNull(oRow["T_USER_USER_TYPE_CODE"]) ? default : Convert.ToString(oRow["T_USER_USER_TYPE_CODE"]);o.My_User.IS_LOGGED_IN = Convert.IsDBNull(oRow["T_USER_IS_LOGGED_IN"]) ? default : Convert.ToBoolean(oRow["T_USER_IS_LOGGED_IN"]);o.My_User.IS_ACTIVE = Convert.IsDBNull(oRow["T_USER_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_USER_IS_ACTIVE"]);o.My_User.ENTRY_DATE = Convert.IsDBNull(oRow["T_USER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_USER_ENTRY_DATE"]);
oList.Add(o);
}
}
return oList;
}
public List<Teacher_category> Get_Teacher_category_By_TEACHER_ID_List_Adv ( List<Int32?> TEACHER_ID_LIST)
{
List<Teacher_category> oList = new List<Teacher_category>();
dynamic p = new ExpandoObject();
p.TEACHER_ID_LIST = string.Join(",", TEACHER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_CATEGORY_BY_TEACHER_ID_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_category o = new Teacher_category();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Category = new Category();
o.My_Category.CATEGORY_ID = Convert.IsDBNull(oRow["T_CATEGORY_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_CATEGORY_ID"]);o.My_Category.NAME = Convert.IsDBNull(oRow["T_CATEGORY_NAME"]) ? default : Convert.ToString(oRow["T_CATEGORY_NAME"]);o.My_Category.DECRIPTION = Convert.IsDBNull(oRow["T_CATEGORY_DECRIPTION"]) ? default : Convert.ToString(oRow["T_CATEGORY_DECRIPTION"]);o.My_Category.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_CATEGORY_ENTRY_USER_ID"]);o.My_Category.ENTRY_DATE = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_CATEGORY_ENTRY_DATE"]);o.My_Category.OWNER_ID = Convert.IsDBNull(oRow["T_CATEGORY_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Teacher_category> Get_Teacher_category_By_CATEGORY_ID_List_Adv ( List<Int32?> CATEGORY_ID_LIST)
{
List<Teacher_category> oList = new List<Teacher_category>();
dynamic p = new ExpandoObject();
p.CATEGORY_ID_LIST = string.Join(",", CATEGORY_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_CATEGORY_BY_CATEGORY_ID_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_category o = new Teacher_category();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Category = new Category();
o.My_Category.CATEGORY_ID = Convert.IsDBNull(oRow["T_CATEGORY_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_CATEGORY_ID"]);o.My_Category.NAME = Convert.IsDBNull(oRow["T_CATEGORY_NAME"]) ? default : Convert.ToString(oRow["T_CATEGORY_NAME"]);o.My_Category.DECRIPTION = Convert.IsDBNull(oRow["T_CATEGORY_DECRIPTION"]) ? default : Convert.ToString(oRow["T_CATEGORY_DECRIPTION"]);o.My_Category.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_CATEGORY_ENTRY_USER_ID"]);o.My_Category.ENTRY_DATE = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_CATEGORY_ENTRY_DATE"]);o.My_Category.OWNER_ID = Convert.IsDBNull(oRow["T_CATEGORY_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Teacher_favorite> Get_Teacher_favorite_By_TEACHER_ID_List_Adv ( List<Int32?> TEACHER_ID_LIST)
{
List<Teacher_favorite> oList = new List<Teacher_favorite>();
dynamic p = new ExpandoObject();
p.TEACHER_ID_LIST = string.Join(",", TEACHER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_FAVORITE_BY_TEACHER_ID_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_favorite o = new Teacher_favorite();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Teacher_favorite> Get_Teacher_favorite_By_STUDENT_ID_List_Adv ( List<Int32?> STUDENT_ID_LIST)
{
List<Teacher_favorite> oList = new List<Teacher_favorite>();
dynamic p = new ExpandoObject();
p.STUDENT_ID_LIST = string.Join(",", STUDENT_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_FAVORITE_BY_STUDENT_ID_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_favorite o = new Teacher_favorite();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Teacher_rank> Get_Teacher_rank_By_TEACHER_ID_List_Adv ( List<Int32?> TEACHER_ID_LIST)
{
List<Teacher_rank> oList = new List<Teacher_rank>();
dynamic p = new ExpandoObject();
p.TEACHER_ID_LIST = string.Join(",", TEACHER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_RANK_BY_TEACHER_ID_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_rank o = new Teacher_rank();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Teacher_report> Get_Teacher_report_By_TEACHER_ID_List_Adv ( List<Int32?> TEACHER_ID_LIST)
{
List<Teacher_report> oList = new List<Teacher_report>();
dynamic p = new ExpandoObject();
p.TEACHER_ID_LIST = string.Join(",", TEACHER_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_REPORT_BY_TEACHER_ID_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_report o = new Teacher_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Teacher_report> Get_Teacher_report_By_STUDENT_ID_List_Adv ( List<Int32?> STUDENT_ID_LIST)
{
List<Teacher_report> oList = new List<Teacher_report>();
dynamic p = new ExpandoObject();
p.STUDENT_ID_LIST = string.Join(",", STUDENT_ID_LIST.ToArray());
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_REPORT_BY_STUDENT_ID_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_report o = new Teacher_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<Answer> Get_Answer_By_Criteria ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Answer> oList = new List<Answer>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_ANSWER_BY_CRITERIA", p);
if (R != null)
{
foreach (var oRow in R)
{
Answer o = new Answer();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Answer> Get_Answer_By_Where ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Answer> oList = new List<Answer>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_ANSWER_BY_WHERE", p);
if (R != null)
{
foreach (var oRow in R)
{
Answer o = new Answer();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Answer_report> Get_Answer_report_By_Criteria ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Answer_report> oList = new List<Answer_report>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_ANSWER_REPORT_BY_CRITERIA", p);
if (R != null)
{
foreach (var oRow in R)
{
Answer_report o = new Answer_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Answer_report> Get_Answer_report_By_Where ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Answer_report> oList = new List<Answer_report>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_ANSWER_REPORT_BY_WHERE", p);
if (R != null)
{
foreach (var oRow in R)
{
Answer_report o = new Answer_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Article> Get_Article_By_Criteria ( string TITLE, string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Article> oList = new List<Article>();
dynamic p = new ExpandoObject();
p.TITLE = TITLE; p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_ARTICLE_BY_CRITERIA", p);
if (R != null)
{
foreach (var oRow in R)
{
Article o = new Article();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Article> Get_Article_By_Where ( string TITLE, string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Article> oList = new List<Article>();
dynamic p = new ExpandoObject();
p.TITLE = TITLE; p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_ARTICLE_BY_WHERE", p);
if (R != null)
{
foreach (var oRow in R)
{
Article o = new Article();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Category> Get_Category_By_Criteria ( string NAME, string DECRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Category> oList = new List<Category>();
dynamic p = new ExpandoObject();
p.NAME = NAME; p.DECRIPTION = DECRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_CATEGORY_BY_CRITERIA", p);
if (R != null)
{
foreach (var oRow in R)
{
Category o = new Category();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Category> Get_Category_By_Where ( string NAME, string DECRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Category> oList = new List<Category>();
dynamic p = new ExpandoObject();
p.NAME = NAME; p.DECRIPTION = DECRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_CATEGORY_BY_WHERE", p);
if (R != null)
{
foreach (var oRow in R)
{
Category o = new Category();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Evaluation> Get_Evaluation_By_Criteria ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Evaluation> oList = new List<Evaluation>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_EVALUATION_BY_CRITERIA", p);
if (R != null)
{
foreach (var oRow in R)
{
Evaluation o = new Evaluation();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Evaluation> Get_Evaluation_By_Where ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Evaluation> oList = new List<Evaluation>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_EVALUATION_BY_WHERE", p);
if (R != null)
{
foreach (var oRow in R)
{
Evaluation o = new Evaluation();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Favorite_category> Get_Favorite_category_By_Criteria ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Favorite_category> oList = new List<Favorite_category>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_FAVORITE_CATEGORY_BY_CRITERIA", p);
if (R != null)
{
foreach (var oRow in R)
{
Favorite_category o = new Favorite_category();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Favorite_category> Get_Favorite_category_By_Where ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Favorite_category> oList = new List<Favorite_category>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_FAVORITE_CATEGORY_BY_WHERE", p);
if (R != null)
{
foreach (var oRow in R)
{
Favorite_category o = new Favorite_category();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Favorite_teacher> Get_Favorite_teacher_By_Criteria ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Favorite_teacher> oList = new List<Favorite_teacher>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_FAVORITE_TEACHER_BY_CRITERIA", p);
if (R != null)
{
foreach (var oRow in R)
{
Favorite_teacher o = new Favorite_teacher();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Favorite_teacher> Get_Favorite_teacher_By_Where ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Favorite_teacher> oList = new List<Favorite_teacher>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_FAVORITE_TEACHER_BY_WHERE", p);
if (R != null)
{
foreach (var oRow in R)
{
Favorite_teacher o = new Favorite_teacher();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Mark_question> Get_Mark_question_By_Criteria ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Mark_question> oList = new List<Mark_question>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_MARK_QUESTION_BY_CRITERIA", p);
if (R != null)
{
foreach (var oRow in R)
{
Mark_question o = new Mark_question();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Mark_question> Get_Mark_question_By_Where ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Mark_question> oList = new List<Mark_question>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_MARK_QUESTION_BY_WHERE", p);
if (R != null)
{
foreach (var oRow in R)
{
Mark_question o = new Mark_question();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Notification> Get_Notification_By_Criteria ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Notification> oList = new List<Notification>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_NOTIFICATION_BY_CRITERIA", p);
if (R != null)
{
foreach (var oRow in R)
{
Notification o = new Notification();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Notification> Get_Notification_By_Where ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Notification> oList = new List<Notification>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_NOTIFICATION_BY_WHERE", p);
if (R != null)
{
foreach (var oRow in R)
{
Notification o = new Notification();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Owner> Get_Owner_By_Criteria ( string CODE, string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Owner> oList = new List<Owner>();
dynamic p = new ExpandoObject();
p.CODE = CODE; p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_OWNER_BY_CRITERIA", p);
if (R != null)
{
foreach (var oRow in R)
{
Owner o = new Owner();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Owner> Get_Owner_By_Where ( string CODE, string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Owner> oList = new List<Owner>();
dynamic p = new ExpandoObject();
p.CODE = CODE; p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_OWNER_BY_WHERE", p);
if (R != null)
{
foreach (var oRow in R)
{
Owner o = new Owner();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Owner> Get_Owner_By_Criteria_V2 ( string CODE, string MAINTENANCE_DUE_DATE, string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Owner> oList = new List<Owner>();
dynamic p = new ExpandoObject();
p.CODE = CODE; p.MAINTENANCE_DUE_DATE = MAINTENANCE_DUE_DATE; p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_OWNER_BY_CRITERIA_V2", p);
if (R != null)
{
foreach (var oRow in R)
{
Owner o = new Owner();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Owner> Get_Owner_By_Where_V2 ( string CODE, string MAINTENANCE_DUE_DATE, string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Owner> oList = new List<Owner>();
dynamic p = new ExpandoObject();
p.CODE = CODE; p.MAINTENANCE_DUE_DATE = MAINTENANCE_DUE_DATE; p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_OWNER_BY_WHERE_V2", p);
if (R != null)
{
foreach (var oRow in R)
{
Owner o = new Owner();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Question> Get_Question_By_Criteria ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Question> oList = new List<Question>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_QUESTION_BY_CRITERIA", p);
if (R != null)
{
foreach (var oRow in R)
{
Question o = new Question();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Question> Get_Question_By_Where ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Question> oList = new List<Question>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_QUESTION_BY_WHERE", p);
if (R != null)
{
foreach (var oRow in R)
{
Question o = new Question();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Question_report> Get_Question_report_By_Criteria ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Question_report> oList = new List<Question_report>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_QUESTION_REPORT_BY_CRITERIA", p);
if (R != null)
{
foreach (var oRow in R)
{
Question_report o = new Question_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Question_report> Get_Question_report_By_Where ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Question_report> oList = new List<Question_report>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_QUESTION_REPORT_BY_WHERE", p);
if (R != null)
{
foreach (var oRow in R)
{
Question_report o = new Question_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Question_token> Get_Question_token_By_Criteria ( string PART, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Question_token> oList = new List<Question_token>();
dynamic p = new ExpandoObject();
p.PART = PART; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_QUESTION_TOKEN_BY_CRITERIA", p);
if (R != null)
{
foreach (var oRow in R)
{
Question_token o = new Question_token();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Question_token> Get_Question_token_By_Where ( string PART, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Question_token> oList = new List<Question_token>();
dynamic p = new ExpandoObject();
p.PART = PART; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_QUESTION_TOKEN_BY_WHERE", p);
if (R != null)
{
foreach (var oRow in R)
{
Question_token o = new Question_token();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Report_article> Get_Report_article_By_Criteria ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Report_article> oList = new List<Report_article>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_REPORT_ARTICLE_BY_CRITERIA", p);
if (R != null)
{
foreach (var oRow in R)
{
Report_article o = new Report_article();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Report_article> Get_Report_article_By_Where ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Report_article> oList = new List<Report_article>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_REPORT_ARTICLE_BY_WHERE", p);
if (R != null)
{
foreach (var oRow in R)
{
Report_article o = new Report_article();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Student> Get_Student_By_Criteria ( string FIRST_NAME, string LAST_NAME, string EMAIL, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Student> oList = new List<Student>();
dynamic p = new ExpandoObject();
p.FIRST_NAME = FIRST_NAME; p.LAST_NAME = LAST_NAME; p.EMAIL = EMAIL; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_STUDENT_BY_CRITERIA", p);
if (R != null)
{
foreach (var oRow in R)
{
Student o = new Student();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Student> Get_Student_By_Where ( string FIRST_NAME, string LAST_NAME, string EMAIL, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Student> oList = new List<Student>();
dynamic p = new ExpandoObject();
p.FIRST_NAME = FIRST_NAME; p.LAST_NAME = LAST_NAME; p.EMAIL = EMAIL; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_STUDENT_BY_WHERE", p);
if (R != null)
{
foreach (var oRow in R)
{
Student o = new Student();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Student_report> Get_Student_report_By_Criteria ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Student_report> oList = new List<Student_report>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_STUDENT_REPORT_BY_CRITERIA", p);
if (R != null)
{
foreach (var oRow in R)
{
Student_report o = new Student_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Student_report> Get_Student_report_By_Where ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Student_report> oList = new List<Student_report>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_STUDENT_REPORT_BY_WHERE", p);
if (R != null)
{
foreach (var oRow in R)
{
Student_report o = new Student_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Teacher> Get_Teacher_By_Criteria ( string FIRST_NAME, string LAST_NAME, string DESCRIPTION, string EMAIL, string MOBILE, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Teacher> oList = new List<Teacher>();
dynamic p = new ExpandoObject();
p.FIRST_NAME = FIRST_NAME; p.LAST_NAME = LAST_NAME; p.DESCRIPTION = DESCRIPTION; p.EMAIL = EMAIL; p.MOBILE = MOBILE; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_BY_CRITERIA", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher o = new Teacher();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Teacher> Get_Teacher_By_Where ( string FIRST_NAME, string LAST_NAME, string DESCRIPTION, string EMAIL, string MOBILE, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Teacher> oList = new List<Teacher>();
dynamic p = new ExpandoObject();
p.FIRST_NAME = FIRST_NAME; p.LAST_NAME = LAST_NAME; p.DESCRIPTION = DESCRIPTION; p.EMAIL = EMAIL; p.MOBILE = MOBILE; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_BY_WHERE", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher o = new Teacher();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Teacher_category> Get_Teacher_category_By_Criteria ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Teacher_category> oList = new List<Teacher_category>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_CATEGORY_BY_CRITERIA", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_category o = new Teacher_category();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Teacher_category> Get_Teacher_category_By_Where ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Teacher_category> oList = new List<Teacher_category>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_CATEGORY_BY_WHERE", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_category o = new Teacher_category();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Teacher_favorite> Get_Teacher_favorite_By_Criteria ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Teacher_favorite> oList = new List<Teacher_favorite>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_FAVORITE_BY_CRITERIA", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_favorite o = new Teacher_favorite();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Teacher_favorite> Get_Teacher_favorite_By_Where ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Teacher_favorite> oList = new List<Teacher_favorite>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_FAVORITE_BY_WHERE", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_favorite o = new Teacher_favorite();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Teacher_rank> Get_Teacher_rank_By_Criteria ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Teacher_rank> oList = new List<Teacher_rank>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_RANK_BY_CRITERIA", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_rank o = new Teacher_rank();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Teacher_rank> Get_Teacher_rank_By_Where ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Teacher_rank> oList = new List<Teacher_rank>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_RANK_BY_WHERE", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_rank o = new Teacher_rank();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Teacher_report> Get_Teacher_report_By_Criteria ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Teacher_report> oList = new List<Teacher_report>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_REPORT_BY_CRITERIA", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_report o = new Teacher_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Teacher_report> Get_Teacher_report_By_Where ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Teacher_report> oList = new List<Teacher_report>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_REPORT_BY_WHERE", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_report o = new Teacher_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<User> Get_User_By_Criteria ( string USERNAME, string PASSWORD, string USER_TYPE_CODE, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<User> oList = new List<User>();
dynamic p = new ExpandoObject();
p.USERNAME = USERNAME; p.PASSWORD = PASSWORD; p.USER_TYPE_CODE = USER_TYPE_CODE; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_USER_BY_CRITERIA", p);
if (R != null)
{
foreach (var oRow in R)
{
User o = new User();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<User> Get_User_By_Where ( string USERNAME, string PASSWORD, string USER_TYPE_CODE, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<User> oList = new List<User>();
dynamic p = new ExpandoObject();
p.USERNAME = USERNAME; p.PASSWORD = PASSWORD; p.USER_TYPE_CODE = USER_TYPE_CODE; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_USER_BY_WHERE", p);
if (R != null)
{
foreach (var oRow in R)
{
User o = new User();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Answer> Get_Answer_By_Criteria_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Answer> oList = new List<Answer>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_ANSWER_BY_CRITERIA_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Answer o = new Answer();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Question = new Question();
o.My_Question.QUESTION_ID = Convert.IsDBNull(oRow["T_QUESTION_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_QUESTION_ID"]);o.My_Question.STUDENT_ID = Convert.IsDBNull(oRow["T_QUESTION_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_STUDENT_ID"]);o.My_Question.CATEGORY_ID = Convert.IsDBNull(oRow["T_QUESTION_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_CATEGORY_ID"]);o.My_Question.TEACHER_ID = Convert.IsDBNull(oRow["T_QUESTION_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_TEACHER_ID"]);o.My_Question.DESCRIPTION = Convert.IsDBNull(oRow["T_QUESTION_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_QUESTION_DESCRIPTION"]);o.My_Question.IS_ANSWERED = Convert.IsDBNull(oRow["T_QUESTION_IS_ANSWERED"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ANSWERED"]);o.My_Question.IS_ACTIVE = Convert.IsDBNull(oRow["T_QUESTION_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ACTIVE"]);o.My_Question.REPORTS = Convert.IsDBNull(oRow["T_QUESTION_REPORTS"]) ? default : Convert.ToInt32(oRow["T_QUESTION_REPORTS"]);o.My_Question.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_QUESTION_ENTRY_USER_ID"]);o.My_Question.ENTRY_DATE = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_QUESTION_ENTRY_DATE"]);o.My_Question.OWNER_ID = Convert.IsDBNull(oRow["T_QUESTION_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_OWNER_ID"]);
o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Answer> Get_Answer_By_Where_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Answer> oList = new List<Answer>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_ANSWER_BY_WHERE_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Answer o = new Answer();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Question = new Question();
o.My_Question.QUESTION_ID = Convert.IsDBNull(oRow["T_QUESTION_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_QUESTION_ID"]);o.My_Question.STUDENT_ID = Convert.IsDBNull(oRow["T_QUESTION_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_STUDENT_ID"]);o.My_Question.CATEGORY_ID = Convert.IsDBNull(oRow["T_QUESTION_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_CATEGORY_ID"]);o.My_Question.TEACHER_ID = Convert.IsDBNull(oRow["T_QUESTION_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_TEACHER_ID"]);o.My_Question.DESCRIPTION = Convert.IsDBNull(oRow["T_QUESTION_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_QUESTION_DESCRIPTION"]);o.My_Question.IS_ANSWERED = Convert.IsDBNull(oRow["T_QUESTION_IS_ANSWERED"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ANSWERED"]);o.My_Question.IS_ACTIVE = Convert.IsDBNull(oRow["T_QUESTION_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ACTIVE"]);o.My_Question.REPORTS = Convert.IsDBNull(oRow["T_QUESTION_REPORTS"]) ? default : Convert.ToInt32(oRow["T_QUESTION_REPORTS"]);o.My_Question.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_QUESTION_ENTRY_USER_ID"]);o.My_Question.ENTRY_DATE = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_QUESTION_ENTRY_DATE"]);o.My_Question.OWNER_ID = Convert.IsDBNull(oRow["T_QUESTION_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_OWNER_ID"]);
o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Answer_report> Get_Answer_report_By_Criteria_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Answer_report> oList = new List<Answer_report>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_ANSWER_REPORT_BY_CRITERIA_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Answer_report o = new Answer_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
o.My_Answer = new Answer();
o.My_Answer.ANSWER_ID = Convert.IsDBNull(oRow["T_ANSWER_ANSWER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_ANSWER_ID"]);o.My_Answer.QUESTION_ID = Convert.IsDBNull(oRow["T_ANSWER_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_QUESTION_ID"]);o.My_Answer.TEACHER_ID = Convert.IsDBNull(oRow["T_ANSWER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_TEACHER_ID"]);o.My_Answer.DESCRIPTION = Convert.IsDBNull(oRow["T_ANSWER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_ANSWER_DESCRIPTION"]);o.My_Answer.SCORE = Convert.IsDBNull(oRow["T_ANSWER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_ANSWER_SCORE"]);o.My_Answer.REVIEWS = Convert.IsDBNull(oRow["T_ANSWER_REVIEWS"]) ? default : Convert.ToInt32(oRow["T_ANSWER_REVIEWS"]);o.My_Answer.REPORTS = Convert.IsDBNull(oRow["T_ANSWER_REPORTS"]) ? default : Convert.ToInt32(oRow["T_ANSWER_REPORTS"]);o.My_Answer.IS_ACTIVE = Convert.IsDBNull(oRow["T_ANSWER_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_ANSWER_IS_ACTIVE"]);o.My_Answer.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_ANSWER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_ANSWER_ENTRY_USER_ID"]);o.My_Answer.ENTRY_DATE = Convert.IsDBNull(oRow["T_ANSWER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_ANSWER_ENTRY_DATE"]);o.My_Answer.OWNER_ID = Convert.IsDBNull(oRow["T_ANSWER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Answer_report> Get_Answer_report_By_Where_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Answer_report> oList = new List<Answer_report>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_ANSWER_REPORT_BY_WHERE_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Answer_report o = new Answer_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
o.My_Answer = new Answer();
o.My_Answer.ANSWER_ID = Convert.IsDBNull(oRow["T_ANSWER_ANSWER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_ANSWER_ID"]);o.My_Answer.QUESTION_ID = Convert.IsDBNull(oRow["T_ANSWER_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_QUESTION_ID"]);o.My_Answer.TEACHER_ID = Convert.IsDBNull(oRow["T_ANSWER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_TEACHER_ID"]);o.My_Answer.DESCRIPTION = Convert.IsDBNull(oRow["T_ANSWER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_ANSWER_DESCRIPTION"]);o.My_Answer.SCORE = Convert.IsDBNull(oRow["T_ANSWER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_ANSWER_SCORE"]);o.My_Answer.REVIEWS = Convert.IsDBNull(oRow["T_ANSWER_REVIEWS"]) ? default : Convert.ToInt32(oRow["T_ANSWER_REVIEWS"]);o.My_Answer.REPORTS = Convert.IsDBNull(oRow["T_ANSWER_REPORTS"]) ? default : Convert.ToInt32(oRow["T_ANSWER_REPORTS"]);o.My_Answer.IS_ACTIVE = Convert.IsDBNull(oRow["T_ANSWER_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_ANSWER_IS_ACTIVE"]);o.My_Answer.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_ANSWER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_ANSWER_ENTRY_USER_ID"]);o.My_Answer.ENTRY_DATE = Convert.IsDBNull(oRow["T_ANSWER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_ANSWER_ENTRY_DATE"]);o.My_Answer.OWNER_ID = Convert.IsDBNull(oRow["T_ANSWER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Article> Get_Article_By_Criteria_Adv ( string TITLE, string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Article> oList = new List<Article>();
dynamic p = new ExpandoObject();
p.TITLE = TITLE; p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_ARTICLE_BY_CRITERIA_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Article o = new Article();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Category = new Category();
o.My_Category.CATEGORY_ID = Convert.IsDBNull(oRow["T_CATEGORY_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_CATEGORY_ID"]);o.My_Category.NAME = Convert.IsDBNull(oRow["T_CATEGORY_NAME"]) ? default : Convert.ToString(oRow["T_CATEGORY_NAME"]);o.My_Category.DECRIPTION = Convert.IsDBNull(oRow["T_CATEGORY_DECRIPTION"]) ? default : Convert.ToString(oRow["T_CATEGORY_DECRIPTION"]);o.My_Category.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_CATEGORY_ENTRY_USER_ID"]);o.My_Category.ENTRY_DATE = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_CATEGORY_ENTRY_DATE"]);o.My_Category.OWNER_ID = Convert.IsDBNull(oRow["T_CATEGORY_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Article> Get_Article_By_Where_Adv ( string TITLE, string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Article> oList = new List<Article>();
dynamic p = new ExpandoObject();
p.TITLE = TITLE; p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_ARTICLE_BY_WHERE_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Article o = new Article();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Category = new Category();
o.My_Category.CATEGORY_ID = Convert.IsDBNull(oRow["T_CATEGORY_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_CATEGORY_ID"]);o.My_Category.NAME = Convert.IsDBNull(oRow["T_CATEGORY_NAME"]) ? default : Convert.ToString(oRow["T_CATEGORY_NAME"]);o.My_Category.DECRIPTION = Convert.IsDBNull(oRow["T_CATEGORY_DECRIPTION"]) ? default : Convert.ToString(oRow["T_CATEGORY_DECRIPTION"]);o.My_Category.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_CATEGORY_ENTRY_USER_ID"]);o.My_Category.ENTRY_DATE = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_CATEGORY_ENTRY_DATE"]);o.My_Category.OWNER_ID = Convert.IsDBNull(oRow["T_CATEGORY_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Category> Get_Category_By_Criteria_Adv ( string NAME, string DECRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Category> oList = new List<Category>();
dynamic p = new ExpandoObject();
p.NAME = NAME; p.DECRIPTION = DECRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_CATEGORY_BY_CRITERIA_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Category o = new Category();
oTools.CopyPropValues_FromDataRecord(oRow, o);

oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Category> Get_Category_By_Where_Adv ( string NAME, string DECRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Category> oList = new List<Category>();
dynamic p = new ExpandoObject();
p.NAME = NAME; p.DECRIPTION = DECRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_CATEGORY_BY_WHERE_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Category o = new Category();
oTools.CopyPropValues_FromDataRecord(oRow, o);

oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Evaluation> Get_Evaluation_By_Criteria_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Evaluation> oList = new List<Evaluation>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_EVALUATION_BY_CRITERIA_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Evaluation o = new Evaluation();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
o.My_Answer = new Answer();
o.My_Answer.ANSWER_ID = Convert.IsDBNull(oRow["T_ANSWER_ANSWER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_ANSWER_ID"]);o.My_Answer.QUESTION_ID = Convert.IsDBNull(oRow["T_ANSWER_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_QUESTION_ID"]);o.My_Answer.TEACHER_ID = Convert.IsDBNull(oRow["T_ANSWER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_TEACHER_ID"]);o.My_Answer.DESCRIPTION = Convert.IsDBNull(oRow["T_ANSWER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_ANSWER_DESCRIPTION"]);o.My_Answer.SCORE = Convert.IsDBNull(oRow["T_ANSWER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_ANSWER_SCORE"]);o.My_Answer.REVIEWS = Convert.IsDBNull(oRow["T_ANSWER_REVIEWS"]) ? default : Convert.ToInt32(oRow["T_ANSWER_REVIEWS"]);o.My_Answer.REPORTS = Convert.IsDBNull(oRow["T_ANSWER_REPORTS"]) ? default : Convert.ToInt32(oRow["T_ANSWER_REPORTS"]);o.My_Answer.IS_ACTIVE = Convert.IsDBNull(oRow["T_ANSWER_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_ANSWER_IS_ACTIVE"]);o.My_Answer.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_ANSWER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_ANSWER_ENTRY_USER_ID"]);o.My_Answer.ENTRY_DATE = Convert.IsDBNull(oRow["T_ANSWER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_ANSWER_ENTRY_DATE"]);o.My_Answer.OWNER_ID = Convert.IsDBNull(oRow["T_ANSWER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Evaluation> Get_Evaluation_By_Where_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Evaluation> oList = new List<Evaluation>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_EVALUATION_BY_WHERE_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Evaluation o = new Evaluation();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
o.My_Answer = new Answer();
o.My_Answer.ANSWER_ID = Convert.IsDBNull(oRow["T_ANSWER_ANSWER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_ANSWER_ID"]);o.My_Answer.QUESTION_ID = Convert.IsDBNull(oRow["T_ANSWER_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_QUESTION_ID"]);o.My_Answer.TEACHER_ID = Convert.IsDBNull(oRow["T_ANSWER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_TEACHER_ID"]);o.My_Answer.DESCRIPTION = Convert.IsDBNull(oRow["T_ANSWER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_ANSWER_DESCRIPTION"]);o.My_Answer.SCORE = Convert.IsDBNull(oRow["T_ANSWER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_ANSWER_SCORE"]);o.My_Answer.REVIEWS = Convert.IsDBNull(oRow["T_ANSWER_REVIEWS"]) ? default : Convert.ToInt32(oRow["T_ANSWER_REVIEWS"]);o.My_Answer.REPORTS = Convert.IsDBNull(oRow["T_ANSWER_REPORTS"]) ? default : Convert.ToInt32(oRow["T_ANSWER_REPORTS"]);o.My_Answer.IS_ACTIVE = Convert.IsDBNull(oRow["T_ANSWER_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_ANSWER_IS_ACTIVE"]);o.My_Answer.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_ANSWER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_ANSWER_ENTRY_USER_ID"]);o.My_Answer.ENTRY_DATE = Convert.IsDBNull(oRow["T_ANSWER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_ANSWER_ENTRY_DATE"]);o.My_Answer.OWNER_ID = Convert.IsDBNull(oRow["T_ANSWER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Favorite_category> Get_Favorite_category_By_Criteria_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Favorite_category> oList = new List<Favorite_category>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_FAVORITE_CATEGORY_BY_CRITERIA_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Favorite_category o = new Favorite_category();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
o.My_Category = new Category();
o.My_Category.CATEGORY_ID = Convert.IsDBNull(oRow["T_CATEGORY_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_CATEGORY_ID"]);o.My_Category.NAME = Convert.IsDBNull(oRow["T_CATEGORY_NAME"]) ? default : Convert.ToString(oRow["T_CATEGORY_NAME"]);o.My_Category.DECRIPTION = Convert.IsDBNull(oRow["T_CATEGORY_DECRIPTION"]) ? default : Convert.ToString(oRow["T_CATEGORY_DECRIPTION"]);o.My_Category.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_CATEGORY_ENTRY_USER_ID"]);o.My_Category.ENTRY_DATE = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_CATEGORY_ENTRY_DATE"]);o.My_Category.OWNER_ID = Convert.IsDBNull(oRow["T_CATEGORY_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Favorite_category> Get_Favorite_category_By_Where_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Favorite_category> oList = new List<Favorite_category>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_FAVORITE_CATEGORY_BY_WHERE_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Favorite_category o = new Favorite_category();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
o.My_Category = new Category();
o.My_Category.CATEGORY_ID = Convert.IsDBNull(oRow["T_CATEGORY_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_CATEGORY_ID"]);o.My_Category.NAME = Convert.IsDBNull(oRow["T_CATEGORY_NAME"]) ? default : Convert.ToString(oRow["T_CATEGORY_NAME"]);o.My_Category.DECRIPTION = Convert.IsDBNull(oRow["T_CATEGORY_DECRIPTION"]) ? default : Convert.ToString(oRow["T_CATEGORY_DECRIPTION"]);o.My_Category.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_CATEGORY_ENTRY_USER_ID"]);o.My_Category.ENTRY_DATE = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_CATEGORY_ENTRY_DATE"]);o.My_Category.OWNER_ID = Convert.IsDBNull(oRow["T_CATEGORY_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Favorite_teacher> Get_Favorite_teacher_By_Criteria_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Favorite_teacher> oList = new List<Favorite_teacher>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_FAVORITE_TEACHER_BY_CRITERIA_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Favorite_teacher o = new Favorite_teacher();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Favorite_teacher> Get_Favorite_teacher_By_Where_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Favorite_teacher> oList = new List<Favorite_teacher>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_FAVORITE_TEACHER_BY_WHERE_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Favorite_teacher o = new Favorite_teacher();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Mark_question> Get_Mark_question_By_Criteria_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Mark_question> oList = new List<Mark_question>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_MARK_QUESTION_BY_CRITERIA_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Mark_question o = new Mark_question();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Question = new Question();
o.My_Question.QUESTION_ID = Convert.IsDBNull(oRow["T_QUESTION_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_QUESTION_ID"]);o.My_Question.STUDENT_ID = Convert.IsDBNull(oRow["T_QUESTION_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_STUDENT_ID"]);o.My_Question.CATEGORY_ID = Convert.IsDBNull(oRow["T_QUESTION_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_CATEGORY_ID"]);o.My_Question.TEACHER_ID = Convert.IsDBNull(oRow["T_QUESTION_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_TEACHER_ID"]);o.My_Question.DESCRIPTION = Convert.IsDBNull(oRow["T_QUESTION_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_QUESTION_DESCRIPTION"]);o.My_Question.IS_ANSWERED = Convert.IsDBNull(oRow["T_QUESTION_IS_ANSWERED"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ANSWERED"]);o.My_Question.IS_ACTIVE = Convert.IsDBNull(oRow["T_QUESTION_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ACTIVE"]);o.My_Question.REPORTS = Convert.IsDBNull(oRow["T_QUESTION_REPORTS"]) ? default : Convert.ToInt32(oRow["T_QUESTION_REPORTS"]);o.My_Question.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_QUESTION_ENTRY_USER_ID"]);o.My_Question.ENTRY_DATE = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_QUESTION_ENTRY_DATE"]);o.My_Question.OWNER_ID = Convert.IsDBNull(oRow["T_QUESTION_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Mark_question> Get_Mark_question_By_Where_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Mark_question> oList = new List<Mark_question>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_MARK_QUESTION_BY_WHERE_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Mark_question o = new Mark_question();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Question = new Question();
o.My_Question.QUESTION_ID = Convert.IsDBNull(oRow["T_QUESTION_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_QUESTION_ID"]);o.My_Question.STUDENT_ID = Convert.IsDBNull(oRow["T_QUESTION_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_STUDENT_ID"]);o.My_Question.CATEGORY_ID = Convert.IsDBNull(oRow["T_QUESTION_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_CATEGORY_ID"]);o.My_Question.TEACHER_ID = Convert.IsDBNull(oRow["T_QUESTION_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_TEACHER_ID"]);o.My_Question.DESCRIPTION = Convert.IsDBNull(oRow["T_QUESTION_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_QUESTION_DESCRIPTION"]);o.My_Question.IS_ANSWERED = Convert.IsDBNull(oRow["T_QUESTION_IS_ANSWERED"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ANSWERED"]);o.My_Question.IS_ACTIVE = Convert.IsDBNull(oRow["T_QUESTION_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ACTIVE"]);o.My_Question.REPORTS = Convert.IsDBNull(oRow["T_QUESTION_REPORTS"]) ? default : Convert.ToInt32(oRow["T_QUESTION_REPORTS"]);o.My_Question.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_QUESTION_ENTRY_USER_ID"]);o.My_Question.ENTRY_DATE = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_QUESTION_ENTRY_DATE"]);o.My_Question.OWNER_ID = Convert.IsDBNull(oRow["T_QUESTION_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Notification> Get_Notification_By_Criteria_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Notification> oList = new List<Notification>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_NOTIFICATION_BY_CRITERIA_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Notification o = new Notification();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_User = new User();
o.My_User.USER_ID = Convert.IsDBNull(oRow["T_USER_USER_ID"]) ? default : Convert.ToInt64(oRow["T_USER_USER_ID"]);o.My_User.OWNER_ID = Convert.IsDBNull(oRow["T_USER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_USER_OWNER_ID"]);o.My_User.USERNAME = Convert.IsDBNull(oRow["T_USER_USERNAME"]) ? default : Convert.ToString(oRow["T_USER_USERNAME"]);o.My_User.PASSWORD = Convert.IsDBNull(oRow["T_USER_PASSWORD"]) ? default : Convert.ToString(oRow["T_USER_PASSWORD"]);o.My_User.USER_TYPE_CODE = Convert.IsDBNull(oRow["T_USER_USER_TYPE_CODE"]) ? default : Convert.ToString(oRow["T_USER_USER_TYPE_CODE"]);o.My_User.IS_LOGGED_IN = Convert.IsDBNull(oRow["T_USER_IS_LOGGED_IN"]) ? default : Convert.ToBoolean(oRow["T_USER_IS_LOGGED_IN"]);o.My_User.IS_ACTIVE = Convert.IsDBNull(oRow["T_USER_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_USER_IS_ACTIVE"]);o.My_User.ENTRY_DATE = Convert.IsDBNull(oRow["T_USER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_USER_ENTRY_DATE"]);
o.My_Question = new Question();
o.My_Question.QUESTION_ID = Convert.IsDBNull(oRow["T_QUESTION_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_QUESTION_ID"]);o.My_Question.STUDENT_ID = Convert.IsDBNull(oRow["T_QUESTION_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_STUDENT_ID"]);o.My_Question.CATEGORY_ID = Convert.IsDBNull(oRow["T_QUESTION_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_CATEGORY_ID"]);o.My_Question.TEACHER_ID = Convert.IsDBNull(oRow["T_QUESTION_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_TEACHER_ID"]);o.My_Question.DESCRIPTION = Convert.IsDBNull(oRow["T_QUESTION_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_QUESTION_DESCRIPTION"]);o.My_Question.IS_ANSWERED = Convert.IsDBNull(oRow["T_QUESTION_IS_ANSWERED"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ANSWERED"]);o.My_Question.IS_ACTIVE = Convert.IsDBNull(oRow["T_QUESTION_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ACTIVE"]);o.My_Question.REPORTS = Convert.IsDBNull(oRow["T_QUESTION_REPORTS"]) ? default : Convert.ToInt32(oRow["T_QUESTION_REPORTS"]);o.My_Question.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_QUESTION_ENTRY_USER_ID"]);o.My_Question.ENTRY_DATE = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_QUESTION_ENTRY_DATE"]);o.My_Question.OWNER_ID = Convert.IsDBNull(oRow["T_QUESTION_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_OWNER_ID"]);
o.My_Answer = new Answer();
o.My_Answer.ANSWER_ID = Convert.IsDBNull(oRow["T_ANSWER_ANSWER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_ANSWER_ID"]);o.My_Answer.QUESTION_ID = Convert.IsDBNull(oRow["T_ANSWER_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_QUESTION_ID"]);o.My_Answer.TEACHER_ID = Convert.IsDBNull(oRow["T_ANSWER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_TEACHER_ID"]);o.My_Answer.DESCRIPTION = Convert.IsDBNull(oRow["T_ANSWER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_ANSWER_DESCRIPTION"]);o.My_Answer.SCORE = Convert.IsDBNull(oRow["T_ANSWER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_ANSWER_SCORE"]);o.My_Answer.REVIEWS = Convert.IsDBNull(oRow["T_ANSWER_REVIEWS"]) ? default : Convert.ToInt32(oRow["T_ANSWER_REVIEWS"]);o.My_Answer.REPORTS = Convert.IsDBNull(oRow["T_ANSWER_REPORTS"]) ? default : Convert.ToInt32(oRow["T_ANSWER_REPORTS"]);o.My_Answer.IS_ACTIVE = Convert.IsDBNull(oRow["T_ANSWER_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_ANSWER_IS_ACTIVE"]);o.My_Answer.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_ANSWER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_ANSWER_ENTRY_USER_ID"]);o.My_Answer.ENTRY_DATE = Convert.IsDBNull(oRow["T_ANSWER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_ANSWER_ENTRY_DATE"]);o.My_Answer.OWNER_ID = Convert.IsDBNull(oRow["T_ANSWER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Notification> Get_Notification_By_Where_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Notification> oList = new List<Notification>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_NOTIFICATION_BY_WHERE_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Notification o = new Notification();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_User = new User();
o.My_User.USER_ID = Convert.IsDBNull(oRow["T_USER_USER_ID"]) ? default : Convert.ToInt64(oRow["T_USER_USER_ID"]);o.My_User.OWNER_ID = Convert.IsDBNull(oRow["T_USER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_USER_OWNER_ID"]);o.My_User.USERNAME = Convert.IsDBNull(oRow["T_USER_USERNAME"]) ? default : Convert.ToString(oRow["T_USER_USERNAME"]);o.My_User.PASSWORD = Convert.IsDBNull(oRow["T_USER_PASSWORD"]) ? default : Convert.ToString(oRow["T_USER_PASSWORD"]);o.My_User.USER_TYPE_CODE = Convert.IsDBNull(oRow["T_USER_USER_TYPE_CODE"]) ? default : Convert.ToString(oRow["T_USER_USER_TYPE_CODE"]);o.My_User.IS_LOGGED_IN = Convert.IsDBNull(oRow["T_USER_IS_LOGGED_IN"]) ? default : Convert.ToBoolean(oRow["T_USER_IS_LOGGED_IN"]);o.My_User.IS_ACTIVE = Convert.IsDBNull(oRow["T_USER_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_USER_IS_ACTIVE"]);o.My_User.ENTRY_DATE = Convert.IsDBNull(oRow["T_USER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_USER_ENTRY_DATE"]);
o.My_Question = new Question();
o.My_Question.QUESTION_ID = Convert.IsDBNull(oRow["T_QUESTION_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_QUESTION_ID"]);o.My_Question.STUDENT_ID = Convert.IsDBNull(oRow["T_QUESTION_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_STUDENT_ID"]);o.My_Question.CATEGORY_ID = Convert.IsDBNull(oRow["T_QUESTION_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_CATEGORY_ID"]);o.My_Question.TEACHER_ID = Convert.IsDBNull(oRow["T_QUESTION_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_TEACHER_ID"]);o.My_Question.DESCRIPTION = Convert.IsDBNull(oRow["T_QUESTION_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_QUESTION_DESCRIPTION"]);o.My_Question.IS_ANSWERED = Convert.IsDBNull(oRow["T_QUESTION_IS_ANSWERED"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ANSWERED"]);o.My_Question.IS_ACTIVE = Convert.IsDBNull(oRow["T_QUESTION_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ACTIVE"]);o.My_Question.REPORTS = Convert.IsDBNull(oRow["T_QUESTION_REPORTS"]) ? default : Convert.ToInt32(oRow["T_QUESTION_REPORTS"]);o.My_Question.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_QUESTION_ENTRY_USER_ID"]);o.My_Question.ENTRY_DATE = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_QUESTION_ENTRY_DATE"]);o.My_Question.OWNER_ID = Convert.IsDBNull(oRow["T_QUESTION_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_OWNER_ID"]);
o.My_Answer = new Answer();
o.My_Answer.ANSWER_ID = Convert.IsDBNull(oRow["T_ANSWER_ANSWER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_ANSWER_ID"]);o.My_Answer.QUESTION_ID = Convert.IsDBNull(oRow["T_ANSWER_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_QUESTION_ID"]);o.My_Answer.TEACHER_ID = Convert.IsDBNull(oRow["T_ANSWER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_TEACHER_ID"]);o.My_Answer.DESCRIPTION = Convert.IsDBNull(oRow["T_ANSWER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_ANSWER_DESCRIPTION"]);o.My_Answer.SCORE = Convert.IsDBNull(oRow["T_ANSWER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_ANSWER_SCORE"]);o.My_Answer.REVIEWS = Convert.IsDBNull(oRow["T_ANSWER_REVIEWS"]) ? default : Convert.ToInt32(oRow["T_ANSWER_REVIEWS"]);o.My_Answer.REPORTS = Convert.IsDBNull(oRow["T_ANSWER_REPORTS"]) ? default : Convert.ToInt32(oRow["T_ANSWER_REPORTS"]);o.My_Answer.IS_ACTIVE = Convert.IsDBNull(oRow["T_ANSWER_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_ANSWER_IS_ACTIVE"]);o.My_Answer.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_ANSWER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_ANSWER_ENTRY_USER_ID"]);o.My_Answer.ENTRY_DATE = Convert.IsDBNull(oRow["T_ANSWER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_ANSWER_ENTRY_DATE"]);o.My_Answer.OWNER_ID = Convert.IsDBNull(oRow["T_ANSWER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Question> Get_Question_By_Criteria_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Question> oList = new List<Question>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_QUESTION_BY_CRITERIA_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Question o = new Question();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
o.My_Category = new Category();
o.My_Category.CATEGORY_ID = Convert.IsDBNull(oRow["T_CATEGORY_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_CATEGORY_ID"]);o.My_Category.NAME = Convert.IsDBNull(oRow["T_CATEGORY_NAME"]) ? default : Convert.ToString(oRow["T_CATEGORY_NAME"]);o.My_Category.DECRIPTION = Convert.IsDBNull(oRow["T_CATEGORY_DECRIPTION"]) ? default : Convert.ToString(oRow["T_CATEGORY_DECRIPTION"]);o.My_Category.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_CATEGORY_ENTRY_USER_ID"]);o.My_Category.ENTRY_DATE = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_CATEGORY_ENTRY_DATE"]);o.My_Category.OWNER_ID = Convert.IsDBNull(oRow["T_CATEGORY_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_OWNER_ID"]);
o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Question> Get_Question_By_Where_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Question> oList = new List<Question>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_QUESTION_BY_WHERE_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Question o = new Question();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
o.My_Category = new Category();
o.My_Category.CATEGORY_ID = Convert.IsDBNull(oRow["T_CATEGORY_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_CATEGORY_ID"]);o.My_Category.NAME = Convert.IsDBNull(oRow["T_CATEGORY_NAME"]) ? default : Convert.ToString(oRow["T_CATEGORY_NAME"]);o.My_Category.DECRIPTION = Convert.IsDBNull(oRow["T_CATEGORY_DECRIPTION"]) ? default : Convert.ToString(oRow["T_CATEGORY_DECRIPTION"]);o.My_Category.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_CATEGORY_ENTRY_USER_ID"]);o.My_Category.ENTRY_DATE = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_CATEGORY_ENTRY_DATE"]);o.My_Category.OWNER_ID = Convert.IsDBNull(oRow["T_CATEGORY_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_OWNER_ID"]);
o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Question_report> Get_Question_report_By_Criteria_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Question_report> oList = new List<Question_report>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_QUESTION_REPORT_BY_CRITERIA_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Question_report o = new Question_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Question = new Question();
o.My_Question.QUESTION_ID = Convert.IsDBNull(oRow["T_QUESTION_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_QUESTION_ID"]);o.My_Question.STUDENT_ID = Convert.IsDBNull(oRow["T_QUESTION_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_STUDENT_ID"]);o.My_Question.CATEGORY_ID = Convert.IsDBNull(oRow["T_QUESTION_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_CATEGORY_ID"]);o.My_Question.TEACHER_ID = Convert.IsDBNull(oRow["T_QUESTION_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_TEACHER_ID"]);o.My_Question.DESCRIPTION = Convert.IsDBNull(oRow["T_QUESTION_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_QUESTION_DESCRIPTION"]);o.My_Question.IS_ANSWERED = Convert.IsDBNull(oRow["T_QUESTION_IS_ANSWERED"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ANSWERED"]);o.My_Question.IS_ACTIVE = Convert.IsDBNull(oRow["T_QUESTION_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ACTIVE"]);o.My_Question.REPORTS = Convert.IsDBNull(oRow["T_QUESTION_REPORTS"]) ? default : Convert.ToInt32(oRow["T_QUESTION_REPORTS"]);o.My_Question.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_QUESTION_ENTRY_USER_ID"]);o.My_Question.ENTRY_DATE = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_QUESTION_ENTRY_DATE"]);o.My_Question.OWNER_ID = Convert.IsDBNull(oRow["T_QUESTION_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Question_report> Get_Question_report_By_Where_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Question_report> oList = new List<Question_report>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_QUESTION_REPORT_BY_WHERE_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Question_report o = new Question_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Question = new Question();
o.My_Question.QUESTION_ID = Convert.IsDBNull(oRow["T_QUESTION_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_QUESTION_ID"]);o.My_Question.STUDENT_ID = Convert.IsDBNull(oRow["T_QUESTION_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_STUDENT_ID"]);o.My_Question.CATEGORY_ID = Convert.IsDBNull(oRow["T_QUESTION_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_CATEGORY_ID"]);o.My_Question.TEACHER_ID = Convert.IsDBNull(oRow["T_QUESTION_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_TEACHER_ID"]);o.My_Question.DESCRIPTION = Convert.IsDBNull(oRow["T_QUESTION_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_QUESTION_DESCRIPTION"]);o.My_Question.IS_ANSWERED = Convert.IsDBNull(oRow["T_QUESTION_IS_ANSWERED"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ANSWERED"]);o.My_Question.IS_ACTIVE = Convert.IsDBNull(oRow["T_QUESTION_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ACTIVE"]);o.My_Question.REPORTS = Convert.IsDBNull(oRow["T_QUESTION_REPORTS"]) ? default : Convert.ToInt32(oRow["T_QUESTION_REPORTS"]);o.My_Question.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_QUESTION_ENTRY_USER_ID"]);o.My_Question.ENTRY_DATE = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_QUESTION_ENTRY_DATE"]);o.My_Question.OWNER_ID = Convert.IsDBNull(oRow["T_QUESTION_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Question_token> Get_Question_token_By_Criteria_Adv ( string PART, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Question_token> oList = new List<Question_token>();
dynamic p = new ExpandoObject();
p.PART = PART; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_QUESTION_TOKEN_BY_CRITERIA_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Question_token o = new Question_token();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Question = new Question();
o.My_Question.QUESTION_ID = Convert.IsDBNull(oRow["T_QUESTION_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_QUESTION_ID"]);o.My_Question.STUDENT_ID = Convert.IsDBNull(oRow["T_QUESTION_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_STUDENT_ID"]);o.My_Question.CATEGORY_ID = Convert.IsDBNull(oRow["T_QUESTION_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_CATEGORY_ID"]);o.My_Question.TEACHER_ID = Convert.IsDBNull(oRow["T_QUESTION_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_TEACHER_ID"]);o.My_Question.DESCRIPTION = Convert.IsDBNull(oRow["T_QUESTION_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_QUESTION_DESCRIPTION"]);o.My_Question.IS_ANSWERED = Convert.IsDBNull(oRow["T_QUESTION_IS_ANSWERED"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ANSWERED"]);o.My_Question.IS_ACTIVE = Convert.IsDBNull(oRow["T_QUESTION_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ACTIVE"]);o.My_Question.REPORTS = Convert.IsDBNull(oRow["T_QUESTION_REPORTS"]) ? default : Convert.ToInt32(oRow["T_QUESTION_REPORTS"]);o.My_Question.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_QUESTION_ENTRY_USER_ID"]);o.My_Question.ENTRY_DATE = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_QUESTION_ENTRY_DATE"]);o.My_Question.OWNER_ID = Convert.IsDBNull(oRow["T_QUESTION_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Question_token> Get_Question_token_By_Where_Adv ( string PART, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Question_token> oList = new List<Question_token>();
dynamic p = new ExpandoObject();
p.PART = PART; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_QUESTION_TOKEN_BY_WHERE_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Question_token o = new Question_token();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Question = new Question();
o.My_Question.QUESTION_ID = Convert.IsDBNull(oRow["T_QUESTION_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_QUESTION_ID"]);o.My_Question.STUDENT_ID = Convert.IsDBNull(oRow["T_QUESTION_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_STUDENT_ID"]);o.My_Question.CATEGORY_ID = Convert.IsDBNull(oRow["T_QUESTION_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_CATEGORY_ID"]);o.My_Question.TEACHER_ID = Convert.IsDBNull(oRow["T_QUESTION_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_TEACHER_ID"]);o.My_Question.DESCRIPTION = Convert.IsDBNull(oRow["T_QUESTION_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_QUESTION_DESCRIPTION"]);o.My_Question.IS_ANSWERED = Convert.IsDBNull(oRow["T_QUESTION_IS_ANSWERED"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ANSWERED"]);o.My_Question.IS_ACTIVE = Convert.IsDBNull(oRow["T_QUESTION_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ACTIVE"]);o.My_Question.REPORTS = Convert.IsDBNull(oRow["T_QUESTION_REPORTS"]) ? default : Convert.ToInt32(oRow["T_QUESTION_REPORTS"]);o.My_Question.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_QUESTION_ENTRY_USER_ID"]);o.My_Question.ENTRY_DATE = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_QUESTION_ENTRY_DATE"]);o.My_Question.OWNER_ID = Convert.IsDBNull(oRow["T_QUESTION_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Report_article> Get_Report_article_By_Criteria_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Report_article> oList = new List<Report_article>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_REPORT_ARTICLE_BY_CRITERIA_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Report_article o = new Report_article();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Article = new Article();
o.My_Article.ARTICLE_ID = Convert.IsDBNull(oRow["T_ARTICLE_ARTICLE_ID"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_ARTICLE_ID"]);o.My_Article.TEACHER_ID = Convert.IsDBNull(oRow["T_ARTICLE_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_TEACHER_ID"]);o.My_Article.CATEGORY_ID = Convert.IsDBNull(oRow["T_ARTICLE_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_CATEGORY_ID"]);o.My_Article.TITLE = Convert.IsDBNull(oRow["T_ARTICLE_TITLE"]) ? default : Convert.ToString(oRow["T_ARTICLE_TITLE"]);o.My_Article.DESCRIPTION = Convert.IsDBNull(oRow["T_ARTICLE_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_ARTICLE_DESCRIPTION"]);o.My_Article.APPLAUDS = Convert.IsDBNull(oRow["T_ARTICLE_APPLAUDS"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_APPLAUDS"]);o.My_Article.REPORTS = Convert.IsDBNull(oRow["T_ARTICLE_REPORTS"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_REPORTS"]);o.My_Article.IS_BLOCKED = Convert.IsDBNull(oRow["T_ARTICLE_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_ARTICLE_IS_BLOCKED"]);o.My_Article.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_ARTICLE_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_ARTICLE_ENTRY_USER_ID"]);o.My_Article.ENTRY_DATE = Convert.IsDBNull(oRow["T_ARTICLE_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_ARTICLE_ENTRY_DATE"]);o.My_Article.OWNER_ID = Convert.IsDBNull(oRow["T_ARTICLE_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Report_article> Get_Report_article_By_Where_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Report_article> oList = new List<Report_article>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_REPORT_ARTICLE_BY_WHERE_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Report_article o = new Report_article();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Article = new Article();
o.My_Article.ARTICLE_ID = Convert.IsDBNull(oRow["T_ARTICLE_ARTICLE_ID"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_ARTICLE_ID"]);o.My_Article.TEACHER_ID = Convert.IsDBNull(oRow["T_ARTICLE_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_TEACHER_ID"]);o.My_Article.CATEGORY_ID = Convert.IsDBNull(oRow["T_ARTICLE_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_CATEGORY_ID"]);o.My_Article.TITLE = Convert.IsDBNull(oRow["T_ARTICLE_TITLE"]) ? default : Convert.ToString(oRow["T_ARTICLE_TITLE"]);o.My_Article.DESCRIPTION = Convert.IsDBNull(oRow["T_ARTICLE_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_ARTICLE_DESCRIPTION"]);o.My_Article.APPLAUDS = Convert.IsDBNull(oRow["T_ARTICLE_APPLAUDS"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_APPLAUDS"]);o.My_Article.REPORTS = Convert.IsDBNull(oRow["T_ARTICLE_REPORTS"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_REPORTS"]);o.My_Article.IS_BLOCKED = Convert.IsDBNull(oRow["T_ARTICLE_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_ARTICLE_IS_BLOCKED"]);o.My_Article.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_ARTICLE_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_ARTICLE_ENTRY_USER_ID"]);o.My_Article.ENTRY_DATE = Convert.IsDBNull(oRow["T_ARTICLE_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_ARTICLE_ENTRY_DATE"]);o.My_Article.OWNER_ID = Convert.IsDBNull(oRow["T_ARTICLE_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Student> Get_Student_By_Criteria_Adv ( string FIRST_NAME, string LAST_NAME, string EMAIL, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Student> oList = new List<Student>();
dynamic p = new ExpandoObject();
p.FIRST_NAME = FIRST_NAME; p.LAST_NAME = LAST_NAME; p.EMAIL = EMAIL; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_STUDENT_BY_CRITERIA_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Student o = new Student();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_User = new User();
o.My_User.USER_ID = Convert.IsDBNull(oRow["T_USER_USER_ID"]) ? default : Convert.ToInt64(oRow["T_USER_USER_ID"]);o.My_User.OWNER_ID = Convert.IsDBNull(oRow["T_USER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_USER_OWNER_ID"]);o.My_User.USERNAME = Convert.IsDBNull(oRow["T_USER_USERNAME"]) ? default : Convert.ToString(oRow["T_USER_USERNAME"]);o.My_User.PASSWORD = Convert.IsDBNull(oRow["T_USER_PASSWORD"]) ? default : Convert.ToString(oRow["T_USER_PASSWORD"]);o.My_User.USER_TYPE_CODE = Convert.IsDBNull(oRow["T_USER_USER_TYPE_CODE"]) ? default : Convert.ToString(oRow["T_USER_USER_TYPE_CODE"]);o.My_User.IS_LOGGED_IN = Convert.IsDBNull(oRow["T_USER_IS_LOGGED_IN"]) ? default : Convert.ToBoolean(oRow["T_USER_IS_LOGGED_IN"]);o.My_User.IS_ACTIVE = Convert.IsDBNull(oRow["T_USER_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_USER_IS_ACTIVE"]);o.My_User.ENTRY_DATE = Convert.IsDBNull(oRow["T_USER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_USER_ENTRY_DATE"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Student> Get_Student_By_Where_Adv ( string FIRST_NAME, string LAST_NAME, string EMAIL, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Student> oList = new List<Student>();
dynamic p = new ExpandoObject();
p.FIRST_NAME = FIRST_NAME; p.LAST_NAME = LAST_NAME; p.EMAIL = EMAIL; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_STUDENT_BY_WHERE_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Student o = new Student();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_User = new User();
o.My_User.USER_ID = Convert.IsDBNull(oRow["T_USER_USER_ID"]) ? default : Convert.ToInt64(oRow["T_USER_USER_ID"]);o.My_User.OWNER_ID = Convert.IsDBNull(oRow["T_USER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_USER_OWNER_ID"]);o.My_User.USERNAME = Convert.IsDBNull(oRow["T_USER_USERNAME"]) ? default : Convert.ToString(oRow["T_USER_USERNAME"]);o.My_User.PASSWORD = Convert.IsDBNull(oRow["T_USER_PASSWORD"]) ? default : Convert.ToString(oRow["T_USER_PASSWORD"]);o.My_User.USER_TYPE_CODE = Convert.IsDBNull(oRow["T_USER_USER_TYPE_CODE"]) ? default : Convert.ToString(oRow["T_USER_USER_TYPE_CODE"]);o.My_User.IS_LOGGED_IN = Convert.IsDBNull(oRow["T_USER_IS_LOGGED_IN"]) ? default : Convert.ToBoolean(oRow["T_USER_IS_LOGGED_IN"]);o.My_User.IS_ACTIVE = Convert.IsDBNull(oRow["T_USER_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_USER_IS_ACTIVE"]);o.My_User.ENTRY_DATE = Convert.IsDBNull(oRow["T_USER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_USER_ENTRY_DATE"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Student_report> Get_Student_report_By_Criteria_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Student_report> oList = new List<Student_report>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_STUDENT_REPORT_BY_CRITERIA_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Student_report o = new Student_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Reported_by_student = new Student();
o.My_Reported_by_student.STUDENT_ID = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_REPORTED_BY_STUDENT_STUDENT_ID"]);o.My_Reported_by_student.USER_ID = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_REPORTED_BY_STUDENT_USER_ID"]);o.My_Reported_by_student.FIRST_NAME = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_REPORTED_BY_STUDENT_FIRST_NAME"]);o.My_Reported_by_student.LAST_NAME = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_REPORTED_BY_STUDENT_LAST_NAME"]);o.My_Reported_by_student.EMAIL = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_REPORTED_BY_STUDENT_EMAIL"]);o.My_Reported_by_student.IS_BLOCKED = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_REPORTED_BY_STUDENT_IS_BLOCKED"]);o.My_Reported_by_student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_REPORTED_BY_STUDENT_PENDING_QUESTIONS"]);o.My_Reported_by_student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_REPORTED_BY_STUDENT_ENTRY_USER_ID"]);o.My_Reported_by_student.ENTRY_DATE = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_REPORTED_BY_STUDENT_ENTRY_DATE"]);o.My_Reported_by_student.OWNER_ID = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_REPORTED_BY_STUDENT_OWNER_ID"]);
o.My_Reported_student = new Student();
o.My_Reported_student.STUDENT_ID = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_REPORTED_STUDENT_STUDENT_ID"]);o.My_Reported_student.USER_ID = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_REPORTED_STUDENT_USER_ID"]);o.My_Reported_student.FIRST_NAME = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_REPORTED_STUDENT_FIRST_NAME"]);o.My_Reported_student.LAST_NAME = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_REPORTED_STUDENT_LAST_NAME"]);o.My_Reported_student.EMAIL = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_REPORTED_STUDENT_EMAIL"]);o.My_Reported_student.IS_BLOCKED = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_REPORTED_STUDENT_IS_BLOCKED"]);o.My_Reported_student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_REPORTED_STUDENT_PENDING_QUESTIONS"]);o.My_Reported_student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_REPORTED_STUDENT_ENTRY_USER_ID"]);o.My_Reported_student.ENTRY_DATE = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_REPORTED_STUDENT_ENTRY_DATE"]);o.My_Reported_student.OWNER_ID = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_REPORTED_STUDENT_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Student_report> Get_Student_report_By_Where_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Student_report> oList = new List<Student_report>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_STUDENT_REPORT_BY_WHERE_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Student_report o = new Student_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Reported_by_student = new Student();
o.My_Reported_by_student.STUDENT_ID = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_REPORTED_BY_STUDENT_STUDENT_ID"]);o.My_Reported_by_student.USER_ID = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_REPORTED_BY_STUDENT_USER_ID"]);o.My_Reported_by_student.FIRST_NAME = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_REPORTED_BY_STUDENT_FIRST_NAME"]);o.My_Reported_by_student.LAST_NAME = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_REPORTED_BY_STUDENT_LAST_NAME"]);o.My_Reported_by_student.EMAIL = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_REPORTED_BY_STUDENT_EMAIL"]);o.My_Reported_by_student.IS_BLOCKED = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_REPORTED_BY_STUDENT_IS_BLOCKED"]);o.My_Reported_by_student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_REPORTED_BY_STUDENT_PENDING_QUESTIONS"]);o.My_Reported_by_student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_REPORTED_BY_STUDENT_ENTRY_USER_ID"]);o.My_Reported_by_student.ENTRY_DATE = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_REPORTED_BY_STUDENT_ENTRY_DATE"]);o.My_Reported_by_student.OWNER_ID = Convert.IsDBNull(oRow["T_REPORTED_BY_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_REPORTED_BY_STUDENT_OWNER_ID"]);
o.My_Reported_student = new Student();
o.My_Reported_student.STUDENT_ID = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_REPORTED_STUDENT_STUDENT_ID"]);o.My_Reported_student.USER_ID = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_REPORTED_STUDENT_USER_ID"]);o.My_Reported_student.FIRST_NAME = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_REPORTED_STUDENT_FIRST_NAME"]);o.My_Reported_student.LAST_NAME = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_REPORTED_STUDENT_LAST_NAME"]);o.My_Reported_student.EMAIL = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_REPORTED_STUDENT_EMAIL"]);o.My_Reported_student.IS_BLOCKED = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_REPORTED_STUDENT_IS_BLOCKED"]);o.My_Reported_student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_REPORTED_STUDENT_PENDING_QUESTIONS"]);o.My_Reported_student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_REPORTED_STUDENT_ENTRY_USER_ID"]);o.My_Reported_student.ENTRY_DATE = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_REPORTED_STUDENT_ENTRY_DATE"]);o.My_Reported_student.OWNER_ID = Convert.IsDBNull(oRow["T_REPORTED_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_REPORTED_STUDENT_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Teacher> Get_Teacher_By_Criteria_Adv ( string FIRST_NAME, string LAST_NAME, string DESCRIPTION, string EMAIL, string MOBILE, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Teacher> oList = new List<Teacher>();
dynamic p = new ExpandoObject();
p.FIRST_NAME = FIRST_NAME; p.LAST_NAME = LAST_NAME; p.DESCRIPTION = DESCRIPTION; p.EMAIL = EMAIL; p.MOBILE = MOBILE; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_BY_CRITERIA_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher o = new Teacher();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_User = new User();
o.My_User.USER_ID = Convert.IsDBNull(oRow["T_USER_USER_ID"]) ? default : Convert.ToInt64(oRow["T_USER_USER_ID"]);o.My_User.OWNER_ID = Convert.IsDBNull(oRow["T_USER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_USER_OWNER_ID"]);o.My_User.USERNAME = Convert.IsDBNull(oRow["T_USER_USERNAME"]) ? default : Convert.ToString(oRow["T_USER_USERNAME"]);o.My_User.PASSWORD = Convert.IsDBNull(oRow["T_USER_PASSWORD"]) ? default : Convert.ToString(oRow["T_USER_PASSWORD"]);o.My_User.USER_TYPE_CODE = Convert.IsDBNull(oRow["T_USER_USER_TYPE_CODE"]) ? default : Convert.ToString(oRow["T_USER_USER_TYPE_CODE"]);o.My_User.IS_LOGGED_IN = Convert.IsDBNull(oRow["T_USER_IS_LOGGED_IN"]) ? default : Convert.ToBoolean(oRow["T_USER_IS_LOGGED_IN"]);o.My_User.IS_ACTIVE = Convert.IsDBNull(oRow["T_USER_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_USER_IS_ACTIVE"]);o.My_User.ENTRY_DATE = Convert.IsDBNull(oRow["T_USER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_USER_ENTRY_DATE"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Teacher> Get_Teacher_By_Where_Adv ( string FIRST_NAME, string LAST_NAME, string DESCRIPTION, string EMAIL, string MOBILE, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Teacher> oList = new List<Teacher>();
dynamic p = new ExpandoObject();
p.FIRST_NAME = FIRST_NAME; p.LAST_NAME = LAST_NAME; p.DESCRIPTION = DESCRIPTION; p.EMAIL = EMAIL; p.MOBILE = MOBILE; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_BY_WHERE_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher o = new Teacher();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_User = new User();
o.My_User.USER_ID = Convert.IsDBNull(oRow["T_USER_USER_ID"]) ? default : Convert.ToInt64(oRow["T_USER_USER_ID"]);o.My_User.OWNER_ID = Convert.IsDBNull(oRow["T_USER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_USER_OWNER_ID"]);o.My_User.USERNAME = Convert.IsDBNull(oRow["T_USER_USERNAME"]) ? default : Convert.ToString(oRow["T_USER_USERNAME"]);o.My_User.PASSWORD = Convert.IsDBNull(oRow["T_USER_PASSWORD"]) ? default : Convert.ToString(oRow["T_USER_PASSWORD"]);o.My_User.USER_TYPE_CODE = Convert.IsDBNull(oRow["T_USER_USER_TYPE_CODE"]) ? default : Convert.ToString(oRow["T_USER_USER_TYPE_CODE"]);o.My_User.IS_LOGGED_IN = Convert.IsDBNull(oRow["T_USER_IS_LOGGED_IN"]) ? default : Convert.ToBoolean(oRow["T_USER_IS_LOGGED_IN"]);o.My_User.IS_ACTIVE = Convert.IsDBNull(oRow["T_USER_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_USER_IS_ACTIVE"]);o.My_User.ENTRY_DATE = Convert.IsDBNull(oRow["T_USER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_USER_ENTRY_DATE"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Teacher_category> Get_Teacher_category_By_Criteria_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Teacher_category> oList = new List<Teacher_category>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_CATEGORY_BY_CRITERIA_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_category o = new Teacher_category();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Category = new Category();
o.My_Category.CATEGORY_ID = Convert.IsDBNull(oRow["T_CATEGORY_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_CATEGORY_ID"]);o.My_Category.NAME = Convert.IsDBNull(oRow["T_CATEGORY_NAME"]) ? default : Convert.ToString(oRow["T_CATEGORY_NAME"]);o.My_Category.DECRIPTION = Convert.IsDBNull(oRow["T_CATEGORY_DECRIPTION"]) ? default : Convert.ToString(oRow["T_CATEGORY_DECRIPTION"]);o.My_Category.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_CATEGORY_ENTRY_USER_ID"]);o.My_Category.ENTRY_DATE = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_CATEGORY_ENTRY_DATE"]);o.My_Category.OWNER_ID = Convert.IsDBNull(oRow["T_CATEGORY_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Teacher_category> Get_Teacher_category_By_Where_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Teacher_category> oList = new List<Teacher_category>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_CATEGORY_BY_WHERE_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_category o = new Teacher_category();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Category = new Category();
o.My_Category.CATEGORY_ID = Convert.IsDBNull(oRow["T_CATEGORY_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_CATEGORY_ID"]);o.My_Category.NAME = Convert.IsDBNull(oRow["T_CATEGORY_NAME"]) ? default : Convert.ToString(oRow["T_CATEGORY_NAME"]);o.My_Category.DECRIPTION = Convert.IsDBNull(oRow["T_CATEGORY_DECRIPTION"]) ? default : Convert.ToString(oRow["T_CATEGORY_DECRIPTION"]);o.My_Category.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_CATEGORY_ENTRY_USER_ID"]);o.My_Category.ENTRY_DATE = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_CATEGORY_ENTRY_DATE"]);o.My_Category.OWNER_ID = Convert.IsDBNull(oRow["T_CATEGORY_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Teacher_favorite> Get_Teacher_favorite_By_Criteria_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Teacher_favorite> oList = new List<Teacher_favorite>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_FAVORITE_BY_CRITERIA_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_favorite o = new Teacher_favorite();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Teacher_favorite> Get_Teacher_favorite_By_Where_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Teacher_favorite> oList = new List<Teacher_favorite>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_FAVORITE_BY_WHERE_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_favorite o = new Teacher_favorite();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Teacher_rank> Get_Teacher_rank_By_Criteria_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Teacher_rank> oList = new List<Teacher_rank>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_RANK_BY_CRITERIA_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_rank o = new Teacher_rank();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Teacher_rank> Get_Teacher_rank_By_Where_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Teacher_rank> oList = new List<Teacher_rank>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_RANK_BY_WHERE_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_rank o = new Teacher_rank();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Teacher_report> Get_Teacher_report_By_Criteria_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Teacher_report> oList = new List<Teacher_report>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_REPORT_BY_CRITERIA_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_report o = new Teacher_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Teacher_report> Get_Teacher_report_By_Where_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Teacher_report> oList = new List<Teacher_report>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_REPORT_BY_WHERE_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_report o = new Teacher_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<User> Get_User_By_Criteria_Adv ( string USERNAME, string PASSWORD, string USER_TYPE_CODE, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<User> oList = new List<User>();
dynamic p = new ExpandoObject();
p.USERNAME = USERNAME; p.PASSWORD = PASSWORD; p.USER_TYPE_CODE = USER_TYPE_CODE; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_USER_BY_CRITERIA_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
User o = new User();
oTools.CopyPropValues_FromDataRecord(oRow, o);

oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<User> Get_User_By_Where_Adv ( string USERNAME, string PASSWORD, string USER_TYPE_CODE, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<User> oList = new List<User>();
dynamic p = new ExpandoObject();
p.USERNAME = USERNAME; p.PASSWORD = PASSWORD; p.USER_TYPE_CODE = USER_TYPE_CODE; p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_USER_BY_WHERE_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
User o = new User();
oTools.CopyPropValues_FromDataRecord(oRow, o);

oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Answer> Get_Answer_By_Criteria_InList ( string DESCRIPTION, List<Int32?> QUESTION_ID_LIST, List<Int32?> TEACHER_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Answer> oList = new List<Answer>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.QUESTION_ID_LIST = string.Join(",", QUESTION_ID_LIST.ToArray()); p.TEACHER_ID_LIST = string.Join(",", TEACHER_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_ANSWER_BY_CRITERIA_IN_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Answer o = new Answer();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Answer> Get_Answer_By_Where_InList ( string DESCRIPTION, List<Int32?> QUESTION_ID_LIST, List<Int32?> TEACHER_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Answer> oList = new List<Answer>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.QUESTION_ID_LIST = string.Join(",", QUESTION_ID_LIST.ToArray()); p.TEACHER_ID_LIST = string.Join(",", TEACHER_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_ANSWER_BY_WHERE_IN_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Answer o = new Answer();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Answer_report> Get_Answer_report_By_Criteria_InList ( string DESCRIPTION, List<Int32?> TEACHER_ID_LIST, List<Int32?> STUDENT_ID_LIST, List<Int32?> ANSWER_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Answer_report> oList = new List<Answer_report>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.TEACHER_ID_LIST = string.Join(",", TEACHER_ID_LIST.ToArray()); p.STUDENT_ID_LIST = string.Join(",", STUDENT_ID_LIST.ToArray()); p.ANSWER_ID_LIST = string.Join(",", ANSWER_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_ANSWER_REPORT_BY_CRITERIA_IN_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Answer_report o = new Answer_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Answer_report> Get_Answer_report_By_Where_InList ( string DESCRIPTION, List<Int32?> TEACHER_ID_LIST, List<Int32?> STUDENT_ID_LIST, List<Int32?> ANSWER_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Answer_report> oList = new List<Answer_report>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.TEACHER_ID_LIST = string.Join(",", TEACHER_ID_LIST.ToArray()); p.STUDENT_ID_LIST = string.Join(",", STUDENT_ID_LIST.ToArray()); p.ANSWER_ID_LIST = string.Join(",", ANSWER_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_ANSWER_REPORT_BY_WHERE_IN_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Answer_report o = new Answer_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Article> Get_Article_By_Criteria_InList ( string TITLE, string DESCRIPTION, List<Int32?> TEACHER_ID_LIST, List<Int32?> CATEGORY_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Article> oList = new List<Article>();
dynamic p = new ExpandoObject();
p.TITLE = TITLE; p.DESCRIPTION = DESCRIPTION; p.TEACHER_ID_LIST = string.Join(",", TEACHER_ID_LIST.ToArray()); p.CATEGORY_ID_LIST = string.Join(",", CATEGORY_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_ARTICLE_BY_CRITERIA_IN_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Article o = new Article();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Article> Get_Article_By_Where_InList ( string TITLE, string DESCRIPTION, List<Int32?> TEACHER_ID_LIST, List<Int32?> CATEGORY_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Article> oList = new List<Article>();
dynamic p = new ExpandoObject();
p.TITLE = TITLE; p.DESCRIPTION = DESCRIPTION; p.TEACHER_ID_LIST = string.Join(",", TEACHER_ID_LIST.ToArray()); p.CATEGORY_ID_LIST = string.Join(",", CATEGORY_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_ARTICLE_BY_WHERE_IN_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Article o = new Article();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Evaluation> Get_Evaluation_By_Criteria_InList ( string DESCRIPTION, List<Int32?> STUDENT_ID_LIST, List<Int32?> ANSWER_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Evaluation> oList = new List<Evaluation>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.STUDENT_ID_LIST = string.Join(",", STUDENT_ID_LIST.ToArray()); p.ANSWER_ID_LIST = string.Join(",", ANSWER_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_EVALUATION_BY_CRITERIA_IN_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Evaluation o = new Evaluation();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Evaluation> Get_Evaluation_By_Where_InList ( string DESCRIPTION, List<Int32?> STUDENT_ID_LIST, List<Int32?> ANSWER_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Evaluation> oList = new List<Evaluation>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.STUDENT_ID_LIST = string.Join(",", STUDENT_ID_LIST.ToArray()); p.ANSWER_ID_LIST = string.Join(",", ANSWER_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_EVALUATION_BY_WHERE_IN_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Evaluation o = new Evaluation();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Favorite_category> Get_Favorite_category_By_Criteria_InList ( string DESCRIPTION, List<Int32?> STUDENT_ID_LIST, List<Int32?> CATEGORY_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Favorite_category> oList = new List<Favorite_category>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.STUDENT_ID_LIST = string.Join(",", STUDENT_ID_LIST.ToArray()); p.CATEGORY_ID_LIST = string.Join(",", CATEGORY_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_FAVORITE_CATEGORY_BY_CRITERIA_IN_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Favorite_category o = new Favorite_category();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Favorite_category> Get_Favorite_category_By_Where_InList ( string DESCRIPTION, List<Int32?> STUDENT_ID_LIST, List<Int32?> CATEGORY_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Favorite_category> oList = new List<Favorite_category>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.STUDENT_ID_LIST = string.Join(",", STUDENT_ID_LIST.ToArray()); p.CATEGORY_ID_LIST = string.Join(",", CATEGORY_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_FAVORITE_CATEGORY_BY_WHERE_IN_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Favorite_category o = new Favorite_category();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Favorite_teacher> Get_Favorite_teacher_By_Criteria_InList ( string DESCRIPTION, List<Int32?> TEACHER_ID_LIST, List<Int32?> STUDENT_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Favorite_teacher> oList = new List<Favorite_teacher>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.TEACHER_ID_LIST = string.Join(",", TEACHER_ID_LIST.ToArray()); p.STUDENT_ID_LIST = string.Join(",", STUDENT_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_FAVORITE_TEACHER_BY_CRITERIA_IN_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Favorite_teacher o = new Favorite_teacher();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Favorite_teacher> Get_Favorite_teacher_By_Where_InList ( string DESCRIPTION, List<Int32?> TEACHER_ID_LIST, List<Int32?> STUDENT_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Favorite_teacher> oList = new List<Favorite_teacher>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.TEACHER_ID_LIST = string.Join(",", TEACHER_ID_LIST.ToArray()); p.STUDENT_ID_LIST = string.Join(",", STUDENT_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_FAVORITE_TEACHER_BY_WHERE_IN_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Favorite_teacher o = new Favorite_teacher();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Mark_question> Get_Mark_question_By_Criteria_InList ( string DESCRIPTION, List<Int32?> QUESTION_ID_LIST, List<Int32?> STUDENT_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Mark_question> oList = new List<Mark_question>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.QUESTION_ID_LIST = string.Join(",", QUESTION_ID_LIST.ToArray()); p.STUDENT_ID_LIST = string.Join(",", STUDENT_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_MARK_QUESTION_BY_CRITERIA_IN_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Mark_question o = new Mark_question();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Mark_question> Get_Mark_question_By_Where_InList ( string DESCRIPTION, List<Int32?> QUESTION_ID_LIST, List<Int32?> STUDENT_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Mark_question> oList = new List<Mark_question>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.QUESTION_ID_LIST = string.Join(",", QUESTION_ID_LIST.ToArray()); p.STUDENT_ID_LIST = string.Join(",", STUDENT_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_MARK_QUESTION_BY_WHERE_IN_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Mark_question o = new Mark_question();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Notification> Get_Notification_By_Criteria_InList ( string DESCRIPTION, List<Int32?> QUESTION_ID_LIST, List<Int32?> ANSWER_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Notification> oList = new List<Notification>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.QUESTION_ID_LIST = string.Join(",", QUESTION_ID_LIST.ToArray()); p.ANSWER_ID_LIST = string.Join(",", ANSWER_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_NOTIFICATION_BY_CRITERIA_IN_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Notification o = new Notification();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Notification> Get_Notification_By_Where_InList ( string DESCRIPTION, List<Int32?> QUESTION_ID_LIST, List<Int32?> ANSWER_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Notification> oList = new List<Notification>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.QUESTION_ID_LIST = string.Join(",", QUESTION_ID_LIST.ToArray()); p.ANSWER_ID_LIST = string.Join(",", ANSWER_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_NOTIFICATION_BY_WHERE_IN_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Notification o = new Notification();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Question> Get_Question_By_Criteria_InList ( string DESCRIPTION, List<Int32?> STUDENT_ID_LIST, List<Int32?> CATEGORY_ID_LIST, List<Int32?> TEACHER_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Question> oList = new List<Question>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.STUDENT_ID_LIST = string.Join(",", STUDENT_ID_LIST.ToArray()); p.CATEGORY_ID_LIST = string.Join(",", CATEGORY_ID_LIST.ToArray()); p.TEACHER_ID_LIST = string.Join(",", TEACHER_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_QUESTION_BY_CRITERIA_IN_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Question o = new Question();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Question> Get_Question_By_Where_InList ( string DESCRIPTION, List<Int32?> STUDENT_ID_LIST, List<Int32?> CATEGORY_ID_LIST, List<Int32?> TEACHER_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Question> oList = new List<Question>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.STUDENT_ID_LIST = string.Join(",", STUDENT_ID_LIST.ToArray()); p.CATEGORY_ID_LIST = string.Join(",", CATEGORY_ID_LIST.ToArray()); p.TEACHER_ID_LIST = string.Join(",", TEACHER_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_QUESTION_BY_WHERE_IN_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Question o = new Question();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Question_report> Get_Question_report_By_Criteria_InList ( string DESCRIPTION, List<Int32?> STUDENT_ID_LIST, List<Int32?> TEACHER_ID_LIST, List<Int32?> QUESTION_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Question_report> oList = new List<Question_report>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.STUDENT_ID_LIST = string.Join(",", STUDENT_ID_LIST.ToArray()); p.TEACHER_ID_LIST = string.Join(",", TEACHER_ID_LIST.ToArray()); p.QUESTION_ID_LIST = string.Join(",", QUESTION_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_QUESTION_REPORT_BY_CRITERIA_IN_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Question_report o = new Question_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Question_report> Get_Question_report_By_Where_InList ( string DESCRIPTION, List<Int32?> STUDENT_ID_LIST, List<Int32?> TEACHER_ID_LIST, List<Int32?> QUESTION_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Question_report> oList = new List<Question_report>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.STUDENT_ID_LIST = string.Join(",", STUDENT_ID_LIST.ToArray()); p.TEACHER_ID_LIST = string.Join(",", TEACHER_ID_LIST.ToArray()); p.QUESTION_ID_LIST = string.Join(",", QUESTION_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_QUESTION_REPORT_BY_WHERE_IN_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Question_report o = new Question_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Report_article> Get_Report_article_By_Criteria_InList ( string DESCRIPTION, List<Int32?> ARTICLE_ID_LIST, List<Int32?> STUDENT_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Report_article> oList = new List<Report_article>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.ARTICLE_ID_LIST = string.Join(",", ARTICLE_ID_LIST.ToArray()); p.STUDENT_ID_LIST = string.Join(",", STUDENT_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_REPORT_ARTICLE_BY_CRITERIA_IN_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Report_article o = new Report_article();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Report_article> Get_Report_article_By_Where_InList ( string DESCRIPTION, List<Int32?> ARTICLE_ID_LIST, List<Int32?> STUDENT_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Report_article> oList = new List<Report_article>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.ARTICLE_ID_LIST = string.Join(",", ARTICLE_ID_LIST.ToArray()); p.STUDENT_ID_LIST = string.Join(",", STUDENT_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_REPORT_ARTICLE_BY_WHERE_IN_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Report_article o = new Report_article();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Teacher_category> Get_Teacher_category_By_Criteria_InList ( string DESCRIPTION, List<Int32?> TEACHER_ID_LIST, List<Int32?> CATEGORY_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Teacher_category> oList = new List<Teacher_category>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.TEACHER_ID_LIST = string.Join(",", TEACHER_ID_LIST.ToArray()); p.CATEGORY_ID_LIST = string.Join(",", CATEGORY_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_CATEGORY_BY_CRITERIA_IN_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_category o = new Teacher_category();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Teacher_category> Get_Teacher_category_By_Where_InList ( string DESCRIPTION, List<Int32?> TEACHER_ID_LIST, List<Int32?> CATEGORY_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Teacher_category> oList = new List<Teacher_category>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.TEACHER_ID_LIST = string.Join(",", TEACHER_ID_LIST.ToArray()); p.CATEGORY_ID_LIST = string.Join(",", CATEGORY_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_CATEGORY_BY_WHERE_IN_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_category o = new Teacher_category();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Teacher_favorite> Get_Teacher_favorite_By_Criteria_InList ( string DESCRIPTION, List<Int32?> TEACHER_ID_LIST, List<Int32?> STUDENT_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Teacher_favorite> oList = new List<Teacher_favorite>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.TEACHER_ID_LIST = string.Join(",", TEACHER_ID_LIST.ToArray()); p.STUDENT_ID_LIST = string.Join(",", STUDENT_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_FAVORITE_BY_CRITERIA_IN_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_favorite o = new Teacher_favorite();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Teacher_favorite> Get_Teacher_favorite_By_Where_InList ( string DESCRIPTION, List<Int32?> TEACHER_ID_LIST, List<Int32?> STUDENT_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Teacher_favorite> oList = new List<Teacher_favorite>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.TEACHER_ID_LIST = string.Join(",", TEACHER_ID_LIST.ToArray()); p.STUDENT_ID_LIST = string.Join(",", STUDENT_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_FAVORITE_BY_WHERE_IN_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_favorite o = new Teacher_favorite();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Teacher_rank> Get_Teacher_rank_By_Criteria_InList ( string DESCRIPTION, List<Int32?> TEACHER_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Teacher_rank> oList = new List<Teacher_rank>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.TEACHER_ID_LIST = string.Join(",", TEACHER_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_RANK_BY_CRITERIA_IN_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_rank o = new Teacher_rank();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Teacher_rank> Get_Teacher_rank_By_Where_InList ( string DESCRIPTION, List<Int32?> TEACHER_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Teacher_rank> oList = new List<Teacher_rank>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.TEACHER_ID_LIST = string.Join(",", TEACHER_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_RANK_BY_WHERE_IN_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_rank o = new Teacher_rank();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Teacher_report> Get_Teacher_report_By_Criteria_InList ( string DESCRIPTION, List<Int32?> TEACHER_ID_LIST, List<Int32?> STUDENT_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Teacher_report> oList = new List<Teacher_report>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.TEACHER_ID_LIST = string.Join(",", TEACHER_ID_LIST.ToArray()); p.STUDENT_ID_LIST = string.Join(",", STUDENT_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_REPORT_BY_CRITERIA_IN_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_report o = new Teacher_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Teacher_report> Get_Teacher_report_By_Where_InList ( string DESCRIPTION, List<Int32?> TEACHER_ID_LIST, List<Int32?> STUDENT_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Teacher_report> oList = new List<Teacher_report>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.TEACHER_ID_LIST = string.Join(",", TEACHER_ID_LIST.ToArray()); p.STUDENT_ID_LIST = string.Join(",", STUDENT_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_REPORT_BY_WHERE_IN_LIST", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_report o = new Teacher_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Answer> Get_Answer_By_Criteria_InList_Adv ( string DESCRIPTION, List<Int32?> QUESTION_ID_LIST, List<Int32?> TEACHER_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Answer> oList = new List<Answer>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.QUESTION_ID_LIST = string.Join(",", QUESTION_ID_LIST.ToArray()); p.TEACHER_ID_LIST = string.Join(",", TEACHER_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_ANSWER_BY_CRITERIA_IN_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Answer o = new Answer();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Question = new Question();
o.My_Question.QUESTION_ID = Convert.IsDBNull(oRow["T_QUESTION_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_QUESTION_ID"]);o.My_Question.STUDENT_ID = Convert.IsDBNull(oRow["T_QUESTION_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_STUDENT_ID"]);o.My_Question.CATEGORY_ID = Convert.IsDBNull(oRow["T_QUESTION_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_CATEGORY_ID"]);o.My_Question.TEACHER_ID = Convert.IsDBNull(oRow["T_QUESTION_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_TEACHER_ID"]);o.My_Question.DESCRIPTION = Convert.IsDBNull(oRow["T_QUESTION_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_QUESTION_DESCRIPTION"]);o.My_Question.IS_ANSWERED = Convert.IsDBNull(oRow["T_QUESTION_IS_ANSWERED"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ANSWERED"]);o.My_Question.IS_ACTIVE = Convert.IsDBNull(oRow["T_QUESTION_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ACTIVE"]);o.My_Question.REPORTS = Convert.IsDBNull(oRow["T_QUESTION_REPORTS"]) ? default : Convert.ToInt32(oRow["T_QUESTION_REPORTS"]);o.My_Question.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_QUESTION_ENTRY_USER_ID"]);o.My_Question.ENTRY_DATE = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_QUESTION_ENTRY_DATE"]);o.My_Question.OWNER_ID = Convert.IsDBNull(oRow["T_QUESTION_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_OWNER_ID"]);
o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Answer> Get_Answer_By_Where_InList_Adv ( string DESCRIPTION, List<Int32?> QUESTION_ID_LIST, List<Int32?> TEACHER_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Answer> oList = new List<Answer>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.QUESTION_ID_LIST = string.Join(",", QUESTION_ID_LIST.ToArray()); p.TEACHER_ID_LIST = string.Join(",", TEACHER_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_ANSWER_BY_WHERE_IN_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Answer o = new Answer();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Question = new Question();
o.My_Question.QUESTION_ID = Convert.IsDBNull(oRow["T_QUESTION_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_QUESTION_ID"]);o.My_Question.STUDENT_ID = Convert.IsDBNull(oRow["T_QUESTION_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_STUDENT_ID"]);o.My_Question.CATEGORY_ID = Convert.IsDBNull(oRow["T_QUESTION_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_CATEGORY_ID"]);o.My_Question.TEACHER_ID = Convert.IsDBNull(oRow["T_QUESTION_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_TEACHER_ID"]);o.My_Question.DESCRIPTION = Convert.IsDBNull(oRow["T_QUESTION_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_QUESTION_DESCRIPTION"]);o.My_Question.IS_ANSWERED = Convert.IsDBNull(oRow["T_QUESTION_IS_ANSWERED"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ANSWERED"]);o.My_Question.IS_ACTIVE = Convert.IsDBNull(oRow["T_QUESTION_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ACTIVE"]);o.My_Question.REPORTS = Convert.IsDBNull(oRow["T_QUESTION_REPORTS"]) ? default : Convert.ToInt32(oRow["T_QUESTION_REPORTS"]);o.My_Question.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_QUESTION_ENTRY_USER_ID"]);o.My_Question.ENTRY_DATE = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_QUESTION_ENTRY_DATE"]);o.My_Question.OWNER_ID = Convert.IsDBNull(oRow["T_QUESTION_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_OWNER_ID"]);
o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Answer_report> Get_Answer_report_By_Criteria_InList_Adv ( string DESCRIPTION, List<Int32?> TEACHER_ID_LIST, List<Int32?> STUDENT_ID_LIST, List<Int32?> ANSWER_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Answer_report> oList = new List<Answer_report>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.TEACHER_ID_LIST = string.Join(",", TEACHER_ID_LIST.ToArray()); p.STUDENT_ID_LIST = string.Join(",", STUDENT_ID_LIST.ToArray()); p.ANSWER_ID_LIST = string.Join(",", ANSWER_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_ANSWER_REPORT_BY_CRITERIA_IN_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Answer_report o = new Answer_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
o.My_Answer = new Answer();
o.My_Answer.ANSWER_ID = Convert.IsDBNull(oRow["T_ANSWER_ANSWER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_ANSWER_ID"]);o.My_Answer.QUESTION_ID = Convert.IsDBNull(oRow["T_ANSWER_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_QUESTION_ID"]);o.My_Answer.TEACHER_ID = Convert.IsDBNull(oRow["T_ANSWER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_TEACHER_ID"]);o.My_Answer.DESCRIPTION = Convert.IsDBNull(oRow["T_ANSWER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_ANSWER_DESCRIPTION"]);o.My_Answer.SCORE = Convert.IsDBNull(oRow["T_ANSWER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_ANSWER_SCORE"]);o.My_Answer.REVIEWS = Convert.IsDBNull(oRow["T_ANSWER_REVIEWS"]) ? default : Convert.ToInt32(oRow["T_ANSWER_REVIEWS"]);o.My_Answer.REPORTS = Convert.IsDBNull(oRow["T_ANSWER_REPORTS"]) ? default : Convert.ToInt32(oRow["T_ANSWER_REPORTS"]);o.My_Answer.IS_ACTIVE = Convert.IsDBNull(oRow["T_ANSWER_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_ANSWER_IS_ACTIVE"]);o.My_Answer.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_ANSWER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_ANSWER_ENTRY_USER_ID"]);o.My_Answer.ENTRY_DATE = Convert.IsDBNull(oRow["T_ANSWER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_ANSWER_ENTRY_DATE"]);o.My_Answer.OWNER_ID = Convert.IsDBNull(oRow["T_ANSWER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Answer_report> Get_Answer_report_By_Where_InList_Adv ( string DESCRIPTION, List<Int32?> TEACHER_ID_LIST, List<Int32?> STUDENT_ID_LIST, List<Int32?> ANSWER_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Answer_report> oList = new List<Answer_report>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.TEACHER_ID_LIST = string.Join(",", TEACHER_ID_LIST.ToArray()); p.STUDENT_ID_LIST = string.Join(",", STUDENT_ID_LIST.ToArray()); p.ANSWER_ID_LIST = string.Join(",", ANSWER_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_ANSWER_REPORT_BY_WHERE_IN_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Answer_report o = new Answer_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
o.My_Answer = new Answer();
o.My_Answer.ANSWER_ID = Convert.IsDBNull(oRow["T_ANSWER_ANSWER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_ANSWER_ID"]);o.My_Answer.QUESTION_ID = Convert.IsDBNull(oRow["T_ANSWER_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_QUESTION_ID"]);o.My_Answer.TEACHER_ID = Convert.IsDBNull(oRow["T_ANSWER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_TEACHER_ID"]);o.My_Answer.DESCRIPTION = Convert.IsDBNull(oRow["T_ANSWER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_ANSWER_DESCRIPTION"]);o.My_Answer.SCORE = Convert.IsDBNull(oRow["T_ANSWER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_ANSWER_SCORE"]);o.My_Answer.REVIEWS = Convert.IsDBNull(oRow["T_ANSWER_REVIEWS"]) ? default : Convert.ToInt32(oRow["T_ANSWER_REVIEWS"]);o.My_Answer.REPORTS = Convert.IsDBNull(oRow["T_ANSWER_REPORTS"]) ? default : Convert.ToInt32(oRow["T_ANSWER_REPORTS"]);o.My_Answer.IS_ACTIVE = Convert.IsDBNull(oRow["T_ANSWER_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_ANSWER_IS_ACTIVE"]);o.My_Answer.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_ANSWER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_ANSWER_ENTRY_USER_ID"]);o.My_Answer.ENTRY_DATE = Convert.IsDBNull(oRow["T_ANSWER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_ANSWER_ENTRY_DATE"]);o.My_Answer.OWNER_ID = Convert.IsDBNull(oRow["T_ANSWER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Article> Get_Article_By_Criteria_InList_Adv ( string TITLE, string DESCRIPTION, List<Int32?> TEACHER_ID_LIST, List<Int32?> CATEGORY_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Article> oList = new List<Article>();
dynamic p = new ExpandoObject();
p.TITLE = TITLE; p.DESCRIPTION = DESCRIPTION; p.TEACHER_ID_LIST = string.Join(",", TEACHER_ID_LIST.ToArray()); p.CATEGORY_ID_LIST = string.Join(",", CATEGORY_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_ARTICLE_BY_CRITERIA_IN_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Article o = new Article();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Category = new Category();
o.My_Category.CATEGORY_ID = Convert.IsDBNull(oRow["T_CATEGORY_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_CATEGORY_ID"]);o.My_Category.NAME = Convert.IsDBNull(oRow["T_CATEGORY_NAME"]) ? default : Convert.ToString(oRow["T_CATEGORY_NAME"]);o.My_Category.DECRIPTION = Convert.IsDBNull(oRow["T_CATEGORY_DECRIPTION"]) ? default : Convert.ToString(oRow["T_CATEGORY_DECRIPTION"]);o.My_Category.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_CATEGORY_ENTRY_USER_ID"]);o.My_Category.ENTRY_DATE = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_CATEGORY_ENTRY_DATE"]);o.My_Category.OWNER_ID = Convert.IsDBNull(oRow["T_CATEGORY_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Article> Get_Article_By_Where_InList_Adv ( string TITLE, string DESCRIPTION, List<Int32?> TEACHER_ID_LIST, List<Int32?> CATEGORY_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Article> oList = new List<Article>();
dynamic p = new ExpandoObject();
p.TITLE = TITLE; p.DESCRIPTION = DESCRIPTION; p.TEACHER_ID_LIST = string.Join(",", TEACHER_ID_LIST.ToArray()); p.CATEGORY_ID_LIST = string.Join(",", CATEGORY_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_ARTICLE_BY_WHERE_IN_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Article o = new Article();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Category = new Category();
o.My_Category.CATEGORY_ID = Convert.IsDBNull(oRow["T_CATEGORY_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_CATEGORY_ID"]);o.My_Category.NAME = Convert.IsDBNull(oRow["T_CATEGORY_NAME"]) ? default : Convert.ToString(oRow["T_CATEGORY_NAME"]);o.My_Category.DECRIPTION = Convert.IsDBNull(oRow["T_CATEGORY_DECRIPTION"]) ? default : Convert.ToString(oRow["T_CATEGORY_DECRIPTION"]);o.My_Category.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_CATEGORY_ENTRY_USER_ID"]);o.My_Category.ENTRY_DATE = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_CATEGORY_ENTRY_DATE"]);o.My_Category.OWNER_ID = Convert.IsDBNull(oRow["T_CATEGORY_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Evaluation> Get_Evaluation_By_Criteria_InList_Adv ( string DESCRIPTION, List<Int32?> STUDENT_ID_LIST, List<Int32?> ANSWER_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Evaluation> oList = new List<Evaluation>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.STUDENT_ID_LIST = string.Join(",", STUDENT_ID_LIST.ToArray()); p.ANSWER_ID_LIST = string.Join(",", ANSWER_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_EVALUATION_BY_CRITERIA_IN_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Evaluation o = new Evaluation();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
o.My_Answer = new Answer();
o.My_Answer.ANSWER_ID = Convert.IsDBNull(oRow["T_ANSWER_ANSWER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_ANSWER_ID"]);o.My_Answer.QUESTION_ID = Convert.IsDBNull(oRow["T_ANSWER_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_QUESTION_ID"]);o.My_Answer.TEACHER_ID = Convert.IsDBNull(oRow["T_ANSWER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_TEACHER_ID"]);o.My_Answer.DESCRIPTION = Convert.IsDBNull(oRow["T_ANSWER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_ANSWER_DESCRIPTION"]);o.My_Answer.SCORE = Convert.IsDBNull(oRow["T_ANSWER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_ANSWER_SCORE"]);o.My_Answer.REVIEWS = Convert.IsDBNull(oRow["T_ANSWER_REVIEWS"]) ? default : Convert.ToInt32(oRow["T_ANSWER_REVIEWS"]);o.My_Answer.REPORTS = Convert.IsDBNull(oRow["T_ANSWER_REPORTS"]) ? default : Convert.ToInt32(oRow["T_ANSWER_REPORTS"]);o.My_Answer.IS_ACTIVE = Convert.IsDBNull(oRow["T_ANSWER_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_ANSWER_IS_ACTIVE"]);o.My_Answer.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_ANSWER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_ANSWER_ENTRY_USER_ID"]);o.My_Answer.ENTRY_DATE = Convert.IsDBNull(oRow["T_ANSWER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_ANSWER_ENTRY_DATE"]);o.My_Answer.OWNER_ID = Convert.IsDBNull(oRow["T_ANSWER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Evaluation> Get_Evaluation_By_Where_InList_Adv ( string DESCRIPTION, List<Int32?> STUDENT_ID_LIST, List<Int32?> ANSWER_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Evaluation> oList = new List<Evaluation>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.STUDENT_ID_LIST = string.Join(",", STUDENT_ID_LIST.ToArray()); p.ANSWER_ID_LIST = string.Join(",", ANSWER_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_EVALUATION_BY_WHERE_IN_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Evaluation o = new Evaluation();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
o.My_Answer = new Answer();
o.My_Answer.ANSWER_ID = Convert.IsDBNull(oRow["T_ANSWER_ANSWER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_ANSWER_ID"]);o.My_Answer.QUESTION_ID = Convert.IsDBNull(oRow["T_ANSWER_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_QUESTION_ID"]);o.My_Answer.TEACHER_ID = Convert.IsDBNull(oRow["T_ANSWER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_TEACHER_ID"]);o.My_Answer.DESCRIPTION = Convert.IsDBNull(oRow["T_ANSWER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_ANSWER_DESCRIPTION"]);o.My_Answer.SCORE = Convert.IsDBNull(oRow["T_ANSWER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_ANSWER_SCORE"]);o.My_Answer.REVIEWS = Convert.IsDBNull(oRow["T_ANSWER_REVIEWS"]) ? default : Convert.ToInt32(oRow["T_ANSWER_REVIEWS"]);o.My_Answer.REPORTS = Convert.IsDBNull(oRow["T_ANSWER_REPORTS"]) ? default : Convert.ToInt32(oRow["T_ANSWER_REPORTS"]);o.My_Answer.IS_ACTIVE = Convert.IsDBNull(oRow["T_ANSWER_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_ANSWER_IS_ACTIVE"]);o.My_Answer.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_ANSWER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_ANSWER_ENTRY_USER_ID"]);o.My_Answer.ENTRY_DATE = Convert.IsDBNull(oRow["T_ANSWER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_ANSWER_ENTRY_DATE"]);o.My_Answer.OWNER_ID = Convert.IsDBNull(oRow["T_ANSWER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Favorite_category> Get_Favorite_category_By_Criteria_InList_Adv ( string DESCRIPTION, List<Int32?> STUDENT_ID_LIST, List<Int32?> CATEGORY_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Favorite_category> oList = new List<Favorite_category>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.STUDENT_ID_LIST = string.Join(",", STUDENT_ID_LIST.ToArray()); p.CATEGORY_ID_LIST = string.Join(",", CATEGORY_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_FAVORITE_CATEGORY_BY_CRITERIA_IN_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Favorite_category o = new Favorite_category();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
o.My_Category = new Category();
o.My_Category.CATEGORY_ID = Convert.IsDBNull(oRow["T_CATEGORY_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_CATEGORY_ID"]);o.My_Category.NAME = Convert.IsDBNull(oRow["T_CATEGORY_NAME"]) ? default : Convert.ToString(oRow["T_CATEGORY_NAME"]);o.My_Category.DECRIPTION = Convert.IsDBNull(oRow["T_CATEGORY_DECRIPTION"]) ? default : Convert.ToString(oRow["T_CATEGORY_DECRIPTION"]);o.My_Category.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_CATEGORY_ENTRY_USER_ID"]);o.My_Category.ENTRY_DATE = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_CATEGORY_ENTRY_DATE"]);o.My_Category.OWNER_ID = Convert.IsDBNull(oRow["T_CATEGORY_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Favorite_category> Get_Favorite_category_By_Where_InList_Adv ( string DESCRIPTION, List<Int32?> STUDENT_ID_LIST, List<Int32?> CATEGORY_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Favorite_category> oList = new List<Favorite_category>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.STUDENT_ID_LIST = string.Join(",", STUDENT_ID_LIST.ToArray()); p.CATEGORY_ID_LIST = string.Join(",", CATEGORY_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_FAVORITE_CATEGORY_BY_WHERE_IN_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Favorite_category o = new Favorite_category();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
o.My_Category = new Category();
o.My_Category.CATEGORY_ID = Convert.IsDBNull(oRow["T_CATEGORY_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_CATEGORY_ID"]);o.My_Category.NAME = Convert.IsDBNull(oRow["T_CATEGORY_NAME"]) ? default : Convert.ToString(oRow["T_CATEGORY_NAME"]);o.My_Category.DECRIPTION = Convert.IsDBNull(oRow["T_CATEGORY_DECRIPTION"]) ? default : Convert.ToString(oRow["T_CATEGORY_DECRIPTION"]);o.My_Category.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_CATEGORY_ENTRY_USER_ID"]);o.My_Category.ENTRY_DATE = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_CATEGORY_ENTRY_DATE"]);o.My_Category.OWNER_ID = Convert.IsDBNull(oRow["T_CATEGORY_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Favorite_teacher> Get_Favorite_teacher_By_Criteria_InList_Adv ( string DESCRIPTION, List<Int32?> TEACHER_ID_LIST, List<Int32?> STUDENT_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Favorite_teacher> oList = new List<Favorite_teacher>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.TEACHER_ID_LIST = string.Join(",", TEACHER_ID_LIST.ToArray()); p.STUDENT_ID_LIST = string.Join(",", STUDENT_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_FAVORITE_TEACHER_BY_CRITERIA_IN_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Favorite_teacher o = new Favorite_teacher();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Favorite_teacher> Get_Favorite_teacher_By_Where_InList_Adv ( string DESCRIPTION, List<Int32?> TEACHER_ID_LIST, List<Int32?> STUDENT_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Favorite_teacher> oList = new List<Favorite_teacher>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.TEACHER_ID_LIST = string.Join(",", TEACHER_ID_LIST.ToArray()); p.STUDENT_ID_LIST = string.Join(",", STUDENT_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_FAVORITE_TEACHER_BY_WHERE_IN_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Favorite_teacher o = new Favorite_teacher();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Mark_question> Get_Mark_question_By_Criteria_InList_Adv ( string DESCRIPTION, List<Int32?> QUESTION_ID_LIST, List<Int32?> STUDENT_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Mark_question> oList = new List<Mark_question>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.QUESTION_ID_LIST = string.Join(",", QUESTION_ID_LIST.ToArray()); p.STUDENT_ID_LIST = string.Join(",", STUDENT_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_MARK_QUESTION_BY_CRITERIA_IN_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Mark_question o = new Mark_question();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Question = new Question();
o.My_Question.QUESTION_ID = Convert.IsDBNull(oRow["T_QUESTION_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_QUESTION_ID"]);o.My_Question.STUDENT_ID = Convert.IsDBNull(oRow["T_QUESTION_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_STUDENT_ID"]);o.My_Question.CATEGORY_ID = Convert.IsDBNull(oRow["T_QUESTION_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_CATEGORY_ID"]);o.My_Question.TEACHER_ID = Convert.IsDBNull(oRow["T_QUESTION_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_TEACHER_ID"]);o.My_Question.DESCRIPTION = Convert.IsDBNull(oRow["T_QUESTION_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_QUESTION_DESCRIPTION"]);o.My_Question.IS_ANSWERED = Convert.IsDBNull(oRow["T_QUESTION_IS_ANSWERED"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ANSWERED"]);o.My_Question.IS_ACTIVE = Convert.IsDBNull(oRow["T_QUESTION_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ACTIVE"]);o.My_Question.REPORTS = Convert.IsDBNull(oRow["T_QUESTION_REPORTS"]) ? default : Convert.ToInt32(oRow["T_QUESTION_REPORTS"]);o.My_Question.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_QUESTION_ENTRY_USER_ID"]);o.My_Question.ENTRY_DATE = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_QUESTION_ENTRY_DATE"]);o.My_Question.OWNER_ID = Convert.IsDBNull(oRow["T_QUESTION_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Mark_question> Get_Mark_question_By_Where_InList_Adv ( string DESCRIPTION, List<Int32?> QUESTION_ID_LIST, List<Int32?> STUDENT_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Mark_question> oList = new List<Mark_question>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.QUESTION_ID_LIST = string.Join(",", QUESTION_ID_LIST.ToArray()); p.STUDENT_ID_LIST = string.Join(",", STUDENT_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_MARK_QUESTION_BY_WHERE_IN_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Mark_question o = new Mark_question();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Question = new Question();
o.My_Question.QUESTION_ID = Convert.IsDBNull(oRow["T_QUESTION_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_QUESTION_ID"]);o.My_Question.STUDENT_ID = Convert.IsDBNull(oRow["T_QUESTION_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_STUDENT_ID"]);o.My_Question.CATEGORY_ID = Convert.IsDBNull(oRow["T_QUESTION_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_CATEGORY_ID"]);o.My_Question.TEACHER_ID = Convert.IsDBNull(oRow["T_QUESTION_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_TEACHER_ID"]);o.My_Question.DESCRIPTION = Convert.IsDBNull(oRow["T_QUESTION_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_QUESTION_DESCRIPTION"]);o.My_Question.IS_ANSWERED = Convert.IsDBNull(oRow["T_QUESTION_IS_ANSWERED"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ANSWERED"]);o.My_Question.IS_ACTIVE = Convert.IsDBNull(oRow["T_QUESTION_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ACTIVE"]);o.My_Question.REPORTS = Convert.IsDBNull(oRow["T_QUESTION_REPORTS"]) ? default : Convert.ToInt32(oRow["T_QUESTION_REPORTS"]);o.My_Question.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_QUESTION_ENTRY_USER_ID"]);o.My_Question.ENTRY_DATE = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_QUESTION_ENTRY_DATE"]);o.My_Question.OWNER_ID = Convert.IsDBNull(oRow["T_QUESTION_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Notification> Get_Notification_By_Criteria_InList_Adv ( string DESCRIPTION, List<Int32?> QUESTION_ID_LIST, List<Int32?> ANSWER_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Notification> oList = new List<Notification>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.QUESTION_ID_LIST = string.Join(",", QUESTION_ID_LIST.ToArray()); p.ANSWER_ID_LIST = string.Join(",", ANSWER_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_NOTIFICATION_BY_CRITERIA_IN_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Notification o = new Notification();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_User = new User();
o.My_User.USER_ID = Convert.IsDBNull(oRow["T_USER_USER_ID"]) ? default : Convert.ToInt64(oRow["T_USER_USER_ID"]);o.My_User.OWNER_ID = Convert.IsDBNull(oRow["T_USER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_USER_OWNER_ID"]);o.My_User.USERNAME = Convert.IsDBNull(oRow["T_USER_USERNAME"]) ? default : Convert.ToString(oRow["T_USER_USERNAME"]);o.My_User.PASSWORD = Convert.IsDBNull(oRow["T_USER_PASSWORD"]) ? default : Convert.ToString(oRow["T_USER_PASSWORD"]);o.My_User.USER_TYPE_CODE = Convert.IsDBNull(oRow["T_USER_USER_TYPE_CODE"]) ? default : Convert.ToString(oRow["T_USER_USER_TYPE_CODE"]);o.My_User.IS_LOGGED_IN = Convert.IsDBNull(oRow["T_USER_IS_LOGGED_IN"]) ? default : Convert.ToBoolean(oRow["T_USER_IS_LOGGED_IN"]);o.My_User.IS_ACTIVE = Convert.IsDBNull(oRow["T_USER_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_USER_IS_ACTIVE"]);o.My_User.ENTRY_DATE = Convert.IsDBNull(oRow["T_USER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_USER_ENTRY_DATE"]);
o.My_Question = new Question();
o.My_Question.QUESTION_ID = Convert.IsDBNull(oRow["T_QUESTION_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_QUESTION_ID"]);o.My_Question.STUDENT_ID = Convert.IsDBNull(oRow["T_QUESTION_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_STUDENT_ID"]);o.My_Question.CATEGORY_ID = Convert.IsDBNull(oRow["T_QUESTION_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_CATEGORY_ID"]);o.My_Question.TEACHER_ID = Convert.IsDBNull(oRow["T_QUESTION_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_TEACHER_ID"]);o.My_Question.DESCRIPTION = Convert.IsDBNull(oRow["T_QUESTION_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_QUESTION_DESCRIPTION"]);o.My_Question.IS_ANSWERED = Convert.IsDBNull(oRow["T_QUESTION_IS_ANSWERED"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ANSWERED"]);o.My_Question.IS_ACTIVE = Convert.IsDBNull(oRow["T_QUESTION_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ACTIVE"]);o.My_Question.REPORTS = Convert.IsDBNull(oRow["T_QUESTION_REPORTS"]) ? default : Convert.ToInt32(oRow["T_QUESTION_REPORTS"]);o.My_Question.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_QUESTION_ENTRY_USER_ID"]);o.My_Question.ENTRY_DATE = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_QUESTION_ENTRY_DATE"]);o.My_Question.OWNER_ID = Convert.IsDBNull(oRow["T_QUESTION_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_OWNER_ID"]);
o.My_Answer = new Answer();
o.My_Answer.ANSWER_ID = Convert.IsDBNull(oRow["T_ANSWER_ANSWER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_ANSWER_ID"]);o.My_Answer.QUESTION_ID = Convert.IsDBNull(oRow["T_ANSWER_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_QUESTION_ID"]);o.My_Answer.TEACHER_ID = Convert.IsDBNull(oRow["T_ANSWER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_TEACHER_ID"]);o.My_Answer.DESCRIPTION = Convert.IsDBNull(oRow["T_ANSWER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_ANSWER_DESCRIPTION"]);o.My_Answer.SCORE = Convert.IsDBNull(oRow["T_ANSWER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_ANSWER_SCORE"]);o.My_Answer.REVIEWS = Convert.IsDBNull(oRow["T_ANSWER_REVIEWS"]) ? default : Convert.ToInt32(oRow["T_ANSWER_REVIEWS"]);o.My_Answer.REPORTS = Convert.IsDBNull(oRow["T_ANSWER_REPORTS"]) ? default : Convert.ToInt32(oRow["T_ANSWER_REPORTS"]);o.My_Answer.IS_ACTIVE = Convert.IsDBNull(oRow["T_ANSWER_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_ANSWER_IS_ACTIVE"]);o.My_Answer.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_ANSWER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_ANSWER_ENTRY_USER_ID"]);o.My_Answer.ENTRY_DATE = Convert.IsDBNull(oRow["T_ANSWER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_ANSWER_ENTRY_DATE"]);o.My_Answer.OWNER_ID = Convert.IsDBNull(oRow["T_ANSWER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Notification> Get_Notification_By_Where_InList_Adv ( string DESCRIPTION, List<Int32?> QUESTION_ID_LIST, List<Int32?> ANSWER_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Notification> oList = new List<Notification>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.QUESTION_ID_LIST = string.Join(",", QUESTION_ID_LIST.ToArray()); p.ANSWER_ID_LIST = string.Join(",", ANSWER_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_NOTIFICATION_BY_WHERE_IN_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Notification o = new Notification();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_User = new User();
o.My_User.USER_ID = Convert.IsDBNull(oRow["T_USER_USER_ID"]) ? default : Convert.ToInt64(oRow["T_USER_USER_ID"]);o.My_User.OWNER_ID = Convert.IsDBNull(oRow["T_USER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_USER_OWNER_ID"]);o.My_User.USERNAME = Convert.IsDBNull(oRow["T_USER_USERNAME"]) ? default : Convert.ToString(oRow["T_USER_USERNAME"]);o.My_User.PASSWORD = Convert.IsDBNull(oRow["T_USER_PASSWORD"]) ? default : Convert.ToString(oRow["T_USER_PASSWORD"]);o.My_User.USER_TYPE_CODE = Convert.IsDBNull(oRow["T_USER_USER_TYPE_CODE"]) ? default : Convert.ToString(oRow["T_USER_USER_TYPE_CODE"]);o.My_User.IS_LOGGED_IN = Convert.IsDBNull(oRow["T_USER_IS_LOGGED_IN"]) ? default : Convert.ToBoolean(oRow["T_USER_IS_LOGGED_IN"]);o.My_User.IS_ACTIVE = Convert.IsDBNull(oRow["T_USER_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_USER_IS_ACTIVE"]);o.My_User.ENTRY_DATE = Convert.IsDBNull(oRow["T_USER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_USER_ENTRY_DATE"]);
o.My_Question = new Question();
o.My_Question.QUESTION_ID = Convert.IsDBNull(oRow["T_QUESTION_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_QUESTION_ID"]);o.My_Question.STUDENT_ID = Convert.IsDBNull(oRow["T_QUESTION_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_STUDENT_ID"]);o.My_Question.CATEGORY_ID = Convert.IsDBNull(oRow["T_QUESTION_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_CATEGORY_ID"]);o.My_Question.TEACHER_ID = Convert.IsDBNull(oRow["T_QUESTION_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_TEACHER_ID"]);o.My_Question.DESCRIPTION = Convert.IsDBNull(oRow["T_QUESTION_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_QUESTION_DESCRIPTION"]);o.My_Question.IS_ANSWERED = Convert.IsDBNull(oRow["T_QUESTION_IS_ANSWERED"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ANSWERED"]);o.My_Question.IS_ACTIVE = Convert.IsDBNull(oRow["T_QUESTION_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ACTIVE"]);o.My_Question.REPORTS = Convert.IsDBNull(oRow["T_QUESTION_REPORTS"]) ? default : Convert.ToInt32(oRow["T_QUESTION_REPORTS"]);o.My_Question.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_QUESTION_ENTRY_USER_ID"]);o.My_Question.ENTRY_DATE = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_QUESTION_ENTRY_DATE"]);o.My_Question.OWNER_ID = Convert.IsDBNull(oRow["T_QUESTION_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_OWNER_ID"]);
o.My_Answer = new Answer();
o.My_Answer.ANSWER_ID = Convert.IsDBNull(oRow["T_ANSWER_ANSWER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_ANSWER_ID"]);o.My_Answer.QUESTION_ID = Convert.IsDBNull(oRow["T_ANSWER_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_QUESTION_ID"]);o.My_Answer.TEACHER_ID = Convert.IsDBNull(oRow["T_ANSWER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_TEACHER_ID"]);o.My_Answer.DESCRIPTION = Convert.IsDBNull(oRow["T_ANSWER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_ANSWER_DESCRIPTION"]);o.My_Answer.SCORE = Convert.IsDBNull(oRow["T_ANSWER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_ANSWER_SCORE"]);o.My_Answer.REVIEWS = Convert.IsDBNull(oRow["T_ANSWER_REVIEWS"]) ? default : Convert.ToInt32(oRow["T_ANSWER_REVIEWS"]);o.My_Answer.REPORTS = Convert.IsDBNull(oRow["T_ANSWER_REPORTS"]) ? default : Convert.ToInt32(oRow["T_ANSWER_REPORTS"]);o.My_Answer.IS_ACTIVE = Convert.IsDBNull(oRow["T_ANSWER_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_ANSWER_IS_ACTIVE"]);o.My_Answer.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_ANSWER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_ANSWER_ENTRY_USER_ID"]);o.My_Answer.ENTRY_DATE = Convert.IsDBNull(oRow["T_ANSWER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_ANSWER_ENTRY_DATE"]);o.My_Answer.OWNER_ID = Convert.IsDBNull(oRow["T_ANSWER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_ANSWER_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Question> Get_Question_By_Criteria_InList_Adv ( string DESCRIPTION, List<Int32?> STUDENT_ID_LIST, List<Int32?> CATEGORY_ID_LIST, List<Int32?> TEACHER_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Question> oList = new List<Question>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.STUDENT_ID_LIST = string.Join(",", STUDENT_ID_LIST.ToArray()); p.CATEGORY_ID_LIST = string.Join(",", CATEGORY_ID_LIST.ToArray()); p.TEACHER_ID_LIST = string.Join(",", TEACHER_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_QUESTION_BY_CRITERIA_IN_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Question o = new Question();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
o.My_Category = new Category();
o.My_Category.CATEGORY_ID = Convert.IsDBNull(oRow["T_CATEGORY_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_CATEGORY_ID"]);o.My_Category.NAME = Convert.IsDBNull(oRow["T_CATEGORY_NAME"]) ? default : Convert.ToString(oRow["T_CATEGORY_NAME"]);o.My_Category.DECRIPTION = Convert.IsDBNull(oRow["T_CATEGORY_DECRIPTION"]) ? default : Convert.ToString(oRow["T_CATEGORY_DECRIPTION"]);o.My_Category.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_CATEGORY_ENTRY_USER_ID"]);o.My_Category.ENTRY_DATE = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_CATEGORY_ENTRY_DATE"]);o.My_Category.OWNER_ID = Convert.IsDBNull(oRow["T_CATEGORY_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_OWNER_ID"]);
o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Question> Get_Question_By_Where_InList_Adv ( string DESCRIPTION, List<Int32?> STUDENT_ID_LIST, List<Int32?> CATEGORY_ID_LIST, List<Int32?> TEACHER_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Question> oList = new List<Question>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.STUDENT_ID_LIST = string.Join(",", STUDENT_ID_LIST.ToArray()); p.CATEGORY_ID_LIST = string.Join(",", CATEGORY_ID_LIST.ToArray()); p.TEACHER_ID_LIST = string.Join(",", TEACHER_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_QUESTION_BY_WHERE_IN_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Question o = new Question();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
o.My_Category = new Category();
o.My_Category.CATEGORY_ID = Convert.IsDBNull(oRow["T_CATEGORY_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_CATEGORY_ID"]);o.My_Category.NAME = Convert.IsDBNull(oRow["T_CATEGORY_NAME"]) ? default : Convert.ToString(oRow["T_CATEGORY_NAME"]);o.My_Category.DECRIPTION = Convert.IsDBNull(oRow["T_CATEGORY_DECRIPTION"]) ? default : Convert.ToString(oRow["T_CATEGORY_DECRIPTION"]);o.My_Category.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_CATEGORY_ENTRY_USER_ID"]);o.My_Category.ENTRY_DATE = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_CATEGORY_ENTRY_DATE"]);o.My_Category.OWNER_ID = Convert.IsDBNull(oRow["T_CATEGORY_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_OWNER_ID"]);
o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Question_report> Get_Question_report_By_Criteria_InList_Adv ( string DESCRIPTION, List<Int32?> STUDENT_ID_LIST, List<Int32?> TEACHER_ID_LIST, List<Int32?> QUESTION_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Question_report> oList = new List<Question_report>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.STUDENT_ID_LIST = string.Join(",", STUDENT_ID_LIST.ToArray()); p.TEACHER_ID_LIST = string.Join(",", TEACHER_ID_LIST.ToArray()); p.QUESTION_ID_LIST = string.Join(",", QUESTION_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_QUESTION_REPORT_BY_CRITERIA_IN_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Question_report o = new Question_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Question = new Question();
o.My_Question.QUESTION_ID = Convert.IsDBNull(oRow["T_QUESTION_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_QUESTION_ID"]);o.My_Question.STUDENT_ID = Convert.IsDBNull(oRow["T_QUESTION_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_STUDENT_ID"]);o.My_Question.CATEGORY_ID = Convert.IsDBNull(oRow["T_QUESTION_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_CATEGORY_ID"]);o.My_Question.TEACHER_ID = Convert.IsDBNull(oRow["T_QUESTION_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_TEACHER_ID"]);o.My_Question.DESCRIPTION = Convert.IsDBNull(oRow["T_QUESTION_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_QUESTION_DESCRIPTION"]);o.My_Question.IS_ANSWERED = Convert.IsDBNull(oRow["T_QUESTION_IS_ANSWERED"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ANSWERED"]);o.My_Question.IS_ACTIVE = Convert.IsDBNull(oRow["T_QUESTION_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ACTIVE"]);o.My_Question.REPORTS = Convert.IsDBNull(oRow["T_QUESTION_REPORTS"]) ? default : Convert.ToInt32(oRow["T_QUESTION_REPORTS"]);o.My_Question.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_QUESTION_ENTRY_USER_ID"]);o.My_Question.ENTRY_DATE = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_QUESTION_ENTRY_DATE"]);o.My_Question.OWNER_ID = Convert.IsDBNull(oRow["T_QUESTION_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Question_report> Get_Question_report_By_Where_InList_Adv ( string DESCRIPTION, List<Int32?> STUDENT_ID_LIST, List<Int32?> TEACHER_ID_LIST, List<Int32?> QUESTION_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Question_report> oList = new List<Question_report>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.STUDENT_ID_LIST = string.Join(",", STUDENT_ID_LIST.ToArray()); p.TEACHER_ID_LIST = string.Join(",", TEACHER_ID_LIST.ToArray()); p.QUESTION_ID_LIST = string.Join(",", QUESTION_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_QUESTION_REPORT_BY_WHERE_IN_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Question_report o = new Question_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Question = new Question();
o.My_Question.QUESTION_ID = Convert.IsDBNull(oRow["T_QUESTION_QUESTION_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_QUESTION_ID"]);o.My_Question.STUDENT_ID = Convert.IsDBNull(oRow["T_QUESTION_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_STUDENT_ID"]);o.My_Question.CATEGORY_ID = Convert.IsDBNull(oRow["T_QUESTION_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_CATEGORY_ID"]);o.My_Question.TEACHER_ID = Convert.IsDBNull(oRow["T_QUESTION_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_TEACHER_ID"]);o.My_Question.DESCRIPTION = Convert.IsDBNull(oRow["T_QUESTION_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_QUESTION_DESCRIPTION"]);o.My_Question.IS_ANSWERED = Convert.IsDBNull(oRow["T_QUESTION_IS_ANSWERED"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ANSWERED"]);o.My_Question.IS_ACTIVE = Convert.IsDBNull(oRow["T_QUESTION_IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["T_QUESTION_IS_ACTIVE"]);o.My_Question.REPORTS = Convert.IsDBNull(oRow["T_QUESTION_REPORTS"]) ? default : Convert.ToInt32(oRow["T_QUESTION_REPORTS"]);o.My_Question.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_QUESTION_ENTRY_USER_ID"]);o.My_Question.ENTRY_DATE = Convert.IsDBNull(oRow["T_QUESTION_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_QUESTION_ENTRY_DATE"]);o.My_Question.OWNER_ID = Convert.IsDBNull(oRow["T_QUESTION_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_QUESTION_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Report_article> Get_Report_article_By_Criteria_InList_Adv ( string DESCRIPTION, List<Int32?> ARTICLE_ID_LIST, List<Int32?> STUDENT_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Report_article> oList = new List<Report_article>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.ARTICLE_ID_LIST = string.Join(",", ARTICLE_ID_LIST.ToArray()); p.STUDENT_ID_LIST = string.Join(",", STUDENT_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_REPORT_ARTICLE_BY_CRITERIA_IN_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Report_article o = new Report_article();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Article = new Article();
o.My_Article.ARTICLE_ID = Convert.IsDBNull(oRow["T_ARTICLE_ARTICLE_ID"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_ARTICLE_ID"]);o.My_Article.TEACHER_ID = Convert.IsDBNull(oRow["T_ARTICLE_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_TEACHER_ID"]);o.My_Article.CATEGORY_ID = Convert.IsDBNull(oRow["T_ARTICLE_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_CATEGORY_ID"]);o.My_Article.TITLE = Convert.IsDBNull(oRow["T_ARTICLE_TITLE"]) ? default : Convert.ToString(oRow["T_ARTICLE_TITLE"]);o.My_Article.DESCRIPTION = Convert.IsDBNull(oRow["T_ARTICLE_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_ARTICLE_DESCRIPTION"]);o.My_Article.APPLAUDS = Convert.IsDBNull(oRow["T_ARTICLE_APPLAUDS"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_APPLAUDS"]);o.My_Article.REPORTS = Convert.IsDBNull(oRow["T_ARTICLE_REPORTS"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_REPORTS"]);o.My_Article.IS_BLOCKED = Convert.IsDBNull(oRow["T_ARTICLE_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_ARTICLE_IS_BLOCKED"]);o.My_Article.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_ARTICLE_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_ARTICLE_ENTRY_USER_ID"]);o.My_Article.ENTRY_DATE = Convert.IsDBNull(oRow["T_ARTICLE_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_ARTICLE_ENTRY_DATE"]);o.My_Article.OWNER_ID = Convert.IsDBNull(oRow["T_ARTICLE_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Report_article> Get_Report_article_By_Where_InList_Adv ( string DESCRIPTION, List<Int32?> ARTICLE_ID_LIST, List<Int32?> STUDENT_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Report_article> oList = new List<Report_article>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.ARTICLE_ID_LIST = string.Join(",", ARTICLE_ID_LIST.ToArray()); p.STUDENT_ID_LIST = string.Join(",", STUDENT_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_REPORT_ARTICLE_BY_WHERE_IN_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Report_article o = new Report_article();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Article = new Article();
o.My_Article.ARTICLE_ID = Convert.IsDBNull(oRow["T_ARTICLE_ARTICLE_ID"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_ARTICLE_ID"]);o.My_Article.TEACHER_ID = Convert.IsDBNull(oRow["T_ARTICLE_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_TEACHER_ID"]);o.My_Article.CATEGORY_ID = Convert.IsDBNull(oRow["T_ARTICLE_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_CATEGORY_ID"]);o.My_Article.TITLE = Convert.IsDBNull(oRow["T_ARTICLE_TITLE"]) ? default : Convert.ToString(oRow["T_ARTICLE_TITLE"]);o.My_Article.DESCRIPTION = Convert.IsDBNull(oRow["T_ARTICLE_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_ARTICLE_DESCRIPTION"]);o.My_Article.APPLAUDS = Convert.IsDBNull(oRow["T_ARTICLE_APPLAUDS"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_APPLAUDS"]);o.My_Article.REPORTS = Convert.IsDBNull(oRow["T_ARTICLE_REPORTS"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_REPORTS"]);o.My_Article.IS_BLOCKED = Convert.IsDBNull(oRow["T_ARTICLE_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_ARTICLE_IS_BLOCKED"]);o.My_Article.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_ARTICLE_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_ARTICLE_ENTRY_USER_ID"]);o.My_Article.ENTRY_DATE = Convert.IsDBNull(oRow["T_ARTICLE_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_ARTICLE_ENTRY_DATE"]);o.My_Article.OWNER_ID = Convert.IsDBNull(oRow["T_ARTICLE_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_ARTICLE_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Teacher_category> Get_Teacher_category_By_Criteria_InList_Adv ( string DESCRIPTION, List<Int32?> TEACHER_ID_LIST, List<Int32?> CATEGORY_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Teacher_category> oList = new List<Teacher_category>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.TEACHER_ID_LIST = string.Join(",", TEACHER_ID_LIST.ToArray()); p.CATEGORY_ID_LIST = string.Join(",", CATEGORY_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_CATEGORY_BY_CRITERIA_IN_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_category o = new Teacher_category();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Category = new Category();
o.My_Category.CATEGORY_ID = Convert.IsDBNull(oRow["T_CATEGORY_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_CATEGORY_ID"]);o.My_Category.NAME = Convert.IsDBNull(oRow["T_CATEGORY_NAME"]) ? default : Convert.ToString(oRow["T_CATEGORY_NAME"]);o.My_Category.DECRIPTION = Convert.IsDBNull(oRow["T_CATEGORY_DECRIPTION"]) ? default : Convert.ToString(oRow["T_CATEGORY_DECRIPTION"]);o.My_Category.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_CATEGORY_ENTRY_USER_ID"]);o.My_Category.ENTRY_DATE = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_CATEGORY_ENTRY_DATE"]);o.My_Category.OWNER_ID = Convert.IsDBNull(oRow["T_CATEGORY_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Teacher_category> Get_Teacher_category_By_Where_InList_Adv ( string DESCRIPTION, List<Int32?> TEACHER_ID_LIST, List<Int32?> CATEGORY_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Teacher_category> oList = new List<Teacher_category>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.TEACHER_ID_LIST = string.Join(",", TEACHER_ID_LIST.ToArray()); p.CATEGORY_ID_LIST = string.Join(",", CATEGORY_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_CATEGORY_BY_WHERE_IN_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_category o = new Teacher_category();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Category = new Category();
o.My_Category.CATEGORY_ID = Convert.IsDBNull(oRow["T_CATEGORY_CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_CATEGORY_ID"]);o.My_Category.NAME = Convert.IsDBNull(oRow["T_CATEGORY_NAME"]) ? default : Convert.ToString(oRow["T_CATEGORY_NAME"]);o.My_Category.DECRIPTION = Convert.IsDBNull(oRow["T_CATEGORY_DECRIPTION"]) ? default : Convert.ToString(oRow["T_CATEGORY_DECRIPTION"]);o.My_Category.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_CATEGORY_ENTRY_USER_ID"]);o.My_Category.ENTRY_DATE = Convert.IsDBNull(oRow["T_CATEGORY_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_CATEGORY_ENTRY_DATE"]);o.My_Category.OWNER_ID = Convert.IsDBNull(oRow["T_CATEGORY_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_CATEGORY_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Teacher_favorite> Get_Teacher_favorite_By_Criteria_InList_Adv ( string DESCRIPTION, List<Int32?> TEACHER_ID_LIST, List<Int32?> STUDENT_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Teacher_favorite> oList = new List<Teacher_favorite>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.TEACHER_ID_LIST = string.Join(",", TEACHER_ID_LIST.ToArray()); p.STUDENT_ID_LIST = string.Join(",", STUDENT_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_FAVORITE_BY_CRITERIA_IN_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_favorite o = new Teacher_favorite();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Teacher_favorite> Get_Teacher_favorite_By_Where_InList_Adv ( string DESCRIPTION, List<Int32?> TEACHER_ID_LIST, List<Int32?> STUDENT_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Teacher_favorite> oList = new List<Teacher_favorite>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.TEACHER_ID_LIST = string.Join(",", TEACHER_ID_LIST.ToArray()); p.STUDENT_ID_LIST = string.Join(",", STUDENT_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_FAVORITE_BY_WHERE_IN_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_favorite o = new Teacher_favorite();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Teacher_rank> Get_Teacher_rank_By_Criteria_InList_Adv ( string DESCRIPTION, List<Int32?> TEACHER_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Teacher_rank> oList = new List<Teacher_rank>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.TEACHER_ID_LIST = string.Join(",", TEACHER_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_RANK_BY_CRITERIA_IN_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_rank o = new Teacher_rank();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Teacher_rank> Get_Teacher_rank_By_Where_InList_Adv ( string DESCRIPTION, List<Int32?> TEACHER_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Teacher_rank> oList = new List<Teacher_rank>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.TEACHER_ID_LIST = string.Join(",", TEACHER_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_RANK_BY_WHERE_IN_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_rank o = new Teacher_rank();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Teacher_report> Get_Teacher_report_By_Criteria_InList_Adv ( string DESCRIPTION, List<Int32?> TEACHER_ID_LIST, List<Int32?> STUDENT_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Teacher_report> oList = new List<Teacher_report>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.TEACHER_ID_LIST = string.Join(",", TEACHER_ID_LIST.ToArray()); p.STUDENT_ID_LIST = string.Join(",", STUDENT_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_REPORT_BY_CRITERIA_IN_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_report o = new Teacher_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public List<Teacher_report> Get_Teacher_report_By_Where_InList_Adv ( string DESCRIPTION, List<Int32?> TEACHER_ID_LIST, List<Int32?> STUDENT_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT)
{
List<Teacher_report> oList = new List<Teacher_report>();
dynamic p = new ExpandoObject();
p.DESCRIPTION = DESCRIPTION; p.TEACHER_ID_LIST = string.Join(",", TEACHER_ID_LIST.ToArray()); p.STUDENT_ID_LIST = string.Join(",", STUDENT_ID_LIST.ToArray()); p.OWNER_ID = OWNER_ID; p.START_ROW = START_ROW; p.END_ROW = END_ROW; p.TOTAL_COUNT = TOTAL_COUNT;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UPG_GET_TEACHER_REPORT_BY_WHERE_IN_LIST_ADV", p);
if (R != null)
{
foreach (var oRow in R)
{
Teacher_report o = new Teacher_report();
oTools.CopyPropValues_FromDataRecord(oRow, o);

o.My_Teacher = new Teacher();
o.My_Teacher.TEACHER_ID = Convert.IsDBNull(oRow["T_TEACHER_TEACHER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_TEACHER_ID"]);o.My_Teacher.USER_ID = Convert.IsDBNull(oRow["T_TEACHER_USER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_USER_ID"]);o.My_Teacher.FIRST_NAME = Convert.IsDBNull(oRow["T_TEACHER_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_FIRST_NAME"]);o.My_Teacher.LAST_NAME = Convert.IsDBNull(oRow["T_TEACHER_LAST_NAME"]) ? default : Convert.ToString(oRow["T_TEACHER_LAST_NAME"]);o.My_Teacher.SCORE = Convert.IsDBNull(oRow["T_TEACHER_SCORE"]) ? default : Convert.ToDecimal(oRow["T_TEACHER_SCORE"]);o.My_Teacher.DESCRIPTION = Convert.IsDBNull(oRow["T_TEACHER_DESCRIPTION"]) ? default : Convert.ToString(oRow["T_TEACHER_DESCRIPTION"]);o.My_Teacher.IS_BLOCKED = Convert.IsDBNull(oRow["T_TEACHER_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_TEACHER_IS_BLOCKED"]);o.My_Teacher.EMAIL = Convert.IsDBNull(oRow["T_TEACHER_EMAIL"]) ? default : Convert.ToString(oRow["T_TEACHER_EMAIL"]);o.My_Teacher.MOBILE = Convert.IsDBNull(oRow["T_TEACHER_MOBILE"]) ? default : Convert.ToString(oRow["T_TEACHER_MOBILE"]);o.My_Teacher.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_TEACHER_ENTRY_USER_ID"]);o.My_Teacher.ENTRY_DATE = Convert.IsDBNull(oRow["T_TEACHER_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_TEACHER_ENTRY_DATE"]);o.My_Teacher.OWNER_ID = Convert.IsDBNull(oRow["T_TEACHER_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_TEACHER_OWNER_ID"]);
o.My_Student = new Student();
o.My_Student.STUDENT_ID = Convert.IsDBNull(oRow["T_STUDENT_STUDENT_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_STUDENT_ID"]);o.My_Student.USER_ID = Convert.IsDBNull(oRow["T_STUDENT_USER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_USER_ID"]);o.My_Student.FIRST_NAME = Convert.IsDBNull(oRow["T_STUDENT_FIRST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_FIRST_NAME"]);o.My_Student.LAST_NAME = Convert.IsDBNull(oRow["T_STUDENT_LAST_NAME"]) ? default : Convert.ToString(oRow["T_STUDENT_LAST_NAME"]);o.My_Student.EMAIL = Convert.IsDBNull(oRow["T_STUDENT_EMAIL"]) ? default : Convert.ToString(oRow["T_STUDENT_EMAIL"]);o.My_Student.IS_BLOCKED = Convert.IsDBNull(oRow["T_STUDENT_IS_BLOCKED"]) ? default : Convert.ToBoolean(oRow["T_STUDENT_IS_BLOCKED"]);o.My_Student.PENDING_QUESTIONS = Convert.IsDBNull(oRow["T_STUDENT_PENDING_QUESTIONS"]) ? default : Convert.ToInt32(oRow["T_STUDENT_PENDING_QUESTIONS"]);o.My_Student.ENTRY_USER_ID = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["T_STUDENT_ENTRY_USER_ID"]);o.My_Student.ENTRY_DATE = Convert.IsDBNull(oRow["T_STUDENT_ENTRY_DATE"]) ? default : Convert.ToString(oRow["T_STUDENT_ENTRY_DATE"]);o.My_Student.OWNER_ID = Convert.IsDBNull(oRow["T_STUDENT_OWNER_ID"]) ? default : Convert.ToInt32(oRow["T_STUDENT_OWNER_ID"]);
oList.Add(o);
}
}
TOTAL_COUNT = p.TOTAL_COUNT;
return oList;
}
public void Delete_Answer ( Int32? ANSWER_ID)
{
var p = new { ANSWER_ID = ANSWER_ID };
ExecuteDelete("UPG_DELETE_ANSWER", p);
}
public void Delete_Answer_report ( Int32? ANSWER_REPORT_ID)
{
var p = new { ANSWER_REPORT_ID = ANSWER_REPORT_ID };
ExecuteDelete("UPG_DELETE_ANSWER_REPORT", p);
}
public void Delete_Appreciate ( Int32? APPRECIATE_ID)
{
var p = new { APPRECIATE_ID = APPRECIATE_ID };
ExecuteDelete("UPG_DELETE_APPRECIATE", p);
}
public void Delete_Article ( Int32? ARTICLE_ID)
{
var p = new { ARTICLE_ID = ARTICLE_ID };
ExecuteDelete("UPG_DELETE_ARTICLE", p);
}
public void Delete_Category ( Int32? CATEGORY_ID)
{
var p = new { CATEGORY_ID = CATEGORY_ID };
ExecuteDelete("UPG_DELETE_CATEGORY", p);
}
public void Delete_Evaluation ( Int32? EVALUATION_ID)
{
var p = new { EVALUATION_ID = EVALUATION_ID };
ExecuteDelete("UPG_DELETE_EVALUATION", p);
}
public void Delete_Favorite_category ( Int32? FAVORITE_CATEGORY_ID)
{
var p = new { FAVORITE_CATEGORY_ID = FAVORITE_CATEGORY_ID };
ExecuteDelete("UPG_DELETE_FAVORITE_CATEGORY", p);
}
public void Delete_Favorite_teacher ( Int32? FAVORITE_TEACHER_ID)
{
var p = new { FAVORITE_TEACHER_ID = FAVORITE_TEACHER_ID };
ExecuteDelete("UPG_DELETE_FAVORITE_TEACHER", p);
}
public void Delete_Mark_question ( Int32? MARK_QUESTION_ID)
{
var p = new { MARK_QUESTION_ID = MARK_QUESTION_ID };
ExecuteDelete("UPG_DELETE_MARK_QUESTION", p);
}
public void Delete_Notification ( Int32? NOTIFICATION_ID)
{
var p = new { NOTIFICATION_ID = NOTIFICATION_ID };
ExecuteDelete("UPG_DELETE_NOTIFICATION", p);
}
public void Delete_Owner ( Int32? OWNER_ID)
{
var p = new { OWNER_ID = OWNER_ID };
ExecuteDelete("UPG_DELETE_OWNER", p);
}
public void Delete_Question ( Int32? QUESTION_ID)
{
var p = new { QUESTION_ID = QUESTION_ID };
ExecuteDelete("UPG_DELETE_QUESTION", p);
}
public void Delete_Question_report ( Int32? QUESTION_REPORT_ID)
{
var p = new { QUESTION_REPORT_ID = QUESTION_REPORT_ID };
ExecuteDelete("UPG_DELETE_QUESTION_REPORT", p);
}
public void Delete_Question_token ( long? QUESTION_TOKEN_ID)
{
var p = new { QUESTION_TOKEN_ID = QUESTION_TOKEN_ID };
ExecuteDelete("UPG_DELETE_QUESTION_TOKEN", p);
}
public void Delete_Report_article ( Int32? REPORT_ARTICLE_ID)
{
var p = new { REPORT_ARTICLE_ID = REPORT_ARTICLE_ID };
ExecuteDelete("UPG_DELETE_REPORT_ARTICLE", p);
}
public void Delete_Student ( Int32? STUDENT_ID)
{
var p = new { STUDENT_ID = STUDENT_ID };
ExecuteDelete("UPG_DELETE_STUDENT", p);
}
public void Delete_Student_report ( Int32? STUDENT_REPORT_ID)
{
var p = new { STUDENT_REPORT_ID = STUDENT_REPORT_ID };
ExecuteDelete("UPG_DELETE_STUDENT_REPORT", p);
}
public void Delete_Teacher ( Int32? TEACHER_ID)
{
var p = new { TEACHER_ID = TEACHER_ID };
ExecuteDelete("UPG_DELETE_TEACHER", p);
}
public void Delete_Teacher_category ( Int32? TEACHER_CATEGORY_ID)
{
var p = new { TEACHER_CATEGORY_ID = TEACHER_CATEGORY_ID };
ExecuteDelete("UPG_DELETE_TEACHER_CATEGORY", p);
}
public void Delete_Teacher_favorite ( Int32? TEACHER_FAVORITE_ID)
{
var p = new { TEACHER_FAVORITE_ID = TEACHER_FAVORITE_ID };
ExecuteDelete("UPG_DELETE_TEACHER_FAVORITE", p);
}
public void Delete_Teacher_rank ( Int32? TEACHER_RANK_ID)
{
var p = new { TEACHER_RANK_ID = TEACHER_RANK_ID };
ExecuteDelete("UPG_DELETE_TEACHER_RANK", p);
}
public void Delete_Teacher_report ( Int32? TEACHER_REPORT_ID)
{
var p = new { TEACHER_REPORT_ID = TEACHER_REPORT_ID };
ExecuteDelete("UPG_DELETE_TEACHER_REPORT", p);
}
public void Delete_User ( long? USER_ID)
{
var p = new { USER_ID = USER_ID };
ExecuteDelete("UPG_DELETE_USER", p);
}
public void Delete_Answer_By_OWNER_ID ( Int32? OWNER_ID)
{
var p = new { OWNER_ID = OWNER_ID };
ExecuteDelete("UPG_DELETE_ANSWER_BY_OWNER_ID", p);
}
public void Delete_Answer_By_QUESTION_ID ( Int32? QUESTION_ID)
{
var p = new { QUESTION_ID = QUESTION_ID };
ExecuteDelete("UPG_DELETE_ANSWER_BY_QUESTION_ID", p);
}
public void Delete_Answer_By_TEACHER_ID ( Int32? TEACHER_ID)
{
var p = new { TEACHER_ID = TEACHER_ID };
ExecuteDelete("UPG_DELETE_ANSWER_BY_TEACHER_ID", p);
}
public void Delete_Answer_report_By_OWNER_ID ( Int32? OWNER_ID)
{
var p = new { OWNER_ID = OWNER_ID };
ExecuteDelete("UPG_DELETE_ANSWER_REPORT_BY_OWNER_ID", p);
}
public void Delete_Answer_report_By_TEACHER_ID ( Int32? TEACHER_ID)
{
var p = new { TEACHER_ID = TEACHER_ID };
ExecuteDelete("UPG_DELETE_ANSWER_REPORT_BY_TEACHER_ID", p);
}
public void Delete_Answer_report_By_STUDENT_ID ( Int32? STUDENT_ID)
{
var p = new { STUDENT_ID = STUDENT_ID };
ExecuteDelete("UPG_DELETE_ANSWER_REPORT_BY_STUDENT_ID", p);
}
public void Delete_Answer_report_By_ANSWER_ID ( Int32? ANSWER_ID)
{
var p = new { ANSWER_ID = ANSWER_ID };
ExecuteDelete("UPG_DELETE_ANSWER_REPORT_BY_ANSWER_ID", p);
}
public void Delete_Appreciate_By_OWNER_ID ( Int32? OWNER_ID)
{
var p = new { OWNER_ID = OWNER_ID };
ExecuteDelete("UPG_DELETE_APPRECIATE_BY_OWNER_ID", p);
}
public void Delete_Appreciate_By_ARTICLE_ID ( Int32? ARTICLE_ID)
{
var p = new { ARTICLE_ID = ARTICLE_ID };
ExecuteDelete("UPG_DELETE_APPRECIATE_BY_ARTICLE_ID", p);
}
public void Delete_Appreciate_By_STUDENT_ID ( Int32? STUDENT_ID)
{
var p = new { STUDENT_ID = STUDENT_ID };
ExecuteDelete("UPG_DELETE_APPRECIATE_BY_STUDENT_ID", p);
}
public void Delete_Article_By_OWNER_ID ( Int32? OWNER_ID)
{
var p = new { OWNER_ID = OWNER_ID };
ExecuteDelete("UPG_DELETE_ARTICLE_BY_OWNER_ID", p);
}
public void Delete_Article_By_TEACHER_ID ( Int32? TEACHER_ID)
{
var p = new { TEACHER_ID = TEACHER_ID };
ExecuteDelete("UPG_DELETE_ARTICLE_BY_TEACHER_ID", p);
}
public void Delete_Article_By_CATEGORY_ID ( Int32? CATEGORY_ID)
{
var p = new { CATEGORY_ID = CATEGORY_ID };
ExecuteDelete("UPG_DELETE_ARTICLE_BY_CATEGORY_ID", p);
}
public void Delete_Category_By_OWNER_ID ( Int32? OWNER_ID)
{
var p = new { OWNER_ID = OWNER_ID };
ExecuteDelete("UPG_DELETE_CATEGORY_BY_OWNER_ID", p);
}
public void Delete_Evaluation_By_OWNER_ID ( Int32? OWNER_ID)
{
var p = new { OWNER_ID = OWNER_ID };
ExecuteDelete("UPG_DELETE_EVALUATION_BY_OWNER_ID", p);
}
public void Delete_Evaluation_By_STUDENT_ID ( Int32? STUDENT_ID)
{
var p = new { STUDENT_ID = STUDENT_ID };
ExecuteDelete("UPG_DELETE_EVALUATION_BY_STUDENT_ID", p);
}
public void Delete_Evaluation_By_ANSWER_ID ( Int32? ANSWER_ID)
{
var p = new { ANSWER_ID = ANSWER_ID };
ExecuteDelete("UPG_DELETE_EVALUATION_BY_ANSWER_ID", p);
}
public void Delete_Favorite_category_By_STUDENT_ID ( Int32? STUDENT_ID)
{
var p = new { STUDENT_ID = STUDENT_ID };
ExecuteDelete("UPG_DELETE_FAVORITE_CATEGORY_BY_STUDENT_ID", p);
}
public void Delete_Favorite_category_By_CATEGORY_ID ( Int32? CATEGORY_ID)
{
var p = new { CATEGORY_ID = CATEGORY_ID };
ExecuteDelete("UPG_DELETE_FAVORITE_CATEGORY_BY_CATEGORY_ID", p);
}
public void Delete_Favorite_category_By_OWNER_ID ( Int32? OWNER_ID)
{
var p = new { OWNER_ID = OWNER_ID };
ExecuteDelete("UPG_DELETE_FAVORITE_CATEGORY_BY_OWNER_ID", p);
}
public void Delete_Favorite_teacher_By_TEACHER_ID ( Int32? TEACHER_ID)
{
var p = new { TEACHER_ID = TEACHER_ID };
ExecuteDelete("UPG_DELETE_FAVORITE_TEACHER_BY_TEACHER_ID", p);
}
public void Delete_Favorite_teacher_By_STUDENT_ID ( Int32? STUDENT_ID)
{
var p = new { STUDENT_ID = STUDENT_ID };
ExecuteDelete("UPG_DELETE_FAVORITE_TEACHER_BY_STUDENT_ID", p);
}
public void Delete_Favorite_teacher_By_OWNER_ID ( Int32? OWNER_ID)
{
var p = new { OWNER_ID = OWNER_ID };
ExecuteDelete("UPG_DELETE_FAVORITE_TEACHER_BY_OWNER_ID", p);
}
public void Delete_Mark_question_By_OWNER_ID ( Int32? OWNER_ID)
{
var p = new { OWNER_ID = OWNER_ID };
ExecuteDelete("UPG_DELETE_MARK_QUESTION_BY_OWNER_ID", p);
}
public void Delete_Mark_question_By_QUESTION_ID ( Int32? QUESTION_ID)
{
var p = new { QUESTION_ID = QUESTION_ID };
ExecuteDelete("UPG_DELETE_MARK_QUESTION_BY_QUESTION_ID", p);
}
public void Delete_Mark_question_By_STUDENT_ID ( Int32? STUDENT_ID)
{
var p = new { STUDENT_ID = STUDENT_ID };
ExecuteDelete("UPG_DELETE_MARK_QUESTION_BY_STUDENT_ID", p);
}
public void Delete_Notification_By_OWNER_ID ( Int32? OWNER_ID)
{
var p = new { OWNER_ID = OWNER_ID };
ExecuteDelete("UPG_DELETE_NOTIFICATION_BY_OWNER_ID", p);
}
public void Delete_Notification_By_USER_ID ( Int32? USER_ID)
{
var p = new { USER_ID = USER_ID };
ExecuteDelete("UPG_DELETE_NOTIFICATION_BY_USER_ID", p);
}
public void Delete_Notification_By_QUESTION_ID ( Int32? QUESTION_ID)
{
var p = new { QUESTION_ID = QUESTION_ID };
ExecuteDelete("UPG_DELETE_NOTIFICATION_BY_QUESTION_ID", p);
}
public void Delete_Notification_By_ANSWER_ID ( Int32? ANSWER_ID)
{
var p = new { ANSWER_ID = ANSWER_ID };
ExecuteDelete("UPG_DELETE_NOTIFICATION_BY_ANSWER_ID", p);
}
public void Delete_Question_By_OWNER_ID ( Int32? OWNER_ID)
{
var p = new { OWNER_ID = OWNER_ID };
ExecuteDelete("UPG_DELETE_QUESTION_BY_OWNER_ID", p);
}
public void Delete_Question_By_STUDENT_ID ( Int32? STUDENT_ID)
{
var p = new { STUDENT_ID = STUDENT_ID };
ExecuteDelete("UPG_DELETE_QUESTION_BY_STUDENT_ID", p);
}
public void Delete_Question_By_CATEGORY_ID ( Int32? CATEGORY_ID)
{
var p = new { CATEGORY_ID = CATEGORY_ID };
ExecuteDelete("UPG_DELETE_QUESTION_BY_CATEGORY_ID", p);
}
public void Delete_Question_By_TEACHER_ID ( Int32? TEACHER_ID)
{
var p = new { TEACHER_ID = TEACHER_ID };
ExecuteDelete("UPG_DELETE_QUESTION_BY_TEACHER_ID", p);
}
public void Delete_Question_report_By_OWNER_ID ( Int32? OWNER_ID)
{
var p = new { OWNER_ID = OWNER_ID };
ExecuteDelete("UPG_DELETE_QUESTION_REPORT_BY_OWNER_ID", p);
}
public void Delete_Question_report_By_STUDENT_ID ( Int32? STUDENT_ID)
{
var p = new { STUDENT_ID = STUDENT_ID };
ExecuteDelete("UPG_DELETE_QUESTION_REPORT_BY_STUDENT_ID", p);
}
public void Delete_Question_report_By_TEACHER_ID ( Int32? TEACHER_ID)
{
var p = new { TEACHER_ID = TEACHER_ID };
ExecuteDelete("UPG_DELETE_QUESTION_REPORT_BY_TEACHER_ID", p);
}
public void Delete_Question_report_By_QUESTION_ID ( Int32? QUESTION_ID)
{
var p = new { QUESTION_ID = QUESTION_ID };
ExecuteDelete("UPG_DELETE_QUESTION_REPORT_BY_QUESTION_ID", p);
}
public void Delete_Question_token_By_PART ( string PART)
{
var p = new { PART = PART };
ExecuteDelete("UPG_DELETE_QUESTION_TOKEN_BY_PART", p);
}
public void Delete_Question_token_By_OWNER_ID ( Int32? OWNER_ID)
{
var p = new { OWNER_ID = OWNER_ID };
ExecuteDelete("UPG_DELETE_QUESTION_TOKEN_BY_OWNER_ID", p);
}
public void Delete_Question_token_By_QUESTION_ID ( long? QUESTION_ID)
{
var p = new { QUESTION_ID = QUESTION_ID };
ExecuteDelete("UPG_DELETE_QUESTION_TOKEN_BY_QUESTION_ID", p);
}
public void Delete_Report_article_By_OWNER_ID ( Int32? OWNER_ID)
{
var p = new { OWNER_ID = OWNER_ID };
ExecuteDelete("UPG_DELETE_REPORT_ARTICLE_BY_OWNER_ID", p);
}
public void Delete_Report_article_By_ARTICLE_ID ( Int32? ARTICLE_ID)
{
var p = new { ARTICLE_ID = ARTICLE_ID };
ExecuteDelete("UPG_DELETE_REPORT_ARTICLE_BY_ARTICLE_ID", p);
}
public void Delete_Report_article_By_STUDENT_ID ( Int32? STUDENT_ID)
{
var p = new { STUDENT_ID = STUDENT_ID };
ExecuteDelete("UPG_DELETE_REPORT_ARTICLE_BY_STUDENT_ID", p);
}
public void Delete_Student_By_OWNER_ID ( Int32? OWNER_ID)
{
var p = new { OWNER_ID = OWNER_ID };
ExecuteDelete("UPG_DELETE_STUDENT_BY_OWNER_ID", p);
}
public void Delete_Student_By_USER_ID ( Int32? USER_ID)
{
var p = new { USER_ID = USER_ID };
ExecuteDelete("UPG_DELETE_STUDENT_BY_USER_ID", p);
}
public void Delete_Student_report_By_OWNER_ID ( Int32? OWNER_ID)
{
var p = new { OWNER_ID = OWNER_ID };
ExecuteDelete("UPG_DELETE_STUDENT_REPORT_BY_OWNER_ID", p);
}
public void Delete_Student_report_By_REPORTED_BY_STUDENT_ID ( Int32? REPORTED_BY_STUDENT_ID)
{
var p = new { REPORTED_BY_STUDENT_ID = REPORTED_BY_STUDENT_ID };
ExecuteDelete("UPG_DELETE_STUDENT_REPORT_BY_REPORTED_BY_STUDENT_ID", p);
}
public void Delete_Student_report_By_REPORTED_STUDENT_ID ( Int32? REPORTED_STUDENT_ID)
{
var p = new { REPORTED_STUDENT_ID = REPORTED_STUDENT_ID };
ExecuteDelete("UPG_DELETE_STUDENT_REPORT_BY_REPORTED_STUDENT_ID", p);
}
public void Delete_Teacher_By_OWNER_ID ( Int32? OWNER_ID)
{
var p = new { OWNER_ID = OWNER_ID };
ExecuteDelete("UPG_DELETE_TEACHER_BY_OWNER_ID", p);
}
public void Delete_Teacher_By_USER_ID ( Int32? USER_ID)
{
var p = new { USER_ID = USER_ID };
ExecuteDelete("UPG_DELETE_TEACHER_BY_USER_ID", p);
}
public void Delete_Teacher_category_By_OWNER_ID ( Int32? OWNER_ID)
{
var p = new { OWNER_ID = OWNER_ID };
ExecuteDelete("UPG_DELETE_TEACHER_CATEGORY_BY_OWNER_ID", p);
}
public void Delete_Teacher_category_By_TEACHER_ID ( Int32? TEACHER_ID)
{
var p = new { TEACHER_ID = TEACHER_ID };
ExecuteDelete("UPG_DELETE_TEACHER_CATEGORY_BY_TEACHER_ID", p);
}
public void Delete_Teacher_category_By_CATEGORY_ID ( Int32? CATEGORY_ID)
{
var p = new { CATEGORY_ID = CATEGORY_ID };
ExecuteDelete("UPG_DELETE_TEACHER_CATEGORY_BY_CATEGORY_ID", p);
}
public void Delete_Teacher_favorite_By_OWNER_ID ( Int32? OWNER_ID)
{
var p = new { OWNER_ID = OWNER_ID };
ExecuteDelete("UPG_DELETE_TEACHER_FAVORITE_BY_OWNER_ID", p);
}
public void Delete_Teacher_favorite_By_TEACHER_ID ( Int32? TEACHER_ID)
{
var p = new { TEACHER_ID = TEACHER_ID };
ExecuteDelete("UPG_DELETE_TEACHER_FAVORITE_BY_TEACHER_ID", p);
}
public void Delete_Teacher_favorite_By_STUDENT_ID ( Int32? STUDENT_ID)
{
var p = new { STUDENT_ID = STUDENT_ID };
ExecuteDelete("UPG_DELETE_TEACHER_FAVORITE_BY_STUDENT_ID", p);
}
public void Delete_Teacher_rank_By_TEACHER_ID ( Int32? TEACHER_ID)
{
var p = new { TEACHER_ID = TEACHER_ID };
ExecuteDelete("UPG_DELETE_TEACHER_RANK_BY_TEACHER_ID", p);
}
public void Delete_Teacher_rank_By_OWNER_ID ( Int32? OWNER_ID)
{
var p = new { OWNER_ID = OWNER_ID };
ExecuteDelete("UPG_DELETE_TEACHER_RANK_BY_OWNER_ID", p);
}
public void Delete_Teacher_report_By_OWNER_ID ( Int32? OWNER_ID)
{
var p = new { OWNER_ID = OWNER_ID };
ExecuteDelete("UPG_DELETE_TEACHER_REPORT_BY_OWNER_ID", p);
}
public void Delete_Teacher_report_By_TEACHER_ID ( Int32? TEACHER_ID)
{
var p = new { TEACHER_ID = TEACHER_ID };
ExecuteDelete("UPG_DELETE_TEACHER_REPORT_BY_TEACHER_ID", p);
}
public void Delete_Teacher_report_By_STUDENT_ID ( Int32? STUDENT_ID)
{
var p = new { STUDENT_ID = STUDENT_ID };
ExecuteDelete("UPG_DELETE_TEACHER_REPORT_BY_STUDENT_ID", p);
}
public void Delete_User_By_OWNER_ID ( Int32? OWNER_ID)
{
var p = new { OWNER_ID = OWNER_ID };
ExecuteDelete("UPG_DELETE_USER_BY_OWNER_ID", p);
}
public void Delete_User_By_USERNAME ( string USERNAME)
{
var p = new { USERNAME = USERNAME };
ExecuteDelete("UPG_DELETE_USER_BY_USERNAME", p);
}
public Int32? Edit_Answer ( Int32? ANSWER_ID, Int32? QUESTION_ID, Int32? TEACHER_ID, string DESCRIPTION, decimal? SCORE, Int32? REVIEWS, Int32? REPORTS, bool? IS_ACTIVE, long? ENTRY_USER_ID, string ENTRY_DATE, Int32? OWNER_ID)
{
Answer oAnswer = new Answer();
oAnswer.ANSWER_ID = ANSWER_ID;oAnswer.QUESTION_ID = QUESTION_ID;oAnswer.TEACHER_ID = TEACHER_ID;oAnswer.DESCRIPTION = DESCRIPTION;oAnswer.SCORE = SCORE;oAnswer.REVIEWS = REVIEWS;oAnswer.REPORTS = REPORTS;oAnswer.IS_ACTIVE = IS_ACTIVE;oAnswer.ENTRY_USER_ID = ENTRY_USER_ID;oAnswer.ENTRY_DATE = ENTRY_DATE;oAnswer.OWNER_ID = OWNER_ID;
ExecuteEdit("UPG_EDIT_ANSWER", oAnswer, "ANSWER_ID");
return oAnswer.ANSWER_ID;
}
public Int32? Edit_Answer_report ( Int32? ANSWER_REPORT_ID, Int32? TEACHER_ID, Int32? STUDENT_ID, Int32? ANSWER_ID, string DESCRIPTION, long? ENTRY_USER_ID, string ENTRY_DATE, Int32? OWNER_ID)
{
Answer_report oAnswer_report = new Answer_report();
oAnswer_report.ANSWER_REPORT_ID = ANSWER_REPORT_ID;oAnswer_report.TEACHER_ID = TEACHER_ID;oAnswer_report.STUDENT_ID = STUDENT_ID;oAnswer_report.ANSWER_ID = ANSWER_ID;oAnswer_report.DESCRIPTION = DESCRIPTION;oAnswer_report.ENTRY_USER_ID = ENTRY_USER_ID;oAnswer_report.ENTRY_DATE = ENTRY_DATE;oAnswer_report.OWNER_ID = OWNER_ID;
ExecuteEdit("UPG_EDIT_ANSWER_REPORT", oAnswer_report, "ANSWER_REPORT_ID");
return oAnswer_report.ANSWER_REPORT_ID;
}
public Int32? Edit_Appreciate ( Int32? APPRECIATE_ID, Int32? ARTICLE_ID, Int32? STUDENT_ID, string DESCRIPTION, long? ENTRY_USER_ID, string ENTRY_DATE, Int32? OWNER_ID)
{
Appreciate oAppreciate = new Appreciate();
oAppreciate.APPRECIATE_ID = APPRECIATE_ID;oAppreciate.ARTICLE_ID = ARTICLE_ID;oAppreciate.STUDENT_ID = STUDENT_ID;oAppreciate.DESCRIPTION = DESCRIPTION;oAppreciate.ENTRY_USER_ID = ENTRY_USER_ID;oAppreciate.ENTRY_DATE = ENTRY_DATE;oAppreciate.OWNER_ID = OWNER_ID;
ExecuteEdit("UPG_EDIT_APPRECIATE", oAppreciate, "APPRECIATE_ID");
return oAppreciate.APPRECIATE_ID;
}
public Int32? Edit_Article ( Int32? ARTICLE_ID, Int32? TEACHER_ID, Int32? CATEGORY_ID, string TITLE, string DESCRIPTION, Int32? APPLAUDS, Int32? REPORTS, bool? IS_BLOCKED, long? ENTRY_USER_ID, string ENTRY_DATE, Int32? OWNER_ID)
{
Article oArticle = new Article();
oArticle.ARTICLE_ID = ARTICLE_ID;oArticle.TEACHER_ID = TEACHER_ID;oArticle.CATEGORY_ID = CATEGORY_ID;oArticle.TITLE = TITLE;oArticle.DESCRIPTION = DESCRIPTION;oArticle.APPLAUDS = APPLAUDS;oArticle.REPORTS = REPORTS;oArticle.IS_BLOCKED = IS_BLOCKED;oArticle.ENTRY_USER_ID = ENTRY_USER_ID;oArticle.ENTRY_DATE = ENTRY_DATE;oArticle.OWNER_ID = OWNER_ID;
ExecuteEdit("UPG_EDIT_ARTICLE", oArticle, "ARTICLE_ID");
return oArticle.ARTICLE_ID;
}
public Int32? Edit_Category ( Int32? CATEGORY_ID, string NAME, string DECRIPTION, long? ENTRY_USER_ID, string ENTRY_DATE, Int32? OWNER_ID)
{
Category oCategory = new Category();
oCategory.CATEGORY_ID = CATEGORY_ID;oCategory.NAME = NAME;oCategory.DECRIPTION = DECRIPTION;oCategory.ENTRY_USER_ID = ENTRY_USER_ID;oCategory.ENTRY_DATE = ENTRY_DATE;oCategory.OWNER_ID = OWNER_ID;
ExecuteEdit("UPG_EDIT_CATEGORY", oCategory, "CATEGORY_ID");
return oCategory.CATEGORY_ID;
}
public Int32? Edit_Evaluation ( Int32? EVALUATION_ID, Int32? STUDENT_ID, Int32? ANSWER_ID, decimal SCORE, long? ENTRY_USER_ID, string ENTRY_DATE, Int32? OWNER_ID, string DESCRIPTION)
{
Evaluation oEvaluation = new Evaluation();
oEvaluation.EVALUATION_ID = EVALUATION_ID;oEvaluation.STUDENT_ID = STUDENT_ID;oEvaluation.ANSWER_ID = ANSWER_ID;oEvaluation.SCORE = SCORE;oEvaluation.ENTRY_USER_ID = ENTRY_USER_ID;oEvaluation.ENTRY_DATE = ENTRY_DATE;oEvaluation.OWNER_ID = OWNER_ID;oEvaluation.DESCRIPTION = DESCRIPTION;
ExecuteEdit("UPG_EDIT_EVALUATION", oEvaluation, "EVALUATION_ID");
return oEvaluation.EVALUATION_ID;
}
public Int32? Edit_Favorite_category ( Int32? FAVORITE_CATEGORY_ID, Int32? STUDENT_ID, Int32? CATEGORY_ID, string DESCRIPTION, long? ENTRY_USER_ID, Int32? OWNER_ID, string ENTRY_DATE)
{
Favorite_category oFavorite_category = new Favorite_category();
oFavorite_category.FAVORITE_CATEGORY_ID = FAVORITE_CATEGORY_ID;oFavorite_category.STUDENT_ID = STUDENT_ID;oFavorite_category.CATEGORY_ID = CATEGORY_ID;oFavorite_category.DESCRIPTION = DESCRIPTION;oFavorite_category.ENTRY_USER_ID = ENTRY_USER_ID;oFavorite_category.OWNER_ID = OWNER_ID;oFavorite_category.ENTRY_DATE = ENTRY_DATE;
ExecuteEdit("UPG_EDIT_FAVORITE_CATEGORY", oFavorite_category, "FAVORITE_CATEGORY_ID");
return oFavorite_category.FAVORITE_CATEGORY_ID;
}
public Int32? Edit_Favorite_teacher ( Int32? FAVORITE_TEACHER_ID, Int32? TEACHER_ID, Int32? STUDENT_ID, string DESCRIPTION, long? ENTRY_USER_ID, Int32? OWNER_ID, string ENTRY_DATE)
{
Favorite_teacher oFavorite_teacher = new Favorite_teacher();
oFavorite_teacher.FAVORITE_TEACHER_ID = FAVORITE_TEACHER_ID;oFavorite_teacher.TEACHER_ID = TEACHER_ID;oFavorite_teacher.STUDENT_ID = STUDENT_ID;oFavorite_teacher.DESCRIPTION = DESCRIPTION;oFavorite_teacher.ENTRY_USER_ID = ENTRY_USER_ID;oFavorite_teacher.OWNER_ID = OWNER_ID;oFavorite_teacher.ENTRY_DATE = ENTRY_DATE;
ExecuteEdit("UPG_EDIT_FAVORITE_TEACHER", oFavorite_teacher, "FAVORITE_TEACHER_ID");
return oFavorite_teacher.FAVORITE_TEACHER_ID;
}
public Int32? Edit_Mark_question ( Int32? MARK_QUESTION_ID, Int32? QUESTION_ID, Int32? STUDENT_ID, long? ENTRY_USER_ID, string ENTRY_DATE, Int32? OWNER_ID, string DESCRIPTION)
{
Mark_question oMark_question = new Mark_question();
oMark_question.MARK_QUESTION_ID = MARK_QUESTION_ID;oMark_question.QUESTION_ID = QUESTION_ID;oMark_question.STUDENT_ID = STUDENT_ID;oMark_question.ENTRY_USER_ID = ENTRY_USER_ID;oMark_question.ENTRY_DATE = ENTRY_DATE;oMark_question.OWNER_ID = OWNER_ID;oMark_question.DESCRIPTION = DESCRIPTION;
ExecuteEdit("UPG_EDIT_MARK_QUESTION", oMark_question, "MARK_QUESTION_ID");
return oMark_question.MARK_QUESTION_ID;
}
public Int32? Edit_Notification ( Int32? NOTIFICATION_ID, Int32? USER_ID, string DESCRIPTION, Int32? QUESTION_ID, Int32? ANSWER_ID, long? ENTRY_USER_ID, string ENTRY_DATE, Int32? OWNER_ID)
{
Notification oNotification = new Notification();
oNotification.NOTIFICATION_ID = NOTIFICATION_ID;oNotification.USER_ID = USER_ID;oNotification.DESCRIPTION = DESCRIPTION;oNotification.QUESTION_ID = QUESTION_ID;oNotification.ANSWER_ID = ANSWER_ID;oNotification.ENTRY_USER_ID = ENTRY_USER_ID;oNotification.ENTRY_DATE = ENTRY_DATE;oNotification.OWNER_ID = OWNER_ID;
ExecuteEdit("UPG_EDIT_NOTIFICATION", oNotification, "NOTIFICATION_ID");
return oNotification.NOTIFICATION_ID;
}
public Int32? Edit_Owner ( Int32? OWNER_ID, string CODE, string MAINTENANCE_DUE_DATE, string DESCRIPTION, string ENTRY_DATE)
{
Owner oOwner = new Owner();
oOwner.OWNER_ID = OWNER_ID;oOwner.CODE = CODE;oOwner.MAINTENANCE_DUE_DATE = MAINTENANCE_DUE_DATE;oOwner.DESCRIPTION = DESCRIPTION;oOwner.ENTRY_DATE = ENTRY_DATE;
ExecuteEdit("UPG_EDIT_OWNER", oOwner, "OWNER_ID");
return oOwner.OWNER_ID;
}
public Int32? Edit_Question ( Int32? QUESTION_ID, Int32? STUDENT_ID, Int32? CATEGORY_ID, Int32? TEACHER_ID, string DESCRIPTION, bool? IS_ANSWERED, bool? IS_ACTIVE, Int32? REPORTS, long? ENTRY_USER_ID, string ENTRY_DATE, Int32? OWNER_ID)
{
Question oQuestion = new Question();
oQuestion.QUESTION_ID = QUESTION_ID;oQuestion.STUDENT_ID = STUDENT_ID;oQuestion.CATEGORY_ID = CATEGORY_ID;oQuestion.TEACHER_ID = TEACHER_ID;oQuestion.DESCRIPTION = DESCRIPTION;oQuestion.IS_ANSWERED = IS_ANSWERED;oQuestion.IS_ACTIVE = IS_ACTIVE;oQuestion.REPORTS = REPORTS;oQuestion.ENTRY_USER_ID = ENTRY_USER_ID;oQuestion.ENTRY_DATE = ENTRY_DATE;oQuestion.OWNER_ID = OWNER_ID;
ExecuteEdit("UPG_EDIT_QUESTION", oQuestion, "QUESTION_ID");
return oQuestion.QUESTION_ID;
}
public Int32? Edit_Question_report ( Int32? QUESTION_REPORT_ID, Int32? STUDENT_ID, Int32? TEACHER_ID, Int32? QUESTION_ID, string DESCRIPTION, long? ENTRY_USER_ID, string ENTRY_DATE, Int32? OWNER_ID)
{
Question_report oQuestion_report = new Question_report();
oQuestion_report.QUESTION_REPORT_ID = QUESTION_REPORT_ID;oQuestion_report.STUDENT_ID = STUDENT_ID;oQuestion_report.TEACHER_ID = TEACHER_ID;oQuestion_report.QUESTION_ID = QUESTION_ID;oQuestion_report.DESCRIPTION = DESCRIPTION;oQuestion_report.ENTRY_USER_ID = ENTRY_USER_ID;oQuestion_report.ENTRY_DATE = ENTRY_DATE;oQuestion_report.OWNER_ID = OWNER_ID;
ExecuteEdit("UPG_EDIT_QUESTION_REPORT", oQuestion_report, "QUESTION_REPORT_ID");
return oQuestion_report.QUESTION_REPORT_ID;
}
public long? Edit_Question_token ( long? QUESTION_TOKEN_ID, long? QUESTION_ID, string PART, long? ENTRY_USER_ID, string ENTRY_DATE, Int32? OWNER_ID)
{
Question_token oQuestion_token = new Question_token();
oQuestion_token.QUESTION_TOKEN_ID = QUESTION_TOKEN_ID;oQuestion_token.QUESTION_ID = QUESTION_ID;oQuestion_token.PART = PART;oQuestion_token.ENTRY_USER_ID = ENTRY_USER_ID;oQuestion_token.ENTRY_DATE = ENTRY_DATE;oQuestion_token.OWNER_ID = OWNER_ID;
ExecuteEdit("UPG_EDIT_QUESTION_TOKEN", oQuestion_token, "QUESTION_TOKEN_ID");
return oQuestion_token.QUESTION_TOKEN_ID;
}
public Int32? Edit_Report_article ( Int32? REPORT_ARTICLE_ID, Int32? ARTICLE_ID, Int32? STUDENT_ID, string DESCRIPTION, long? ENTRY_USER_ID, string ENTRY_DATE, Int32? OWNER_ID)
{
Report_article oReport_article = new Report_article();
oReport_article.REPORT_ARTICLE_ID = REPORT_ARTICLE_ID;oReport_article.ARTICLE_ID = ARTICLE_ID;oReport_article.STUDENT_ID = STUDENT_ID;oReport_article.DESCRIPTION = DESCRIPTION;oReport_article.ENTRY_USER_ID = ENTRY_USER_ID;oReport_article.ENTRY_DATE = ENTRY_DATE;oReport_article.OWNER_ID = OWNER_ID;
ExecuteEdit("UPG_EDIT_REPORT_ARTICLE", oReport_article, "REPORT_ARTICLE_ID");
return oReport_article.REPORT_ARTICLE_ID;
}
public Int32? Edit_Student ( Int32? STUDENT_ID, Int32? USER_ID, string FIRST_NAME, string LAST_NAME, string EMAIL, bool? IS_BLOCKED, Int32? PENDING_QUESTIONS, long? ENTRY_USER_ID, string ENTRY_DATE, Int32? OWNER_ID)
{
Student oStudent = new Student();
oStudent.STUDENT_ID = STUDENT_ID;oStudent.USER_ID = USER_ID;oStudent.FIRST_NAME = FIRST_NAME;oStudent.LAST_NAME = LAST_NAME;oStudent.EMAIL = EMAIL;oStudent.IS_BLOCKED = IS_BLOCKED;oStudent.PENDING_QUESTIONS = PENDING_QUESTIONS;oStudent.ENTRY_USER_ID = ENTRY_USER_ID;oStudent.ENTRY_DATE = ENTRY_DATE;oStudent.OWNER_ID = OWNER_ID;
ExecuteEdit("UPG_EDIT_STUDENT", oStudent, "STUDENT_ID");
return oStudent.STUDENT_ID;
}
public Int32? Edit_Student_report ( Int32? STUDENT_REPORT_ID, Int32? REPORTED_BY_STUDENT_ID, Int32? REPORTED_STUDENT_ID, string DESCRIPTION, long? ENTRY_USER_ID, string ENTRY_DATE, Int32? OWNER_ID)
{
Student_report oStudent_report = new Student_report();
oStudent_report.STUDENT_REPORT_ID = STUDENT_REPORT_ID;oStudent_report.REPORTED_BY_STUDENT_ID = REPORTED_BY_STUDENT_ID;oStudent_report.REPORTED_STUDENT_ID = REPORTED_STUDENT_ID;oStudent_report.DESCRIPTION = DESCRIPTION;oStudent_report.ENTRY_USER_ID = ENTRY_USER_ID;oStudent_report.ENTRY_DATE = ENTRY_DATE;oStudent_report.OWNER_ID = OWNER_ID;
ExecuteEdit("UPG_EDIT_STUDENT_REPORT", oStudent_report, "STUDENT_REPORT_ID");
return oStudent_report.STUDENT_REPORT_ID;
}
public Int32? Edit_Teacher ( Int32? TEACHER_ID, Int32? USER_ID, string FIRST_NAME, string LAST_NAME, decimal SCORE, string DESCRIPTION, bool? IS_BLOCKED, string EMAIL, string MOBILE, long? ENTRY_USER_ID, string ENTRY_DATE, Int32? OWNER_ID)
{
Teacher oTeacher = new Teacher();
oTeacher.TEACHER_ID = TEACHER_ID;oTeacher.USER_ID = USER_ID;oTeacher.FIRST_NAME = FIRST_NAME;oTeacher.LAST_NAME = LAST_NAME;oTeacher.SCORE = SCORE;oTeacher.DESCRIPTION = DESCRIPTION;oTeacher.IS_BLOCKED = IS_BLOCKED;oTeacher.EMAIL = EMAIL;oTeacher.MOBILE = MOBILE;oTeacher.ENTRY_USER_ID = ENTRY_USER_ID;oTeacher.ENTRY_DATE = ENTRY_DATE;oTeacher.OWNER_ID = OWNER_ID;
ExecuteEdit("UPG_EDIT_TEACHER", oTeacher, "TEACHER_ID");
return oTeacher.TEACHER_ID;
}
public Int32? Edit_Teacher_category ( Int32? TEACHER_CATEGORY_ID, Int32? TEACHER_ID, Int32? CATEGORY_ID, string DESCRIPTION, long? ENTRY_USER_ID, string ENTRY_DATE, Int32? OWNER_ID)
{
Teacher_category oTeacher_category = new Teacher_category();
oTeacher_category.TEACHER_CATEGORY_ID = TEACHER_CATEGORY_ID;oTeacher_category.TEACHER_ID = TEACHER_ID;oTeacher_category.CATEGORY_ID = CATEGORY_ID;oTeacher_category.DESCRIPTION = DESCRIPTION;oTeacher_category.ENTRY_USER_ID = ENTRY_USER_ID;oTeacher_category.ENTRY_DATE = ENTRY_DATE;oTeacher_category.OWNER_ID = OWNER_ID;
ExecuteEdit("UPG_EDIT_TEACHER_CATEGORY", oTeacher_category, "TEACHER_CATEGORY_ID");
return oTeacher_category.TEACHER_CATEGORY_ID;
}
public Int32? Edit_Teacher_favorite ( Int32? TEACHER_FAVORITE_ID, Int32? TEACHER_ID, Int32? STUDENT_ID, string DESCRIPTION, long? ENTRY_USER_ID, string ENTRY_DATE, Int32? OWNER_ID)
{
Teacher_favorite oTeacher_favorite = new Teacher_favorite();
oTeacher_favorite.TEACHER_FAVORITE_ID = TEACHER_FAVORITE_ID;oTeacher_favorite.TEACHER_ID = TEACHER_ID;oTeacher_favorite.STUDENT_ID = STUDENT_ID;oTeacher_favorite.DESCRIPTION = DESCRIPTION;oTeacher_favorite.ENTRY_USER_ID = ENTRY_USER_ID;oTeacher_favorite.ENTRY_DATE = ENTRY_DATE;oTeacher_favorite.OWNER_ID = OWNER_ID;
ExecuteEdit("UPG_EDIT_TEACHER_FAVORITE", oTeacher_favorite, "TEACHER_FAVORITE_ID");
return oTeacher_favorite.TEACHER_FAVORITE_ID;
}
public Int32? Edit_Teacher_rank ( Int32? TEACHER_RANK_ID, Int32? TEACHER_ID, Int32? SCORE, Int32? OVERALL_RANKING, long? ENTRY_USER_ID, Int32? OWNER_ID, string ENTRY_DATE, string DESCRIPTION)
{
Teacher_rank oTeacher_rank = new Teacher_rank();
oTeacher_rank.TEACHER_RANK_ID = TEACHER_RANK_ID;oTeacher_rank.TEACHER_ID = TEACHER_ID;oTeacher_rank.SCORE = SCORE;oTeacher_rank.OVERALL_RANKING = OVERALL_RANKING;oTeacher_rank.ENTRY_USER_ID = ENTRY_USER_ID;oTeacher_rank.OWNER_ID = OWNER_ID;oTeacher_rank.ENTRY_DATE = ENTRY_DATE;oTeacher_rank.DESCRIPTION = DESCRIPTION;
ExecuteEdit("UPG_EDIT_TEACHER_RANK", oTeacher_rank, "TEACHER_RANK_ID");
return oTeacher_rank.TEACHER_RANK_ID;
}
public Int32? Edit_Teacher_report ( Int32? TEACHER_REPORT_ID, Int32? TEACHER_ID, Int32? STUDENT_ID, string DESCRIPTION, long? ENTRY_USER_ID, string ENTRY_DATE, Int32? OWNER_ID)
{
Teacher_report oTeacher_report = new Teacher_report();
oTeacher_report.TEACHER_REPORT_ID = TEACHER_REPORT_ID;oTeacher_report.TEACHER_ID = TEACHER_ID;oTeacher_report.STUDENT_ID = STUDENT_ID;oTeacher_report.DESCRIPTION = DESCRIPTION;oTeacher_report.ENTRY_USER_ID = ENTRY_USER_ID;oTeacher_report.ENTRY_DATE = ENTRY_DATE;oTeacher_report.OWNER_ID = OWNER_ID;
ExecuteEdit("UPG_EDIT_TEACHER_REPORT", oTeacher_report, "TEACHER_REPORT_ID");
return oTeacher_report.TEACHER_REPORT_ID;
}
public long? Edit_User ( long? USER_ID, Int32? OWNER_ID, string USERNAME, string PASSWORD, string USER_TYPE_CODE, bool? IS_LOGGED_IN, bool? IS_ACTIVE, string ENTRY_DATE)
{
User oUser = new User();
oUser.USER_ID = USER_ID;oUser.OWNER_ID = OWNER_ID;oUser.USERNAME = USERNAME;oUser.PASSWORD = PASSWORD;oUser.USER_TYPE_CODE = USER_TYPE_CODE;oUser.IS_LOGGED_IN = IS_LOGGED_IN;oUser.IS_ACTIVE = IS_ACTIVE;oUser.ENTRY_DATE = ENTRY_DATE;
ExecuteEdit("UPG_EDIT_USER", oUser, "USER_ID");
return oUser.USER_ID;
}
public List<dynamic> GET_DISTINCT_SETUP_TBL ( Int32? OWNER_ID)
{
List<dynamic> oList = new List<dynamic>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("GET_DISTINCT_SETUP_TBL", p);
if (R != null)
{
foreach (var oRow in R)
{
dynamic o = new ExpandoObject();
o.TBL_NAME = Convert.IsDBNull(oRow["TBL_NAME"]) ? default : Convert.ToString(oRow["TBL_NAME"]);
oList.Add(o);
}
}
return oList;
}
public List<dynamic> GET_NEXT_VALUE ( string STARTER_CODE)
{
List<dynamic> oList = new List<dynamic>();
dynamic p = new ExpandoObject();
p.STARTER_CODE = STARTER_CODE;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("GET_NEXT_VALUE", p);
if (R != null)
{
foreach (var oRow in R)
{
dynamic o = new ExpandoObject();
o.LAST_VALUE = Convert.IsDBNull(oRow["LAST_VALUE"]) ? default : Convert.ToInt64(oRow["LAST_VALUE"]);
oList.Add(o);
}
}
return oList;
}
public List<dynamic> GET_TBL_SETUP ()
{
List<dynamic> oList = new List<dynamic>();
dynamic p = new ExpandoObject();
IEnumerable<IDataRecord> R = ExecuteSelectQuery("GET_TBL_SETUP", p);
if (R != null)
{
foreach (var oRow in R)
{
dynamic o = new ExpandoObject();
o.OWNER_ID = Convert.IsDBNull(oRow["OWNER_ID"]) ? default : Convert.ToInt32(oRow["OWNER_ID"]);o.TBL_NAME = Convert.IsDBNull(oRow["TBL_NAME"]) ? default : Convert.ToString(oRow["TBL_NAME"]);o.CODE_NAME = Convert.IsDBNull(oRow["CODE_NAME"]) ? default : Convert.ToString(oRow["CODE_NAME"]);o.ISSYSTEM = Convert.IsDBNull(oRow["ISSYSTEM"]) ? default : Convert.ToBoolean(oRow["ISSYSTEM"]);o.ISDELETEABLE = Convert.IsDBNull(oRow["ISDELETEABLE"]) ? default : Convert.ToBoolean(oRow["ISDELETEABLE"]);o.ISUPDATEABLE = Convert.IsDBNull(oRow["ISUPDATEABLE"]) ? default : Convert.ToBoolean(oRow["ISUPDATEABLE"]);o.ISDELETED = Convert.IsDBNull(oRow["ISDELETED"]) ? default : Convert.ToBoolean(oRow["ISDELETED"]);o.ISVISIBLE = Convert.IsDBNull(oRow["ISVISIBLE"]) ? default : Convert.ToBoolean(oRow["ISVISIBLE"]);o.DISPLAY_ORDER = Convert.IsDBNull(oRow["DISPLAY_ORDER"]) ? default : Convert.ToInt32(oRow["DISPLAY_ORDER"]);o.CODE_VALUE_EN = Convert.IsDBNull(oRow["CODE_VALUE_EN"]) ? default : Convert.ToString(oRow["CODE_VALUE_EN"]);o.CODE_VALUE_FR = Convert.IsDBNull(oRow["CODE_VALUE_FR"]) ? default : Convert.ToString(oRow["CODE_VALUE_FR"]);o.CODE_VALUE_AR = Convert.IsDBNull(oRow["CODE_VALUE_AR"]) ? default : Convert.ToString(oRow["CODE_VALUE_AR"]);o.NOTES = Convert.IsDBNull(oRow["NOTES"]) ? default : Convert.ToString(oRow["NOTES"]);o.ENTRY_DATE = Convert.IsDBNull(oRow["ENTRY_DATE"]) ? default : Convert.ToString(oRow["ENTRY_DATE"]);o.ENTRY_USER_ID = Convert.IsDBNull(oRow["ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["ENTRY_USER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<dynamic> UP_CHECK_USER_EXISTENCE ( Int32? OWNER_ID, string USERNAME,ref  bool? EXISTS)
{
List<dynamic> oList = new List<dynamic>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID; p.USERNAME = USERNAME; p.EXISTS = EXISTS;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UP_CHECK_USER_EXISTENCE", p);
if (R != null)
{
foreach (var oRow in R)
{
dynamic o = new ExpandoObject();
oList.Add(o);
}
}
EXISTS = p.EXISTS;
return oList;
}
public List<dynamic> UP_EDIT_SETUP ( Int32? OWNER_ID, string TBL_NAME, string CODE_NAME, bool? ISSYSTEM, bool? ISDELETEABLE, bool? ISUPDATEABLE, bool? ISVISIBLE, bool? ISDELETED, Int32? DISPLAY_ORDER, string CODE_VALUE_EN, string CODE_VALUE_FR, string CODE_VALUE_AR, string ENTRY_DATE, Int32? ENTRY_USER_ID, string NOTES)
{
List<dynamic> oList = new List<dynamic>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID; p.TBL_NAME = TBL_NAME; p.CODE_NAME = CODE_NAME; p.ISSYSTEM = ISSYSTEM; p.ISDELETEABLE = ISDELETEABLE; p.ISUPDATEABLE = ISUPDATEABLE; p.ISVISIBLE = ISVISIBLE; p.ISDELETED = ISDELETED; p.DISPLAY_ORDER = DISPLAY_ORDER; p.CODE_VALUE_EN = CODE_VALUE_EN; p.CODE_VALUE_FR = CODE_VALUE_FR; p.CODE_VALUE_AR = CODE_VALUE_AR; p.ENTRY_DATE = ENTRY_DATE; p.ENTRY_USER_ID = ENTRY_USER_ID; p.NOTES = NOTES;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UP_EDIT_SETUP", p);
if (R != null)
{
foreach (var oRow in R)
{
dynamic o = new ExpandoObject();
oList.Add(o);
}
}
return oList;
}
public List<dynamic> UP_EXTRACT_ROUTINE_PARAMETERS ( string ROUTINE_NAME)
{
List<dynamic> oList = new List<dynamic>();
dynamic p = new ExpandoObject();
p.ROUTINE_NAME = ROUTINE_NAME;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UP_EXTRACT_ROUTINE_PARAMETERS", p);
if (R != null)
{
foreach (var oRow in R)
{
dynamic o = new ExpandoObject();
o.ROUTINE_NAME = Convert.IsDBNull(oRow["ROUTINE_NAME"]) ? default : Convert.ToString(oRow["ROUTINE_NAME"]);o.PARAM_NAME = Convert.IsDBNull(oRow["PARAM_NAME"]) ? default : Convert.ToString(oRow["PARAM_NAME"]);o.PARAM_TYPE = Convert.IsDBNull(oRow["PARAM_TYPE"]) ? default : Convert.ToString(oRow["PARAM_TYPE"]);o.IS_OUTPUT = Convert.IsDBNull(oRow["IS_OUTPUT"]) ? default : Convert.ToBoolean(oRow["IS_OUTPUT"]);
oList.Add(o);
}
}
return oList;
}
public List<dynamic> UP_EXTRACT_ROUTINE_RESULT_SCHEMA ( string ROUTINE_NAME)
{
List<dynamic> oList = new List<dynamic>();
dynamic p = new ExpandoObject();
p.ROUTINE_NAME = ROUTINE_NAME;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UP_EXTRACT_ROUTINE_RESULT_SCHEMA", p);
if (R != null)
{
foreach (var oRow in R)
{
dynamic o = new ExpandoObject();
o.ROUTINE_NAME = Convert.IsDBNull(oRow["ROUTINE_NAME"]) ? default : Convert.ToString(oRow["ROUTINE_NAME"]);o.COLUMN_NAME = Convert.IsDBNull(oRow["COLUMN_NAME"]) ? default : Convert.ToString(oRow["COLUMN_NAME"]);o.COLUMN_TYPE = Convert.IsDBNull(oRow["COLUMN_TYPE"]) ? default : Convert.ToString(oRow["COLUMN_TYPE"]);
oList.Add(o);
}
}
return oList;
}
public List<dynamic> UP_GENERATE_INSERT_STATEMENTS ( string @tableName)
{
List<dynamic> oList = new List<dynamic>();
dynamic p = new ExpandoObject();
p.@tableName = @tableName;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UP_GENERATE_INSERT_STATEMENTS", p);
if (R != null)
{
foreach (var oRow in R)
{
dynamic o = new ExpandoObject();
oList.Add(o);
}
}
return oList;
}
public List<dynamic> UP_GET_NEXT_VALUE ( string STARTER_CODE,ref  Int32? VALUE)
{
List<dynamic> oList = new List<dynamic>();
dynamic p = new ExpandoObject();
p.STARTER_CODE = STARTER_CODE; p.VALUE = VALUE;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UP_GET_NEXT_VALUE", p);
if (R != null)
{
foreach (var oRow in R)
{
dynamic o = new ExpandoObject();
oList.Add(o);
}
}
VALUE = p.VALUE;
return oList;
}
public List<dynamic> UP_GET_QUESTION_NOT_ANSWERED ( Int32? @__OWNER)
{
List<dynamic> oList = new List<dynamic>();
dynamic p = new ExpandoObject();
p.@__OWNER = @__OWNER;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UP_GET_QUESTION_NOT_ANSWERED", p);
if (R != null)
{
foreach (var oRow in R)
{
dynamic o = new ExpandoObject();
o.QUESTION_ID = Convert.IsDBNull(oRow["QUESTION_ID"]) ? default : Convert.ToInt32(oRow["QUESTION_ID"]);o.STUDENT_ID = Convert.IsDBNull(oRow["STUDENT_ID"]) ? default : Convert.ToInt32(oRow["STUDENT_ID"]);o.CATEGORY_ID = Convert.IsDBNull(oRow["CATEGORY_ID"]) ? default : Convert.ToInt32(oRow["CATEGORY_ID"]);o.TEACHER_ID = Convert.IsDBNull(oRow["TEACHER_ID"]) ? default : Convert.ToInt32(oRow["TEACHER_ID"]);o.DESCRIPTION = Convert.IsDBNull(oRow["DESCRIPTION"]) ? default : Convert.ToString(oRow["DESCRIPTION"]);o.IS_ANSWERED = Convert.IsDBNull(oRow["IS_ANSWERED"]) ? default : Convert.ToBoolean(oRow["IS_ANSWERED"]);o.IS_ACTIVE = Convert.IsDBNull(oRow["IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["IS_ACTIVE"]);o.REPORTS = Convert.IsDBNull(oRow["REPORTS"]) ? default : Convert.ToInt32(oRow["REPORTS"]);o.ENTRY_USER_ID = Convert.IsDBNull(oRow["ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["ENTRY_USER_ID"]);o.ENTRY_DATE = Convert.IsDBNull(oRow["ENTRY_DATE"]) ? default : Convert.ToString(oRow["ENTRY_DATE"]);o.OWNER_ID = Convert.IsDBNull(oRow["OWNER_ID"]) ? default : Convert.ToInt32(oRow["OWNER_ID"]);o.FTS = Convert.IsDBNull(oRow["FTS"]) ? default : Convert.ToString(oRow["FTS"]);
oList.Add(o);
}
}
return oList;
}
public List<dynamic> UP_GET_SETUP_ENTRIES ( Int32? OWNER_ID, string TBL_NAME, bool? ISDELETED, bool? ISVISIBLE)
{
List<dynamic> oList = new List<dynamic>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID; p.TBL_NAME = TBL_NAME; p.ISDELETED = ISDELETED; p.ISVISIBLE = ISVISIBLE;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UP_GET_SETUP_ENTRIES", p);
if (R != null)
{
foreach (var oRow in R)
{
dynamic o = new ExpandoObject();
o.OWNER_ID = Convert.IsDBNull(oRow["OWNER_ID"]) ? default : Convert.ToInt32(oRow["OWNER_ID"]);o.TBL_NAME = Convert.IsDBNull(oRow["TBL_NAME"]) ? default : Convert.ToString(oRow["TBL_NAME"]);o.CODE_NAME = Convert.IsDBNull(oRow["CODE_NAME"]) ? default : Convert.ToString(oRow["CODE_NAME"]);o.ISSYSTEM = Convert.IsDBNull(oRow["ISSYSTEM"]) ? default : Convert.ToBoolean(oRow["ISSYSTEM"]);o.ISDELETEABLE = Convert.IsDBNull(oRow["ISDELETEABLE"]) ? default : Convert.ToBoolean(oRow["ISDELETEABLE"]);o.ISUPDATEABLE = Convert.IsDBNull(oRow["ISUPDATEABLE"]) ? default : Convert.ToBoolean(oRow["ISUPDATEABLE"]);o.DISPLAY_ORDER = Convert.IsDBNull(oRow["DISPLAY_ORDER"]) ? default : Convert.ToInt32(oRow["DISPLAY_ORDER"]);o.ISVISIBLE = Convert.IsDBNull(oRow["ISVISIBLE"]) ? default : Convert.ToBoolean(oRow["ISVISIBLE"]);o.ISDELETED = Convert.IsDBNull(oRow["ISDELETED"]) ? default : Convert.ToBoolean(oRow["ISDELETED"]);o.CODE_VALUE_EN = Convert.IsDBNull(oRow["CODE_VALUE_EN"]) ? default : Convert.ToString(oRow["CODE_VALUE_EN"]);o.CODE_VALUE_FR = Convert.IsDBNull(oRow["CODE_VALUE_FR"]) ? default : Convert.ToString(oRow["CODE_VALUE_FR"]);o.CODE_VALUE_AR = Convert.IsDBNull(oRow["CODE_VALUE_AR"]) ? default : Convert.ToString(oRow["CODE_VALUE_AR"]);o.NOTES = Convert.IsDBNull(oRow["NOTES"]) ? default : Convert.ToString(oRow["NOTES"]);o.ENTRY_DATE = Convert.IsDBNull(oRow["ENTRY_DATE"]) ? default : Convert.ToString(oRow["ENTRY_DATE"]);o.ENTRY_USER_ID = Convert.IsDBNull(oRow["ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["ENTRY_USER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<dynamic> UP_GET_SETUP_ENTRY ( Int32? OWNER_ID, string TBL_NAME, string CODE_NAME)
{
List<dynamic> oList = new List<dynamic>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID; p.TBL_NAME = TBL_NAME; p.CODE_NAME = CODE_NAME;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UP_GET_SETUP_ENTRY", p);
if (R != null)
{
foreach (var oRow in R)
{
dynamic o = new ExpandoObject();
o.OWNER_ID = Convert.IsDBNull(oRow["OWNER_ID"]) ? default : Convert.ToInt32(oRow["OWNER_ID"]);o.TBL_NAME = Convert.IsDBNull(oRow["TBL_NAME"]) ? default : Convert.ToString(oRow["TBL_NAME"]);o.CODE_NAME = Convert.IsDBNull(oRow["CODE_NAME"]) ? default : Convert.ToString(oRow["CODE_NAME"]);o.ISSYSTEM = Convert.IsDBNull(oRow["ISSYSTEM"]) ? default : Convert.ToBoolean(oRow["ISSYSTEM"]);o.ISDELETEABLE = Convert.IsDBNull(oRow["ISDELETEABLE"]) ? default : Convert.ToBoolean(oRow["ISDELETEABLE"]);o.ISUPDATEABLE = Convert.IsDBNull(oRow["ISUPDATEABLE"]) ? default : Convert.ToBoolean(oRow["ISUPDATEABLE"]);o.DISPLAY_ORDER = Convert.IsDBNull(oRow["DISPLAY_ORDER"]) ? default : Convert.ToInt32(oRow["DISPLAY_ORDER"]);o.ISVISIBLE = Convert.IsDBNull(oRow["ISVISIBLE"]) ? default : Convert.ToBoolean(oRow["ISVISIBLE"]);o.ISDELETED = Convert.IsDBNull(oRow["ISDELETED"]) ? default : Convert.ToBoolean(oRow["ISDELETED"]);o.CODE_VALUE_EN = Convert.IsDBNull(oRow["CODE_VALUE_EN"]) ? default : Convert.ToString(oRow["CODE_VALUE_EN"]);o.CODE_VALUE_FR = Convert.IsDBNull(oRow["CODE_VALUE_FR"]) ? default : Convert.ToString(oRow["CODE_VALUE_FR"]);o.CODE_VALUE_AR = Convert.IsDBNull(oRow["CODE_VALUE_AR"]) ? default : Convert.ToString(oRow["CODE_VALUE_AR"]);o.NOTES = Convert.IsDBNull(oRow["NOTES"]) ? default : Convert.ToString(oRow["NOTES"]);o.ENTRY_DATE = Convert.IsDBNull(oRow["ENTRY_DATE"]) ? default : Convert.ToString(oRow["ENTRY_DATE"]);o.ENTRY_USER_ID = Convert.IsDBNull(oRow["ENTRY_USER_ID"]) ? default : Convert.ToInt64(oRow["ENTRY_USER_ID"]);
oList.Add(o);
}
}
return oList;
}
public List<dynamic> UP_GET_USER_BY_CREDENTIALS ( Int32? OWNER_ID, string USERNAME, string PASSWORD)
{
List<dynamic> oList = new List<dynamic>();
dynamic p = new ExpandoObject();
p.OWNER_ID = OWNER_ID; p.USERNAME = USERNAME; p.PASSWORD = PASSWORD;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UP_GET_USER_BY_CREDENTIALS", p);
if (R != null)
{
foreach (var oRow in R)
{
dynamic o = new ExpandoObject();
o.USER_ID = Convert.IsDBNull(oRow["USER_ID"]) ? default : Convert.ToInt64(oRow["USER_ID"]);o.OWNER_ID = Convert.IsDBNull(oRow["OWNER_ID"]) ? default : Convert.ToInt32(oRow["OWNER_ID"]);o.USERNAME = Convert.IsDBNull(oRow["USERNAME"]) ? default : Convert.ToString(oRow["USERNAME"]);o.PASSWORD = Convert.IsDBNull(oRow["PASSWORD"]) ? default : Convert.ToString(oRow["PASSWORD"]);o.ENTRY_DATE = Convert.IsDBNull(oRow["ENTRY_DATE"]) ? default : Convert.ToString(oRow["ENTRY_DATE"]);
oList.Add(o);
}
}
return oList;
}
public List<dynamic> UP_GET_USER_BY_USERNAME ( string USERNAME)
{
List<dynamic> oList = new List<dynamic>();
dynamic p = new ExpandoObject();
p.USERNAME = USERNAME;
IEnumerable<IDataRecord> R = ExecuteSelectQuery("UP_GET_USER_BY_USERNAME", p);
if (R != null)
{
foreach (var oRow in R)
{
dynamic o = new ExpandoObject();
o.USER_ID = Convert.IsDBNull(oRow["USER_ID"]) ? default : Convert.ToInt64(oRow["USER_ID"]);o.OWNER_ID = Convert.IsDBNull(oRow["OWNER_ID"]) ? default : Convert.ToInt32(oRow["OWNER_ID"]);o.USERNAME = Convert.IsDBNull(oRow["USERNAME"]) ? default : Convert.ToString(oRow["USERNAME"]);o.PASSWORD = Convert.IsDBNull(oRow["PASSWORD"]) ? default : Convert.ToString(oRow["PASSWORD"]);o.USER_TYPE_CODE = Convert.IsDBNull(oRow["USER_TYPE_CODE"]) ? default : Convert.ToString(oRow["USER_TYPE_CODE"]);o.IS_LOGGED_IN = Convert.IsDBNull(oRow["IS_LOGGED_IN"]) ? default : Convert.ToBoolean(oRow["IS_LOGGED_IN"]);o.IS_ACTIVE = Convert.IsDBNull(oRow["IS_ACTIVE"]) ? default : Convert.ToBoolean(oRow["IS_ACTIVE"]);o.ENTRY_DATE = Convert.IsDBNull(oRow["ENTRY_DATE"]) ? default : Convert.ToString(oRow["ENTRY_DATE"]);o.FTS = Convert.IsDBNull(oRow["FTS"]) ? default : Convert.ToString(oRow["FTS"]);
oList.Add(o);
}
}
return oList;
}
}
}
