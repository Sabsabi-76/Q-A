using System;
using System.Collections.Generic;
namespace DALC
{
#region Repositories
public partial class Answer
{
public Int32? ANSWER_ID {get;set;}
public Int32? QUESTION_ID {get;set;}
public Int32? TEACHER_ID {get;set;}
public string DESCRIPTION {get;set;}
public decimal? SCORE {get;set;}
public Int32? REVIEWS {get;set;}
public Int32? REPORTS {get;set;}
public bool? IS_ACTIVE {get;set;}
public long? ENTRY_USER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Int32? OWNER_ID {get;set;}
public Question My_Question {get;set;}
public Teacher My_Teacher {get;set;}
}
public partial class Answer_report
{
public Int32? ANSWER_REPORT_ID {get;set;}
public Int32? TEACHER_ID {get;set;}
public Int32? STUDENT_ID {get;set;}
public Int32? ANSWER_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? ENTRY_USER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Int32? OWNER_ID {get;set;}
public Teacher My_Teacher {get;set;}
public Student My_Student {get;set;}
public Answer My_Answer {get;set;}
}
public partial class Appreciate
{
public Int32? APPRECIATE_ID {get;set;}
public Int32? ARTICLE_ID {get;set;}
public Int32? STUDENT_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? ENTRY_USER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Int32? OWNER_ID {get;set;}
public Article My_Article {get;set;}
public Student My_Student {get;set;}
}
public partial class Article
{
public Int32? ARTICLE_ID {get;set;}
public Int32? TEACHER_ID {get;set;}
public Int32? CATEGORY_ID {get;set;}
public string TITLE {get;set;}
public string DESCRIPTION {get;set;}
public Int32? APPLAUDS {get;set;}
public Int32? REPORTS {get;set;}
public bool? IS_BLOCKED {get;set;}
public long? ENTRY_USER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Int32? OWNER_ID {get;set;}
public Teacher My_Teacher {get;set;}
public Category My_Category {get;set;}
}
public partial class Category
{
public Int32? CATEGORY_ID {get;set;}
public string NAME {get;set;}
public string DECRIPTION {get;set;}
public long? ENTRY_USER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Int32? OWNER_ID {get;set;}
}
public partial class Evaluation
{
public Int32? EVALUATION_ID {get;set;}
public Int32? STUDENT_ID {get;set;}
public Int32? ANSWER_ID {get;set;}
public decimal SCORE {get;set;}
public long? ENTRY_USER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public Student My_Student {get;set;}
public Answer My_Answer {get;set;}
}
public partial class Favorite_category
{
public Int32? FAVORITE_CATEGORY_ID {get;set;}
public Int32? STUDENT_ID {get;set;}
public Int32? CATEGORY_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? ENTRY_USER_ID {get;set;}
public Int32? OWNER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Student My_Student {get;set;}
public Category My_Category {get;set;}
}
public partial class Favorite_teacher
{
public Int32? FAVORITE_TEACHER_ID {get;set;}
public Int32? TEACHER_ID {get;set;}
public Int32? STUDENT_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? ENTRY_USER_ID {get;set;}
public Int32? OWNER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Teacher My_Teacher {get;set;}
public Student My_Student {get;set;}
}
public partial class Mark_question
{
public Int32? MARK_QUESTION_ID {get;set;}
public Int32? QUESTION_ID {get;set;}
public Int32? STUDENT_ID {get;set;}
public long? ENTRY_USER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Int32? OWNER_ID {get;set;}
public string DESCRIPTION {get;set;}
public Question My_Question {get;set;}
public Student My_Student {get;set;}
}
public partial class Notification
{
public Int32? NOTIFICATION_ID {get;set;}
public Int32? USER_ID {get;set;}
public string DESCRIPTION {get;set;}
public Int32? QUESTION_ID {get;set;}
public Int32? ANSWER_ID {get;set;}
public long? ENTRY_USER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Int32? OWNER_ID {get;set;}
public User My_User {get;set;}
public Question My_Question {get;set;}
public Answer My_Answer {get;set;}
}
public partial class Owner
{
public Int32? OWNER_ID {get;set;}
public string CODE {get;set;}
public string MAINTENANCE_DUE_DATE {get;set;}
public string DESCRIPTION {get;set;}
public string ENTRY_DATE {get;set;}
}
public partial class Question
{
public Int32? QUESTION_ID {get;set;}
public Int32? STUDENT_ID {get;set;}
public Int32? CATEGORY_ID {get;set;}
public Int32? TEACHER_ID {get;set;}
public string DESCRIPTION {get;set;}
public bool? IS_ANSWERED {get;set;}
public bool? IS_ACTIVE {get;set;}
public Int32? REPORTS {get;set;}
public long? ENTRY_USER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Int32? OWNER_ID {get;set;}
public Student My_Student {get;set;}
public Category My_Category {get;set;}
public Teacher My_Teacher {get;set;}
}
public partial class Question_report
{
public Int32? QUESTION_REPORT_ID {get;set;}
public Int32? STUDENT_ID {get;set;}
public Int32? TEACHER_ID {get;set;}
public Int32? QUESTION_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? ENTRY_USER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Int32? OWNER_ID {get;set;}
public Student My_Student {get;set;}
public Teacher My_Teacher {get;set;}
public Question My_Question {get;set;}
}
public partial class Question_token
{
public long? QUESTION_TOKEN_ID {get;set;}
public long? QUESTION_ID {get;set;}
public string PART {get;set;}
public long? ENTRY_USER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Int32? OWNER_ID {get;set;}
public Question My_Question {get;set;}
}
public partial class Report_article
{
public Int32? REPORT_ARTICLE_ID {get;set;}
public Int32? ARTICLE_ID {get;set;}
public Int32? STUDENT_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? ENTRY_USER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Int32? OWNER_ID {get;set;}
public Article My_Article {get;set;}
public Student My_Student {get;set;}
}
public partial class Student
{
public Int32? STUDENT_ID {get;set;}
public Int32? USER_ID {get;set;}
public string FIRST_NAME {get;set;}
public string LAST_NAME {get;set;}
public string EMAIL {get;set;}
public bool? IS_BLOCKED {get;set;}
public Int32? PENDING_QUESTIONS {get;set;}
public long? ENTRY_USER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Int32? OWNER_ID {get;set;}
public User My_User {get;set;}
}
public partial class Student_report
{
public Int32? STUDENT_REPORT_ID {get;set;}
public Int32? REPORTED_BY_STUDENT_ID {get;set;}
public Int32? REPORTED_STUDENT_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? ENTRY_USER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Int32? OWNER_ID {get;set;}
public Student My_Reported_by_student {get;set;}
public Student My_Reported_student {get;set;}
}
public partial class Teacher
{
public Int32? TEACHER_ID {get;set;}
public Int32? USER_ID {get;set;}
public string FIRST_NAME {get;set;}
public string LAST_NAME {get;set;}
public decimal SCORE {get;set;}
public string DESCRIPTION {get;set;}
public bool? IS_BLOCKED {get;set;}
public string EMAIL {get;set;}
public string MOBILE {get;set;}
public long? ENTRY_USER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Int32? OWNER_ID {get;set;}
public User My_User {get;set;}
}
public partial class Teacher_category
{
public Int32? TEACHER_CATEGORY_ID {get;set;}
public Int32? TEACHER_ID {get;set;}
public Int32? CATEGORY_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? ENTRY_USER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Int32? OWNER_ID {get;set;}
public Teacher My_Teacher {get;set;}
public Category My_Category {get;set;}
}
public partial class Teacher_favorite
{
public Int32? TEACHER_FAVORITE_ID {get;set;}
public Int32? TEACHER_ID {get;set;}
public Int32? STUDENT_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? ENTRY_USER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Int32? OWNER_ID {get;set;}
public Teacher My_Teacher {get;set;}
public Student My_Student {get;set;}
}
public partial class Teacher_rank
{
public Int32? TEACHER_RANK_ID {get;set;}
public Int32? TEACHER_ID {get;set;}
public Int32? SCORE {get;set;}
public Int32? OVERALL_RANKING {get;set;}
public long? ENTRY_USER_ID {get;set;}
public Int32? OWNER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public string DESCRIPTION {get;set;}
public Teacher My_Teacher {get;set;}
}
public partial class Teacher_report
{
public Int32? TEACHER_REPORT_ID {get;set;}
public Int32? TEACHER_ID {get;set;}
public Int32? STUDENT_ID {get;set;}
public string DESCRIPTION {get;set;}
public long? ENTRY_USER_ID {get;set;}
public string ENTRY_DATE {get;set;}
public Int32? OWNER_ID {get;set;}
public Teacher My_Teacher {get;set;}
public Student My_Student {get;set;}
}
public partial class User
{
public long? USER_ID {get;set;}
public Int32? OWNER_ID {get;set;}
public string USERNAME {get;set;}
public string PASSWORD {get;set;}
public string USER_TYPE_CODE {get;set;}
public bool? IS_LOGGED_IN {get;set;}
public bool? IS_ACTIVE {get;set;}
public string ENTRY_DATE {get;set;}
}
#endregion 
public partial interface IDALC
{
Answer Get_Answer_By_ANSWER_ID ( Int32? ANSWER_ID);
Answer_report Get_Answer_report_By_ANSWER_REPORT_ID ( Int32? ANSWER_REPORT_ID);
Appreciate Get_Appreciate_By_APPRECIATE_ID ( Int32? APPRECIATE_ID);
Article Get_Article_By_ARTICLE_ID ( Int32? ARTICLE_ID);
Category Get_Category_By_CATEGORY_ID ( Int32? CATEGORY_ID);
Evaluation Get_Evaluation_By_EVALUATION_ID ( Int32? EVALUATION_ID);
Favorite_category Get_Favorite_category_By_FAVORITE_CATEGORY_ID ( Int32? FAVORITE_CATEGORY_ID);
Favorite_teacher Get_Favorite_teacher_By_FAVORITE_TEACHER_ID ( Int32? FAVORITE_TEACHER_ID);
Mark_question Get_Mark_question_By_MARK_QUESTION_ID ( Int32? MARK_QUESTION_ID);
Notification Get_Notification_By_NOTIFICATION_ID ( Int32? NOTIFICATION_ID);
Owner Get_Owner_By_OWNER_ID ( Int32? OWNER_ID);
Question Get_Question_By_QUESTION_ID ( Int32? QUESTION_ID);
Question_report Get_Question_report_By_QUESTION_REPORT_ID ( Int32? QUESTION_REPORT_ID);
Question_token Get_Question_token_By_QUESTION_TOKEN_ID ( long? QUESTION_TOKEN_ID);
Report_article Get_Report_article_By_REPORT_ARTICLE_ID ( Int32? REPORT_ARTICLE_ID);
Student Get_Student_By_STUDENT_ID ( Int32? STUDENT_ID);
Student_report Get_Student_report_By_STUDENT_REPORT_ID ( Int32? STUDENT_REPORT_ID);
Teacher Get_Teacher_By_TEACHER_ID ( Int32? TEACHER_ID);
Teacher_category Get_Teacher_category_By_TEACHER_CATEGORY_ID ( Int32? TEACHER_CATEGORY_ID);
Teacher_favorite Get_Teacher_favorite_By_TEACHER_FAVORITE_ID ( Int32? TEACHER_FAVORITE_ID);
Teacher_rank Get_Teacher_rank_By_TEACHER_RANK_ID ( Int32? TEACHER_RANK_ID);
Teacher_report Get_Teacher_report_By_TEACHER_REPORT_ID ( Int32? TEACHER_REPORT_ID);
User Get_User_By_USER_ID ( long? USER_ID);
Answer Get_Answer_By_ANSWER_ID_Adv ( Int32? ANSWER_ID);
Answer_report Get_Answer_report_By_ANSWER_REPORT_ID_Adv ( Int32? ANSWER_REPORT_ID);
Appreciate Get_Appreciate_By_APPRECIATE_ID_Adv ( Int32? APPRECIATE_ID);
Article Get_Article_By_ARTICLE_ID_Adv ( Int32? ARTICLE_ID);
Category Get_Category_By_CATEGORY_ID_Adv ( Int32? CATEGORY_ID);
Evaluation Get_Evaluation_By_EVALUATION_ID_Adv ( Int32? EVALUATION_ID);
Favorite_category Get_Favorite_category_By_FAVORITE_CATEGORY_ID_Adv ( Int32? FAVORITE_CATEGORY_ID);
Favorite_teacher Get_Favorite_teacher_By_FAVORITE_TEACHER_ID_Adv ( Int32? FAVORITE_TEACHER_ID);
Mark_question Get_Mark_question_By_MARK_QUESTION_ID_Adv ( Int32? MARK_QUESTION_ID);
Notification Get_Notification_By_NOTIFICATION_ID_Adv ( Int32? NOTIFICATION_ID);
Question Get_Question_By_QUESTION_ID_Adv ( Int32? QUESTION_ID);
Question_report Get_Question_report_By_QUESTION_REPORT_ID_Adv ( Int32? QUESTION_REPORT_ID);
Question_token Get_Question_token_By_QUESTION_TOKEN_ID_Adv ( long? QUESTION_TOKEN_ID);
Report_article Get_Report_article_By_REPORT_ARTICLE_ID_Adv ( Int32? REPORT_ARTICLE_ID);
Student Get_Student_By_STUDENT_ID_Adv ( Int32? STUDENT_ID);
Student_report Get_Student_report_By_STUDENT_REPORT_ID_Adv ( Int32? STUDENT_REPORT_ID);
Teacher Get_Teacher_By_TEACHER_ID_Adv ( Int32? TEACHER_ID);
Teacher_category Get_Teacher_category_By_TEACHER_CATEGORY_ID_Adv ( Int32? TEACHER_CATEGORY_ID);
Teacher_favorite Get_Teacher_favorite_By_TEACHER_FAVORITE_ID_Adv ( Int32? TEACHER_FAVORITE_ID);
Teacher_rank Get_Teacher_rank_By_TEACHER_RANK_ID_Adv ( Int32? TEACHER_RANK_ID);
Teacher_report Get_Teacher_report_By_TEACHER_REPORT_ID_Adv ( Int32? TEACHER_REPORT_ID);
User Get_User_By_USER_ID_Adv ( long? USER_ID);
List<Answer> Get_Answer_By_ANSWER_ID_List ( List<Int32?> ANSWER_ID_LIST);
List<Answer_report> Get_Answer_report_By_ANSWER_REPORT_ID_List ( List<Int32?> ANSWER_REPORT_ID_LIST);
List<Appreciate> Get_Appreciate_By_APPRECIATE_ID_List ( List<Int32?> APPRECIATE_ID_LIST);
List<Article> Get_Article_By_ARTICLE_ID_List ( List<Int32?> ARTICLE_ID_LIST);
List<Category> Get_Category_By_CATEGORY_ID_List ( List<Int32?> CATEGORY_ID_LIST);
List<Evaluation> Get_Evaluation_By_EVALUATION_ID_List ( List<Int32?> EVALUATION_ID_LIST);
List<Favorite_category> Get_Favorite_category_By_FAVORITE_CATEGORY_ID_List ( List<Int32?> FAVORITE_CATEGORY_ID_LIST);
List<Favorite_teacher> Get_Favorite_teacher_By_FAVORITE_TEACHER_ID_List ( List<Int32?> FAVORITE_TEACHER_ID_LIST);
List<Mark_question> Get_Mark_question_By_MARK_QUESTION_ID_List ( List<Int32?> MARK_QUESTION_ID_LIST);
List<Notification> Get_Notification_By_NOTIFICATION_ID_List ( List<Int32?> NOTIFICATION_ID_LIST);
List<Owner> Get_Owner_By_OWNER_ID_List ( List<Int32?> OWNER_ID_LIST);
List<Question> Get_Question_By_QUESTION_ID_List ( List<Int32?> QUESTION_ID_LIST);
List<Question_report> Get_Question_report_By_QUESTION_REPORT_ID_List ( List<Int32?> QUESTION_REPORT_ID_LIST);
List<Question_token> Get_Question_token_By_QUESTION_TOKEN_ID_List ( List<long?> QUESTION_TOKEN_ID_LIST);
List<Report_article> Get_Report_article_By_REPORT_ARTICLE_ID_List ( List<Int32?> REPORT_ARTICLE_ID_LIST);
List<Student> Get_Student_By_STUDENT_ID_List ( List<Int32?> STUDENT_ID_LIST);
List<Student_report> Get_Student_report_By_STUDENT_REPORT_ID_List ( List<Int32?> STUDENT_REPORT_ID_LIST);
List<Teacher> Get_Teacher_By_TEACHER_ID_List ( List<Int32?> TEACHER_ID_LIST);
List<Teacher_category> Get_Teacher_category_By_TEACHER_CATEGORY_ID_List ( List<Int32?> TEACHER_CATEGORY_ID_LIST);
List<Teacher_favorite> Get_Teacher_favorite_By_TEACHER_FAVORITE_ID_List ( List<Int32?> TEACHER_FAVORITE_ID_LIST);
List<Teacher_rank> Get_Teacher_rank_By_TEACHER_RANK_ID_List ( List<Int32?> TEACHER_RANK_ID_LIST);
List<Teacher_report> Get_Teacher_report_By_TEACHER_REPORT_ID_List ( List<Int32?> TEACHER_REPORT_ID_LIST);
List<User> Get_User_By_USER_ID_List ( List<long?> USER_ID_LIST);
List<Answer> Get_Answer_By_ANSWER_ID_List_Adv ( List<Int32?> ANSWER_ID_LIST);
List<Answer_report> Get_Answer_report_By_ANSWER_REPORT_ID_List_Adv ( List<Int32?> ANSWER_REPORT_ID_LIST);
List<Appreciate> Get_Appreciate_By_APPRECIATE_ID_List_Adv ( List<Int32?> APPRECIATE_ID_LIST);
List<Article> Get_Article_By_ARTICLE_ID_List_Adv ( List<Int32?> ARTICLE_ID_LIST);
List<Category> Get_Category_By_CATEGORY_ID_List_Adv ( List<Int32?> CATEGORY_ID_LIST);
List<Evaluation> Get_Evaluation_By_EVALUATION_ID_List_Adv ( List<Int32?> EVALUATION_ID_LIST);
List<Favorite_category> Get_Favorite_category_By_FAVORITE_CATEGORY_ID_List_Adv ( List<Int32?> FAVORITE_CATEGORY_ID_LIST);
List<Favorite_teacher> Get_Favorite_teacher_By_FAVORITE_TEACHER_ID_List_Adv ( List<Int32?> FAVORITE_TEACHER_ID_LIST);
List<Mark_question> Get_Mark_question_By_MARK_QUESTION_ID_List_Adv ( List<Int32?> MARK_QUESTION_ID_LIST);
List<Notification> Get_Notification_By_NOTIFICATION_ID_List_Adv ( List<Int32?> NOTIFICATION_ID_LIST);
List<Question> Get_Question_By_QUESTION_ID_List_Adv ( List<Int32?> QUESTION_ID_LIST);
List<Question_report> Get_Question_report_By_QUESTION_REPORT_ID_List_Adv ( List<Int32?> QUESTION_REPORT_ID_LIST);
List<Question_token> Get_Question_token_By_QUESTION_TOKEN_ID_List_Adv ( List<long?> QUESTION_TOKEN_ID_LIST);
List<Report_article> Get_Report_article_By_REPORT_ARTICLE_ID_List_Adv ( List<Int32?> REPORT_ARTICLE_ID_LIST);
List<Student> Get_Student_By_STUDENT_ID_List_Adv ( List<Int32?> STUDENT_ID_LIST);
List<Student_report> Get_Student_report_By_STUDENT_REPORT_ID_List_Adv ( List<Int32?> STUDENT_REPORT_ID_LIST);
List<Teacher> Get_Teacher_By_TEACHER_ID_List_Adv ( List<Int32?> TEACHER_ID_LIST);
List<Teacher_category> Get_Teacher_category_By_TEACHER_CATEGORY_ID_List_Adv ( List<Int32?> TEACHER_CATEGORY_ID_LIST);
List<Teacher_favorite> Get_Teacher_favorite_By_TEACHER_FAVORITE_ID_List_Adv ( List<Int32?> TEACHER_FAVORITE_ID_LIST);
List<Teacher_rank> Get_Teacher_rank_By_TEACHER_RANK_ID_List_Adv ( List<Int32?> TEACHER_RANK_ID_LIST);
List<Teacher_report> Get_Teacher_report_By_TEACHER_REPORT_ID_List_Adv ( List<Int32?> TEACHER_REPORT_ID_LIST);
List<User> Get_User_By_USER_ID_List_Adv ( List<long?> USER_ID_LIST);
List<Answer> Get_Answer_By_OWNER_ID ( Int32? OWNER_ID);
List<Answer> Get_Answer_By_QUESTION_ID ( Int32? QUESTION_ID);
List<Answer> Get_Answer_By_TEACHER_ID ( Int32? TEACHER_ID);
List<Answer_report> Get_Answer_report_By_OWNER_ID ( Int32? OWNER_ID);
List<Answer_report> Get_Answer_report_By_TEACHER_ID ( Int32? TEACHER_ID);
List<Answer_report> Get_Answer_report_By_STUDENT_ID ( Int32? STUDENT_ID);
List<Answer_report> Get_Answer_report_By_ANSWER_ID ( Int32? ANSWER_ID);
List<Appreciate> Get_Appreciate_By_OWNER_ID ( Int32? OWNER_ID);
List<Appreciate> Get_Appreciate_By_ARTICLE_ID ( Int32? ARTICLE_ID);
List<Appreciate> Get_Appreciate_By_STUDENT_ID ( Int32? STUDENT_ID);
List<Article> Get_Article_By_OWNER_ID ( Int32? OWNER_ID);
List<Article> Get_Article_By_TEACHER_ID ( Int32? TEACHER_ID);
List<Article> Get_Article_By_CATEGORY_ID ( Int32? CATEGORY_ID);
List<Category> Get_Category_By_OWNER_ID ( Int32? OWNER_ID);
List<Evaluation> Get_Evaluation_By_OWNER_ID ( Int32? OWNER_ID);
List<Evaluation> Get_Evaluation_By_STUDENT_ID ( Int32? STUDENT_ID);
List<Evaluation> Get_Evaluation_By_ANSWER_ID ( Int32? ANSWER_ID);
List<Favorite_category> Get_Favorite_category_By_STUDENT_ID ( Int32? STUDENT_ID);
List<Favorite_category> Get_Favorite_category_By_CATEGORY_ID ( Int32? CATEGORY_ID);
List<Favorite_category> Get_Favorite_category_By_OWNER_ID ( Int32? OWNER_ID);
List<Favorite_teacher> Get_Favorite_teacher_By_TEACHER_ID ( Int32? TEACHER_ID);
List<Favorite_teacher> Get_Favorite_teacher_By_STUDENT_ID ( Int32? STUDENT_ID);
List<Favorite_teacher> Get_Favorite_teacher_By_OWNER_ID ( Int32? OWNER_ID);
List<Mark_question> Get_Mark_question_By_OWNER_ID ( Int32? OWNER_ID);
List<Mark_question> Get_Mark_question_By_QUESTION_ID ( Int32? QUESTION_ID);
List<Mark_question> Get_Mark_question_By_STUDENT_ID ( Int32? STUDENT_ID);
List<Notification> Get_Notification_By_OWNER_ID ( Int32? OWNER_ID);
List<Notification> Get_Notification_By_USER_ID ( Int32? USER_ID);
List<Notification> Get_Notification_By_QUESTION_ID ( Int32? QUESTION_ID);
List<Notification> Get_Notification_By_ANSWER_ID ( Int32? ANSWER_ID);
List<Question> Get_Question_By_OWNER_ID ( Int32? OWNER_ID);
List<Question> Get_Question_By_STUDENT_ID ( Int32? STUDENT_ID);
List<Question> Get_Question_By_CATEGORY_ID ( Int32? CATEGORY_ID);
List<Question> Get_Question_By_TEACHER_ID ( Int32? TEACHER_ID);
List<Question_report> Get_Question_report_By_OWNER_ID ( Int32? OWNER_ID);
List<Question_report> Get_Question_report_By_STUDENT_ID ( Int32? STUDENT_ID);
List<Question_report> Get_Question_report_By_TEACHER_ID ( Int32? TEACHER_ID);
List<Question_report> Get_Question_report_By_QUESTION_ID ( Int32? QUESTION_ID);
List<Question_token> Get_Question_token_By_PART ( string PART);
List<Question_token> Get_Question_token_By_OWNER_ID ( Int32? OWNER_ID);
List<Question_token> Get_Question_token_By_QUESTION_ID ( long? QUESTION_ID);
List<Report_article> Get_Report_article_By_OWNER_ID ( Int32? OWNER_ID);
List<Report_article> Get_Report_article_By_ARTICLE_ID ( Int32? ARTICLE_ID);
List<Report_article> Get_Report_article_By_STUDENT_ID ( Int32? STUDENT_ID);
List<Student> Get_Student_By_OWNER_ID ( Int32? OWNER_ID);
List<Student> Get_Student_By_USER_ID ( Int32? USER_ID);
List<Student_report> Get_Student_report_By_OWNER_ID ( Int32? OWNER_ID);
List<Student_report> Get_Student_report_By_REPORTED_BY_STUDENT_ID ( Int32? REPORTED_BY_STUDENT_ID);
List<Student_report> Get_Student_report_By_REPORTED_STUDENT_ID ( Int32? REPORTED_STUDENT_ID);
List<Teacher> Get_Teacher_By_OWNER_ID ( Int32? OWNER_ID);
List<Teacher> Get_Teacher_By_USER_ID ( Int32? USER_ID);
List<Teacher_category> Get_Teacher_category_By_OWNER_ID ( Int32? OWNER_ID);
List<Teacher_category> Get_Teacher_category_By_TEACHER_ID ( Int32? TEACHER_ID);
List<Teacher_category> Get_Teacher_category_By_CATEGORY_ID ( Int32? CATEGORY_ID);
List<Teacher_favorite> Get_Teacher_favorite_By_OWNER_ID ( Int32? OWNER_ID);
List<Teacher_favorite> Get_Teacher_favorite_By_TEACHER_ID ( Int32? TEACHER_ID);
List<Teacher_favorite> Get_Teacher_favorite_By_STUDENT_ID ( Int32? STUDENT_ID);
List<Teacher_rank> Get_Teacher_rank_By_TEACHER_ID ( Int32? TEACHER_ID);
List<Teacher_rank> Get_Teacher_rank_By_OWNER_ID ( Int32? OWNER_ID);
List<Teacher_report> Get_Teacher_report_By_OWNER_ID ( Int32? OWNER_ID);
List<Teacher_report> Get_Teacher_report_By_TEACHER_ID ( Int32? TEACHER_ID);
List<Teacher_report> Get_Teacher_report_By_STUDENT_ID ( Int32? STUDENT_ID);
List<User> Get_User_By_OWNER_ID ( Int32? OWNER_ID);
List<User> Get_User_By_USERNAME ( string USERNAME);
List<Answer> Get_Answer_By_OWNER_ID_Adv ( Int32? OWNER_ID);
List<Answer> Get_Answer_By_QUESTION_ID_Adv ( Int32? QUESTION_ID);
List<Answer> Get_Answer_By_TEACHER_ID_Adv ( Int32? TEACHER_ID);
List<Answer_report> Get_Answer_report_By_OWNER_ID_Adv ( Int32? OWNER_ID);
List<Answer_report> Get_Answer_report_By_TEACHER_ID_Adv ( Int32? TEACHER_ID);
List<Answer_report> Get_Answer_report_By_STUDENT_ID_Adv ( Int32? STUDENT_ID);
List<Answer_report> Get_Answer_report_By_ANSWER_ID_Adv ( Int32? ANSWER_ID);
List<Appreciate> Get_Appreciate_By_OWNER_ID_Adv ( Int32? OWNER_ID);
List<Appreciate> Get_Appreciate_By_ARTICLE_ID_Adv ( Int32? ARTICLE_ID);
List<Appreciate> Get_Appreciate_By_STUDENT_ID_Adv ( Int32? STUDENT_ID);
List<Article> Get_Article_By_OWNER_ID_Adv ( Int32? OWNER_ID);
List<Article> Get_Article_By_TEACHER_ID_Adv ( Int32? TEACHER_ID);
List<Article> Get_Article_By_CATEGORY_ID_Adv ( Int32? CATEGORY_ID);
List<Category> Get_Category_By_OWNER_ID_Adv ( Int32? OWNER_ID);
List<Evaluation> Get_Evaluation_By_OWNER_ID_Adv ( Int32? OWNER_ID);
List<Evaluation> Get_Evaluation_By_STUDENT_ID_Adv ( Int32? STUDENT_ID);
List<Evaluation> Get_Evaluation_By_ANSWER_ID_Adv ( Int32? ANSWER_ID);
List<Favorite_category> Get_Favorite_category_By_STUDENT_ID_Adv ( Int32? STUDENT_ID);
List<Favorite_category> Get_Favorite_category_By_CATEGORY_ID_Adv ( Int32? CATEGORY_ID);
List<Favorite_category> Get_Favorite_category_By_OWNER_ID_Adv ( Int32? OWNER_ID);
List<Favorite_teacher> Get_Favorite_teacher_By_TEACHER_ID_Adv ( Int32? TEACHER_ID);
List<Favorite_teacher> Get_Favorite_teacher_By_STUDENT_ID_Adv ( Int32? STUDENT_ID);
List<Favorite_teacher> Get_Favorite_teacher_By_OWNER_ID_Adv ( Int32? OWNER_ID);
List<Mark_question> Get_Mark_question_By_OWNER_ID_Adv ( Int32? OWNER_ID);
List<Mark_question> Get_Mark_question_By_QUESTION_ID_Adv ( Int32? QUESTION_ID);
List<Mark_question> Get_Mark_question_By_STUDENT_ID_Adv ( Int32? STUDENT_ID);
List<Notification> Get_Notification_By_OWNER_ID_Adv ( Int32? OWNER_ID);
List<Notification> Get_Notification_By_USER_ID_Adv ( Int32? USER_ID);
List<Notification> Get_Notification_By_QUESTION_ID_Adv ( Int32? QUESTION_ID);
List<Notification> Get_Notification_By_ANSWER_ID_Adv ( Int32? ANSWER_ID);
List<Question> Get_Question_By_OWNER_ID_Adv ( Int32? OWNER_ID);
List<Question> Get_Question_By_STUDENT_ID_Adv ( Int32? STUDENT_ID);
List<Question> Get_Question_By_CATEGORY_ID_Adv ( Int32? CATEGORY_ID);
List<Question> Get_Question_By_TEACHER_ID_Adv ( Int32? TEACHER_ID);
List<Question_report> Get_Question_report_By_OWNER_ID_Adv ( Int32? OWNER_ID);
List<Question_report> Get_Question_report_By_STUDENT_ID_Adv ( Int32? STUDENT_ID);
List<Question_report> Get_Question_report_By_TEACHER_ID_Adv ( Int32? TEACHER_ID);
List<Question_report> Get_Question_report_By_QUESTION_ID_Adv ( Int32? QUESTION_ID);
List<Question_token> Get_Question_token_By_PART_Adv ( string PART);
List<Question_token> Get_Question_token_By_OWNER_ID_Adv ( Int32? OWNER_ID);
List<Question_token> Get_Question_token_By_QUESTION_ID_Adv ( long? QUESTION_ID);
List<Report_article> Get_Report_article_By_OWNER_ID_Adv ( Int32? OWNER_ID);
List<Report_article> Get_Report_article_By_ARTICLE_ID_Adv ( Int32? ARTICLE_ID);
List<Report_article> Get_Report_article_By_STUDENT_ID_Adv ( Int32? STUDENT_ID);
List<Student> Get_Student_By_OWNER_ID_Adv ( Int32? OWNER_ID);
List<Student> Get_Student_By_USER_ID_Adv ( Int32? USER_ID);
List<Student_report> Get_Student_report_By_OWNER_ID_Adv ( Int32? OWNER_ID);
List<Student_report> Get_Student_report_By_REPORTED_BY_STUDENT_ID_Adv ( Int32? REPORTED_BY_STUDENT_ID);
List<Student_report> Get_Student_report_By_REPORTED_STUDENT_ID_Adv ( Int32? REPORTED_STUDENT_ID);
List<Teacher> Get_Teacher_By_OWNER_ID_Adv ( Int32? OWNER_ID);
List<Teacher> Get_Teacher_By_USER_ID_Adv ( Int32? USER_ID);
List<Teacher_category> Get_Teacher_category_By_OWNER_ID_Adv ( Int32? OWNER_ID);
List<Teacher_category> Get_Teacher_category_By_TEACHER_ID_Adv ( Int32? TEACHER_ID);
List<Teacher_category> Get_Teacher_category_By_CATEGORY_ID_Adv ( Int32? CATEGORY_ID);
List<Teacher_favorite> Get_Teacher_favorite_By_OWNER_ID_Adv ( Int32? OWNER_ID);
List<Teacher_favorite> Get_Teacher_favorite_By_TEACHER_ID_Adv ( Int32? TEACHER_ID);
List<Teacher_favorite> Get_Teacher_favorite_By_STUDENT_ID_Adv ( Int32? STUDENT_ID);
List<Teacher_rank> Get_Teacher_rank_By_TEACHER_ID_Adv ( Int32? TEACHER_ID);
List<Teacher_rank> Get_Teacher_rank_By_OWNER_ID_Adv ( Int32? OWNER_ID);
List<Teacher_report> Get_Teacher_report_By_OWNER_ID_Adv ( Int32? OWNER_ID);
List<Teacher_report> Get_Teacher_report_By_TEACHER_ID_Adv ( Int32? TEACHER_ID);
List<Teacher_report> Get_Teacher_report_By_STUDENT_ID_Adv ( Int32? STUDENT_ID);
List<User> Get_User_By_OWNER_ID_Adv ( Int32? OWNER_ID);
List<User> Get_User_By_USERNAME_Adv ( string USERNAME);
List<Answer> Get_Answer_By_QUESTION_ID_List ( List<Int32?> QUESTION_ID_LIST);
List<Answer> Get_Answer_By_TEACHER_ID_List ( List<Int32?> TEACHER_ID_LIST);
List<Answer_report> Get_Answer_report_By_TEACHER_ID_List ( List<Int32?> TEACHER_ID_LIST);
List<Answer_report> Get_Answer_report_By_STUDENT_ID_List ( List<Int32?> STUDENT_ID_LIST);
List<Answer_report> Get_Answer_report_By_ANSWER_ID_List ( List<Int32?> ANSWER_ID_LIST);
List<Appreciate> Get_Appreciate_By_ARTICLE_ID_List ( List<Int32?> ARTICLE_ID_LIST);
List<Appreciate> Get_Appreciate_By_STUDENT_ID_List ( List<Int32?> STUDENT_ID_LIST);
List<Article> Get_Article_By_TEACHER_ID_List ( List<Int32?> TEACHER_ID_LIST);
List<Article> Get_Article_By_CATEGORY_ID_List ( List<Int32?> CATEGORY_ID_LIST);
List<Evaluation> Get_Evaluation_By_STUDENT_ID_List ( List<Int32?> STUDENT_ID_LIST);
List<Evaluation> Get_Evaluation_By_ANSWER_ID_List ( List<Int32?> ANSWER_ID_LIST);
List<Favorite_category> Get_Favorite_category_By_STUDENT_ID_List ( List<Int32?> STUDENT_ID_LIST);
List<Favorite_category> Get_Favorite_category_By_CATEGORY_ID_List ( List<Int32?> CATEGORY_ID_LIST);
List<Favorite_teacher> Get_Favorite_teacher_By_TEACHER_ID_List ( List<Int32?> TEACHER_ID_LIST);
List<Favorite_teacher> Get_Favorite_teacher_By_STUDENT_ID_List ( List<Int32?> STUDENT_ID_LIST);
List<Mark_question> Get_Mark_question_By_QUESTION_ID_List ( List<Int32?> QUESTION_ID_LIST);
List<Mark_question> Get_Mark_question_By_STUDENT_ID_List ( List<Int32?> STUDENT_ID_LIST);
List<Notification> Get_Notification_By_USER_ID_List ( List<Int32?> USER_ID_LIST);
List<Notification> Get_Notification_By_QUESTION_ID_List ( List<Int32?> QUESTION_ID_LIST);
List<Notification> Get_Notification_By_ANSWER_ID_List ( List<Int32?> ANSWER_ID_LIST);
List<Question> Get_Question_By_STUDENT_ID_List ( List<Int32?> STUDENT_ID_LIST);
List<Question> Get_Question_By_CATEGORY_ID_List ( List<Int32?> CATEGORY_ID_LIST);
List<Question> Get_Question_By_TEACHER_ID_List ( List<Int32?> TEACHER_ID_LIST);
List<Question_report> Get_Question_report_By_STUDENT_ID_List ( List<Int32?> STUDENT_ID_LIST);
List<Question_report> Get_Question_report_By_TEACHER_ID_List ( List<Int32?> TEACHER_ID_LIST);
List<Question_report> Get_Question_report_By_QUESTION_ID_List ( List<Int32?> QUESTION_ID_LIST);
List<Question_token> Get_Question_token_By_QUESTION_ID_List ( List<long?> QUESTION_ID_LIST);
List<Report_article> Get_Report_article_By_ARTICLE_ID_List ( List<Int32?> ARTICLE_ID_LIST);
List<Report_article> Get_Report_article_By_STUDENT_ID_List ( List<Int32?> STUDENT_ID_LIST);
List<Student> Get_Student_By_USER_ID_List ( List<Int32?> USER_ID_LIST);
List<Student_report> Get_Student_report_By_REPORTED_BY_STUDENT_ID_List ( List<Int32?> REPORTED_BY_STUDENT_ID_LIST);
List<Student_report> Get_Student_report_By_REPORTED_STUDENT_ID_List ( List<Int32?> REPORTED_STUDENT_ID_LIST);
List<Teacher> Get_Teacher_By_USER_ID_List ( List<Int32?> USER_ID_LIST);
List<Teacher_category> Get_Teacher_category_By_TEACHER_ID_List ( List<Int32?> TEACHER_ID_LIST);
List<Teacher_category> Get_Teacher_category_By_CATEGORY_ID_List ( List<Int32?> CATEGORY_ID_LIST);
List<Teacher_favorite> Get_Teacher_favorite_By_TEACHER_ID_List ( List<Int32?> TEACHER_ID_LIST);
List<Teacher_favorite> Get_Teacher_favorite_By_STUDENT_ID_List ( List<Int32?> STUDENT_ID_LIST);
List<Teacher_rank> Get_Teacher_rank_By_TEACHER_ID_List ( List<Int32?> TEACHER_ID_LIST);
List<Teacher_report> Get_Teacher_report_By_TEACHER_ID_List ( List<Int32?> TEACHER_ID_LIST);
List<Teacher_report> Get_Teacher_report_By_STUDENT_ID_List ( List<Int32?> STUDENT_ID_LIST);
List<Answer> Get_Answer_By_QUESTION_ID_List_Adv ( List<Int32?> QUESTION_ID_LIST);
List<Answer> Get_Answer_By_TEACHER_ID_List_Adv ( List<Int32?> TEACHER_ID_LIST);
List<Answer_report> Get_Answer_report_By_TEACHER_ID_List_Adv ( List<Int32?> TEACHER_ID_LIST);
List<Answer_report> Get_Answer_report_By_STUDENT_ID_List_Adv ( List<Int32?> STUDENT_ID_LIST);
List<Answer_report> Get_Answer_report_By_ANSWER_ID_List_Adv ( List<Int32?> ANSWER_ID_LIST);
List<Appreciate> Get_Appreciate_By_ARTICLE_ID_List_Adv ( List<Int32?> ARTICLE_ID_LIST);
List<Appreciate> Get_Appreciate_By_STUDENT_ID_List_Adv ( List<Int32?> STUDENT_ID_LIST);
List<Article> Get_Article_By_TEACHER_ID_List_Adv ( List<Int32?> TEACHER_ID_LIST);
List<Article> Get_Article_By_CATEGORY_ID_List_Adv ( List<Int32?> CATEGORY_ID_LIST);
List<Evaluation> Get_Evaluation_By_STUDENT_ID_List_Adv ( List<Int32?> STUDENT_ID_LIST);
List<Evaluation> Get_Evaluation_By_ANSWER_ID_List_Adv ( List<Int32?> ANSWER_ID_LIST);
List<Favorite_category> Get_Favorite_category_By_STUDENT_ID_List_Adv ( List<Int32?> STUDENT_ID_LIST);
List<Favorite_category> Get_Favorite_category_By_CATEGORY_ID_List_Adv ( List<Int32?> CATEGORY_ID_LIST);
List<Favorite_teacher> Get_Favorite_teacher_By_TEACHER_ID_List_Adv ( List<Int32?> TEACHER_ID_LIST);
List<Favorite_teacher> Get_Favorite_teacher_By_STUDENT_ID_List_Adv ( List<Int32?> STUDENT_ID_LIST);
List<Mark_question> Get_Mark_question_By_QUESTION_ID_List_Adv ( List<Int32?> QUESTION_ID_LIST);
List<Mark_question> Get_Mark_question_By_STUDENT_ID_List_Adv ( List<Int32?> STUDENT_ID_LIST);
List<Notification> Get_Notification_By_USER_ID_List_Adv ( List<Int32?> USER_ID_LIST);
List<Notification> Get_Notification_By_QUESTION_ID_List_Adv ( List<Int32?> QUESTION_ID_LIST);
List<Notification> Get_Notification_By_ANSWER_ID_List_Adv ( List<Int32?> ANSWER_ID_LIST);
List<Question> Get_Question_By_STUDENT_ID_List_Adv ( List<Int32?> STUDENT_ID_LIST);
List<Question> Get_Question_By_CATEGORY_ID_List_Adv ( List<Int32?> CATEGORY_ID_LIST);
List<Question> Get_Question_By_TEACHER_ID_List_Adv ( List<Int32?> TEACHER_ID_LIST);
List<Question_report> Get_Question_report_By_STUDENT_ID_List_Adv ( List<Int32?> STUDENT_ID_LIST);
List<Question_report> Get_Question_report_By_TEACHER_ID_List_Adv ( List<Int32?> TEACHER_ID_LIST);
List<Question_report> Get_Question_report_By_QUESTION_ID_List_Adv ( List<Int32?> QUESTION_ID_LIST);
List<Question_token> Get_Question_token_By_QUESTION_ID_List_Adv ( List<long?> QUESTION_ID_LIST);
List<Report_article> Get_Report_article_By_ARTICLE_ID_List_Adv ( List<Int32?> ARTICLE_ID_LIST);
List<Report_article> Get_Report_article_By_STUDENT_ID_List_Adv ( List<Int32?> STUDENT_ID_LIST);
List<Student> Get_Student_By_USER_ID_List_Adv ( List<Int32?> USER_ID_LIST);
List<Student_report> Get_Student_report_By_REPORTED_BY_STUDENT_ID_List_Adv ( List<Int32?> REPORTED_BY_STUDENT_ID_LIST);
List<Student_report> Get_Student_report_By_REPORTED_STUDENT_ID_List_Adv ( List<Int32?> REPORTED_STUDENT_ID_LIST);
List<Teacher> Get_Teacher_By_USER_ID_List_Adv ( List<Int32?> USER_ID_LIST);
List<Teacher_category> Get_Teacher_category_By_TEACHER_ID_List_Adv ( List<Int32?> TEACHER_ID_LIST);
List<Teacher_category> Get_Teacher_category_By_CATEGORY_ID_List_Adv ( List<Int32?> CATEGORY_ID_LIST);
List<Teacher_favorite> Get_Teacher_favorite_By_TEACHER_ID_List_Adv ( List<Int32?> TEACHER_ID_LIST);
List<Teacher_favorite> Get_Teacher_favorite_By_STUDENT_ID_List_Adv ( List<Int32?> STUDENT_ID_LIST);
List<Teacher_rank> Get_Teacher_rank_By_TEACHER_ID_List_Adv ( List<Int32?> TEACHER_ID_LIST);
List<Teacher_report> Get_Teacher_report_By_TEACHER_ID_List_Adv ( List<Int32?> TEACHER_ID_LIST);
List<Teacher_report> Get_Teacher_report_By_STUDENT_ID_List_Adv ( List<Int32?> STUDENT_ID_LIST);
List<Answer> Get_Answer_By_Criteria ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Answer> Get_Answer_By_Where ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Answer_report> Get_Answer_report_By_Criteria ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Answer_report> Get_Answer_report_By_Where ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Article> Get_Article_By_Criteria ( string TITLE, string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Article> Get_Article_By_Where ( string TITLE, string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Category> Get_Category_By_Criteria ( string NAME, string DECRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Category> Get_Category_By_Where ( string NAME, string DECRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Evaluation> Get_Evaluation_By_Criteria ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Evaluation> Get_Evaluation_By_Where ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Favorite_category> Get_Favorite_category_By_Criteria ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Favorite_category> Get_Favorite_category_By_Where ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Favorite_teacher> Get_Favorite_teacher_By_Criteria ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Favorite_teacher> Get_Favorite_teacher_By_Where ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Mark_question> Get_Mark_question_By_Criteria ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Mark_question> Get_Mark_question_By_Where ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Notification> Get_Notification_By_Criteria ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Notification> Get_Notification_By_Where ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Owner> Get_Owner_By_Criteria ( string CODE, string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Owner> Get_Owner_By_Where ( string CODE, string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Owner> Get_Owner_By_Criteria_V2 ( string CODE, string MAINTENANCE_DUE_DATE, string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Owner> Get_Owner_By_Where_V2 ( string CODE, string MAINTENANCE_DUE_DATE, string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Question> Get_Question_By_Criteria ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Question> Get_Question_By_Where ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Question_report> Get_Question_report_By_Criteria ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Question_report> Get_Question_report_By_Where ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Question_token> Get_Question_token_By_Criteria ( string PART, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Question_token> Get_Question_token_By_Where ( string PART, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Report_article> Get_Report_article_By_Criteria ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Report_article> Get_Report_article_By_Where ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Student> Get_Student_By_Criteria ( string FIRST_NAME, string LAST_NAME, string EMAIL, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Student> Get_Student_By_Where ( string FIRST_NAME, string LAST_NAME, string EMAIL, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Student_report> Get_Student_report_By_Criteria ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Student_report> Get_Student_report_By_Where ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Teacher> Get_Teacher_By_Criteria ( string FIRST_NAME, string LAST_NAME, string DESCRIPTION, string EMAIL, string MOBILE, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Teacher> Get_Teacher_By_Where ( string FIRST_NAME, string LAST_NAME, string DESCRIPTION, string EMAIL, string MOBILE, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Teacher_category> Get_Teacher_category_By_Criteria ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Teacher_category> Get_Teacher_category_By_Where ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Teacher_favorite> Get_Teacher_favorite_By_Criteria ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Teacher_favorite> Get_Teacher_favorite_By_Where ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Teacher_rank> Get_Teacher_rank_By_Criteria ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Teacher_rank> Get_Teacher_rank_By_Where ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Teacher_report> Get_Teacher_report_By_Criteria ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Teacher_report> Get_Teacher_report_By_Where ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<User> Get_User_By_Criteria ( string USERNAME, string PASSWORD, string USER_TYPE_CODE, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<User> Get_User_By_Where ( string USERNAME, string PASSWORD, string USER_TYPE_CODE, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Answer> Get_Answer_By_Criteria_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Answer> Get_Answer_By_Where_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Answer_report> Get_Answer_report_By_Criteria_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Answer_report> Get_Answer_report_By_Where_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Article> Get_Article_By_Criteria_Adv ( string TITLE, string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Article> Get_Article_By_Where_Adv ( string TITLE, string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Category> Get_Category_By_Criteria_Adv ( string NAME, string DECRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Category> Get_Category_By_Where_Adv ( string NAME, string DECRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Evaluation> Get_Evaluation_By_Criteria_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Evaluation> Get_Evaluation_By_Where_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Favorite_category> Get_Favorite_category_By_Criteria_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Favorite_category> Get_Favorite_category_By_Where_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Favorite_teacher> Get_Favorite_teacher_By_Criteria_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Favorite_teacher> Get_Favorite_teacher_By_Where_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Mark_question> Get_Mark_question_By_Criteria_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Mark_question> Get_Mark_question_By_Where_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Notification> Get_Notification_By_Criteria_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Notification> Get_Notification_By_Where_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Question> Get_Question_By_Criteria_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Question> Get_Question_By_Where_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Question_report> Get_Question_report_By_Criteria_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Question_report> Get_Question_report_By_Where_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Question_token> Get_Question_token_By_Criteria_Adv ( string PART, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Question_token> Get_Question_token_By_Where_Adv ( string PART, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Report_article> Get_Report_article_By_Criteria_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Report_article> Get_Report_article_By_Where_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Student> Get_Student_By_Criteria_Adv ( string FIRST_NAME, string LAST_NAME, string EMAIL, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Student> Get_Student_By_Where_Adv ( string FIRST_NAME, string LAST_NAME, string EMAIL, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Student_report> Get_Student_report_By_Criteria_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Student_report> Get_Student_report_By_Where_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Teacher> Get_Teacher_By_Criteria_Adv ( string FIRST_NAME, string LAST_NAME, string DESCRIPTION, string EMAIL, string MOBILE, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Teacher> Get_Teacher_By_Where_Adv ( string FIRST_NAME, string LAST_NAME, string DESCRIPTION, string EMAIL, string MOBILE, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Teacher_category> Get_Teacher_category_By_Criteria_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Teacher_category> Get_Teacher_category_By_Where_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Teacher_favorite> Get_Teacher_favorite_By_Criteria_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Teacher_favorite> Get_Teacher_favorite_By_Where_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Teacher_rank> Get_Teacher_rank_By_Criteria_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Teacher_rank> Get_Teacher_rank_By_Where_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Teacher_report> Get_Teacher_report_By_Criteria_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Teacher_report> Get_Teacher_report_By_Where_Adv ( string DESCRIPTION, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<User> Get_User_By_Criteria_Adv ( string USERNAME, string PASSWORD, string USER_TYPE_CODE, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<User> Get_User_By_Where_Adv ( string USERNAME, string PASSWORD, string USER_TYPE_CODE, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Answer> Get_Answer_By_Criteria_InList ( string DESCRIPTION, List<Int32?> QUESTION_ID_LIST, List<Int32?> TEACHER_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Answer> Get_Answer_By_Where_InList ( string DESCRIPTION, List<Int32?> QUESTION_ID_LIST, List<Int32?> TEACHER_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Answer_report> Get_Answer_report_By_Criteria_InList ( string DESCRIPTION, List<Int32?> TEACHER_ID_LIST, List<Int32?> STUDENT_ID_LIST, List<Int32?> ANSWER_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Answer_report> Get_Answer_report_By_Where_InList ( string DESCRIPTION, List<Int32?> TEACHER_ID_LIST, List<Int32?> STUDENT_ID_LIST, List<Int32?> ANSWER_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Article> Get_Article_By_Criteria_InList ( string TITLE, string DESCRIPTION, List<Int32?> TEACHER_ID_LIST, List<Int32?> CATEGORY_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Article> Get_Article_By_Where_InList ( string TITLE, string DESCRIPTION, List<Int32?> TEACHER_ID_LIST, List<Int32?> CATEGORY_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Evaluation> Get_Evaluation_By_Criteria_InList ( string DESCRIPTION, List<Int32?> STUDENT_ID_LIST, List<Int32?> ANSWER_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Evaluation> Get_Evaluation_By_Where_InList ( string DESCRIPTION, List<Int32?> STUDENT_ID_LIST, List<Int32?> ANSWER_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Favorite_category> Get_Favorite_category_By_Criteria_InList ( string DESCRIPTION, List<Int32?> STUDENT_ID_LIST, List<Int32?> CATEGORY_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Favorite_category> Get_Favorite_category_By_Where_InList ( string DESCRIPTION, List<Int32?> STUDENT_ID_LIST, List<Int32?> CATEGORY_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Favorite_teacher> Get_Favorite_teacher_By_Criteria_InList ( string DESCRIPTION, List<Int32?> TEACHER_ID_LIST, List<Int32?> STUDENT_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Favorite_teacher> Get_Favorite_teacher_By_Where_InList ( string DESCRIPTION, List<Int32?> TEACHER_ID_LIST, List<Int32?> STUDENT_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Mark_question> Get_Mark_question_By_Criteria_InList ( string DESCRIPTION, List<Int32?> QUESTION_ID_LIST, List<Int32?> STUDENT_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Mark_question> Get_Mark_question_By_Where_InList ( string DESCRIPTION, List<Int32?> QUESTION_ID_LIST, List<Int32?> STUDENT_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Notification> Get_Notification_By_Criteria_InList ( string DESCRIPTION, List<Int32?> QUESTION_ID_LIST, List<Int32?> ANSWER_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Notification> Get_Notification_By_Where_InList ( string DESCRIPTION, List<Int32?> QUESTION_ID_LIST, List<Int32?> ANSWER_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Question> Get_Question_By_Criteria_InList ( string DESCRIPTION, List<Int32?> STUDENT_ID_LIST, List<Int32?> CATEGORY_ID_LIST, List<Int32?> TEACHER_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Question> Get_Question_By_Where_InList ( string DESCRIPTION, List<Int32?> STUDENT_ID_LIST, List<Int32?> CATEGORY_ID_LIST, List<Int32?> TEACHER_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Question_report> Get_Question_report_By_Criteria_InList ( string DESCRIPTION, List<Int32?> STUDENT_ID_LIST, List<Int32?> TEACHER_ID_LIST, List<Int32?> QUESTION_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Question_report> Get_Question_report_By_Where_InList ( string DESCRIPTION, List<Int32?> STUDENT_ID_LIST, List<Int32?> TEACHER_ID_LIST, List<Int32?> QUESTION_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Report_article> Get_Report_article_By_Criteria_InList ( string DESCRIPTION, List<Int32?> ARTICLE_ID_LIST, List<Int32?> STUDENT_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Report_article> Get_Report_article_By_Where_InList ( string DESCRIPTION, List<Int32?> ARTICLE_ID_LIST, List<Int32?> STUDENT_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Teacher_category> Get_Teacher_category_By_Criteria_InList ( string DESCRIPTION, List<Int32?> TEACHER_ID_LIST, List<Int32?> CATEGORY_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Teacher_category> Get_Teacher_category_By_Where_InList ( string DESCRIPTION, List<Int32?> TEACHER_ID_LIST, List<Int32?> CATEGORY_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Teacher_favorite> Get_Teacher_favorite_By_Criteria_InList ( string DESCRIPTION, List<Int32?> TEACHER_ID_LIST, List<Int32?> STUDENT_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Teacher_favorite> Get_Teacher_favorite_By_Where_InList ( string DESCRIPTION, List<Int32?> TEACHER_ID_LIST, List<Int32?> STUDENT_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Teacher_rank> Get_Teacher_rank_By_Criteria_InList ( string DESCRIPTION, List<Int32?> TEACHER_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Teacher_rank> Get_Teacher_rank_By_Where_InList ( string DESCRIPTION, List<Int32?> TEACHER_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Teacher_report> Get_Teacher_report_By_Criteria_InList ( string DESCRIPTION, List<Int32?> TEACHER_ID_LIST, List<Int32?> STUDENT_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Teacher_report> Get_Teacher_report_By_Where_InList ( string DESCRIPTION, List<Int32?> TEACHER_ID_LIST, List<Int32?> STUDENT_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Answer> Get_Answer_By_Criteria_InList_Adv ( string DESCRIPTION, List<Int32?> QUESTION_ID_LIST, List<Int32?> TEACHER_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Answer> Get_Answer_By_Where_InList_Adv ( string DESCRIPTION, List<Int32?> QUESTION_ID_LIST, List<Int32?> TEACHER_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Answer_report> Get_Answer_report_By_Criteria_InList_Adv ( string DESCRIPTION, List<Int32?> TEACHER_ID_LIST, List<Int32?> STUDENT_ID_LIST, List<Int32?> ANSWER_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Answer_report> Get_Answer_report_By_Where_InList_Adv ( string DESCRIPTION, List<Int32?> TEACHER_ID_LIST, List<Int32?> STUDENT_ID_LIST, List<Int32?> ANSWER_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Article> Get_Article_By_Criteria_InList_Adv ( string TITLE, string DESCRIPTION, List<Int32?> TEACHER_ID_LIST, List<Int32?> CATEGORY_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Article> Get_Article_By_Where_InList_Adv ( string TITLE, string DESCRIPTION, List<Int32?> TEACHER_ID_LIST, List<Int32?> CATEGORY_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Evaluation> Get_Evaluation_By_Criteria_InList_Adv ( string DESCRIPTION, List<Int32?> STUDENT_ID_LIST, List<Int32?> ANSWER_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Evaluation> Get_Evaluation_By_Where_InList_Adv ( string DESCRIPTION, List<Int32?> STUDENT_ID_LIST, List<Int32?> ANSWER_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Favorite_category> Get_Favorite_category_By_Criteria_InList_Adv ( string DESCRIPTION, List<Int32?> STUDENT_ID_LIST, List<Int32?> CATEGORY_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Favorite_category> Get_Favorite_category_By_Where_InList_Adv ( string DESCRIPTION, List<Int32?> STUDENT_ID_LIST, List<Int32?> CATEGORY_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Favorite_teacher> Get_Favorite_teacher_By_Criteria_InList_Adv ( string DESCRIPTION, List<Int32?> TEACHER_ID_LIST, List<Int32?> STUDENT_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Favorite_teacher> Get_Favorite_teacher_By_Where_InList_Adv ( string DESCRIPTION, List<Int32?> TEACHER_ID_LIST, List<Int32?> STUDENT_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Mark_question> Get_Mark_question_By_Criteria_InList_Adv ( string DESCRIPTION, List<Int32?> QUESTION_ID_LIST, List<Int32?> STUDENT_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Mark_question> Get_Mark_question_By_Where_InList_Adv ( string DESCRIPTION, List<Int32?> QUESTION_ID_LIST, List<Int32?> STUDENT_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Notification> Get_Notification_By_Criteria_InList_Adv ( string DESCRIPTION, List<Int32?> QUESTION_ID_LIST, List<Int32?> ANSWER_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Notification> Get_Notification_By_Where_InList_Adv ( string DESCRIPTION, List<Int32?> QUESTION_ID_LIST, List<Int32?> ANSWER_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Question> Get_Question_By_Criteria_InList_Adv ( string DESCRIPTION, List<Int32?> STUDENT_ID_LIST, List<Int32?> CATEGORY_ID_LIST, List<Int32?> TEACHER_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Question> Get_Question_By_Where_InList_Adv ( string DESCRIPTION, List<Int32?> STUDENT_ID_LIST, List<Int32?> CATEGORY_ID_LIST, List<Int32?> TEACHER_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Question_report> Get_Question_report_By_Criteria_InList_Adv ( string DESCRIPTION, List<Int32?> STUDENT_ID_LIST, List<Int32?> TEACHER_ID_LIST, List<Int32?> QUESTION_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Question_report> Get_Question_report_By_Where_InList_Adv ( string DESCRIPTION, List<Int32?> STUDENT_ID_LIST, List<Int32?> TEACHER_ID_LIST, List<Int32?> QUESTION_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Report_article> Get_Report_article_By_Criteria_InList_Adv ( string DESCRIPTION, List<Int32?> ARTICLE_ID_LIST, List<Int32?> STUDENT_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Report_article> Get_Report_article_By_Where_InList_Adv ( string DESCRIPTION, List<Int32?> ARTICLE_ID_LIST, List<Int32?> STUDENT_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Teacher_category> Get_Teacher_category_By_Criteria_InList_Adv ( string DESCRIPTION, List<Int32?> TEACHER_ID_LIST, List<Int32?> CATEGORY_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Teacher_category> Get_Teacher_category_By_Where_InList_Adv ( string DESCRIPTION, List<Int32?> TEACHER_ID_LIST, List<Int32?> CATEGORY_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Teacher_favorite> Get_Teacher_favorite_By_Criteria_InList_Adv ( string DESCRIPTION, List<Int32?> TEACHER_ID_LIST, List<Int32?> STUDENT_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Teacher_favorite> Get_Teacher_favorite_By_Where_InList_Adv ( string DESCRIPTION, List<Int32?> TEACHER_ID_LIST, List<Int32?> STUDENT_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Teacher_rank> Get_Teacher_rank_By_Criteria_InList_Adv ( string DESCRIPTION, List<Int32?> TEACHER_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Teacher_rank> Get_Teacher_rank_By_Where_InList_Adv ( string DESCRIPTION, List<Int32?> TEACHER_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Teacher_report> Get_Teacher_report_By_Criteria_InList_Adv ( string DESCRIPTION, List<Int32?> TEACHER_ID_LIST, List<Int32?> STUDENT_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
List<Teacher_report> Get_Teacher_report_By_Where_InList_Adv ( string DESCRIPTION, List<Int32?> TEACHER_ID_LIST, List<Int32?> STUDENT_ID_LIST, Int32? OWNER_ID, Int64? START_ROW, Int64? END_ROW,ref  Int64? TOTAL_COUNT);
void Delete_Answer ( Int32? ANSWER_ID);
void Delete_Answer_report ( Int32? ANSWER_REPORT_ID);
void Delete_Appreciate ( Int32? APPRECIATE_ID);
void Delete_Article ( Int32? ARTICLE_ID);
void Delete_Category ( Int32? CATEGORY_ID);
void Delete_Evaluation ( Int32? EVALUATION_ID);
void Delete_Favorite_category ( Int32? FAVORITE_CATEGORY_ID);
void Delete_Favorite_teacher ( Int32? FAVORITE_TEACHER_ID);
void Delete_Mark_question ( Int32? MARK_QUESTION_ID);
void Delete_Notification ( Int32? NOTIFICATION_ID);
void Delete_Owner ( Int32? OWNER_ID);
void Delete_Question ( Int32? QUESTION_ID);
void Delete_Question_report ( Int32? QUESTION_REPORT_ID);
void Delete_Question_token ( long? QUESTION_TOKEN_ID);
void Delete_Report_article ( Int32? REPORT_ARTICLE_ID);
void Delete_Student ( Int32? STUDENT_ID);
void Delete_Student_report ( Int32? STUDENT_REPORT_ID);
void Delete_Teacher ( Int32? TEACHER_ID);
void Delete_Teacher_category ( Int32? TEACHER_CATEGORY_ID);
void Delete_Teacher_favorite ( Int32? TEACHER_FAVORITE_ID);
void Delete_Teacher_rank ( Int32? TEACHER_RANK_ID);
void Delete_Teacher_report ( Int32? TEACHER_REPORT_ID);
void Delete_User ( long? USER_ID);
void Delete_Answer_By_OWNER_ID ( Int32? OWNER_ID);
void Delete_Answer_By_QUESTION_ID ( Int32? QUESTION_ID);
void Delete_Answer_By_TEACHER_ID ( Int32? TEACHER_ID);
void Delete_Answer_report_By_OWNER_ID ( Int32? OWNER_ID);
void Delete_Answer_report_By_TEACHER_ID ( Int32? TEACHER_ID);
void Delete_Answer_report_By_STUDENT_ID ( Int32? STUDENT_ID);
void Delete_Answer_report_By_ANSWER_ID ( Int32? ANSWER_ID);
void Delete_Appreciate_By_OWNER_ID ( Int32? OWNER_ID);
void Delete_Appreciate_By_ARTICLE_ID ( Int32? ARTICLE_ID);
void Delete_Appreciate_By_STUDENT_ID ( Int32? STUDENT_ID);
void Delete_Article_By_OWNER_ID ( Int32? OWNER_ID);
void Delete_Article_By_TEACHER_ID ( Int32? TEACHER_ID);
void Delete_Article_By_CATEGORY_ID ( Int32? CATEGORY_ID);
void Delete_Category_By_OWNER_ID ( Int32? OWNER_ID);
void Delete_Evaluation_By_OWNER_ID ( Int32? OWNER_ID);
void Delete_Evaluation_By_STUDENT_ID ( Int32? STUDENT_ID);
void Delete_Evaluation_By_ANSWER_ID ( Int32? ANSWER_ID);
void Delete_Favorite_category_By_STUDENT_ID ( Int32? STUDENT_ID);
void Delete_Favorite_category_By_CATEGORY_ID ( Int32? CATEGORY_ID);
void Delete_Favorite_category_By_OWNER_ID ( Int32? OWNER_ID);
void Delete_Favorite_teacher_By_TEACHER_ID ( Int32? TEACHER_ID);
void Delete_Favorite_teacher_By_STUDENT_ID ( Int32? STUDENT_ID);
void Delete_Favorite_teacher_By_OWNER_ID ( Int32? OWNER_ID);
void Delete_Mark_question_By_OWNER_ID ( Int32? OWNER_ID);
void Delete_Mark_question_By_QUESTION_ID ( Int32? QUESTION_ID);
void Delete_Mark_question_By_STUDENT_ID ( Int32? STUDENT_ID);
void Delete_Notification_By_OWNER_ID ( Int32? OWNER_ID);
void Delete_Notification_By_USER_ID ( Int32? USER_ID);
void Delete_Notification_By_QUESTION_ID ( Int32? QUESTION_ID);
void Delete_Notification_By_ANSWER_ID ( Int32? ANSWER_ID);
void Delete_Question_By_OWNER_ID ( Int32? OWNER_ID);
void Delete_Question_By_STUDENT_ID ( Int32? STUDENT_ID);
void Delete_Question_By_CATEGORY_ID ( Int32? CATEGORY_ID);
void Delete_Question_By_TEACHER_ID ( Int32? TEACHER_ID);
void Delete_Question_report_By_OWNER_ID ( Int32? OWNER_ID);
void Delete_Question_report_By_STUDENT_ID ( Int32? STUDENT_ID);
void Delete_Question_report_By_TEACHER_ID ( Int32? TEACHER_ID);
void Delete_Question_report_By_QUESTION_ID ( Int32? QUESTION_ID);
void Delete_Question_token_By_PART ( string PART);
void Delete_Question_token_By_OWNER_ID ( Int32? OWNER_ID);
void Delete_Question_token_By_QUESTION_ID ( long? QUESTION_ID);
void Delete_Report_article_By_OWNER_ID ( Int32? OWNER_ID);
void Delete_Report_article_By_ARTICLE_ID ( Int32? ARTICLE_ID);
void Delete_Report_article_By_STUDENT_ID ( Int32? STUDENT_ID);
void Delete_Student_By_OWNER_ID ( Int32? OWNER_ID);
void Delete_Student_By_USER_ID ( Int32? USER_ID);
void Delete_Student_report_By_OWNER_ID ( Int32? OWNER_ID);
void Delete_Student_report_By_REPORTED_BY_STUDENT_ID ( Int32? REPORTED_BY_STUDENT_ID);
void Delete_Student_report_By_REPORTED_STUDENT_ID ( Int32? REPORTED_STUDENT_ID);
void Delete_Teacher_By_OWNER_ID ( Int32? OWNER_ID);
void Delete_Teacher_By_USER_ID ( Int32? USER_ID);
void Delete_Teacher_category_By_OWNER_ID ( Int32? OWNER_ID);
void Delete_Teacher_category_By_TEACHER_ID ( Int32? TEACHER_ID);
void Delete_Teacher_category_By_CATEGORY_ID ( Int32? CATEGORY_ID);
void Delete_Teacher_favorite_By_OWNER_ID ( Int32? OWNER_ID);
void Delete_Teacher_favorite_By_TEACHER_ID ( Int32? TEACHER_ID);
void Delete_Teacher_favorite_By_STUDENT_ID ( Int32? STUDENT_ID);
void Delete_Teacher_rank_By_TEACHER_ID ( Int32? TEACHER_ID);
void Delete_Teacher_rank_By_OWNER_ID ( Int32? OWNER_ID);
void Delete_Teacher_report_By_OWNER_ID ( Int32? OWNER_ID);
void Delete_Teacher_report_By_TEACHER_ID ( Int32? TEACHER_ID);
void Delete_Teacher_report_By_STUDENT_ID ( Int32? STUDENT_ID);
void Delete_User_By_OWNER_ID ( Int32? OWNER_ID);
void Delete_User_By_USERNAME ( string USERNAME);
Int32? Edit_Answer ( Int32? ANSWER_ID, Int32? QUESTION_ID, Int32? TEACHER_ID, string DESCRIPTION, decimal? SCORE, Int32? REVIEWS, Int32? REPORTS, bool? IS_ACTIVE, long? ENTRY_USER_ID, string ENTRY_DATE, Int32? OWNER_ID);
Int32? Edit_Answer_report ( Int32? ANSWER_REPORT_ID, Int32? TEACHER_ID, Int32? STUDENT_ID, Int32? ANSWER_ID, string DESCRIPTION, long? ENTRY_USER_ID, string ENTRY_DATE, Int32? OWNER_ID);
Int32? Edit_Appreciate ( Int32? APPRECIATE_ID, Int32? ARTICLE_ID, Int32? STUDENT_ID, string DESCRIPTION, long? ENTRY_USER_ID, string ENTRY_DATE, Int32? OWNER_ID);
Int32? Edit_Article ( Int32? ARTICLE_ID, Int32? TEACHER_ID, Int32? CATEGORY_ID, string TITLE, string DESCRIPTION, Int32? APPLAUDS, Int32? REPORTS, bool? IS_BLOCKED, long? ENTRY_USER_ID, string ENTRY_DATE, Int32? OWNER_ID);
Int32? Edit_Category ( Int32? CATEGORY_ID, string NAME, string DECRIPTION, long? ENTRY_USER_ID, string ENTRY_DATE, Int32? OWNER_ID);
Int32? Edit_Evaluation ( Int32? EVALUATION_ID, Int32? STUDENT_ID, Int32? ANSWER_ID, decimal SCORE, long? ENTRY_USER_ID, string ENTRY_DATE, Int32? OWNER_ID, string DESCRIPTION);
Int32? Edit_Favorite_category ( Int32? FAVORITE_CATEGORY_ID, Int32? STUDENT_ID, Int32? CATEGORY_ID, string DESCRIPTION, long? ENTRY_USER_ID, Int32? OWNER_ID, string ENTRY_DATE);
Int32? Edit_Favorite_teacher ( Int32? FAVORITE_TEACHER_ID, Int32? TEACHER_ID, Int32? STUDENT_ID, string DESCRIPTION, long? ENTRY_USER_ID, Int32? OWNER_ID, string ENTRY_DATE);
Int32? Edit_Mark_question ( Int32? MARK_QUESTION_ID, Int32? QUESTION_ID, Int32? STUDENT_ID, long? ENTRY_USER_ID, string ENTRY_DATE, Int32? OWNER_ID, string DESCRIPTION);
Int32? Edit_Notification ( Int32? NOTIFICATION_ID, Int32? USER_ID, string DESCRIPTION, Int32? QUESTION_ID, Int32? ANSWER_ID, long? ENTRY_USER_ID, string ENTRY_DATE, Int32? OWNER_ID);
Int32? Edit_Owner ( Int32? OWNER_ID, string CODE, string MAINTENANCE_DUE_DATE, string DESCRIPTION, string ENTRY_DATE);
Int32? Edit_Question ( Int32? QUESTION_ID, Int32? STUDENT_ID, Int32? CATEGORY_ID, Int32? TEACHER_ID, string DESCRIPTION, bool? IS_ANSWERED, bool? IS_ACTIVE, Int32? REPORTS, long? ENTRY_USER_ID, string ENTRY_DATE, Int32? OWNER_ID);
Int32? Edit_Question_report ( Int32? QUESTION_REPORT_ID, Int32? STUDENT_ID, Int32? TEACHER_ID, Int32? QUESTION_ID, string DESCRIPTION, long? ENTRY_USER_ID, string ENTRY_DATE, Int32? OWNER_ID);
long? Edit_Question_token ( long? QUESTION_TOKEN_ID, long? QUESTION_ID, string PART, long? ENTRY_USER_ID, string ENTRY_DATE, Int32? OWNER_ID);
Int32? Edit_Report_article ( Int32? REPORT_ARTICLE_ID, Int32? ARTICLE_ID, Int32? STUDENT_ID, string DESCRIPTION, long? ENTRY_USER_ID, string ENTRY_DATE, Int32? OWNER_ID);
Int32? Edit_Student ( Int32? STUDENT_ID, Int32? USER_ID, string FIRST_NAME, string LAST_NAME, string EMAIL, bool? IS_BLOCKED, Int32? PENDING_QUESTIONS, long? ENTRY_USER_ID, string ENTRY_DATE, Int32? OWNER_ID);
Int32? Edit_Student_report ( Int32? STUDENT_REPORT_ID, Int32? REPORTED_BY_STUDENT_ID, Int32? REPORTED_STUDENT_ID, string DESCRIPTION, long? ENTRY_USER_ID, string ENTRY_DATE, Int32? OWNER_ID);
Int32? Edit_Teacher ( Int32? TEACHER_ID, Int32? USER_ID, string FIRST_NAME, string LAST_NAME, decimal SCORE, string DESCRIPTION, bool? IS_BLOCKED, string EMAIL, string MOBILE, long? ENTRY_USER_ID, string ENTRY_DATE, Int32? OWNER_ID);
Int32? Edit_Teacher_category ( Int32? TEACHER_CATEGORY_ID, Int32? TEACHER_ID, Int32? CATEGORY_ID, string DESCRIPTION, long? ENTRY_USER_ID, string ENTRY_DATE, Int32? OWNER_ID);
Int32? Edit_Teacher_favorite ( Int32? TEACHER_FAVORITE_ID, Int32? TEACHER_ID, Int32? STUDENT_ID, string DESCRIPTION, long? ENTRY_USER_ID, string ENTRY_DATE, Int32? OWNER_ID);
Int32? Edit_Teacher_rank ( Int32? TEACHER_RANK_ID, Int32? TEACHER_ID, Int32? SCORE, Int32? OVERALL_RANKING, long? ENTRY_USER_ID, Int32? OWNER_ID, string ENTRY_DATE, string DESCRIPTION);
Int32? Edit_Teacher_report ( Int32? TEACHER_REPORT_ID, Int32? TEACHER_ID, Int32? STUDENT_ID, string DESCRIPTION, long? ENTRY_USER_ID, string ENTRY_DATE, Int32? OWNER_ID);
long? Edit_User ( long? USER_ID, Int32? OWNER_ID, string USERNAME, string PASSWORD, string USER_TYPE_CODE, bool? IS_LOGGED_IN, bool? IS_ACTIVE, string ENTRY_DATE);
List<dynamic> GET_DISTINCT_SETUP_TBL ( Int32? OWNER_ID);
List<dynamic> GET_NEXT_VALUE ( string STARTER_CODE);
List<dynamic> GET_TBL_SETUP ();
List<dynamic> UP_CHECK_USER_EXISTENCE ( Int32? OWNER_ID, string USERNAME,ref  bool? EXISTS);
List<dynamic> UP_EDIT_SETUP ( Int32? OWNER_ID, string TBL_NAME, string CODE_NAME, bool? ISSYSTEM, bool? ISDELETEABLE, bool? ISUPDATEABLE, bool? ISVISIBLE, bool? ISDELETED, Int32? DISPLAY_ORDER, string CODE_VALUE_EN, string CODE_VALUE_FR, string CODE_VALUE_AR, string ENTRY_DATE, Int32? ENTRY_USER_ID, string NOTES);
List<dynamic> UP_EXTRACT_ROUTINE_PARAMETERS ( string ROUTINE_NAME);
List<dynamic> UP_EXTRACT_ROUTINE_RESULT_SCHEMA ( string ROUTINE_NAME);
List<dynamic> UP_GENERATE_INSERT_STATEMENTS ( string @tableName);
List<dynamic> UP_GET_NEXT_VALUE ( string STARTER_CODE,ref  Int32? VALUE);
List<dynamic> UP_GET_QUESTION_NOT_ANSWERED ( Int32? @__OWNER);
List<dynamic> UP_GET_SETUP_ENTRIES ( Int32? OWNER_ID, string TBL_NAME, bool? ISDELETED, bool? ISVISIBLE);
List<dynamic> UP_GET_SETUP_ENTRY ( Int32? OWNER_ID, string TBL_NAME, string CODE_NAME);
List<dynamic> UP_GET_USER_BY_CREDENTIALS ( Int32? OWNER_ID, string USERNAME, string PASSWORD);
List<dynamic> UP_GET_USER_BY_USERNAME ( string USERNAME);
}
}
